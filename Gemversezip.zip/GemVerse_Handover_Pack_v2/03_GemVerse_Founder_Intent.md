# Founder Intent

GemVerse should feel like a world worth preserving.

Success:
- Meaningful contribution
- Wonder
- Belonging
- Legacy

Never sacrifice:
- Hope
- Community
- Civilization focus
for engagement metrics or monetization.
