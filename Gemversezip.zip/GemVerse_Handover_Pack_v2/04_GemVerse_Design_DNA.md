# Design DNA

Target emotions:
Wonder, Curiosity, Comfort, Hope, Discovery, Connection.

Avoid:
FOMO, grind, anxiety, manipulation, exclusion.

Design test:
Does this strengthen wonder?
Does this strengthen belonging?
Does this strengthen contribution?
