# GemVerse Project Intelligence v2

GemVerse is a Premium Cozy Fantasy Civilization Adventure.

Core truth:
- Civilization is the protagonist.
- The Guardian is a contributor.
- The Shattering has no villain.
- Belonging is the hidden Eighth Pillar.

Primary themes:
Wonder, Belonging, Contribution, Memory, Discovery, Community, Harmony, Legacy, Hope.

Product identity:
Not a combat RPG.
Not a gacha.
Not a power fantasy.
A living civilization that players help restore and preserve.
