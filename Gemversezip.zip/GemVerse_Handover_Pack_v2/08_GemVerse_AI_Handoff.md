# AI Handoff Instructions

Before creating new canon:
1. Preserve existing philosophy.
2. Check if topic is complete, partial, unfinished, or mystery.
3. Do not convert mysteries into answers accidentally.
4. Favor hope over cynicism.
5. Favor contribution over heroism.
6. Favor civilization over individuals.

Final rule:
GemVerse is a living civilization, not merely a game.
