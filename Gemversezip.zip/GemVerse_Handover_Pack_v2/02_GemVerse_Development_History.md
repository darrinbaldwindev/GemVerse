# Development History

Evolution:
1. Puzzle-first concept.
2. Realm-based world.
3. House philosophy system.
4. Path identity system.
5. Archive-centered civilization.
6. Companion witnesses.
7. Belonging discovered as hidden pillar.
8. Civilization becomes protagonist.
9. Legacy becomes endgame.

Critical preserved decisions:
- No chosen one.
- No dark lord.
- No pay-to-win.
