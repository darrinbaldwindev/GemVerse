# Narrative DNA

Rules:
- Civilization matters more than heroes.
- Communities matter.
- History matters.
- Companions have agency.
- No ultimate evil.
- No endless escalation.

Truth emerges collectively through Realms, Houses and Paths.
