# Canon Status

Complete:
- Eight Pillars
- Seven Houses
- Six Paths
- Archive philosophy
- Companion philosophy

Partial:
- First Harmony
- Restoration Era
- Crystal Network
- Lantern Network
- Realm cultures

Unfinished:
- Five Wounds
- Harmony Council
- Companion Encyclopedia
- Citizen Encyclopedia

Intentional mysteries:
- Missing Realm
- Memory Ocean
- Lost Harmonists
- Seven Beacons
