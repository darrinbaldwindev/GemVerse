# GemVerse Founder Intent

GemVerse should feel like a civilization worth preserving, not merely a game worth playing.
