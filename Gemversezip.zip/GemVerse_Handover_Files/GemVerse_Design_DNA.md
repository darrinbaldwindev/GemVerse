# GemVerse Design DNA

Core emotions: Wonder, Curiosity, Comfort, Hope, Discovery, Connection.
