# GemVerse Development History

Major decisions:
- The Shattering has no villain.
- Belonging became the hidden Eighth Pillar.
- Civilization is the protagonist.
- The Guardian is a contributor, not a savior.
