# Open Development Ledger

Complete, Partial, Unfinished, and Intentional Mystery tracking.
