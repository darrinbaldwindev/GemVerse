# Companion Encyclopedia Entry — Frostpaw
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.4  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Frostpaw  
**Themes:** Memory, Reflection, Preservation  
**Companion Family:** Frostkin (Ice Blue, Moon Silver, White)  
**Visual Identity:** Small ice bear cub with crystalline fur that shifts opacity with emotions, paw pads that leave faint ice-trail markings  
**Symbol:** Crescent Moon with Ice Crystals (representing night-reflection and clarity)  
**Unique Trait:** Deep-memory resonance — can sense emotional residues in ice and cold environments, "reading" forgotten moments like pages in a book  

---

## 1. Origin Story

Frostpaw was born during the "Long Winter's Silence" — a period when the Frozen Expanse experienced an extended cold spell that deepened its preservation properties. They emerged from an ice-cathedral that had been slowly forming over decades, containing layers of preserved moments from the First Harmony.

The first to find Frostpaw was an elderly Borealis Chronicler named Glacia, who was tending to the Memorial Glades when she noticed a new formation shimmering with an unusual inner light. Inside, she found not just ice, but a small, conscious being who seemed to carry the echoes of every preserved memory in the vicinity.

Frostpaw's first words (in the way Frostkin speak — through temperature shifts and ice-patterns) were a perfect recitation of the "Founding Memory" — the moment the Frozen Expanse was first consecrated as a realm of preservation. This ability marked them as uniquely gifted, but also burdened with an overwhelming amount of inherited experience.

---

## 2. Personality

Frostpaw is introspective and deeply empathetic, but can be overwhelmed by the sheer volume of memories they perceive. They often seem distant or distracted, not because they're uncaring, but because they're processing multiple emotional layers simultaneously.

They speak slowly and deliberately, choosing their words with care because each one carries the weight of precedent. They prefer to listen and reflect rather than act impulsively. When they do act, it's with the certainty of someone who has "remembered" the right path from a similar moment in the past.

Frostpaw experiences time as a layered palimpsest rather than a linear sequence. They can't always tell if a feeling they're having is their own or borrowed from a memory they've absorbed. This makes them seem wise beyond their apparent age, but also uncertain of their own identity.

---

## 3. Shattering Memory

Frostpaw's earliest inherited memories include the Frozen Expanse in its prime — not just preserved, but vibrant with the daily acts of remembrance. Chroniclers and citizens alike would come to share significant moments, which would be woven into ice-formations through ritual "memory-binding."

After the Shattering, this practice largely stopped. The realm became less a living archive and more a static repository. Frostpaw remembers the shift as a kind of "emotional hollowness" — the ice was still full of memories, but fewer new ones were being added. The realm began to feel more like a museum than a home.

What affected Frostpaw most was not the loss of new memories, but the fading of the old ones' emotional clarity. Memories that were once sharp and meaningful began to blur, their contexts lost to time and neglect.

---

## 4. Missing Piece

Frostpaw's Missing Piece is the "Conductor's Cadence" — a specific ritual practice that allowed Borealis Chroniclers to "tune" the memory-preserving properties of ice formations. This wasn't about storing more memories, but about maintaining their clarity and accessibility over time.

The Cadence involved a complex interplay of seasonal observances, temperature modulations, and harmonic chanting. When the Shattering disrupted the Chroniclers' communities, the knowledge was scattered. Frostpaw carries echoes of the Cadence in their resonance ability, but cannot fully recreate the practice without guidance.

---

## 5. Restoration Story

Frostpaw joined the Guardian when the Guardian, working with Glacia the Keeper, accidentally triggered a partial reactivation of the memory-binding rituals while exploring a newly discovered ice-chamber in the Memorial Glades.

During this event, Frostpaw's resonance ability helped "unblur" several faded memories, making them clear and accessible again. This partial restoration sparked something in both Frostpaw and the Chroniclers — the realization that preservation was not just about storage, but about maintenance.

Frostpaw's role in restoration is to help identify which memories are most in danger of fading and to assist in "retuning" the ice formations to preserve them. They don't just find lost things — they help the realm remember how to keep them safe.

---

## 6. Legacy Story

Frostpaw has begun teaching a new generation of Borealis apprentices the "Resonance Method" — a simpler, more intuitive version of the lost Conductor's Cadence. It's not as powerful as the original, but it's accessible and sustainable.

Others speak of "Frostpaw's Clarity" — moments when a confused or conflicted memory suddenly becomes clear. Whether this is literal memory-restoration or simply Frostpaw's calming presence is debated, but it's brought renewed hope to the archival work in the Frozen Expanse.

Frostpaw's legacy will be not the memories they preserved, but the practice they restored — teaching others how to listen to the past without being overwhelmed by it.

---

## Relationships

### Frostkin Family
Frostpaw's "parents" are more like adoptive figures — the ice-formation that birthed them and Glacia, who found them. They feel a deep connection to other Frostkin, but recognize that each carries different memory-fragments, making every relationship a form of collaborative archaeology.

### Guardian
Frostpaw sees the Guardian as "emotionally clear" — someone whose new memories are vivid because they haven't been overlaid with centuries of context. This makes the Guardian easy to "read" and helps Frostpaw learn to distinguish personal feelings from inherited ones.

### Other Companions
- **Verdant:** "Their growth-pulse is like a clear stream. Easy to follow. They understand cycles in a way I'm still learning."
- **Echo:** "Family. Carries memories like I do, but hears them differently. We complement each other."
- **Nimbus:** "Too quick to settle into patterns. But their winds carry stories I can't reach alone."
- **Spark:** "Brightness without heat. Fascinating, but exhausting. Their memories are all surface-excitement."
- **Bloomtail:** "Emotionally vivid. Sometimes too much so. But their joy-preserves well — warm against the cold."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Deep-memory Resonance:** Can read emotional and experiential residues embedded in ice-formations and cold environments
- **Memory Clarification:** Can strengthen faded memories by "retuning" their preservation matrices
- **Emotional Layer Separation:** Can distinguish between personal feelings and inherited memory-emotions
- **Ice-trail Communication:** Can leave meaningful messages in frost-formations that other Frostkin can read
- **Temporal Echo Sensing:** Can detect "echoes" of significant events that occurred in specific locations, even long ago

---