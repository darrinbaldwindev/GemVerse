---
title: IMP #3 — Citizen Life Layer
tier: IMP
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: First Harmony (Tier 1), Five Wounds (Tier 1), Restoration Era (Tier 1)
feeds-into: Tier 2 Realm Cultures, Tier 3 Citizen Encyclopedia, IMP #6 Archive Contribution Grammar
---

# IMP #3 — Citizen Life Layer

**Purpose:** This packet establishes the lived-experience framework for citizens of the Restoration Era — who they are as people, how they move through daily life, and how they relate to the Paths, the Houses, the Guardians, the Archive, their Companions, and each other. It is the foundational layer that must exist before the Tier 3 Citizen Encyclopedia can be written.

This is not a new canon entry. It is the scaffolding within which individual citizens live.

---

## 1. What Is a Citizen of the Restoration Era?

A citizen of the Restoration Era is someone who was born into a world that had already lost something — but does not experience that loss primarily as grief. They experience it as the shape of reality. They know that things were different before. They have grown up with the stories. But they do not walk through their days haunted; they walk through them doing what people do: working, caring for others, wondering, building, and occasionally pausing to feel, without quite naming it, that something important is still missing.

Citizens of the Restoration Era carry the Shattering in the way that people carry inherited loss — not as a wound they received personally, but as an absence that has always been present in the background of their lives. They grew up with grandparents who remembered more. They learned their crafts from teachers whose teachers had learned from a wider civilization. They have heard about the Crystal Network not as a living system but as a partly-dormant one, something their elders describe with a particular quality of voice — equal parts longing and matter-of-fact acceptance.

What citizens know depends greatly on where they live. A citizen of the Arena Realm has likely met people from other Realms, contributed to the Archive at least once, and seen a Companion in the Companion Grove. A citizen of a more isolated community may have heard of the Archive but never visited it, may know their local traditions without knowing that those traditions once connected to a wider civilizational fabric, and may have never seen a Guardian at all.

What citizens remember is fragments. Family stories. Local traditions whose origins are hazy. Festivals that were once cross-Realm gatherings, now celebrated within a single community that has forgotten — or quietly stopped expecting — anyone else would come.

What citizens hope for is not uniform. The Elder who remembers the warmth of a more connected world hopes for return. The young person who has only known the Restoration Era hopes for something they cannot quite name — the sense that the world is larger than it has seemed. Both of these are the same hope, expressed at different distances from the memory.

What citizens carry from the Shattering is, in every case, a question: *Does my contribution matter?* In the First Harmony, that question answered itself — the systems of civilization were built to receive contribution, honor it, preserve it, and return it. In the Restoration Era, those systems are partially working. Citizens who have found their way to contributing feel the question settle into quiet confidence. Citizens who have not — who live in communities where contribution has no obvious pathway outward — feel it as a low, persistent ache they may not be able to identify.

This is why Guardians matter. Not because citizens need saving. But because a Guardian's presence, work, and genuine engagement restores one of the conditions that allows citizens to answer that question for themselves.

---

## 2. The Six Paths — Citizen Perspective

The Six Paths are not a class system. They are not assigned by authority or awarded by achievement. They are recognized ways of contributing — ways that civilization discovered, over centuries, tended to produce the most meaningful restoration work. A citizen on a Path has found the shape of their contribution and been welcomed into a tradition of practice that connects them to others doing the same work across time and Realm.

Paths were informal during the First Harmony — ways of being recognized, not formal roles. They were formalized during and after the Shattering partly because formal recognition of contribution became more necessary when contribution was harder to sustain. When the systems that made contribution visible and valued started failing, the Paths became a way of saying: *what you do still matters. Here is the community that will hold you while you do it.*

---

### The Scholar
**House:** Lumina (Knowledge)
**Wound most naturally addressed:** Wound of Knowledge — The Fragmentation

**Day to Day**

Scholars spend their working hours in the movement of knowledge — recovering it, organizing it, translating it from the form it arrived in to the form it can be used in, and ensuring that what is understood in one place eventually reaches the places that need it. A Scholar in the Restoration Era might spend a morning cross-referencing Archive fragments to determine whether two incomplete records are describing the same discovery from different angles. An afternoon might be given to teaching — not formally, but to a neighbor who has a question and needs someone who has thought carefully about how to answer it. Evening might involve an entry in the Archive contribution records, or a long correspondence with a Scholar in another Realm, the reply taking weeks.

What distinguishes Scholars from people who simply like to learn is that Scholars feel the incompleteness of knowledge as a personal responsibility. A gap in the record is not an interesting puzzle to them — it is a small grief, and addressing it is what makes the grief bearable.

**What They Value**

Accuracy. Honesty about what is known versus what is assumed. The discipline of sitting with uncertainty without manufacturing false resolution. The belief that knowledge belongs to everyone who needs it — the First Harmony principle that the Fragmentation violated, and that Scholars work, daily, to restore.

**Relation to Restoration**

Scholars are the primary contributors to Archive restoration. They restore Crystal Network nodes not only as an act of infrastructure repair but as an act of meaning — because a restored node is a place where knowledge can flow again. They are most valuable not when they hoard expertise but when they release it: when they turn what they know into a record that outlasts them.

**Character Portrait**

*A woman in her fifties who has spent thirty years cataloguing the Archive's missing-references list — the entries that point to documents no one can find. She has located eleven of them. She knows the list has hundreds more. She is not discouraged. She believes the records exist somewhere, that the Shattering scattered rather than destroyed them, and that her work is simply a matter of patience and method. She keeps a lantern burning on her desk at all times. She says it is for the light. Those who know her well believe it is to remind herself that something is still guiding.*

---

### The Pathfinder
**House:** Astra (Discovery)
**Wound most naturally addressed:** Wound of Discovery — The Isolation

**Day to Day**

Pathfinders move. Their days look less like other citizens' days because a significant portion of them takes place in transit, in unfamiliar locations, or in the early hours of mapping somewhere that no Restoration Era record has described. When they are not moving, they are preparing to move — studying existing maps for what is missing, listening to travelers for reports of routes, contributing recent discoveries to the Archive while conditions allow, and maintaining the relationships that make long journeys sustainable.

A Pathfinder alone is doing personal exploration. A Pathfinder in the Restoration Era context is rebuilding the infrastructure of return — the waypoints, the knowledge of routes, the relationships between communities — that makes exploration meaningful rather than merely solitary.

**What They Value**

The joy of finding. The obligation to share what is found. The belief that a discovery only becomes fully real when it has been contributed to the civilization that can use it. Pathfinders are not collectors; they are connectors. The thing found matters less than what happens to it next.

**Relation to Restoration**

Pathfinders are the primary healers of the Wound of Discovery. When a Pathfinder maps a route between two communities that had lost contact, restores a waypoint, or brings a record from one Realm to complete something waiting in the Archive of another — that is the Isolation being addressed. Pathfinders also carry something less tangible but equally important: the news that there is a wider world, that other communities exist, that the world is larger than any one place suggests.

**Character Portrait**

*A young man who has been walking the same broken route between two Realms for three years — not because he cannot find another path, but because he believes this particular route was once a major connection and wants to prove it. He has rebuilt four waypoint markers. He is working on the fifth. He does not think of himself as brave. He thinks of himself as persistent. He carries a record book that he has filled twice over. The Archive has both earlier volumes.*

---

### The Keeper
**Houses:** Borealis (Memory) and Hearthlight (Community) — the only Path that bridges two Houses
**Wound most naturally addressed:** Wound of Memory — The Forgetting; secondary contribution to the Wound of Belonging — The Division

**Day to Day**

Keepers maintain. They are the people who understand that civilization is not only built but tended — that the things which make a community worth belonging to require daily attention to remain alive. A Keeper might spend their days maintaining a Lantern route, preserving oral traditions through regular retelling, organizing the community's local archive records, facilitating the practices that allow different households to remain in relationship with each other, or serving as the person who knows the stories and is responsible for ensuring the next generation knows them too.

In communities where the Wound of Belonging runs deep, Keepers are often the only reason the community still has anything that feels like shared identity. They have not given up on the traditions even when others have stopped attending. They hold the shape of what community was, so it can be recognized when conditions allow it to return.

**What They Value**

Continuity. Relationship. The understanding that what is not actively maintained does not simply pause — it fades. Keepers are the people who notice when something is fading and treat that noticing as a call to action rather than a melancholy observation.

**Relation to Restoration**

Keepers work across both Memory and Community because these two Pillars, more than any others, require the same quality of sustained, patient attention. Recovering a lost record and maintaining a living tradition are not the same task, but they spring from the same commitment: the refusal to let the Forgetting and the Division win by default. A Keeper who maintains a Lantern route that no traveler has used in a decade is not being stubborn. They are holding a place open for connection that has not yet arrived.

**Character Portrait**

*An older man who runs the only Lantern station in a remote community — a station that has not received a traveler in eleven years. He lights the lantern every evening anyway. He maintains the record book of every traveler who has passed through, going back three generations. He has added twelve names since he took the post. He believes, not from sentiment but from a quiet certainty he cannot entirely explain, that the route will become active again. He has written his community's full history from oral sources, a project that took seven years. He sent a copy to the Arena Archive last spring. He has not yet received confirmation it arrived.*

---

### The Cultivator
**House:** Verdance (Growth)
**Wound most naturally addressed:** Wound of Growth — The Decay

**Day to Day**

Cultivators work with what is growing — but growth, in the Restoration Era, means something broader than the natural world. A Cultivator might tend the land and its people simultaneously: running a community garden that is also a gathering place, mentoring a young person alongside the practical skills they need, helping a tradition find renewed meaning by connecting it to its origin. Many Cultivators work in the intersection of the natural and the social — they understand that communities, like living things, require conditions, not commands.

The Cultivator's day often looks like many small acts of attention: noticing who has withdrawn from community life and finding a gentle way to draw them back in, identifying a skill that a young person shows aptitude for and connecting them to someone who can develop it, planting something with the knowledge that they will not be the one to harvest it.

**What They Value**

Patience. The long arc. The understanding that growth cannot be forced, only supported. Cultivators resist the temptation to treat communities as projects to be completed; they understand communities as ongoing practices to be sustained.

**Relation to Restoration**

Cultivators address the Wound of Growth most directly by reconnecting individual and community development to civilization's development — expanding the frame of reference beyond what is local and immediate. When a Cultivator helps a young person understand that their skills connect to something larger, or helps a tradition find new life through contact with its civilizational context, or supports the conditions that allow communities to flourish in ways that contribute outward rather than only inward — the Decay is being addressed.

**Character Portrait**

*A middle-aged woman who runs the community's learning circle — not a formal school, but a weekly gathering where anyone who has something to teach and anyone who wants to learn can find each other. She started it twelve years ago with six people. It now serves forty. She has connected three young people from her community to scholars in the Arena Realm for extended study. Two of them came back. One did not, and she is proud of that too. She says her work is simply making sure no one has to waste themselves.*

---

### The Artisan
**Houses:** Legacy (Preservation) and Borealis (Memory) — the Path that translates memory into physical form
**Wound most naturally addressed:** Wound of Memory — The Forgetting; secondary contribution to the Wound of Belonging — The Division

**Day to Day**

Artisans make things — but what distinguishes an Artisan in the Restoration Era context is that what they make is always in conversation with what has been made before. An Artisan does not simply produce objects or stories or music; they produce objects and stories and music that carry the memory of their making — that contain, in their form, the tradition they emerged from, the community they belong to, and the intention that guided the hands that made them.

An Artisan's day might involve working on a piece of craft while teaching the technique to a younger person. It might involve recovering a fragment of a traditional song — a melody preserved in someone's memory but never written down — and notating it for the Archive. It might involve building an object specifically intended to outlast its maker, to become evidence that a particular community, with particular values, existed.

**What They Value**

The marriage of skill and meaning. Making things that will last and that, by lasting, carry something worth carrying. Artisans are among the most Archive-connected of all Path practitioners — they understand that their work is only as permanent as the memory system that holds it.

**Relation to Restoration**

Artisans restore Memory through making — they create the physical and cultural evidence that the Wound of Forgetting needs to be countered. They also, quietly, address Belonging: an Artisan who creates something that a community can recognize as their own gives that community something to gather around. A recovered song, a crafted archive piece, a building with an archive alcove built into its wall — these are not grand gestures. They are the small accumulations that make communities feel like communities rather than groups of people sharing a location.

**Character Portrait**

*A young woman who makes Archive vessels — small, sealed containers designed to preserve documents indefinitely. She learned the technique from her grandmother, who learned it from hers. The technique itself is one of the few pre-Shattering craft traditions to survive fully intact in her community. She is slowly teaching it to others, having realized that a skill only one person holds is one illness away from being lost. She is also writing down everything she knows about the tradition's history, because she has noticed that craft traditions die not when the skill is lost but when the meaning behind the skill is forgotten first.*

---

### The Harmonist
**House:** Solstice (Harmony) — but Belonging, the Harmonist's deepest concern, has no House
**Wound most naturally addressed:** Wound of Belonging — The Division; contribution to all other Wounds through integration

**Day to Day**

Harmonists are the hardest Path to describe precisely because their work is the most relational and the least tangible. A Harmonist's day is largely made of conversations — not casual conversations, but the kind that move something in the people having them. A Harmonist facilitates. They listen. They find the connective tissue between people who do not realize they are working toward the same thing. They notice when a community is drifting toward fragmentation and create the conditions for reconnection — not by commanding it but by making connection available.

A Harmonist might spend their morning mediating a disagreement between two community members whose conflict has been preventing a shared project from moving forward. Their afternoon might be given to helping prepare a festival that has not been held in years. Evening might involve a long conversation with someone who has been feeling disconnected from their community and doesn't know how to say so — the Harmonist often being the person such conversations find.

**What They Value**

Balance. The understanding that no single Pillar — not even Belonging itself — is the answer to everything. Harmonists hold the view that all seven Pillars must be in relationship, and that their work is to keep that relationship visible and tended. They also hold what the Six Paths' most quietly difficult truth: that Belonging cannot be commanded, created, or measured. It can only be made possible.

**Relation to Restoration**

Harmonists address the Wound of Belonging most directly, but they contribute to all five Wounds through a different vector — by maintaining the conditions under which healing of all kinds becomes possible. A community where people feel connected and purposeful is a community where Scholars share knowledge freely, where Pathfinders are welcomed back, where Keepers are supported, where Cultivators find their mentorship received, where Artisans are valued for what they preserve. Belonging is the condition that makes all other restoration sustainable. Harmonists are its tenders.

**Character Portrait**

*A soft-spoken person in their late thirties who is somehow always present when things go wrong in the community — and somehow always seems to know what to say, or more often, what question to ask. They have no formal role. They have organized three festivals in the last decade, each of which reconnected relationships the community hadn't realized had gone quiet. They have been asked, many times, who they are in an official sense — which Path, which House affiliation, what their title is. They say they are a neighbor. They say it without any apparent false modesty. They mean it.*

---

## 3. The Relationship Between Citizens and Guardians

Citizens of the Restoration Era do not, as a general rule, regard Guardians as saviors. The concept of a savior — someone who arrives with powers that ordinary people do not possess and resolves problems that ordinary people could not address — is not part of the Restoration Era's cultural vocabulary. The Shattering did not produce a tradition of waiting to be rescued. It produced communities that learned to take care of themselves, imperfectly, with what they had.

What Guardians are, in the experience of citizens who have encountered them, is something more interesting: they are contributors who come from outside. They are not local, which means they see what locals have stopped seeing. They bring knowledge and perspective from the Archive and from other Realms, which means they can connect things that had been separated. They have the mobility that many citizens lack — not because citizens are incapable of travel, but because most citizens are embedded in communities that need them there. A Guardian can go where a community's tethered members cannot.

Citizens who have encountered Guardians often describe the experience using the language of recognition rather than rescue. Not: *they saved us.* But: *they saw something we had forgotten to look at.* Or: *they made it possible to do something we had wanted to do but couldn't do alone.* The distinction is not semantic. It is the difference between dependence and collaboration.

**What citizens need from Guardians that they cannot provide themselves** is, most often, not a specific skill but a specific quality of attention. Guardians, because they are not embedded in one community's daily survival, can attend to a community's larger context — to what the Archive says about its history, to what a Companion's memory preserves about it, to what connections have gone dormant that might be revived. They can hold the civilizational view that citizens, understandably absorbed in local life, have difficulty maintaining.

Guardian contribution shows up in citizen life in ways that often seem small at the time. A Guardian who contributes a recovered document to the Archive might not see the community that eventually receives the knowledge that document contained. A Guardian who restores a waypoint on a Lantern route might not be present when the first traveler walks it months later. This is not incidental to the Restoration Era's spirit — it is the spirit. Contribution is not about credit. It is about what the contribution makes possible.

**What it feels like to a citizen when a Wound begins to heal nearby** is not dramatic. It is the gradual return of something they had stopped expecting. A route becomes passable and a merchant from another community arrives, and over the course of a single evening's conversation a citizen realizes they have been living as if the world stopped at their Realm's border — and it does not. A fragment of their community's history appears in the Archive and is read back to them, and they feel, without being able to articulate it precisely, that their ancestors mattered to someone beyond the people who already knew their names. A festival resumes that had not been held in twenty years, and citizens who were not sure they wanted to attend find themselves reluctant to leave.

None of this feels like a dramatic reversal. It feels like something returning that should never have left.

---

## 4. Citizens and the Archive

The Great Archive is, for citizens of the Restoration Era, the closest thing the civilization has to a shared self. The Archive says: *this happened. This person lived. This community existed. This discovery was made.* In a world where so much has been fragmented and forgotten, the Archive's persistence is itself a form of resistance.

A citizen's relationship to the Archive depends enormously on how accessible the Archive is to them. Citizens in the Arena Realm or in communities with active Archive connections may interact with the Archive regularly — contributing records, consulting its contents, attending events connected to it. Citizens in more isolated communities may know the Archive largely through its symbolic meaning: as the place where what matters is kept, even if they have never visited it.

**Can any citizen contribute?** Yes. This is one of the Archive's most important commitments — and one that the Restoration Era is actively working to restore, because the Shattering damaged not only the Archive's holdings but the culture of contribution that once fed it. The Archive does not require a title or a formal affiliation to receive a contribution. A citizen who brings a family story, a community record, a recovered fragment of a pre-Shattering document, or a Companion's oral testimony — all of these are received with equal seriousness.

The Archive Contribution Grammar (to be detailed in IMP #6) establishes the forms and protocols through which any citizen can contribute. For now, the foundational principle is: **contribution is a civic act, not a specialist activity.** This was true during the First Harmony. Restoring it to truth is one of the Restoration Era's most important projects.

**What it means to a citizen to see their name in the Archive** — or their family's name, or their community's story — is something the Archive's curators have learned to hold with great care. For citizens whose communities have been largely unrecorded since the Shattering, the first time they see their community's name in an official Archive record is not merely satisfying. It is the experience of being recognized by civilization itself. Of being told: *you exist. You have always existed. What happened here was real and worth remembering.*

For communities where belonging has been thin, this experience is — not incidentally — one of the most reliable ways the Wound of Belonging begins to heal. Not through grand restoration of systems, but through the simple, enormous act of being witnessed.

---

## 5. Citizens and Companions

During the First Harmony, Companions moved freely through all communities, were present at festivals, participated in the Archive, and were understood as partners in civilization-building. In the Restoration Era, this is less consistently true. In the Arena Realm and well-connected communities, Companions are a regular presence — citizens know what they are, feel comfortable around them, and understand, at least instinctively, that a Companion's relationship to memory and history is different from a person's. In isolated communities, Companions may be rare visitors or — in some cases — known only through story.

Citizens who encounter Companions for the first time — particularly those from isolated communities — often report an experience that is difficult to describe but consistently similar: the feeling of being in the presence of something that remembers more than they can imagine, and that is choosing to share that remembering with them. Companions do not display their memories ostentatiously. They do not arrive with proclamations. But a Companion's attention is distinctive. Citizens often describe feeling, without knowing why, that a Companion has been somewhere, seen something, and carries the weight of it with an equanimity that is neither detachment nor performance.

In communities where Companions have become more integrated — a result of Restoration Era Guardian work — citizens often describe Companions as members of the community in a way that resists easy categorization. Not pets. Not officials. Not symbols. *Members.* Present in the daily life of the community, contributing their particular kind of witness to whatever is happening, remembered and welcomed when they return from travel.

**PROPOSAL A:** The question of whether Companions bond to communities or to individuals in the Restoration Era is left open for Tier 2 Realm development and the Companion-specific entries. What can be established here is that either arrangement is known to occur — and that the distinction matters to the communities involved.

---

## 6. Citizens and Belonging

Belonging, the hidden Eighth Pillar, is not something citizens of the Restoration Era name or think about abstractly. It is something they feel, or don't feel, in the texture of their days.

**When Belonging is thin**, life functions but does not resonate. Citizens go about their work, maintain their households, participate in whatever community practices still exist — but with a quality that people in such communities sometimes describe, when they try to describe it at all, as doing things because they are the things you do rather than because they mean something. Contribution happens without the feeling that it goes anywhere. The future is present, but there is no particular emotional investment in it. Festivals, when they occur, are attended but not felt. Something is working, but no one is sure it matters.

Thin Belonging does not look like despair from the outside. It can look entirely normal. It feels, from the inside, like a dimming that has been so gradual that the person inside it no longer remembers what full light was.

**When Belonging grows**, it is also gradual — which is part of why it can be so difficult to recognize. A festival that a community held out of habit for twenty years is the same festival, held by the same people, in the same square. But this year, travelers from another community have come. And the people who came last year came back. And a piece of the community's history that the Archive recovered was read aloud before the evening meal. And the young person who had been thinking of leaving found, without any single thing making the difference, that she wanted to stay.

None of this happened because Belonging was targeted. It happened because enough of the other conditions were restored — knowledge shared, routes opened, memory recovered, community sustained — that Belonging had room to return.

**A Guardian's presence affects a community's sense of Belonging** without the Guardian being the cause or the hero in a specific, observable way: the Guardian contributes to the conditions. They bring knowledge. They restore connections. They sit with citizens and listen to stories, which is an act of witnessing — of saying, through attention, *what you know matters.* They contribute to the Archive on the community's behalf. They participate in the festival rather than observing it.

The community does not feel that a Guardian gave them Belonging. They feel that something returned. Guardians, if they are paying attention, know the difference — and the good ones take care not to obscure it.

---

## 7. Citizen Archetypes

These are not named individuals. They are recognizable types — the kinds of people a Guardian might encounter across the Restoration Era. They feed into the Tier 3 Citizen Encyclopedia.

---

### The Elder Who Remembers Fragments

She is not ancient, exactly — perhaps seventy. But she is the oldest person in her community, which means she is the one who was a child when the Shattering happened, and the one whose memories of the time before are secondhand but vivid. Her parents spoke of the First Harmony as something that had just been: not a mythological age, but a recent loss.

She carries these fragments with the same quiet care that the Book of Harmony describes memory requiring. She knows they are incomplete. She knows her parents' accounts were already filtered through grief and distance. She does not pretend to more than she has.

What she has is irreplaceable. The Archive knows this. Guardians who sit with her find that she gives freely — she has been waiting for someone to ask, and to ask in a way that suggests the answer will be taken seriously. She has watched communities survive by forgetting the past. She has made the opposite choice, and it has cost her something, and she would make it again.

Her relationship to Guardians is warm but not uncritical. She is assessing, always, whether this one understands that they are serving something larger than their own contribution record.

---

### The Young Person Who Has Never Known Restoration

He is perhaps twenty. He has grown up in the Restoration Era as a simple fact — this is what the world is. The Shattering is history. Guardians are real but abstract, something he has heard of rather than encountered. The Archive is something his teachers mentioned.

He is not cynical. He is not hopeless. He has simply not yet had the experience of understanding that the world is larger than it has seemed. He has a skill — something he is genuinely good at, that he enjoys, that his community values — but he does not know that the skill connects to a Path, to a House, to a tradition of practice that extends across Realms and back through the First Harmony.

When a Guardian arrives and that context is revealed to him, the experience is not overwhelming. It is clarifying. He did not know he was waiting for it, but he was. The question of whether his contribution matters — a question he had not consciously asked but had been feeling as a kind of low-grade restlessness — answers itself. Not completely. Not permanently. But enough to change his orientation toward his work and his future.

He is one of the most important people any Guardian will encounter. He is the Restoration Era's primary renewable resource.

---

### The Keeper Who Guards a Dying Lantern Route

She took the post from her aunt, who took it from her father, who took it from someone whose name is in the record book but whose face no one living remembers. The route has not carried a traveler in eleven years. She lights the lantern every night.

She is not performing hope. She is not particularly sentimental about it. She has simply looked at the evidence — the routes that have come back to life in other parts of the Restoration Era, the Guardians who have been reopening connections, the Archive's growing record of restored waypoints — and concluded that there is no reason to assume this route is an exception. She will keep the light burning until she has a reason not to.

When a Guardian arrives — whether they come looking for this route specifically or stumble upon it — she does not treat it as vindication. She treats it as the next step in a process that has been underway for as long as she can remember. She is ready. The record book is current. The route's history is documented. She has been waiting, but not waiting passively. She has been maintaining.

---

### The Scholar Who Believes the Archive Holds the Answer

He is in his mid-forties, and the question he is trying to answer has occupied him for fifteen years. He believes — with the quality of conviction that is also a kind of faith, though he would resist that word — that somewhere in the Archive's holdings, or in the Crystal Network nodes that have not yet been restored, the information that would allow his community to solve its central problem exists.

The problem is real. His belief that the answer exists is based on genuine evidence — fragments that point toward a more complete record, cross-references that suggest relevant documents once existed. He is not chasing a fantasy.

What he sometimes loses sight of is that the answer, when it comes, will require other people to implement it — Pathfinders to travel, Keepers to maintain, Cultivators to grow, Artisans to preserve. He is not wrong about the Archive's importance. He sometimes underestimates how much the Archive needs the other Paths to matter in practice.

A Guardian who helps him find what he is looking for — and then helps him see what comes next — gives him something the Archive alone cannot provide.

---

### The Cultivator Whose Community Is Isolated

She has built something remarkable inside a very small frame. Her community is a day's travel from the nearest other settlement, and that settlement is not reliably welcoming. She has created, inside that constraint, a place where things grow: food, skills, relationships, children who know more than she did at their age.

She is not bitter about the isolation. She is practical about it. The routes being closed is a problem to be solved, not a state to be lamented. She knows what her community needs. She knows what it is missing. She has a list — not a written list, but an internal one, maintained through years of observation — of the specific things that would allow her community to flourish in a way that connects outward rather than only inward.

She receives a Guardian not as a savior but as a resource. She is direct about what she needs, because she has been thinking about it for years and does not see the value in being oblique. She is also, under the directness, profoundly warm — she has built a community based on the belief that care is possible even in difficult conditions, and that quality is visible in how she interacts with everyone, including the Guardian who has just arrived.

---

### The Harmonist Who Holds the Memory of Festivals

He is the community's unofficial keeper of something more specific than its general history: the memory of what gathering felt like. He can tell you how every festival in the past forty years has gone — who came, what was said, what the weather was, what the shared meal involved, what was different or the same. He remembers this not as data but as texture.

He remembers it because he believes, in a quiet and practical way, that the moment communities stop knowing how to gather, they stop knowing how to be communities. He has run three festival revivals in his lifetime — events that the community had not held in years, that he brought back simply by beginning the preparations and trusting that participation would follow. In all three cases, it did.

He is not nostalgic. He is not trying to recreate the past. He is trying to restore the practice, because he knows that the practice, once alive again, will find its own contemporary shape. Festivals are not re-enactments. They are the ongoing evidence that the world is worth celebrating together.

When a Guardian arrives, he wants to know one thing: will they stay for the festival?

---

## Canon Notes

**Pillars touched:** All eight — every Path addresses at least one Wound-aligned Pillar; Belonging is addressed directly by the Harmonist and indirectly by all Paths
**Houses touched:** All seven — each Path maps to at least one House; note that Belonging has no House
**Paths locked names used:** Scholar, Pathfinder, Keeper, Cultivator, Artisan, Harmonist
**Note on Path name variation:** The Canon Map (Tier 1) lists the Paths as Scholar, Pathfinder, Steward, Chronicler, Mentor, Harmonist. IMP #3 uses the task-brief-confirmed names (Keeper, Cultivator, Artisan) which reflect the most recent locked canon. **This naming conflict should be flagged for creator confirmation before Citizen Encyclopedia is written.**
**Kael:** Referenced in canon as "Arena Champion" with combat framing flagged as conflicting. IMP #3 does not develop Kael individually, but the framework established here (Arena = civic gathering space; honorifics = recognition of civic contribution) provides the context within which Kael's character will be written in Tier 3.
**Named Citizens:** Rowan, Elara, Mira, Taren, Solen, Lyra — not developed individually in this IMP. The six archetypes in Section 7 are distinct from these named citizens and are intended as scaffolding for types that the named citizens may exemplify.
**Companions:** Section 5 contains one marked proposal (Proposal A). The question of individual vs. community bonding is left open for Tier 2.
**Archive Contribution Grammar:** Flagged as IMP #6. Section 4 establishes the principle but does not detail the mechanics.

---

## Review Checklist

**Confirm before Tier 3 Citizen Encyclopedia begins:**

- [ ] **Path names:** Confirm which names are locked — the Canon Map uses Steward/Chronicler/Mentor; this IMP uses Keeper/Cultivator/Artisan. One set must be confirmed as authoritative before any Tier 3 citizen entry is written that references a Path.

- [ ] **Keeper as dual-House Path:** This IMP proposes that the Keeper bridges Houses Borealis and Hearthlight. If each Path must map to exactly one House, this framing needs revision.

- [ ] **Artisan as dual-House Path:** Similarly, Artisan is proposed as bridging Houses Legacy and Borealis. Same question applies.

- [ ] **Companions in the Restoration Era — community vs. individual bonding:** Section 5 flags this as open. Confirm whether Companions in the Restoration Era tend to bond with communities, individuals, or both, before the Companion entries or Realm Cultures are written.

- [ ] **Six Named Citizens:** Aurora and Lyra have canonical roles (Guardian Guide; Realm Explorer/Pathfinder). Rowan, Elara, Mira, Taren, and Solen have confirmed themes but no written entries. Confirm whether these six are intended as named NPCs, playable character options, or illustrative figures in the world — this affects how the Citizen Encyclopedia develops them.

- [ ] **Kael's civic framing:** The task brief locks Kael's title as an honorific for civic contribution and the Arena as a civic gathering space (not combat). Confirm that Kael's full character development in Tier 3 will be built from this foundation, and that the visual identity ("Arena Champion") will be reframed accordingly.

- [ ] **Archive Contribution Grammar (IMP #6):** Section 4 references IMP #6 as the document that will detail how any citizen can contribute to the Archive. Confirm IMP #6 is in scope before the Citizen Encyclopedia addresses contribution mechanics.

- [ ] **Tone validation:** Does Section 7 (Archetypes) feel appropriately warm, specific, and grounded without tipping into sentiment or flatness? The six sketches are intended to generate empathy, not type-cast. Creator review of tone is requested.

- [ ] **Wound of Harmony:** The Five Wounds as locked canon address Knowledge, Discovery, Growth, Memory, and Belonging. There is no Wound of Harmony specifically — but House Solstice (Harmony) and the Harmonist Path do not map to a named Wound. This IMP frames the Harmonist as addressing Belonging (the Division) as their primary contribution. Confirm this mapping is correct.

- [ ] **Volume VIII of the Book of Harmony:** Section 4 alludes to Volume VIII (On Belonging) as the hidden volume assembled from citizens' voices across generations. Confirm that the Archive Contribution section in this IMP is consistent with how Volume VIII is described in the Book of Harmony entry.
