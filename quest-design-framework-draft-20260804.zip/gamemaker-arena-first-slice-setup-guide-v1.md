# GameMaker Arena First Slice Setup Guide

Version: v1  
Status: Draft — Creator Review Required  
Date: 2026-06-26 AEST  

Project: GemVerse  
Realm: Arena  
Build Target: GameMaker prototype  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related files:

- `arena-first-experience-spec-v1.md`
- `arena-first-slice-dialogue-content-pack-v1.md`
- `arena-first-slice-ui-screen-map-v1.md`
- `arena-first-slice-prototype-assembly-brief-v1.md`
- `implementation-checklist-arena-first-slice-v1.md`
- `arena-slice-qa-script-v1.md`

---

## Purpose

This guide translates the Arena first slice into a practical GameMaker setup plan.

It is designed to help a beginner or first-time builder create a rough but playable Arena prototype using GameMaker’s core workflow: rooms, objects, sprites, scripts, and object events.

This is not a polished production architecture. It is a minimal, low-friction setup that gets the slice working as fast as possible while preserving GemVerse tone.

---

## What You Are Building

You are building one short prototype sequence with seven states:

1. Arrival in Arena  
2. Lantern Keeper greeting  
3. Puzzle introduction  
4. Puzzle play  
5. Restoration response  
6. Archive fragment  
7. Return to Arena

The build goal is to make this flow playable end to end before adding polish.

---

## Recommended Project Structure

Create folders in GameMaker like this:

- Sprites
- Objects
- Rooms
- Scripts
- Fonts
- Audio (optional)

Keep the project intentionally small. Do not add extra systems yet.

---

## Room Setup

Create these rooms in this order.

### Rooms list

- `rm_arrival`
- `rm_keeper`
- `rm_intro`
- `rm_puzzle`
- `rm_restoration`
- `rm_fragment`
- `rm_return`

### What each room does

- `rm_arrival` — first impression of Arena and opening line.
- `rm_keeper` — Lantern Keeper speaks and frames the place.
- `rm_intro` — puzzle context and invitation.
- `rm_puzzle` — small playable puzzle board.
- `rm_restoration` — post-success restoration text.
- `rm_fragment` — Archive Fragment card.
- `rm_return` — return to Arena with closing line.

If you want the simplest possible setup, use one background image per room, even if some rooms share the same image.

---

## Suggested Sprite List

Start with placeholders if needed.

### Environment sprites

- `spr_arena_bg`
- `spr_arena_bg_restored`
- `spr_lantern_glow`

### Character sprites

- `spr_keeper_portrait` or `spr_keeper_idle`
- optional: `spr_companion_small`

### UI sprites

- `spr_text_panel`
- `spr_button`
- `spr_button_hover`
- `spr_archive_card`

### Puzzle sprites

- `spr_tile_a`
- `spr_tile_b`
- `spr_tile_c`
- `spr_tile_d`
- optional solved-state variants if useful

Do not wait for final art. Flat-color placeholders are fine.

---

## Suggested Object List

These names keep the prototype readable.

### Controller objects

- `obj_game_controller`
- `obj_room_controller`
- `obj_puzzle_controller`

### UI objects

- `obj_textbox`
- `obj_button_primary`
- `obj_button_secondary` (optional)
- `obj_archive_card`

### Character objects

- `obj_keeper`
- optional: `obj_companion`

### Puzzle objects

- `obj_puzzle_tile`
- `obj_puzzle_goal_marker` (optional)

You do not need all of these in every room.

---

## Minimal Working Build Strategy

Build the prototype in three passes.

### Pass 1 — Click-through shell

Goal: every room exists and the player can move from start to finish.

In this pass:

- add background images
- add one text box object per room
- add one button object per room
- wire buttons to the next room
- use the final text from the dialogue/content pack

Do not build the real puzzle yet.

### Pass 2 — Puzzle room

Goal: replace the placeholder puzzle room with one small working puzzle.

In this pass:

- add a 4x4 or 5x5 tile grid
- allow swapping or positioning tiles
- define a solved layout
- trigger success when the current layout matches the solved layout

### Pass 3 — Restoration feedback

Goal: make success change the feeling of the world.

In this pass:

- swap `spr_arena_bg` to `spr_arena_bg_restored`
- add a glow effect or brighter banner
- add Archive card room after restoration

This order matches the assembly brief and reduces overwhelm.

---

## Text Placement Plan

Use the dialogue/content pack as your source of truth.

### Room-by-room text plan

#### `rm_arrival`

Text:

"The first thing you notice is not grandeur, but care. A lantern still burns. The paths are still tended. Someone has been keeping this place ready for arrivals."

Primary button:

`Look around`

#### `rm_keeper`

Text sequence:

1. "We keep the lantern lit for arrivals, even when we don't know who is coming."
2. "We used to keep careful records here. Not only in ledgers, but in paths, lantern marks, worn stone, and the way people made room for one another."

Primary button:

`Show me`

#### `rm_intro`

Text sequence:

1. "If you have a moment, help me with something small. That's often where remembering begins."
2. "This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."
3. "This pattern marked the opening of Harmony Week. Restore it, and the square may remember how it felt when every path led here."

Primary button:

`Begin restoring`

#### `rm_puzzle`

Optional hint text:

"Not every trace points to the same kind of gathering. Look for what people left ready for one another."

Success should move to `rm_restoration`.

#### `rm_restoration`

Text:

"The last line falls into place. For a heartbeat, you hear echoes — footsteps, soft laughter, someone calling a familiar name. Nothing returns all at once, but the square remembers enough to answer."

Keeper follow-up:

"A small thing restored is still a real return."

Primary button:

`Read fragment`

#### `rm_fragment`

Title:

`Archive Fragment`

Text:

"Harmony Week Ledger, Year 173 of the First Harmony. Names of each community that sent someone, written in the same patient hand."

Primary button:

`Continue`

#### `rm_return`

Text:

"This is only one pattern. There are others, tucked into corners, carved under dust. Each one remembers a different way people stood together."

Primary button:

`End for now`

---

## Basic Room Logic

Use a simple room-to-room flow.

### Recommended transitions

- `rm_arrival` -> `rm_keeper`
- `rm_keeper` -> `rm_intro`
- `rm_intro` -> `rm_puzzle`
- `rm_puzzle` -> `rm_restoration` on puzzle success
- `rm_restoration` -> `rm_fragment`
- `rm_fragment` -> `rm_return`

The return room can restart, close, or simply stop there.

---

## Button Logic Pattern

Use one reusable button object if possible.

Suggested variables for `obj_button_primary`:

- `button_text`
- `target_room`

### Simple behavior idea

- In Create event, assign button label text and target room.
- In Mouse Left Pressed event, go to `target_room`.
- In Draw event, draw the button sprite and text label.

This avoids making a different button object for every room.

---

## Text Box Logic Pattern

Use one reusable text box object.

Suggested variables for `obj_textbox`:

- `display_text`
- `speaker_name` (optional)

### Simple behavior idea

- In Create event, assign the text for the current room.
- In Draw GUI event, draw panel sprite and text.
- If a room has multiple lines, either:
  - stack them in one text block, or
  - use a line index and advance on click.

For the fastest prototype, use one text block per room rather than a typewriter system.

---

## Puzzle Setup Recommendation

For the first build, keep the puzzle extremely simple.

### Best beginner option

Use a 4x4 tile swap puzzle with a fixed solved state.

Workflow:

- place 16 tile instances in a grid
- each tile knows its current slot and correct slot
- clicking two tiles swaps them
- after each swap, check whether every tile is in the correct slot
- when all tiles match, trigger success

This is much easier than building a full match-3 or physics-based system.

### Tone rule

The puzzle should feel like restoring a pattern, not clearing a board.

That means:

- no explosions
- no destructive sound effects
- no score popups
- no combo multipliers
- no energy or life counters

---

## Recommended Controller Responsibilities

### `obj_game_controller`

Use this only if you want one persistent object for shared values.

Possible use:

- store whether the puzzle is solved
- store whether restored visuals should show

For a very small prototype, this object can be optional.

### `obj_puzzle_controller`

This object can:

- create the puzzle tiles
- track selected tiles
- check solved state
- trigger `room_goto(rm_restoration)` when complete

This keeps puzzle logic out of the tile objects themselves.

---

## UI and Tone Rules in GameMaker

Keep these in front of you while building.

### Allowed UI language

- `Look around`
- `Show me`
- `Begin restoring`
- `Read fragment`
- `Continue`
- `End for now`

### Avoid completely

- `Play level`
- `Battle`
- `Fight`
- `Victory`
- `Power up`
- `Boost`
- `Clear board`
- `Next level`
- `Out of energy`

### Visual rules

- no combat silhouettes
- no loud reward splash screens
- no mobile puzzle HUD clutter
- no top-of-screen currencies or meters

If the UI starts to look like a generic mobile puzzle game, simplify it.

---

## Beginner Build Order

If you are doing this yourself, follow this order exactly.

1. Create the project folders.
2. Create all seven rooms.
3. Add one placeholder background to each room.
4. Make one text box object and one button object.
5. Paste the room text from this guide into the rooms.
6. Wire every room to the next room.
7. Test the click-through shell end to end.
8. Build the puzzle room as the only real interaction.
9. Add the restoration background and Archive card.
10. Run the QA script after the first playable version exists.

This order gets you something visible quickly and keeps motivation high.

---

## Definition of Done for the First GameMaker Prototype

The prototype is done enough for review when:

- the player can move through all seven rooms,
- all text is visible and readable,
- the puzzle can be solved,
- success triggers the restoration room,
- the Archive fragment appears,
- the closing room lands emotionally,
- and no part of the build uses combat or generic power-up framing.

That is enough for a real GemVerse tone test.

---

## What to Build After This

Once the first GameMaker version works, the next best improvements are:

1. better text progression inside dialogue rooms,
2. a cleaner puzzle board presentation,
3. subtle ambient sound,
4. a slightly stronger restored-state visual shift,
5. one playtest pass using the QA script and revision log template.

Do not add more content before the first slice feels right.
