# GemVerse Tier Roadmap & Task Tracker
**Version:** 2.0 — Updated 2026-06-01
**Previous Version:** 1.0 — 2026-06-01
**Maintained by:** Computer (Task 4 — Tier Roadmap and Task Tracker Updater)
**Stop rule:** Never reorder tiers without creator approval. Never add must-do items without creator approval.

> **v2.0 Update Note:** All six Tier 1 entries are now written. Tier 2, 3, and 4 work can begin. However, Tier 1 entries 1.4–1.6 (Crystal Network, Lantern Network, Restoration Era) are in Draft status and require creator confirmation before being locked. All five Implementation Packets (IMP #1–5) are written and in Draft status, pending creator review. Five new canon flags were raised this session — see "New Flags Raised This Session" at the bottom.

---

## TIER ORDER (Locked by Creator)

Tier 1 → Tier 2 → Tier 3 → Tier 4 → Tier 5 → Tier 6

The Book of Harmony must be completed before any other Tier 1 entry. The Restoration Era must be the last Tier 1 entry (it depends on all five above it).

---

## TIER 1 — Foundation Lore
*Must be completed before Tier 2 begins.*

| # | Task | Status | Output | Completed | Notes |
|---|---|---|---|---|---|
| 1.1 | Book of Harmony | ✅ Complete | `tier1/04-book-of-harmony.md` | 2026-06-01 | Authorship + 12 principles + 11 fragments locked. Author: Harmony Council. |
| 1.2 | First Harmony | ✅ Complete | `tier1/05-first-harmony.md` | 2026-06-01 | Duration (3–4 centuries) and Threshold model locked. |
| 1.3 | Five Wounds | ✅ Complete | `tier1/06-five-wounds.md` | 2026-06-01 | All 5 Wounds locked (names, Pillars, Houses, recovery directions). |
| 1.4 | Crystal Network | 🟡 Draft | `tier1/07-crystal-network.md` | 2026-06-01 | Awaiting creator review — origin story and nodes flagged. |
| 1.5 | Lantern Network | 🟡 Draft | `tier1/08-lantern-network.md` | 2026-06-01 | Awaiting creator review. |
| 1.6 | Restoration Era | 🟡 Draft | `tier1/09-restoration-era.md` | 2026-06-01 | Awaiting creator review. Must be last Tier 1 entry. |

---

## TIER 2 — World Depth
*Can begin after Tier 1 is complete.*

| # | Task | Status | Output | Notes |
|---|---|---|---|---|
| 2.1 | Realm Cultures × 8 | ⬜ Pending | — | Food, music, architecture, traditions, holidays, folk heroes per realm |
| 2.2 | Harmony Council | ⬜ Pending | — | Members, purpose, decisions, fate during Shattering |
| 2.3 | Realm Histories × 8 | ⬜ Pending | — | Each realm's history from First Harmony through Shattering to Restoration Era |

---

## TIER 3 — Characters
*Can begin after Tier 1 is complete.*

| # | Task | Status | Output | Notes |
|---|---|---|---|---|
| 3.1 | Companion Encyclopedia — Spark | ⬜ Pending | — | 6-part structure: Origin, Personality, Shattering Memory, Missing Piece, Restoration Story, Legacy Story |
| 3.2 | Companion Encyclopedia — Verdant | ⬜ Pending | — | |
| 3.3 | Companion Encyclopedia — Nimbus | ⬜ Pending | — | |
| 3.4 | Companion Encyclopedia — Frostpaw | ⬜ Pending | — | |
| 3.5 | Companion Encyclopedia — Prism | ⬜ Pending | — | |
| 3.6 | Companion Encyclopedia — Bloomtail | ⬜ Pending | — | |
| 3.7 | Companion Encyclopedia — Galewing | ⬜ Pending | — | |
| 3.8 | Companion Encyclopedia — Echo | ⬜ Pending | — | |
| 3.9 | Citizen Encyclopedia — Rowan | ⬜ Pending | — | Background, role, relationships, personal goal, contribution story, legacy story |
| 3.10 | Citizen Encyclopedia — Elara | ⬜ Pending | — | |
| 3.11 | Citizen Encyclopedia — Mira | ⬜ Pending | — | |
| 3.12 | Citizen Encyclopedia — Taren | ⬜ Pending | — | |
| 3.13 | Citizen Encyclopedia — Solen | ⬜ Pending | — | |
| 3.14 | Citizen Encyclopedia — Lyra | ⬜ Pending | — | |

---

## TIER 4 — Systems
*Can begin after Tier 1 is complete.*

| # | Task | Status | Output | Notes |
|---|---|---|---|---|
| 4.1 | Festival Encyclopedia × 10 | ⬜ Pending | — | Full traditions, rituals, structure for all 10 festivals |
| 4.2 | Harmony Index | ⬜ Pending | — | Measurement, contributions, Realm/Community/Civilization levels |
| 4.3 | Great Archive Systems | ⬜ Pending | — | Hall of Legends, Book of Guardians, Memory Crystals, Unanswered Questions |

---

## TIER 5 — Narrative
*Can begin after Tier 2 and 3 are substantially complete.*

| # | Task | Status | Output | Notes |
|---|---|---|---|---|
| 5.1 | Narrative Bible — Aurora Arc | ⬜ Pending | — | |
| 5.2 | Narrative Bible — Spark Arc | ⬜ Pending | — | |
| 5.3 | Narrative Bible — Companion Memory Arc | ⬜ Pending | — | |
| 5.4 | Narrative Bible — The Lost Harmonists | ⬜ Pending | — | Open mystery — handle with care |
| 5.5 | Narrative Bible — The Missing Realm | ⬜ Pending | — | Open mystery — handle with care |
| 5.6 | Narrative Bible — The Seven Beacons | ⬜ Pending | — | |
| 5.7 | Narrative Bible — The Great Convergence | ⬜ Pending | — | |
| 5.8 | Narrative Bible — Legacy Era | ⬜ Pending | — | |

---

## TIER 6 — Product & Technical
*Can begin at any time but requires Tier 1–3 as foundation.*

| # | Task | Status | Output | Notes |
|---|---|---|---|---|
| 6.1 | Product Bible | ⬜ Pending | — | Gameplay loop, progression, social systems, community systems |
| 6.2 | MVP Definition | ⬜ Pending | — | Arena Realm scope — full detailed spec |
| 6.3 | Technical Architecture | ⬜ Pending | — | |

---

## IMPLEMENTATION PACKETS (IMP)
*Supporting documents that expand on Tier 1 foundations for use across Tier 2–4.*

| # | Packet | Status | Output | Completed | Notes |
|---|---|---|---|---|---|
| IMP #1 | First Harmony Daily-Life Framework | 🟡 Draft | `imp/imp-01-first-harmony-daily-life.md` | 2026-06-01 | Awaiting creator review |
| IMP #2 | Five Wounds Restoration Model | 🟡 Draft | `imp/imp-02-five-wounds-restoration-model.md` | 2026-06-01 | Awaiting creator review |
| IMP #3 | Citizen Life Layer | 🟡 Draft | `imp/imp-03-citizen-life-layer.md` | 2026-06-01 | Awaiting creator review |
| IMP #4 | Companion Relationship Web | 🟡 Draft | `imp/imp-04-companion-relationship-web.md` | 2026-06-01 | Awaiting creator review |
| IMP #5 | Mystery Governance Map | 🟡 Draft | `imp/imp-05-mystery-governance-map.md` | 2026-06-01 | Awaiting creator review |

---

## COMPLETED WORK LOG

| Date | Task | Output | Approved By |
|---|---|---|---|
| 2026-06-01 | Canon Map v1.0 | `01-canon-map.md` | Auto-generated from session |
| 2026-06-01 | Conflicts & Decisions Log v1.0 | `02-conflicts-log.md` | Auto-generated from session |
| 2026-06-01 | Tier 1 Readiness Report | `03-tier1-readiness.md` | Auto-generated from session |
| 2026-06-01 | Book of Harmony (Tier 1.1) | `tier1/04-book-of-harmony.md` | Creator — all items approved |
| 2026-06-01 | First Harmony (Tier 1.2) | `tier1/05-first-harmony.md` | Locked — duration and Threshold model confirmed |
| 2026-06-01 | Five Wounds (Tier 1.3) | `tier1/06-five-wounds.md` | Locked — all 5 Wounds confirmed |
| 2026-06-01 | Crystal Network draft (Tier 1.4) | `tier1/07-crystal-network.md` | Pending creator review |
| 2026-06-01 | Lantern Network draft (Tier 1.5) | `tier1/08-lantern-network.md` | Pending creator review |
| 2026-06-01 | Restoration Era draft (Tier 1.6) | `tier1/09-restoration-era.md` | Pending creator review |
| 2026-06-01 | IMP #1 — First Harmony Daily-Life Framework | `imp/imp-01-first-harmony-daily-life.md` | Pending creator review |
| 2026-06-01 | IMP #2 — Five Wounds Restoration Model | `imp/imp-02-five-wounds-restoration-model.md` | Pending creator review |
| 2026-06-01 | IMP #3 — Citizen Life Layer | `imp/imp-03-citizen-life-layer.md` | Pending creator review |
| 2026-06-01 | IMP #4 — Companion Relationship Web | `imp/imp-04-companion-relationship-web.md` | Pending creator review |
| 2026-06-01 | IMP #5 — Mystery Governance Map | `imp/imp-05-mystery-governance-map.md` | Pending creator review |
| 2026-06-01 | Transfer Tool (6 vols + 6 supp requests) | Deployed website | Creator |
| 2026-06-01 | All 6 ChatGPT transfer volumes | Integrated into Canon Map | Creator |
| 2026-06-01 | Visual Transfer Intake (Task 10) | `work-queue/asset-registry.md` v2.0, `work-queue/canon-risk-report-20260601.md` | Auto-generated from session |

---

## DEPENDENCY MAP

```
Book of Harmony (1.1) ✅
    └── First Harmony (1.2) ✅
            └── Five Wounds (1.3) ✅
                    └── Crystal Network (1.4) 🟡 Draft
                    └── Lantern Network (1.5) 🟡 Draft
                            └── Restoration Era (1.6) 🟡 Draft  ← last Tier 1
                                    └── TIER 2 unlocks (can begin; 1.4–1.6 need lock confirmation)
                                    └── TIER 3 unlocks (can begin; 1.4–1.6 need lock confirmation)
                                    └── TIER 4 unlocks (can begin; 1.4–1.6 need lock confirmation)
```

---

## NEW FLAGS RAISED THIS SESSION
*Added: 2026-06-01 — Requires creator review and resolution before affected content is locked.*

| # | Flag | Severity | Status | Notes |
|---|---|---|---|---|
| F-01 | Story Screen text: "Crystal Heart" + "darkness spread" | 🔴 CRITICAL | Unresolved | Language conflicts with established canon; source text needs creator review |
| F-02 | "Heart of the Core" realm — unknown identity | 🟠 HIGH | Flagged | Realm name not recognized in current canon map; identity unknown |
| F-03 | Spark role framing as "puzzle helper" | 🟡 MEDIUM | Unresolved | Framing may conflict with Spark's established companion role; needs creator ruling |
| F-04 | "Save the Realms" tagline variant | 🟠 HIGH | Do Not Use | Approved tagline is confirmed: **"Restore Realms. Build Your Legacy."** Do not use variant. |
| F-05 | Forestkin vs. Verdankin — companion family name | 🔵 LOW | Flagged for creator confirmation | Two names in use for the same companion family; creator to confirm canonical name |
