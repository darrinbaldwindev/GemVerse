# Realm Packet — Arena Realm
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 2 Entry:** 2.1 (primary hub realm)  
**Linked Files:** `01-canon-map.md`, `06-five-wounds.md`, `decision-01-kael-reframe-resolution.md`, `gemverse-visual-framing-notes-arena-kael-v1-UPDATE-20260804.md`, `asset-registry.md`

---

## Overview

**Name:** Arena Realm  
**Theme:** Community  
**Current State:** Most connected; acts as crossroads and hub for Restoration Era civilization  
**Wound Alignment:** Wound of Belonging — Division  
**Visual Identity (from Art Bible):** "A lush realm of ancient strength" — *Reframed: A lush realm of collective civic strength*  
**Symbol:** Interlinked Circles (representing connected communities and shared purpose)  
**Key Locations:** Harmony Plaza, Great Archive, House Districts, Companion Grove, Festival Grounds, Guardian Hall, Marketplace, Lantern Tower

---

## 1. Realm Essence

The Arena Realm is the beating heart of the Restoration Era civilization — a place where the work of reconnecting what was divided happens every day through the ordinary, extraordinary practice of people showing up for each other.

In the First Harmony, the Arena Realm was the civilization's central gathering place — not a capital in the hierarchical sense, but a crossroads where paths from all Realms converged. Its "arena" spaces were not for competition but for convergence: great plazas where communities gathered to share harvests, resolve disputes through dialogue, celebrate festivals that spanned Realm boundaries, and plan collective projects that no single Realm could achieve alone.

The realm embodies Community not as proximity or shared identity, but as **active participation** — the daily choice to show up, to contribute, to listen, to build together.

---

## 2. Current State (Restoration Era)

The Arena Realm is the most intact of all Realms, having maintained more of its civic infrastructure through the Shattering than any other. This wasn't luck — it was the result of generations of citizens who understood that community infrastructure requires the same care as physical infrastructure.

### Active Systems:
- **Great Archive**: Fully operational, serving as the primary Anchor for the Lantern Network's Archive Succession
- **Lantern Tower**: Continuously maintained, one of the few Lantern sites that never went dark
- **House Districts**: All seven Houses maintain active presences, though with reduced populations
- **Festival Grounds**: Regular community gatherings continue, though with fewer cross-Realm participants
- **Marketplace**: Active trade hub connecting all accessible Realms
- **Guardian Hall**: Operational as the primary arrival and orientation point for new Guardians

### Areas of Ongoing Restoration:
- **Cross-Realm Connections**: While the Arena Realm itself is stable, the routes to other Realms remain fragmented
- **House Collaboration**: The seven Houses maintain their individual presences but have lost some of the deep inter-House collaboration that characterized the First Harmony
- **Companion Integration**: The Companion Grove is active but fewer Companions visit regularly than in the First Harmony
- **Youth Engagement**: Younger generations need structured pathways into civic participation

---

## 3. Cultural Details

### Daily Life

Citizens of the Arena Realm follow a rhythm of "participating, maintaining, and welcoming." Their work is visibly civic — every task, from maintaining the Great Archive's reading rooms to preparing the Festival Grounds for seasonal celebrations, is understood as a contribution to the whole.

A common greeting is "What are you building today?" — referring not just to physical construction, but to relationships, understanding, community capacity. The answer is expected to be specific and shared.

Meals are often communal, with neighborhoods organizing rotating community kitchens. Children learn civic skills alongside academic ones — facilitation, conflict resolution, collaborative planning — from an early age.

### Arts & Traditions

The realm's art form is **Collaborative Creation** — projects that require multiple contributors and cannot be completed by any single person. This includes:
- **Community Murals**: Each citizen adds a small element to a larger design
- **Harmony Choirs**: Multi-part songs where no single voice carries the melody
- **Shared Gardens**: Each household tends a section, but harvests are pooled
- **Story Circles**: Narratives built one sentence at a time by different participants

Festivals are the realm's heartbeat. The **Festival of Beginnings** welcomes new citizens and Guardians. The **Lantern Gathering** renews the realm's connection to the Lantern Network. The **Harmony Week** is the largest celebration, historically drawing participants from all Realms. The **Mentor Celebration** honors those who guide others into civic participation.

### Notable Citizens

- **Rowan** (Community, Reliability, Stewardship) — Community Facilitation Specialist, Mentor Path
- **The Archive Steward** — Elder chronicler who has maintained the Great Archive's continuity through the Shattering
- **The Lantern Keeper** — One of the few Keepers who never let the Lantern Tower's flame falter
- **The House Liaisons** — Seven citizens who coordinate between their respective Houses and the broader community
- **The Festival Coordinator** — Organizes the realm's celebration calendar, ensuring traditions remain alive and relevant

---

## 4. Community Themes

The Arena Realm is aligned with the **Wound of Belonging — Division**. This is the deepest Wound, representing not just physical separation but the erosion of the sense that we belong to each other.

### What the Arena Realm Reveals About the Wound:

- **Belonging Requires Participation** — You don't belong by being present; you belong by contributing. The Arena Realm's citizens understand this viscerally.
- **Division Is Not Just Distance** — Communities can be physically close but emotionally divided. The Wound of Belonging is as much about lost habits of participation as about severed routes.
- **Restoration Is Reweaving** — Healing the Division means re-establishing the daily practices of showing up for each other, not just rebuilding roads or reactivating nodes.

---

## 5. Puzzle Integration Points

### Community Pattern Puzzles

These are the most natural puzzles for the Arena Realm. They may involve:

- **Festival Reconstruction** — Restoring a community celebration by coordinating multiple citizens' contributions
- **Plaza Harmony** — Aligning different community groups' needs in a shared space
- **Tradition Revival** — Reconstructing a lost practice from fragmented memories and records

### Archive Connection Puzzles

The Great Archive contains numerous civilization-scale puzzles:

- **Cross-Realm Record Assembly** — Combining fragments from different Realms to reconstruct shared history
- **Guardian Contribution Integration** — Helping new Guardians understand how their work connects to civilizational restoration
- **Book of Harmony Fragment Synthesis** — Assembling the original text from distributed Archive copies

### Lantern Network Puzzles

The Lantern Tower and associated routes provide puzzle opportunities:

- **Route Restoration Planning** — Coordinating multiple communities to restore a Lantern route
- **Welcome Ceremony Design** — Creating arrival experiences that foster belonging
- **Memory Wall Reconstruction** — Rebuilding the records of travelers' passages

---

## 6. Restoration Goals

The Arena Realm's restoration is not about fixing what's broken — it's about deepening what's working and extending it outward. This means:

1. **Strengthening Internal Cohesion** — Ensuring the Arena Realm's own community practices remain vital and inclusive
2. **Extending Welcoming Infrastructure** — Preparing to receive citizens and Guardians from other Realms as routes are restored
3. **Modeling Restored Community** — Serving as a living example of what post-Shattering community can be
4. **Facilitating Cross-Realm Collaboration** — Using the realm's central position to coordinate multi-Realm restoration projects

---

## 7. Mystery Hooks (Open, Not Resolved)

- **The First Guardian's Vow** — The founding Guardian's original commitment, recorded in the Guardian Hall but never fully understood. What did they promise, and to whom?
- **The Silent Archive Wing** — A section of the Great Archive that has been sealed since the Shattering. Its contents are unknown, and the key was lost with the Archive's last pre-Shattering steward.
- **The Unfinished Festival Grounds Expansion** — A project begun in the First Harmony's final decades, abandoned during the Shattering. Its blueprints suggest a space designed for a gathering that never happened — or hasn't happened yet.

---

## 8. Companion Connections

The Arena Realm's Companion Grove is designed to welcome all companion families, but certain companions have particularly strong affinities:

- **Bloomtail** — Natural partner for the realm's community garden and Circle Garden projects
- **Spark** — Energizes community gatherings and welcomes new arrivals with enthusiasm
- **Echo** — Preserves the oral histories of the realm's communities and festivals
- **Nimbus** — Coordinates the aerial route connections to other Realms
- **Galewing** — Facilitates large-scale community gatherings and cross-Realm journeys
- **Verdant** — Advises on the realm's environmental sustainability and green spaces
- **Prism** — Helps navigate the multi-perspective challenges of diverse community integration
- **Frostpaw** — Maintains the long-term community memory that grounds present work in historical context

---

## 9. Kael — Arena Champion of Community Contribution

### Reframed Narrative Integration

Following Conflict 3 resolution (Decision 01), Kael's role in the Arena Realm is now canonically established as **Champion of Contribution**:

> Kael earned distinction not through combat but through extraordinary civic contribution in the Arena Realm. "Arena" refers to a place of community gathering and achievement, not combat. Kael is celebrated for what he built, restored, or organized — not what he defeated. His title is honorific, not martial.

### Kael's Current Role

Kael serves as the **Guardian Hall Steward** — the primary orientation figure for new Guardians arriving in the Arena Realm. His responsibilities include:

- **Guardian Orientation**: Helping new Guardians understand the civilizational context of their role
- **Community Connection**: Introducing Guardians to the citizens and projects where their contributions will be most meaningful
- **Restoration Coordination**: Facilitating the multi-community projects that form the backbone of Arena Realm restoration work
- **Tradition Keeping**: Maintaining the practices that define Arena Realm civic culture

### Kael's Visual and Narrative Presentation

Per `gemverse-visual-framing-notes-arena-kael-v1-UPDATE-20260804.md`:
- Visual identity should represent civic leadership, not combat prowess
- Tools: Planning boards, community maps, restoration coordination materials
- Attire: Civic wear (robes, sashes, medallions of office) appropriate for a community leader
- Posture: Collaborative (open hands, eye contact, inclusive gestures)
- Background context: Citizens working together, community projects in progress

---

## Files Updated / Referenced

- `asset-registry.md` — Arena Realm environment art and Kael character art tags updated
- `decision-01-kael-reframe-resolution.md` — Conflict 3 resolution documentation
- `gemverse-visual-framing-notes-arena-kael-v1-UPDATE-20260804.md` — Visual framing guidelines
- `06-five-wounds.md` — Wound of Belonging alignment
- `tier-roadmap-tracker.md` — Arena Realm Packet status: Draft Complete