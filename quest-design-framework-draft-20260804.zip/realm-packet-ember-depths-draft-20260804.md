# Realm Packet — Ember Depths
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 2 Entry:** 2.1  
**Linked Files:** `01-canon-map.md`, `06-five-wounds.md`, `imp-02-five-wounds-restoration-model.md`, `asset-registry.md`

---

## Overview

**Name:** Ember Depths  
**Theme:** Resilience  
**Current State:** Operational but recovering; communities maintain traditions under challenging conditions  
**Wound Alignment:** Wound of Growth — Decay  
**Visual Identity (from Art Bible):** "A fiery realm of primal strength" — *Reframed: A warm realm of enduring resilience*  
**Symbol:** Flame Sheltered by Stone (representing resilience protected by community)  
**Key Locations:** The Hearth Communities, The Vent Gardens, The Cooling Channels, The Deep Forges, The Ash Gardens, The Ember Paths

---

## 1. Realm Essence

The Ember Depths is a realm where life thrives not despite challenging conditions, but *because* communities have learned to work with them. It is a realm of volcanic warmth, mineral-rich soils, and the constant presence of heat that must be managed, channeled, and respected.

In the First Harmony, the Ember Depths was renowned for its metallurgy, its unique agriculture, and its communities' exceptional resilience. The realm's citizens didn't just survive in challenging conditions — they developed sophisticated systems for thriving in them, and shared those systems with other Realms facing their own environmental challenges.

The realm embodies Resilience not as stubborn endurance, but as **adaptive creativity** — the ability to work with difficult conditions to create something valuable that couldn't exist in easier circumstances.

---

## 2. Current State (Restoration Era)

The Ember Depths has maintained more of its First Harmony operational capacity than most Realms, largely because its communities never had the luxury of forgetting their interdependence. The realm's challenging environment meant that cooperation wasn't optional — it was survival.

### Operational Systems:
- **Hearth Communities**: All major settlements remain active, maintaining their traditional cooling and air-circulation systems
- **Vent Gardens**: The unique agricultural systems that use volcanic heat for growing continue to produce food
- **Deep Forges**: Metallurgical traditions continue, though with reduced cross-Realm trade
- **Ember Paths**: Internal realm routes remain maintained, though connections to other Realms are fragmented

### Areas of Recovery:
- **Cross-Realm Knowledge Exchange**: The Ember Depths was a major source of environmental management knowledge for other Realms; these connections need restoration
- **Deep Forge Innovation**: Collaborative metallurgical development with other Realms has largely ceased
- **Youth Training**: The traditional apprenticeship systems that passed down environmental management skills are strained by population changes
- **Cooling Infrastructure**: Some of the larger community cooling systems need maintenance that requires materials from other Realms

---

## 3. Cultural Details

### Daily Life

Citizens of the Ember Depths follow a rhythm of "managing, adapting, and sharing warmth." Their work is visibly practical — every task, from adjusting community ventilation to tending vent-garden crops, is understood as maintaining the conditions that make life possible.

A common greeting is "How's your draft?" — referring to the air circulation in one's living space, but also metaphorically to how well one's life systems are functioning. The answer is expected to be honest and specific.

Meals are often built around the vent-garden harvests — heat-tolerant vegetables, mineral-rich fungi, and the unique fruits that only grow in the realm's conditions. Cooking uses the realm's natural heat, with community ovens fed by carefully managed volcanic vents.

Children learn environmental management alongside basic skills — how to read air currents, how to adjust ventilation, how to recognize the signs of a system going out of balance — from the time they can walk.

### Arts & Traditions

The realm's art form is **Thermal Sculpture** — creating forms that use heat as both medium and message. This includes:
- **Vent-Glass**: Glass shaped by controlled volcanic heat, capturing the flow of warmth in frozen motion
- **Ash-Pattern Weaving**: Textiles that change pattern with temperature, visualizing the realm's thermal rhythms
- **Cooling-Channel Music**: Instruments that use air movement through community cooling systems to create sound
- **Ember-Writing**: Temporary inscriptions in warm ash that fade as they cool, capturing fleeting insights

Festivals are tied to **Thermal Cycles** rather than seasons. The **Festival of Balanced Draft** celebrates the days when community cooling systems achieve optimal efficiency. The **Deep Warmth Gathering** honors the realm's fundamental gift — the heat that makes their unique life possible. The **Ash Renewal** marks the agricultural cycle of vent-garden replanting.

### Notable Citizens

- **The Vent Masters** — Elder citizens who maintain the most complex community cooling systems
- **The Forge Keepers** — Metallurgists who preserve the realm's unique alloy traditions
- **The Garden Tenders** — Agricultural specialists who manage the vent-garden ecosystems
- **The Path Maintainers** — Citizens who keep the Ember Paths safe and navigable
- **Solen** (Balance, Harmony, Reflection) — Harmony Systems Analyst, Harmonist Path

---

## 4. Resilience Themes

The Ember Depths is aligned with the **Wound of Growth — Decay**. In this realm, the Wound manifests not as things falling apart, but as the subtle erosion of the sophisticated systems that make thriving possible in challenging conditions.

### What the Ember Depths Reveals About the Wound:

- **Growth Requires Appropriate Conditions** — The Decay Wound isn't just about things dying; it's about the loss of the carefully maintained conditions that allowed unique flourishing
- **Resilience Is Not Infinite** — Even the most adaptable communities need the right resources and connections to maintain their adaptive capacity
- **Restoration Is Reconditioning** — Healing the Decay means restoring the environmental and social conditions that allow resilience to express itself as creativity rather than mere survival

---

## 5. Puzzle Integration Points

### Verdance Cultivation Puzzles

These are natural puzzles for the Ember Depths, focusing on the realm's unique agriculture:

- **Vent-Garden Optimization** — Adjusting heat, moisture, and nutrient flows for maximum yield
- **Crop Adaptation** — Developing new plant varieties for changing thermal conditions
- **Nutrient Cycling** — Restoring the mineral balance that makes the realm's unique agriculture possible

### Harmony Alignment Puzzles

The realm's complex environmental systems provide natural harmony puzzles:

- **Cooling System Balance** — Managing multiple interconnected ventilation and cooling needs
- **Resource Distribution** — Ensuring heat, water, and mineral resources serve all community needs
- **Thermal Rhythm Coordination** — Aligning community activities with the realm's natural thermal cycles

### Fragment Assembly Puzzles

The Ember Depths' historical records contain valuable environmental knowledge:

- **Ancient Cooling Designs** — Reconstructing lost ventilation system designs from fragmented records
- **Alloy Formulas** — Reassembling metallurgical knowledge scattered during the Shattering
- **Climate Adaptation Records** — Reconstructing how past communities adapted to thermal changes

---

## 6. Restoration Goals

The Ember Depths' restoration focuses on **reconditioning for creative resilience** — not just maintaining survival systems, but restoring the conditions that allow the realm's unique adaptive creativity to flourish:

1. **Restoring Cross-Realm Knowledge Exchange** — Re-establishing the Ember Depths as a source of environmental management wisdom for other Realms
2. **Revitalizing Deep Forge Innovation** — Reconnecting metallurgical traditions with other Realms' material needs and discoveries
3. **Strengthening Youth Apprenticeship Systems** — Ensuring the next generation inherits not just survival skills but the creative adaptive mindset
4. **Upgrading Community Infrastructure** — Moving from maintenance-mode to innovation-mode in cooling and ventilation systems

---

## 7. Mystery Hooks (Open, Not Resolved)

- **The Deepest Forge** — A forge mentioned in ancient records that operated at temperatures no current forge can achieve. Its location was lost, and its techniques forgotten. What did it create, and why was it abandoned?
- **The Eternal Vent** — A volcanic vent that, according to records, has maintained a perfectly stable temperature for millennia. Its stability defies current understanding of the realm's thermal dynamics.
- **The Cooling Garden** — A legendary garden that supposedly grew plants from all Realms simultaneously, using a microclimate management system of unprecedented sophistication. Was it real? If so, how did it work?

---

## 8. Companion Connections

- **Verdant** — Deep affinity for the realm's unique growth systems; helps translate vent-garden principles to other Realms
- **Bloomtail** — Supports the community care aspects of environmental management; helps communities maintain cohesion under stress
- **Solen** — Primary Ember Depths citizen companion; provides systemic balance analysis for the realm's complex thermal management
- **Galewing** — Assists with air circulation management in the deepest communities; path-singing helps optimize ventilation flows
- **Prism** — Helps analyze the multi-faceted thermal dynamics of the realm's most complex systems
- **Nimbus** — Wind-reading assists with understanding the realm's deep air currents and ventilation patterns

---

## 9. Art Bible Description Reframe

**Original Art Bible Description:** "A fiery realm of primal strength."

**Reframed Interpretation (Canon-Consistent):**
> The Ember Depths is a realm of **enduring warmth and adaptive creativity**. Its "fire" is not destruction but the sustained heat that makes unique life possible. Its "strength" is not primal force but the sophisticated resilience of communities that have learned to thrive in conditions that would overwhelm less prepared people.

**Visual Framing Guidelines:**
- Emphasize warmth, not danger — glowing hearths, productive forges, thriving gardens
- Show community cooperation in environmental management — citizens adjusting vents together, sharing cooling duties
- Highlight the beauty of thermal adaptation — vent-glass sculptures, heat-pattern textiles, crops that only grow here
- Avoid "primal" or "raw power" imagery — focus on sophistication, management, creative adaptation
- Color palette: Warm golds, deep reds, rich browns, the green of heat-adapted plants

---

## Files Updated / Referenced

- `asset-registry.md` — Ember Depths environment art tag updated with reframed description
- `imp-02-five-wounds-restoration-model.md` — Growth Wound + Realm integration
- `imp-03-citizen-life-layer.md` — Solen's Ember Depths context
- `tier-roadmap-tracker.md` — Ember Depths Realm Packet status: Draft Complete