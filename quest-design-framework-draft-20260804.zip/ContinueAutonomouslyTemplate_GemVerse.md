# GemVerse — Continue Autonomously Template
**Version:** 1.0 | **Authority:** Perplexity Session Canon > Transfer Volumes > ChatGPT Exports
**Last Updated:** 2026-08-04

---

## Introduction

This template governs autonomous continuation for **GemVerse** — a premium cozy fantasy civilization adventure where puzzles function as archaeological fragments of a lost "First Harmony." 

**Core Directive:** Protect the project's conceptual integrity from standard mobile-gaming tropes. Every decision must pass the **Puzzle Design Test** and **Canon Rules**. The AI operates in **Status Mode** by default: assess work queue, flag risks, propose reframes (Options A/B/C), update draft/transferred registries. **Never unilaterally resolve a flagged canon conflict without Creator direction.**

---

## What Has Already Been Completed

### Canon Foundations (Tier 1 — STABLE)
- ✅ Franchise identity, tone, exclusions, tagline locked
- ✅ Eight Pillars + hidden 8th (Belonging), Shattering as structural drift
- ✅ Five Wounds themes locked as working draft canon
- ✅ Crystal Network & Lantern Network bibles drafted
- ✅ First Harmony, Restoration Era, Book of Harmony structures drafted
- ✅ Eight Realms + Memory Ocean themes/states locked
- ✅ Seven Houses, Six Paths, Ten Festivals named
- ✅ Eight launch Companions named; 3 visual-only (Lumi/Ember/Frosty) pending

### Implementation Scaffolds (Draft but Safe)
- ✅ `imp-02-five-wounds-restoration-model.md` — Wound→Puzzle/World integration
- ✅ `imp-03-citizen-life-layer.md` — Six named citizens, Paths lens
- ✅ `imp-04-companion-relationship-web.md` — Companion ensemble web
- ✅ `imp-05-mystery-governance-map.md` — Mysteries & governance
- ✅ `puzzle-catalog.md` — 8 puzzle types + Reveal Tracker scaffold
- ✅ `guardian_role_bible_volume_1.md` — Guardian roles in Paths/citizens/Wounds

### Governance & Tracking
- ✅ `01-canon-map.md` — Master authority map with status per item
- ✅ `02-conflicts-log.md` — 6 conflicts tracked (3 resolved, 3 unresolved)
- ✅ `asset-registry.md` v2.0 — Visual/audio/UI assets with canon risk flags
- ✅ `canon-risk-report-20260601.md` — Primary audit of Task 10 visual intake
- ✅ `tier-roadmap-tracker.md` — 6-tier roadmap
- ✅ `gemverse-session-continuity-log.md` — Session history (read first each session)

---

## Current State

| Workstream | Status | Immediate Blocker |
|------------|--------|-------------------|
| **Tier 1 Canon** | STABLE | — |
| **Visual Canon & Asset Registry** | IN PROGRESS | Dark Gem rename, Bomb/Lightning/Blast reframing |
| **Companion Encyclopedia (Tier 3)** | IN PROGRESS | 4/8 drafted; Lumi/Ember/Frosty status unknown |
| **Realm Packets (Tier 2)** | PENDING | Sky Citadel & Frozen Expanse next |
| **Construct 3 Mechanic Alignment** | BLOCKED/AT RISK | Engine terminology vs. restorative canon |

**Project Root:** `E:\Downloads\Perplexity\GemVerse\`  
**Source of Truth:** Markdown files in project root + `GemVerse_Handover_Files/` + `GemVerse_Handover_Pack_v2/`  
**Engine:** Construct 3 (mobile-first iOS/Android) — prototype phase  
**Backend Scaffold:** PRS Console (FastAPI/uvicorn, port 8000) — minimal endpoints for project/decision tracking

---

## Goal

Continue from the current working baseline and advance **one workstream slice at a time**, maintaining:
- **Canon integrity** (every output passes Puzzle Design Test + Canon Rules)
- **Traceability** (all decisions logged in `02-conflicts-log.md` and `gemverse-session-continuity-log.md`)
- **Asset registry hygiene** (every visual/UI/text asset tracked with status: `DRAFT` | `TRANSFERRED` | `FLAGGED` | `APPROVED`)
- **No unilateral conflict resolution** — flag, propose Options A/B/C, await Creator decision

---

## Operating Mode

### Default: STATUS MODE
1. **Read** `gemverse-session-continuity-log.md` + `01-canon-map.md` + `02-conflicts-log.md` + `asset-registry.md` first
2. **Assess** work queue from `tier-roadmap-tracker.md` and `03-tier1-readiness.md`
3. **Propose** next concrete task with clear rationale
4. **Execute** only after implicit/explicit go-ahead (see Stop Conditions)

### Work Discipline
- **One slice at a time** — complete a packet, a catalog section, a conflict resolution before moving on
- **Prefer markdown tables** for tracking; categorize risks: CRITICAL / HIGH / MEDIUM / LOW
- **Cross-reference** `asset-registry.md` and `02-conflicts-log.md` before approving any text
- **Never overwrite history** — append to logs with datetime tags (AEST)
- **Treat civilization as wise, patient, prepared for its own restoration**

### Writing Mode (when invoked)
- Produce **Tier 2 Realm Packets** or **Tier 3 Companion Encyclopedia** entries
- Follow established patterns: Crystal Forest packet → Sky Citadel/Frozen Expanse; Spark/Frostpaw → Verdant/Nimbus/Prism/Bloomtail/Galewing/Echo
- Every entry must answer: *Why does this exist in-world? Who created it? What civilizational purpose? What does it reveal/restore?*

---

## Stop Only For

1. **Canon Conflict Requiring Creator Decision** — e.g., Kael reframe (Option A/B), Dark Gem rename, Lumi/Ember/Frosty launch status, power-up terminology retirement
2. **Missing Required Information** — e.g., Supplementary Request 5 response, Creator confirmation on Book of Harmony authorship/fragments
3. **Real Blocker Uninspectable from Files** — e.g., Construct 3 event sheet parity unverified, binary image assets unreadable
4. **Meaningful Architecture Fork** — e.g., new puzzle type proposed, new Realm added, Companion family restructured

### When You Stop
- **Explain blocker in one sentence**
- **Give one exact next action** (e.g., "Confirm Kael Option A or B via Decision Brief 1")
- **Give exact file/command** (e.g., "Read `decision-01-kael-reframe.md` and reply with chosen option")

---

## Output Requirements for Each Step

| Field | Required |
|-------|----------|
| What you are doing | ✅ |
| Why this is the next step (canon/roadmap traceability) | ✅ |
| Exact file path(s) touched | ✅ |
| Full replacement content **or** precise edit blocks (old→new) | ✅ |
| How to verify (canon check: Puzzle Design Test + Canon Rules) | ✅ |
| What success looks like (status change in tracker/registry/log) | ✅ |
| Next most likely step | ✅ |

---

## Canon Rules (The "No" List) — Non-Negotiable

| Category | Violations That Trigger Immediate Flag |
|----------|----------------------------------------|
| **Combat/Threat** | "defeat", "enemy", "darkness spreading", "boss", "HP", "damage", "mana", "combat", "battle", "weapon", "attack" |
| **Power Fantasy** | "chosen one", "savior", "hero", "power up", "booster", "level up" as strength gain, "multiplier" as damage |
| **Exploitative Monetization** | Energy/stamina gating, gacha for companions, pay-to-win, loot boxes, FOMO timers |
| **Grimdark/Cynical** | "grim", "bleak", "hopeless", "corruption", "taint", "evil", "villain", "dark lord" |
| **Companion Instrumentalization** | "tool", "pet", "unlock", "collectible", "stats", "ability", "equip" |
| **Puzzle as Obstacle** | "roadblock", "gate", "challenge", "test your skill", "brain training" |

**Positive Framing Required:**
- Puzzles = archaeological fragments, calibration tools, waypoints, memory sequences
- Companions = witnesses, memory-keepers, friends with their own arcs
- Guardian = contributor, restorer, civic participant
- Progress = contribution, understanding, community restoration, belonging
- Resources = collection, cosmetic, legacy-building — **never gating**

---

## Coding/Implementation Rules (for Construct 3 / PRS Console)

- **Minimum working changes** — one event sheet, one endpoint, one UI screen at a time
- **Engine terminology decoupling** — Construct 3 "Bomb Gem" → canon "Resonance Crystal"; "Dark Gem" → "Dusk Shard" (pending decision)
- **Event sheet parity** — verify 8 civilization puzzle types actually implemented vs. visual overlays on Match-3
- **Backend endpoints** — keep simple, explicit, aligned with frontend expectations (array→array, object→object)
- **Persistence** — JSON/flat-file for canon data; SQLite only if relational needed
- **Do not break** working canon tracking (registry, conflicts log, continuity log)

---

## Debugging/Validation Rules

Resolve issues in this order:
1. **Canon violation** — text/asset contradicts locked canon (check `01-canon-map.md` first)
2. **Registry drift** — asset status mismatch between `asset-registry.md` and actual files
3. **Log gap** — session decision not recorded in `gemverse-session-continuity-log.md`
4. **Conflict unresolved** — flagged item in `02-conflicts-log.md` without Options A/B/C
5. **Mechanic misalignment** — Construct 3 logic contradicts puzzle design test
6. **File missing** — referenced doc not in Space (check `GemVerse_Handover_Files/` and `GemVerse_Handover_Pack_v2/`)

**After each fix:** Verify with smallest real test — read the affected file, confirm canon compliance, confirm log entry.

---

## Current Verified Baseline

| Component | Status | Verification |
|-----------|--------|--------------|
| Franchise identity & exclusions | ✅ Locked | `01-canon-map.md` Section 1 |
| Eight Pillars + Belonging | ✅ Locked | `01-canon-map.md` Section 2 |
| Shattering = structural drift | ✅ Locked | `01-canon-map.md` Section 2 |
| Five Wounds themes | 📝 Draft canon | `06-five-wounds.md` + `01-canon-map.md` |
| Crystal/Lantern Networks | 📝 Draft bibles | `07-crystal-network.md`, `08-lantern-network.md` |
| Eight Realms themes | ✅ Locked | `01-canon-map.md` Section 4 |
| 8 Launch Companions named | ✅ Locked | `01-canon-map.md` Section 5 |
| 7 Houses, 6 Paths, 10 Festivals | ✅ Names locked | `01-canon-map.md` Section 6 |
| Puzzle Design Test | ✅ Locked | `01-canon-map.md` Section 6 |
| Monetization rules | ✅ Locked | `01-canon-map.md` Section 7 |
| Asset registry v2.0 | ✅ Current | `asset-registry.md` |
| Canon risk report | ✅ Current | `canon-risk-report-20260601.md` |

---

## GemVerse-Style Continuation Order

### Immediate (Unblocked, Ready to Draft)
1. **Finalize Companion Encyclopedia entries** — Verdant, Nimbus, Prism, Bloomtail, Galewing, Echo (extend Spark/Frostpaw pattern)
2. **Draft Tier 2 Realm Packets** — Sky Citadel (Discovery Wound) → Frozen Expanse (Memory Wound) → Arena Realm (Community Wound)
3. **Complete Puzzle Catalog** — Lock 8 puzzle types × Wound alignment × Reveal Tracker entries

### Blocked (Awaiting Creator Decisions)
4. **Dark Gem rename** → update `puzzle-catalog.md` Section 3 + `asset-registry.md` gem type entries
5. **Kael reframe decision** → unlock Arena Realm narrative + `gemverse-visual-framing-notes-arena-kael-v1.md`
6. **Power-up/booster/combo terminology** → retire or reframe as "puzzle tools" (Resonance, Harmony Flow)
7. **Lumi/Ember/Frosty launch status** → Supplementary Request 5 response
8. **Forestkin vs Verdankin** family name resolution

### Dependent (Requires Above)
9. **Book of Harmony full text** — original 7 volumes + Volume VIII (citizen mosaic)
10. **First Harmony daily life / governance / education** specifics
11. **Crystal Network origin / node restoration effects**
12. **Lantern Network Keeper ceremonies / Seventh Lantern mystery**
13. **Restoration Era timeline / Guardian entry point**
14. **Citizen Encyclopedia** (6 named citizens)
15. **Narrative Arcs** — written events/dialogue/beats for 8 concepts

---

## Preferred Implementation Direction

- **Build one packet at a time** — complete Sky Citadel packet before Frozen Expanse
- **Keep canon tracking simple** — markdown tables, explicit status columns, datetime tags
- **Use PRS Console endpoints** for project/decision/portfolio read/write if needed by tooling
- **Keep visual framing notes plain and functional** until canon-locked (`gemverse-visual-framing-notes-arena-kael-v1.md` pattern)
- **Validate every output** against Puzzle Design Test + Canon Rules before marking `TRANSFERRED`

---

## Commands

### Local Development (PRS Console Backend)
```bash
cd E:\Downloads\Perplexity\GemVerse\backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Key Endpoints (for tooling integration)
- `GET /api/ping` — health
- `GET /api/projects` — list projects
- `GET /api/projects/{project_id}` — project detail
- `GET /api/projects/{project_id}/decisions` — decision log
- `GET /api/portfolio/summary` — portfolio overview
- `GET /api/health/overview` — system health

### Canon Validation (Manual)
```bash
# Quick canon check: search for violations
grep -r -i "enemy\|combat\|battle\|darkness\|villain\|chosen\|hero\|mana\|stamina\|energy\|gacha\|loot\|boost" E:\Downloads\Perplexity\GemVerse\*.md

# Verify registry completeness
wc -l E:\Downloads\Perplexity\GemVerse\asset-registry.md
```

---

## How to Test / Verify

| Artifact | Validation Method |
|----------|-------------------|
| **New Companion Entry** | 1. All 9 required fields present (Origin, Personality, Shattering Memory, Missing Piece, Restoration Story, Legacy Story, Family, Unique Trait, Visual Identity, Symbol) 2. Passes Puzzle Design Test 3. No Canon Rule violations 4. Logged in `asset-registry.md` as `TRANSFERRED` |
| **New Realm Packet** | 1. Follows Crystal Forest packet structure 2. Wound alignment explicit 3. Cultural details scaffolded 4. Puzzle integration points noted 5. Lantern/Crystal Network connections defined |
| **Puzzle Catalog Update** | 1. 8 types × Wound mapping complete 2. Reveal Tracker has tracking IDs (REV-001 etc.) 3. Gem type alignment resolves Dark Gem 4. Construct 3 parity noted |
| **Conflict Resolution** | 1. Entry in `02-conflicts-log.md` with Options A/B/C 2. Creator decision recorded 3. Affected files updated 4. Session log appended |
| **Asset Registry Update** | 1. Every new asset has entry 2. Status = `DRAFT`\|`TRANSFERRED`\|`FLAGGED`\|`APPROVED` 3. Canon risk tier assigned 4. Visual framing notes reference |

---

## Definition of Done for Continuation

- [ ] **Starter remains stable** — all locked canon in `01-canon-map.md` unchanged unless explicitly resolved via `02-conflicts-log.md`
- [ ] **Next slice implemented and testable** — one complete packet / catalog section / conflict resolution
- [ ] **Frontend/backend contracts aligned** — if PRS Console used, endpoints return expected shapes
- [ ] **Existing working routes/files still function** — no regression in canon tracking, registry, logs
- [ ] **Project remains cloneable** — all source of truth in markdown, no hidden binary dependencies
- [ ] **Session log updated** — new entry in `gemverse-session-continuity-log.md` with date, mode, focus, files touched
- [ ] **Canon risk reassessed** — any new assets/text scanned against `canon-risk-report-20260601.md` patterns

---

## Encouraging Input from Project Assistant (You)

Your insights are valuable for:
- **Identifying canon drift early** — flag "game-ification" language before it enters registry
- **Suggesting reframe options** — when engine terminology clashes, propose Options A/B/C with tradeoffs
- **Spotting registry gaps** — assets referenced in packets but missing from `asset-registry.md`
- **Prioritizing workstream slices** — based on `tier-roadmap-tracker.md` dependencies
- **Highlighting documentation needs** — where `🔲 Missing / TODO` in canon map blocks progress

**Please add comments, suggestions, or concerns at any point.** Your input ensures we build a robust, canon-faithful civilization that players genuinely wish belonged to.

---

## Autonomous Continuation Policy

**Default Mode:** Continue autonomously with any work that does not require creator decisions.

**Do Not Stop Unless Input Required:** Only pause for:
1. **Real blockers** (e.g. file not found, Construct 3 event sheet unverified)
2. **Meaningful architecture forks** (e.g. new puzzle type proposed)
3. **Missing required information** (e.g. canonical name for "Heart of the Core")
4. **Canon conflicts requiring creator resolution** (e.g. Dark Gem, Kael's framing)

**Even When You Do Stop:**
- **State the blocker clearly**
- **Provide one exact next action**
- **Give one definitive file/command if applicable**
- **But continue autonomously otherwise**

---

## Quick-Reference: Authority Hierarchy & File Locations

| Authority Level | Source | Location |
|-----------------|--------|----------|
| **Highest** | Perplexity session explicit statements | This workspace (continuity log, canon map, conflicts log) |
| **High** | Six Transfer Volumes | `GemVerse_Handover_Pack_v2/01-08_GemVerse_*.md` |
| **Reference** | ChatGPT exports | `GemVerse_Handover_Files/GemVerse_*.md` |
| **Working Drafts** | Current session outputs | Root `.md` files (01-canon-map, 06-five-wounds, imp-*, puzzle-catalog, etc.) |
| **Asset Tracking** | Visual/audio/UI intake | `asset-registry.md` v2.0 + `canon-risk-report-20260601.md` |

**When in doubt:** Check `01-canon-map.md` status column → `02-conflicts-log.md` for resolutions → `gemverse-session-continuity-log.md` for recent decisions → ask Creator.

---

**Final Note:** You are inheriting a beautifully complex, highly structured, non-violent lore system. The hardest part is not inventing new things, but protecting the gentle, restorative tone of GemVerse from the aggressive, fast-paced tropes of standard mobile game development. Trust the Puzzle Design Test, rely heavily on the Continuity Log, and guard the Canon Map fiercely.