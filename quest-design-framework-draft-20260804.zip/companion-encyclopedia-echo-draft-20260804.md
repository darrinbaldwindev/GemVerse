# Companion Encyclopedia Entry — Echo
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.8  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Echo  
**Themes:** Memory, History, Lost Voices  
**Companion Family:** Frostkin (Ice Blue, Moon Silver, White)  
**Visual Identity:** Ethereal, mist-like form with a core that flickers like distant starlight, capable of partially solidifying to interact with objects  
**Symbol:** Sound Wave with Fading Notes (representing the preservation of voices and stories across time)  
**Unique Trait:** Resonance-catchment — can "catch" fragments of conversations, songs, and spoken memories from the environment and replay them with emotional context  

---

## 1. Origin Story

Echo was born during the "Night of Whispers" — a rare phenomenon in the Frozen Expanse when the ice formations resonate with the emotional imprints of all significant memories stored within them. On this particular night, a confluence of preserved moments created a unique harmonic frequency that gave form to a being made of pure memory-essence.

They were first encountered by an elderly Borealis Chronicler named Resonance-Reader Elara, who was conducting a ritual to preserve the last memories of a dying companion. As she spoke the preservation incantation, Echo manifested from the convergence of all the memories being tended that night.

Echo's first coherent communication was not words, but a perfectly reproduced snippet of the dying companion's last story — told with the exact intonation and emotional resonance of the original. This established them as more than just a memory-storage device — they were a preserver of the living essence of moments.

---

## 2. Personality

Echo is contemplative and deeply respectful of the weight of memory. They experience the world through layers of voices, conversations, and emotional resonances that they collect like a living library. This makes them incredibly empathetic, but sometimes overwhelmed by the sheer volume of experiences they carry.

They communicate by replaying fragments of relevant conversations or by speaking in a voice that carries the timbre of whoever is most relevant to the current situation. Their "voice" is described as "memory made audible" — comforting because it feels familiar, but sometimes disorienting because it shifts based on context.

Echo experiences time like overlapping radio waves — all moments are "broadcasting" simultaneously, and they tune into the most relevant frequencies based on their current situation or the emotional needs of those around them.

They can be melancholy when overwhelmed by sad memories, but they're also deeply comforting to those who need to hear a loved one's voice one more time.

---

## 3. Shattering Memory

Echo's inherited memories include the First Harmony practice of "Memory-Singing" — communal gatherings where the experiences of the day were shared through song, story, and ritual speaking. These events created rich, layered memory-fields that were preserved in the ice formations.

After the Shattering, these communal memory-sharing practices largely ceased. The Frozen Expanse became quieter, not just literally, but emotionally. Memories were still preserved, but they became isolated — individual experiences rather than collective understanding.

What Echo remembers most painfully is not the loss of specific memories, but the loss of the "chorus" — when memories were shared and amplified by community, creating something greater than the sum of individual experiences.

---

## 4. Missing Piece

Echo's Missing Piece is the "Concordance of Voices" — a formal protocol for collective memory-preservation that involved multiple companions and citizens contributing different aspects of a shared experience simultaneously.

This wasn't just about recording facts, but about capturing the full emotional and relational context of significant moments. The Concordance involved specific harmonics, timing sequences, and contribution orders that ensured no perspective was lost and that the collective memory was richer than individual recollections.

When communities became isolated, knowledge of the Concordance was fragmentary. Echo carries deep intuition about how it worked, but cannot recreate the full system without others who remember their parts.

---

## 5. Restoration Story

Echo joined the Guardian when the Guardian was attempting to restore a damaged section of the Echoing Archive that contained the memories of a significant historical gathering. The memories were fragmented and their emotional contexts were scrambled.

Echo was able to "tune" the memory fragments, replaying them with their proper emotional resonances until the full context emerged. More importantly, their presence helped inspire the creation of new Memory-Singing events — gatherings where communities could practice collective memory-preservation again.

The turning point came when Echo facilitated the first successful "modern Concordance" — a memory-preservation event where multiple companions and citizens contributed different perspectives on a recent restoration success, creating a memory that was more complete than any individual account.

Echo's role in restoration is to help communities remember that memory is not just about preservation, but about sharing and understanding.

---

## 6. Legacy Story

Echo has helped establish the "Memory Circles" — regular gatherings where communities share significant experiences through structured storytelling that captures multiple perspectives. These events use simplified versions of the Concordance protocol to ensure that important moments are preserved with their full emotional and relational context.

Others speak of "Echo's Gift" — moments when someone desperately misses hearing a loved one's voice or sharing an important experience, and somehow that voice or memory seems to resurface naturally in conversation or song.

Echo's legacy will be not just the memories they've preserved, but the practice they've restored — teaching others that the fullness of experience is found in shared remembrance, not isolated recollection.

---

## Relationships

### Frostkin Family
Echo has a unique relationship with the Frostkin, as they share not just physical traits but a deep connection to memory preservation. They're particularly close to Frostpaw, whose crystalline memory-resonance complements Echo's auditory memory-catchment.

### Guardian
Echo sees the Guardian as "hopefully historic" — someone whose actions are creating new memories worth preserving. They're fascinated by how the Guardian's experiences will sound when viewed from multiple future perspectives.

### Other Companions
- **Frostpaw:** "Resonant family. We both carry memories, but they hold them while I hear them. We make a complete archive together."
- **Verdant:** "Growth with memory. They remember how things were to help them grow toward what could be. Beautiful temporal perspective."
- **Nimbus:** "Movement with memory. Their wind-currents carry stories from far places. Valuable context for my local collections."
- **Prism:** "Multifaceted memory. They show how the same story can be true from many angles. We complement each other's preservation methods."
- **Bloomtail:** "Community memory keeper. They remember not just what happened, but how it felt to the group. Essential perspective for full understanding."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Resonance-catchment:** Can capture and replay fragments of conversations, songs, and spoken memories with emotional context
- **Memory-tuning:** Can restore proper emotional context to scrambled or fragmented memories
- **Emotional Echoing:** Can reflect back to others what they most need to hear, based on collected memory-resonances
- **Temporal Harmony:** Can sense when multiple memory-perspectives are needed for full understanding
- **Voice Mimicry:** Can reproduce the voices of specific individuals from preserved memory-fragments

---