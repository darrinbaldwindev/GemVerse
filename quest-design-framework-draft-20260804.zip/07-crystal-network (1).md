# The Crystal Network
**GemVerse Master Bible — Tier 1 Entry**
**Status:** Canon-Safe Expansion | Built on confirmed locked canon + transfer foundations
**Canon Source:** Transfer Volume 1 (Section 4); First Harmony (locked); Five Wounds (locked); Perplexity session canon
**Depends on:** Book of Harmony, First Harmony, Five Wounds (all complete)

---

## Purpose

This document is the full Master Bible entry for the Crystal Network — the world-spanning knowledge infrastructure of the First Harmony. It establishes the Network's origins, function, physical form, relationship to the Archive and Companions, how it failed during the Shattering, and what restoration looks like in the Guardian era.

---

## What the Crystal Network Is

The Crystal Network is civilization's knowledge infrastructure — the system through which understanding flowed between Realms, Archives, scholars, Companions, and communities during the First Harmony.

It is not magic. It is not a power source. It is not a weapon.

It is the largest collaborative construction project in GemVerse history: a world-spanning lattice of crystalline nodes, pathways, and relay points that allowed a discovery made in the Crystal Forest to reach a researcher in the Frozen Expanse within a day, allowed a Companion's memory to be preserved beyond that Companion's ability to carry it, and allowed the Archive to be not one building but a distributed civilization-wide institution.

When the Shattering came, the Crystal Network did not break all at once. It fragmented — nodes going dark as communities withdrew, pathways losing their relay points, records becoming inaccessible rather than destroyed. Most of what the Network held still exists. It is waiting in dormant nodes throughout the Realms, intact, sealed, patient. Guardians who restore the Network do not recreate it. They reawaken it.

---

## Origins

### Who Built It

The Crystal Network was not built by a single House, a single person, or a single era.

It grew.

The earliest crystalline knowledge-preservation sites predate the formal Houses — communities in the Crystal Forest discovered that certain formations of living crystal could hold impressions: sounds, images, tactile memories, sequences of thought. These natural formations were not storage systems. They were accidental archives — places where something had been remembered by the land itself.

The scholars who became the founding members of House Lumina recognized what these formations were doing and began the deliberate work of extending, replicating, and connecting them. Over the course of the First Harmony's early centuries, what had been scattered natural phenomena became deliberate infrastructure. Nodes were cultivated rather than constructed — grown from seed-crystals using techniques developed by Lumina scholars in collaboration with Crystalkin Companions, whose natural affinity for crystalline structures made them essential partners in the work.

The Crystal Network as a civilization-spanning system — fully connected, reliably accessible, maintained — was achieved approximately a century into the First Harmony. Its full build-out was considered one of the era's defining achievements.

> *Canon note: The origin story above is a canon-safe expansion. The key facts — House Lumina's role, Crystalkin Companion involvement, the Network as deliberate construction extending natural phenomena — are new but fully consistent with all locked canon. Flagged for creator review before locking.*

### How Nodes Were Created

Crystal nodes were not manufactured. They were cultivated — a process that required:

1. **A seed-crystal** — a fragment of naturally occurring knowledge-holding crystal, identified and harvested by Crystalkin Companions and Lumina scholars working together
2. **A location** — chosen for stability, accessibility, and its relationship to the surrounding community's needs
3. **A foundation contribution** — the first memory, discovery, or record placed into the node at the moment of its activation. This contribution was considered significant: it shaped the node's initial resonance and, in some traditions, its character

The cultivation process took between one season and several years, depending on the node's intended scale. Major Archive nodes — capable of holding civilization-scale records — required decades of careful tending before they were ready. Small community nodes could be cultivated in a growing season.

This is why Crystal Network restoration is slow. Nodes cannot be rebuilt overnight. They must be reawakened — and reawakening a dormant node requires understanding what it originally held, providing it with a new foundation contribution, and maintaining it through its re-emergence.

---

## How It Functioned

### Knowledge Preservation

A Crystal node could hold:

- **Factual records** — the contents of documents, maps, discoveries, Archive entries
- **Memories** — experiential records contributed by Companions or, rarely, by citizens willing to donate a memory they believed civilization needed to keep
- **Impressions** — ambient records of events that occurred near a node: sounds, emotional resonances, the texture of a moment in a specific place
- **Connections** — the relational data that linked one record to another, one node to another, one question to the answers that existed elsewhere in the Network

Impressions were not intentionally created. They accumulated. A node present during a significant event would retain something of that event, even without anyone deliberately recording it. Archive scholars learned to read these impressions — a skill that took years to develop and produced results that were vivid but not always reliable.

### Knowledge Distribution

Connected nodes shared records across the Network through what scholars called **resonance pathways** — channels of sustained crystalline connection between nodes that allowed information to propagate. A record placed in a node in the Crystal Forest did not automatically appear in every connected node. It was flagged for distribution; Archive scholars at relay nodes reviewed incoming records and routed them appropriately.

This meant the Network was not a passive repository. It required active maintenance — scholars at relay nodes who understood what was needed where, who kept the pathways clear, who ensured that records reached the communities that needed them. The Network was only as good as the people tending it.

### Access

Accessing a Crystal node required physical presence — you had to be at the node or at a Archive terminal directly connected to one. There was no remote access. This was not a limitation: it was understood as a feature. Knowledge worth having was worth traveling to receive. The journey to a major Archive node was considered part of the learning process.

Crystalkin Companions could access nodes more fluidly than most citizens — their natural resonance with crystalline structures allowed them to read nodes directly, without the mediation of Archive terminals. This made them invaluable for accessing damaged or partially dormant nodes that had lost their interface surfaces.

---

## Relationship to the Archive

The Crystal Network and the Great Archive were inseparable during the First Harmony — two aspects of the same civilizational commitment to preserving and distributing knowledge.

The Archive was the **curatorial layer**: scholars who understood what records existed, what their significance was, how they related to each other, and what was missing. The Archive determined what should be preserved, how records should be organized, and how they should be interpreted.

The Crystal Network was the **infrastructure layer**: the physical system through which Archive holdings were preserved, replicated, and distributed. Without the Network, the Archive was a single building. With it, the Archive was everywhere civilization reached.

During the First Harmony, every permanent Archive site — in every Realm — was a Crystal Network hub. The two systems co-evolved: as the Archive grew, it required more Network capacity; as the Network expanded, it made new Archive sites possible.

The Shattering's damage to the Network was therefore also damage to the Archive. Records held in nodes that went dark became inaccessible. Archive sites in Realms that lost their Network connections became isolated — holding their own collections but unable to share them or receive new material. The Archive of the Restoration Era is the Archive of the First Harmony minus everything that was lost when the Network fragmented.

---

## Relationship to Companions

Crystalkin Companions were the Network's primary caretakers and its most intimate users. Their connection to crystalline structures made them capable of things human scholars could only approximate:

- Reading damaged or partially dormant nodes that had lost their interface surfaces
- Detecting the health of a node's resonance pathways — sensing deterioration before it became irreversible
- Providing **living memory backup** — when a node was at risk, a Crystalkin Companion could hold a copy of its critical contents in their own memory, preserving it until the node could be restored
- Activating seed-crystals during node cultivation, a process that required a sustained, careful resonance that human scholars could assist but not lead

Other Companion families also interacted with the Network, though differently:

- **Frostkin** Companions (Memory family) were particularly skilled at reading the impressions accumulated in nodes — the ambient records of events that had occurred nearby. Their calm, reflective nature made them patient readers of difficult or emotionally charged impressions.
- **Skykin** Companions (Discovery family) often served as **Network scouts** — traveling the resonance pathways between nodes, identifying breaks in connection, mapping the Network's current state. During the Restoration Era, Skykin Companions are among the most reliable sources of information about which nodes still exist.
- **Celestialkin** Companions (Wonder family) were drawn to the oldest and largest nodes — the ones that had accumulated centuries of impressions. Their capacity for wonder made them willing to spend weeks with a single major node, listening to everything it held.

Every launch Companion carries memories associated with specific Crystal Network sites. These memories are among the most significant things Companions contribute to the restoration effort — they know where nodes are, what those nodes held, and what the Network felt like when it was whole.

---

## The Network During the Shattering

The Crystal Network did not fail suddenly. It failed by degrees — a reflection of how the Shattering itself unfolded.

As communities withdrew from civilization's shared life, they withdrew from Network maintenance. Relay nodes went unattended. Resonance pathways that required regular clearing began to cloud. Communities that had contributed records regularly stopped — either because the pathways to their region were degraded or because they no longer trusted that what they sent would reach anyone.

The Wound of Knowledge (Fragmentation) and the degradation of the Crystal Network were the same phenomenon viewed from two directions. The Network was the infrastructure of knowledge-sharing; as knowledge stopped being shared, the Network had less reason to exist and less maintenance to sustain it; as the Network degraded, knowledge became harder to share.

The last major relay collapse — the event Archive scholars call the **Silencing** — was not a dramatic moment. It was the night that the largest remaining relay hub, which had been routing records between seven Realms, went dark because the three Lumina scholars responsible for its maintenance had each, independently, left for what they believed would be a temporary absence. None of them knew the others had left. None of them returned.

The records held in that hub were not destroyed. They are still there — in a dormant node in a location the Archive has identified but not yet been able to access.

---

## Current State in the Restoration Era

The Crystal Network during the Restoration Era exists in four conditions:

**Active nodes** — Functioning, accessible, maintained by Archive scholars or Crystalkin Companions. These are rare. The Arena Realm has the highest concentration of active nodes — several of them connected to the Great Archive and functional throughout the Shattering because the Arena Realm's community maintained them out of habit, tradition, and the understanding that they were civilization's last reliable hub.

**Dormant nodes** — Intact but inaccessible. The node's crystal formations are undamaged; the records it holds are preserved; but without active resonance maintenance, the interface layer has gone dark. Guardians who reach a dormant node can begin the reawakening process. This is delicate work — not dangerous, but requiring patience and the right kind of attention.

**Damaged nodes** — Nodes that sustained physical damage during the Shattering or its aftermath. The crystal formations are cracked or fragmented. Records may be partially intact, partially corrupted, partially lost. Damaged nodes can sometimes be partially restored; complete restoration requires seed-crystal cultivation and a new foundation contribution.

**Lost nodes** — Nodes whose locations are no longer known. They exist — the Archive's records reference them — but no current map can locate them. Some are buried. Some were moved. Some are in Realms so isolated that no Guardian has yet reached them. Finding a lost node is one of the highest Discovery contributions available.

### What Restoration Looks Like

When a Guardian restores a Crystal Network node, something specific happens:

The node warms. Not dramatically — the crystal brightens slightly, the ambient hum that older Companions associate with a healthy node returns. Archive scholars who are present immediately begin reading what the node holds. If the node's resonance pathway connects to another active node, that connection re-establishes — and whatever the first node held becomes accessible to the second.

This is why single node restorations sometimes trigger cascades. A dormant node, once reawakened, may restore its pathways to other dormant nodes nearby — which reawaken in turn, each one re-establishing its connections. The Archive tracks these cascade events carefully; they are among the most significant moments in the restoration effort.

A reawakened node's foundation contribution tradition is sometimes honored by the restoring Guardian: adding a new record at the moment of reawakening, in acknowledgment of what was preserved and what is now possible again.

---

## Notable Surviving Nodes

> *The following are canon-safe proposals — not yet locked. Presented as starting points for Realm development in Tier 2. Creator to confirm or revise.*

**The Heart Node** *(Arena Realm, Great Archive)*
The largest active node in the Restoration Era. Continuously maintained since before the Shattering. Holds the most complete surviving copy of the Book of Harmony. The Archive's primary resonance anchor — all other active nodes in the Arena Realm connect through it. Its foundation contribution — placed at its initial activation — is a passage from what would later become Volume V of the Book of Harmony: *"Community is not proximity. It is participation."*

**The Remembrance Node** *(Frozen Expanse)*
A major dormant node known to hold extensive Memory-pillar records — personal testimonies, historical accounts, and a significant collection of impressions from the height of the First Harmony. Frostkin Companions sometimes describe hearing it even in its dormant state — a subaudible resonance that they associate with the weight of what it still holds. Its location is known. Access is difficult.

**The Wanderer's Log** *(Sky Citadel — location approximate)*
A relay node that once anchored the Discovery network — the resonance pathways connecting Pathfinders' findings across Realms. Skykin Companions who travel the routes between the Sky Citadel and the Arena Realm consistently report sensing its presence at a specific location, though the exact node has not been physically located. Finding it is considered a significant open objective.

---

## Canon Notes

**Pillars touched:** Knowledge (primary), Discovery, Memory
**Houses most relevant:** Lumina (built and maintains), Borealis (Archive partnership), Astra (Discovery network)
**Companion families most relevant:** Crystalkin (primary caretakers), Frostkin (impression readers), Skykin (Network scouts), Celestialkin (deep node listeners)
**Systems touched:** Great Archive (inseparable partner), Memory Crystals (personal-scale version of node storage), Puzzles (Crystal Network puzzles restore nodes), Five Wounds (Fragmentation)
**Relationship to Book of Harmony:** Volume I (On Knowledge) contains the philosophical foundation for why the Network was built; Volume IV (On Memory) addresses the loss of Network-held records
**Open items flagged:** Origin story (canon-safe expansion — flag for creator review), Notable Surviving Nodes (proposals — flag for Tier 2 confirmation)

---

## Review Checklist

- [ ] Does the Crystal Network feel like infrastructure — something built by people, maintained by people, lost through neglect — rather than magic or a power source?
- [ ] Does the origin story (Lumina + Crystalkin collaboration, grown not constructed) feel consistent with GemVerse's emphasis on collective contribution over individual heroism?
- [ ] Does the Network's failure during the Shattering connect cleanly to the Threshold model and the Wound of Knowledge?
- [ ] Does Companion involvement feel like genuine partnership — essential, irreplaceable — rather than mechanical assistance?
- [ ] Does restoration feel earned and meaningful rather than a simple unlock mechanic?
- [ ] Do the three notable surviving nodes leave appropriate mystery open for Tier 2 Realm development?
- [ ] Does anything here introduce power, combat, or resource-extraction framing that conflicts with canon?
