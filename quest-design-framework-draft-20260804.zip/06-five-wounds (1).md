# The Five Wounds
**GemVerse Master Bible — Tier 1 Entry**
**Status:** Canon-Safe Expansion | Working draft names confirmed as locked canon this session
**Canon Source:** Transfer Volume 1; First Harmony (now locked); Book of Harmony (locked); Perplexity session canon
**Depends on:** Book of Harmony, First Harmony (both complete)

---

## Purpose

This document is the full Master Bible entry for the Five Wounds — the five civilization-scale fractures caused by the Shattering. It establishes each Wound's identity, what was lost, how it manifests in the Restoration Era, and what healing looks like. The Five Wounds are the primary framework through which Guardians understand what they are restoring and why.

---

## What the Five Wounds Are

The Five Wounds are not physical injuries. They are not battle scars. They are not the work of a villain.

They are what civilization lost when the Pillars drifted too far apart to support each other — five fractures in the fabric of a world that had, for three centuries, held itself together through connection, memory, and shared contribution.

Each Wound corresponds to a Pillar that became disconnected from the others. Each represents not a single catastrophic event but the slow, compounding consequence of neglect — the kind of damage that happens when something that required constant attention stops receiving it.

The wounds did not appear in sequence. They deepened together, each one making the others worse, until the Threshold was crossed and the systems that civilization depended on collapsed simultaneously.

They are called Wounds because that is what they feel like to live inside. Not disasters. Not ruins. Wounds. Still present. Still aching. Capable of healing — but only with care, time, and the right kind of attention.

---

## The Five Wounds

### Wound of Knowledge — The Fragmentation

**Pillar:** Knowledge
**House Alignment:** Lumina
**Nature:** Knowledge stopped flowing. Research became isolated. Discoveries were made but not shared.

**What Was Lost**

During the First Harmony, knowledge moved. A discovery in the Crystal Forest arrived at the Archive in the Arena Realm within days, distributed through the Crystal Network to researchers across every Realm. A question asked in the Frozen Expanse could receive answers from scholars in the Sky Citadel who had been working on the same problem from a different direction.

When communities began to specialize and withdraw, knowledge stopped moving. Discoveries were made — research did not stop — but the results stayed local. Scholars in one Realm solved problems that scholars in another Realm were still struggling with, unaware the solution existed. Libraries accumulated without distributing. The Crystal Network, starved of connection, carried less and less.

What was lost was not knowledge itself. What was lost was the understanding that knowledge belongs to everyone who needs it.

**How It Manifests in the Restoration Era**

- Fragments of the same discovery exist in multiple locations, separated from each other, each incomplete
- Archive records reference works that cannot be located — the works exist somewhere, but no one knows where
- Communities have developed local solutions to problems that civilization had already solved before the Shattering — rebuilding knowledge that was never lost, simply fragmented
- Scholars sometimes encounter the same puzzle from opposite directions, not realizing they are working toward the same answer

**What Healing Looks Like**

The Wound of Knowledge heals when discoveries are shared rather than hoarded. When a Guardian recovers a Crystal Network node, restores an Archive connection, or brings a fragment from one location to complete a record held in another — that is the Wound of Knowledge being addressed. It heals through reconnection, not reconstruction. Most of what was lost still exists. It is simply separated from itself.

**Guardian Contribution**
Crystal Network restoration, Archive contribution, cross-Realm knowledge exchange, recovering lost records, completing fragmented discoveries.

---

### Wound of Discovery — The Isolation

**Pillar:** Discovery
**House Alignment:** Astra
**Nature:** Exploration disconnected. Realms drifted apart. Paths between communities closed.

**What Was Lost**

Discovery during the First Harmony was understood as a shared project — a Pathfinder's find belonged to civilization, not to the Pathfinder or their Realm. Routes were maintained as civic infrastructure. Maps were kept current by the Archive and distributed freely. A traveler moving between Realms could follow Lantern routes and Crystal waypoints, confident they would find community at each stop.

As specialization deepened, travel became less common. Routes fell into disrepair when the communities responsible for maintaining them turned their attention inward. Pathfinders had fewer places to bring what they found. The joy of discovery — which had always been partly the joy of bringing something back to share — dimmed when there was nowhere obvious to bring it.

What was lost was not the capacity for discovery. What was lost was the infrastructure of return — the network of places and people that made exploration meaningful rather than merely solitary.

**How It Manifests in the Restoration Era**

- Realms that were once two days' travel apart now feel unreachably distant — not because the distance changed but because the routes between them are overgrown, unmapped, or forgotten
- Pathfinders still exist, but many work alone, without the support structures that once made long-range exploration sustainable
- Some discoveries are never shared because there is no clear path back to the people who need them
- Certain Realm boundaries have become effectively walls — not by decree but by neglect

**What Healing Looks Like**

The Wound of Discovery heals when connections between Realms are rebuilt — when a Guardian maps a route, restores a waypoint, or creates the conditions for a Pathfinder to return safely with what they found. It also heals through celebration: recognizing discovery publicly, contributing findings to the Archive, ensuring that what is found does not stay found only by one person.

**Guardian Contribution**
Realm exploration, route restoration, waypoint recovery, Pathfinder support, cross-Realm connection, discovery contribution to the Archive.

---

### Wound of Growth — The Decay

**Pillar:** Growth
**House Alignment:** Verdance
**Nature:** Communities stopped nurturing the future. Mentorship weakened. The next generation was prepared for a narrower world.

**What Was Lost**

Growth during the First Harmony was understood broadly — not just personal development but the development of communities, traditions, and the conditions that allow the next generation to flourish. Mentorship was a civic obligation. Communities invested in their young people's capacity to contribute to the whole of civilization, not just to the immediate community.

As communities turned inward, growth narrowed. Children were prepared for local contribution rather than civilizational contribution. The expectation that a young person might travel, study in another Realm, and return changed — it became unusual, then rare. Mentorship became about passing on what the local community knew rather than expanding toward what civilization knew.

The consequence was not immediate. A generation raised in a narrowing world does not know it is narrow. The decay was quiet. Communities continued to function, continued to grow in their own terms. What they lost was the connection between their growth and civilization's growth — the sense that their development served something larger than themselves.

**How It Manifests in the Restoration Era**

- Traditions that once renewed themselves through cross-community contact now repeat without renewal — forms preserved but meaning forgotten
- Young citizens in isolated communities express the sense that there is no larger world to contribute to — not from hopelessness, but from simple unfamiliarity
- Skills that require civilization-scale infrastructure to practice have become rare: certain kinds of Archive scholarship, Crystal Network maintenance, Lantern Keeper traditions
- Mentorship still exists but is often local and narrow — exceptional mentors who think in civilizational terms are rare and recognized immediately

**What Healing Looks Like**

The Wound of Growth heals when communities reconnect their development to civilization's development. When a Guardian supports a young citizen's access to Archive knowledge from beyond their Realm, establishes a connection between mentors and learners across communities, or helps a tradition find new meaning through contact with its larger context — that is this Wound being addressed.

**Guardian Contribution**
Mentorship, education support, community development projects, cross-community connection, renewing traditions, expanding local horizons toward civilizational participation.

---

### Wound of Memory — The Forgetting

**Pillar:** Memory
**House Alignment:** Borealis
**Nature:** Records disappeared. History became uncertain. The story civilization told about itself developed gaps — and then stopped being told.

**What Was Lost**

Memory during the First Harmony was the work of everyone. Citizens contributed records to their local Archive sites. Oral traditions were maintained alongside written ones. The Crystal Network preserved discoveries and distributed them so that the loss of one node did not mean the loss of its contents. The Book of Harmony described memory preservation as civic work — not the province of specialists but the responsibility of anyone who had something worth remembering.

When the Crystal Network began to fail, records that had only been stored in nodes became inaccessible. Communities that had relied on the Network stopped contributing to it — it seemed pointless to add records to a system that was failing. The Archive, receiving less, had less to distribute, which made communities trust it less, which made them contribute less. Volume IV of the Book of Harmony — On Memory — suffered the deepest damage in the Shattering. That irony is not lost on Archive scholars.

What was lost is not fully known, because what was lost includes the record of what was lost.

**How It Manifests in the Restoration Era**

- Archive records contain references to documents, events, and people that cannot be located anywhere — the records of the records exist, but not the records themselves
- Communities hold traditions whose meaning has been forgotten — the practice survives but the story behind it does not
- Companions carry memories of events for which no written record exists — they are the only source
- Historians working in the Restoration Era regularly encounter the discovery that something they believed was known is actually only assumed — the original source is missing
- Volume IV of the Book of Harmony is the most incomplete volume in every surviving Archive copy

**What Healing Looks Like**

The Wound of Memory heals when records are recovered, verified, and contributed to the Archive. When a Companion's testimony is recorded for the first time. When a community's forgotten tradition is traced back to its origin. When a Guardian recovers a Crystal Network node and discovers what it was holding. Memory does not return all at once — it returns one recovered fragment at a time.

**Guardian Contribution**
Archive contribution, Crystal Network node recovery, Companion testimony recording, tradition research, Memory Crystal creation, Book of Harmony fragment recovery.

---

### Wound of Belonging — The Division

**Pillar:** Belonging (Hidden Eighth)
**House Alignment:** None (Belonging has no House)
**Nature:** Citizens stopped feeling connected to each other and to civilization. The ambient sense of being part of something larger quietly disappeared.
**Severity:** Likely the deepest Wound. Certainly the least visible.

**What Was Lost**

Belonging during the First Harmony was never named. It did not need to be. It was present in the texture of daily life — in the assumption that one's contribution mattered, that one's stories would be preserved, that one's children would inherit something worth inheriting. It was present in the festivals where communities from different Realms chose to know people they didn't have to know. It was present in the Archive, which said through its very existence: you are worth remembering.

As the other Pillars drifted and the systems that connected civilization weakened, Belonging did not announce its departure. People did not wake up one day and declare themselves disconnected. They simply felt, gradually, that there was less point to contribution — that their discoveries went nowhere, that the larger civilization was not really there anymore, that the future was not really theirs to shape.

The Wound of Belonging is not despair. It is something quieter: the absence of the feeling that you are part of something. The failure of the condition that allows people to show up fully.

**How It Manifests in the Restoration Era**

- Communities exist that function adequately but feel hollow to the people inside them — they produce, they maintain, but they do not feel like civilization
- Citizens who have traveled to the Arena Realm often describe the experience as being reminded that a larger world exists — as if they had forgotten to expect it
- Some communities have lost their festival traditions entirely — and with them, the structured opportunity to connect with people beyond their immediate circle
- The Harmony Index has no metric for Belonging — it cannot be measured, only felt
- Companions who experienced the First Harmony sometimes grieve not a specific loss but the loss of a feeling: the feeling of being witnessed by a civilization that cared

**What Healing Looks Like**

The Wound of Belonging cannot be healed by any single action. It heals as the other four Wounds heal — when knowledge flows again, when discovery is celebrated and shared, when communities reconnect their growth to civilization's, when memory is recovered and preserved. Belonging is what emerges when all of that is working.

It also heals through specific, personal acts: when a Guardian sits with a citizen and listens to their story. When a festival reconnects communities that had stopped knowing each other. When a Companion's memory is honored in the Archive. When someone looks around and realizes they are not alone in this work.

There is no progress bar for the Wound of Belonging. Guardians who focus only on measurable restoration will not notice it healing. Guardians who pay attention will.

**Guardian Contribution**
Festival participation, community engagement, listening to citizens, honoring Companion memories, mentorship, showing up — repeatedly, over time, without requiring recognition for it.

---

## The Five Wounds Together

The Five Wounds are not independent. Each one weakens the conditions that would allow the others to heal.

A civilization that cannot share knowledge (Fragmentation) cannot coordinate recovery from isolation (Isolation). Communities that have stopped growing in a civilizational direction (Decay) produce fewer people capable of the sustained Archive work that would address Forgetting. And none of the other four Wounds can fully heal while communities feel no reason to contribute to something beyond themselves (Division).

This is why the Restoration Era requires Guardians who understand all five — not just the one they are most naturally equipped to address. A Scholar who restores Crystal Network nodes without also attending to community belonging is healing one Wound while the others quietly deepen. A Mentor who rebuilds local community without recovering lost records leaves civilization without the memory it needs to understand what it is rebuilding.

The Five Wounds heal together or they heal slowly. The Harmony Index reflects this: Realm Harmony, Community Harmony, and Civilization Harmony rise together as Guardians contribute across all five dimensions.

---

## What the Five Wounds Are Not

- They are not punishment. No civilization was judged and found wanting.
- They are not permanent. Each is capable of healing with sustained, genuine effort.
- They are not someone's fault. The drift that caused them was civilizational — the result of countless small decisions, none of them malicious.
- They are not equal. The Wound of Belonging is considered deepest because it is the condition that makes healing the other four possible. Without belonging, there is no reason to contribute to restoration.
- They are not a checklist. A civilization where all five metrics are high but belonging is absent is not a healed civilization. It is a functional one. The difference matters.

---

## Canon Notes

**Pillars touched:** Knowledge, Discovery, Growth, Memory, Belonging (all five Wound-aligned Pillars)
**Houses touched:** Lumina, Astra, Verdance, Borealis (four Houses align to four Wounds; Belonging has no House)
**Paths most relevant:** All six Paths address different Wounds — no single Path heals all five
**Systems touched:** Crystal Network (Fragmentation), Lantern Network (Isolation), Great Archive (Forgetting), Harmony Index (all five), Festivals (Division/Belonging)
**Establishes foundation for:** Crystal Network entry (Fragmentation context), Lantern Network entry (Isolation context), Restoration Era entry (all five Wounds are ongoing)
**Relationship to Book of Harmony:** The Twelve Principles speak directly to each Wound — particularly Principles 2–5 (imbalance passages) and Principle 7 (Belonging cannot be commanded)
**Open items:** None — all five Wound names, descriptions, and recovery directions are now locked canon

---

## Review Checklist

- [ ] Do all five Wounds emerge from Pillar imbalance — with no villain, no single cause, no group to blame?
- [ ] Does the Wound of Belonging feel meaningfully different from the other four — less visible, less measurable, potentially deepest?
- [ ] Does the Threshold model (from the First Harmony entry) connect cleanly to the simultaneous emergence of all five Wounds?
- [ ] Does each Wound's "What Healing Looks Like" section map directly to Guardian actions that are already established in the gameplay loop?
- [ ] Does the section "The Five Wounds Together" reinforce interdependence without making any single Wound feel irrelevant?
- [ ] Does "What the Five Wounds Are Not" preempt any grimdark, blame, or punishment framing?
- [ ] Does the Wound of Memory's line — "What was lost includes the record of what was lost" — feel appropriately devastating without being hopeless?
