# Shared Project Context Template

Use this document to store project-specific material that builds up over time and should be readable by all assistants working on the same project.

## File status
- File owner:
- Current version: v1.0
- Last updated date: 2026-06-02
- Last updated time: 14:44 AEST
- Updated by: Assistant
- Source of truth location:

## Change log
- 2026-06-02 | 14:44 AEST | v1.0 | Added versioning fields and timestamp tracking to the shared project context template. | Makes it easier to identify and upload the latest copy.

## Purpose

This file is the shared knowledge base for one specific project.
It should contain the project context that is not part of the global workflow template.
All assistants should treat this file as the primary reference for project-specific background, decisions, constraints, and working assumptions.

## How assistants should use this file

- Read this file before making project-specific recommendations when it is available.
- Treat the contents as shared context for all assistants in the project.
- Do not overwrite established project decisions here without clear instruction.
- Add new decisions, constraints, and conventions in a way that keeps the document easy to scan.
- If information in this file conflicts with the global workflow template, the global workflow governs process, while this file governs project-specific context.

## Suggested sections

### 1. Project overview
- Project name
- Short description
- Main objective
- Current stage

### 2. Goals
- Primary goals
- Secondary goals
- Success criteria

### 3. Scope
- In scope
- Out of scope
- Current priorities

### 4. Assistant roles for this project
- List the active assistant titles for this project
- Define what each assistant owns
- Note any handoff rules between assistants

### 5. Key decisions
- Important decisions already made
- Why they were made
- What should not be changed without approval

### 6. Constraints
- Technical constraints
- Brand constraints
- Marketplace constraints
- Budget, time, or staffing constraints

### 7. Standards and conventions
- Naming conventions
- Formatting preferences
- Content rules
- Structural rules

### 8. Reference materials
- Important source files
- Key documents
- Links or file names that assistants should check first

### 9. Open questions
- Unresolved decisions
- Pending approvals
- Missing information

### 10. Change log
- Date
- Time
- Version
- What was added or changed
- Why it matters

## Working note

Keep this file project-specific.
Do not use it for general assistant behavior rules that belong in the global workflow template.
Use one copy of this file per project and update it over time as the shared source of truth.
