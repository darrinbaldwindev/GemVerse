# Citizen Encyclopedia Entry — Mira
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.11  
**Linked Files:** `01-canon-map.md`, `imp-03-citizen-life-layer.md`, `imp-04-companion-relationship-web.md`

---

## Overview

**Name:** Mira  
**Themes:** Creativity, Imagination, Expression  
**Path Alignment:** Harmonist Path (Harmony Pillar)  
**Visual Identity:** [Pending - Character art not yet available]  
**Symbol:** Paintbrush with Light Trails (representing creativity that illuminates connections)  
**Notable Traits:** Boundless imagination, ability to visualize abstract concepts, natural mediator through creative expression

---

## 1. Background

Mira grew up in the Twilight Frontier, a realm where the boundaries between the known and unknown are delightfully blurred. Their childhood was filled with stories that changed each time they were told, landscapes that shifted with the light, and a community that celebrated questions more than answers.

From an early age, Mira showed an unusual ability to see connections that others missed - not logical connections, but creative ones. They could look at a problem and immediately visualize multiple metaphorical approaches, seeing how a gardening challenge might be illuminated by a music metaphor, or how a community conflict might be resolved through a shared art project.

This creative perspective wasn't always understood in more structured environments. When Mira's family spent time in the Crystal Forest for a scholarly exchange, Mira found the rigid categorization systems constraining. They kept asking "what if this means something else?" and "what if we looked at it through a different lens?"

A visiting Harmonist recognized Mira's gift and invited them to train in the Harmonist Path - not to constrain their creativity, but to give it structure and purpose. The training taught Mira how to channel creative thinking into harmony restoration: how to use metaphor and imagination to help people see past rigid positions, how to use collaborative art to build connections between divided groups, and how to use creative expression as a form of civilizational healing.

---

## 2. Role in Society

Mira serves as a **Creative Harmony Facilitator** in the Twilight Frontier, working at the intersection of community life and the more mysterious aspects of the realm. Their role involves:

- **Metaphorical Mediation**: Helping conflicting parties find common ground through creative reframing
- **Community Expression Projects**: Organizing collaborative creative work that builds connections
- **Mystery Integration**: Helping communities live comfortably with the unknown elements of the Twilight Frontier
- **Imagination Cultivation**: Encouraging creative thinking as a civilizational skill, not just an artistic pursuit

Mira is particularly valued for their ability to work with ambiguity. The Twilight Frontier contains many phenomena that don't fit neat categories - whispers in the wind that might be memories or might be imagination, paths that appear only to those who aren't looking for them, structures that change when observed from different angles. While others find this unsettling, Mira helps communities see it as an invitation to creative engagement rather than a problem to solve.

They also serve as a bridge between the more structured civilizational systems and the inherently mysterious nature of the Twilight Frontier. When Archive scholars try to document frontier phenomena using standard methods, Mira helps them develop creative approaches that respect the phenomena's nature while still capturing useful information.

---

## 3. Relationships

### Companion Connections

Mira has developed particularly strong relationships with several companions:

- **Nimbus**: Both work with the unknown - Nimbus through exploration, Mira through imagination. They often collaborate on "what might be there" projects.
- **Galewing**: Shares the joy of discovering new perspectives. Galewing's path-singing creates routes; Mira's creativity finds meaning in the journey.
- **Prism**: Deep intellectual connection. Prism shows multiple perspectives; Mira helps people emotionally inhabit those perspectives.
- **Bloomtail**: Collaborates on community creative projects. Bloomtail's growth facilitation provides the structure for Mira's creative expression.

### Citizen Relationships

- **Mentor**: A senior Harmonist who taught Mira to channel creativity into civilizational service
- **Peers**: Other Harmonist Path practitioners who appreciate Mira's unconventional approaches
- **Community Artists**: Citizens in the Twilight Frontier who participate in collaborative expression projects
- **Younger Citizens**: Often drawn to Mira's ability to make the mysterious feel wondrous rather than frightening

### Institutional Relationships

- **Harmony Council Representatives**: Consults on approaches to civilizational challenges that resist standard solutions
- **Archive Creative Documentation Division**: Works on recording phenomena that don't fit standard categories
- **Twilight Frontier Community Council**: Serves as creative voice in community decision-making

---

## 4. Personal Goal

Mira's current personal goal is to develop a **Creative Resilience Framework** - a set of practices that help communities use imagination and creative expression to navigate uncertainty, loss, and change.

This involves:
- Developing collaborative creative practices for communities facing difficult transitions
- Creating "imagination exercises" that help people see new possibilities in constrained situations
- Building frameworks for documenting creative community responses to challenges
- Establishing creative mentorship programs that pass on imaginative resilience skills

They're working on this with Harmonist scholars, Archive creative specialists, and companions who understand the relationship between creativity and civilizational health.

---

## 5. Contribution Story

Mira's most significant contribution came during a period when several Twilight Frontier communities were experiencing a mysterious phenomenon - citizens were having shared dreams of a place that didn't exist on any map, a "city of light" that appeared in dreams but couldn't be found in waking exploration.

Rather than treating this as a problem to solve or a delusion to dismiss, Mira recognized it as a collective creative expression of the communities' longing for connection and hope. They organized a **Shared Dream Project** where communities collaboratively built physical representations of the dream-city - not as literal constructions, but as art installations that captured its essence.

This project:
- Brought together communities that had been growing apart due to different interpretations of the phenomenon
- Created beautiful shared spaces that became gathering places for cross-community connection
- Resulted in documented creative methodologies now used in other Realms for collective visioning
- Helped citizens understand that some civilizational needs express themselves through imagination rather than logic

The project's success demonstrated that creative approaches can address civilizational challenges that logical methods cannot reach.

---

## 6. Legacy Story

Mira's work is beginning to influence how other Realms approach the relationship between imagination and civilizational health. The **Creative Resilience Framework** is being studied by Harmonist scholars and community leaders across multiple Realms.

Archive scholars have documented Mira's approach as a significant evolution in understanding how imagination serves civilizational resilience - not as escape, but as a way of perceiving possibilities that logical analysis alone cannot reveal.

Mira hopes their legacy will be a civilization that values imagination as a practical skill for navigation, problem-solving, and community building - not just as decoration for festivals. They see creative thinking as essential for a civilization that's restoring itself: when you're rebuilding something that's never existed in quite this form before, imagination isn't optional - it's essential.

---

## Citizen Abilities (Narrative, Not Mechanical)

- **Creative Reframing**: Can help people see situations through new metaphors and perspectives
- **Collaborative Expression Facilitation**: Guides groups in creative projects that build connection
- **Ambiguity Navigation**: Helps communities live productively with uncertainty and mystery
- **Cross-Domain Metaphor Building**: Connects disparate concepts through creative analogy
- **Imagination Cultivation**: Develops creative thinking as a practical civilizational skill

---