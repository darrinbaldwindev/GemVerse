# Arena Slice QA Script

Version: v1  
Status: Draft — Internal Testing Aid  
Date: 2026-06-09 AEST  

Project: GemVerse  
Realm: Arena  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related file: `arena-first-experience-spec-v1.md`

---

## Purpose

Use this script after playing the Arena first slice prototype to check whether the experience actually feels like GemVerse in practice, not just on paper.

This script is intended for creator review, internal playtesting, or assistant-led self-audit.

---

## Test Setup

Before running this script:

- Play the slice from the beginning without skipping text.
- Do one pass as a new player and one pass as a reviewer.
- Answer the questions immediately after each pass.

---

## Core Questions

### 1. What did Arena feel like?

Choose the strongest fit:

- [ ] A civic crossroads / gathering place
- [ ] A puzzle hub with light story dressing
- [ ] A battleground / challenge space
- [ ] Unclear

Target answer: civic crossroads / gathering place.

### 2. What did the puzzle feel like?

Choose the strongest fit:

- [ ] Restoring a meaningful pattern from the world
- [ ] Solving an abstract game board
- [ ] Beating a level for progression
- [ ] Unclear

Target answer: restoring a meaningful pattern from the world.

### 3. How did success feel?

Choose the strongest fit:

- [ ] Quiet restoration / reconnection
- [ ] Standard game victory
- [ ] Score or performance reward
- [ ] Unclear

Target answer: quiet restoration / reconnection.

### 4. If a companion appeared, what role did they feel like they played?

Choose the strongest fit:

- [ ] Witness / presence / memory keeper
- [ ] Hint tool or mechanic helper
- [ ] Mascot with no real role
- [ ] No companion shown

Target answer: witness / presence / memory keeper.

### 5. Did any line of copy feel off-tone for GemVerse?

- [ ] No
- [ ] Yes

If yes, note the exact line and why it felt wrong.

---

## Red-Flag Checks

Mark any that appeared during the slice:

- [ ] Combat or strength framing
- [ ] Savior / hero language
- [ ] Power-up / booster language
- [ ] Combo multiplier emphasis
- [ ] Energy / stamina / lives language
- [ ] Companion treated like a tool
- [ ] Puzzle felt arbitrary rather than in-world
- [ ] Archive reveal felt disconnected from the puzzle

If any box is checked, the slice needs another revision pass before being treated as on-tone.

---

## Short Reflection Prompts

Answer in one or two sentences each.

1. What was the strongest GemVerse-feeling moment in the slice?
2. What felt most generic or closest to an ordinary puzzle game?
3. What one change would most improve the sense of restoration and belonging?
4. Did the final Archive fragment make the puzzle feel more meaningful?
5. Would this slice make you want to see another realm memory restored?

---

## Pass / Revise Rule

Treat the slice as ready for the next internal step only if:

- Arena clearly reads as civic space,
- the puzzle clearly reads as a civilizational remnant,
- the success state feels restorative,
- and no major red-flag checks are triggered.

If two or more red flags appear, revise before expanding the slice.
