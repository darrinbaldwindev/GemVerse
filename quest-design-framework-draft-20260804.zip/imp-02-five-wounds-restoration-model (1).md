---
title: IMP #2 — Five Wounds Restoration Model
tier: IMP
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: Five Wounds (Tier 1), Crystal Network (Tier 1), Lantern Network (Tier 1)
feeds-into: Quest Design, Puzzle Catalog (Task 8), Harmony Index, Narrative Bible (Tier 5)
---

# IMP #2 — Five Wounds Restoration Model

**GemVerse Implementation Packet**
**Purpose:** This document translates the Five Wounds from philosophical framework into practical implementation logic. It answers the design question: *How does healing actually work?* What does a Guardian do, specifically? What does the world look, feel, and sound like as each Wound begins to close? What is the pace of recovery, and what does it demand from players, writers, and quest designers?

This packet does not introduce new canon. It deepens the Five Wounds Tier 1 document with the implementation layer needed to build from it.

---

## Framing: How Healing Works in GemVerse

Restoration in GemVerse is not a meter filling. It is not a countdown. It is the slow, non-linear return of conditions that civilization requires to function — conditions that were not lost in a single moment and cannot be recovered in one.

The appropriate mental model is ecological recovery: a forest regenerating after a long dry spell. Healing is visible only at scale, over time. Individual contributions matter enormously; no single contribution completes the work. The forest does not announce when it has crossed the threshold from damaged to recovering. It simply begins, gradually, to sound and smell and feel like a forest again.

Guardians are contributors to this process. They are not its heroes. They do not save the world. They restore the conditions under which the world can continue to save itself.

Three design rules govern every Wound's restoration:

1. **No single action heals a Wound.** Wounds heal through accumulation — many contributions, across many realms, over extended time.
2. **Healing is always visible in the world before it is visible on any metric.** NPCs change. Environments shift. The Archive updates its records. Players should feel healing happening before they see any number confirm it.
3. **The Wound of Belonging never has a number.** Everything else may eventually register somewhere on the Harmony Index. Belonging does not. It is felt.

---

## Wound I — The Fragmentation (Wound of Knowledge)

**Pillar:** Knowledge | **House:** Lumina | **Harmony Index Axis:** Knowledge Harmony

### 1. Current World State

The Fragmentation is the Wound that civilization cannot easily see from inside it, because the knowledge that would let communities recognize their own incompleteness is itself missing.

In the Restoration Era, the Crystal Forest glimmers with nodes that receive no signal. The Archive in the Arena Realm holds thousands of index entries for documents that cannot be located — the record of the record, but not the record. In the Sky Citadel, a research circle has spent two generations working on a problem that a scholar in the Twilight Frontier solved forty years ago. Neither group knows the other exists.

The world sounds like this: quiet rooms full of careful people working on partial pictures. Libraries that accumulate without distributing. Scholars who ask questions into silence. The Crystal Network nodes that are still active hum at lower resonance than they once did — faint, like a voice heard from the next room.

### 2. What Healing Looks Like

Recovery from the Fragmentation is not about creating new knowledge. The knowledge, in most cases, still exists somewhere. It is about restoring the pathways between existing knowledge and the people who need it.

**Early stage:** Individual Crystal Network nodes are restored. The Archive receives its first new submissions from communities that had stopped contributing. Scholars in separate realms begin receiving references to each other's work. A community discovers that the "unsolvable" problem they've been living with has a documented solution in an Archive record they couldn't access.

**Middle stage:** Cross-realm knowledge exchanges become regular. Lumina scholars begin a Knowledge Index project — a record of what is known where, so the same territory is never unknowingly covered twice. Duplicate research is recognized for what it is: not wasted effort but a symptom of a wound that is healing.

**Later stage:** The Crystal Network's resonance increases perceptibly. Nodes in different realms hum at the same frequency when they carry the same knowledge. Scholars describe the experience of submitting a discovery and knowing, for the first time, that it will reach the people who need it.

No moment declares the Fragmentation healed. There is only the ongoing fact of knowledge moving again.

### 3. Guardian Actions

Guardians contribute to this Wound's healing through:

- **Crystal Network node restoration:** Physically locating dormant nodes, solving the activation puzzle, and re-establishing connection. (What did this node carry? Who has been living without it?)
- **Fragment completion:** Finding the missing half of a split discovery — one piece held in the Frozen Expanse, the other referenced in the Archive's index but unlocatable until a Guardian retrieves it from a fallen library in the Ember Depths.
- **Cross-realm knowledge bridge:** Carrying a specific scholarly record from one realm to another, connecting researchers who didn't know they were working toward the same answer from opposite directions.
- **Archive contribution:** Adding a newly discovered text, technique, or account to the Archive's holdings, ensuring it can be distributed rather than sitting with one person.

Frame: A Guardian who restores a Crystal Network node has not healed the Fragmentation. They have healed one severed connection. The Wound requires hundreds of such connections. Their contribution is real and it is not sufficient alone, and both of those things are true simultaneously.

### 4. Puzzle Integration

**Puzzle type:** Resonance Puzzles — ancient Crystal Network nodes that require restoring signal pathways, matching harmonic frequencies, or completing a disrupted information pattern.

*Puzzle Design Test applied:*
- **Why does it exist?** The node was built to carry knowledge across long distances. The puzzle is the residue of the original signal pattern — the system trying to re-establish a connection it was designed to hold.
- **Who created it?** Archive engineers of the First Harmony, who embedded redundancy mechanisms into nodes so that a partial failure could be self-corrected if someone understood the original design.
- **What purpose does it serve?** The puzzle reveals what knowledge the node carried — players are not solving an abstract obstacle, they are tracing what was lost.
- **What does it reveal?** Each node, when restored, contributes a piece of a larger picture: what this region knew, what it was sharing, and what gap its silence has left.

Secondary puzzle type: **Archive Fragment Matching** — a discovery exists in multiple incomplete pieces at different Archive sites. The puzzle is understanding what was connected, and in what order.

### 5. World Response

When a Crystal Network node is restored:

- The Archive in the Arena Realm logs the reconnection. A Lumina Scholar sends a message to the Guardian acknowledging the contribution — not effusively, but specifically: *"The Ember Depths node is back. We hadn't known it was still intact. There are eight records it was holding that we'd listed as lost."*
- Scholars in nearby communities begin receiving the node's archived knowledge. Over the following days, NPCs in the area comment on things they've just learned — small details, practical things, not declarations of wonder.
- The Crystal Network map in the Archive updates: a previously dark point of light becomes active, and Archive scholars begin planning what to route through it next.
- If multiple nodes in a region have been restored, the hum of the network becomes audible when a Guardian stands near active node locations — a harmonic resonance that was not there before.

### 6. Belonging Connection

The Wound of Knowledge has a Belonging consequence that is easy to miss: communities that cannot access civilization's knowledge begin to feel that civilization is not really there anymore. When knowledge starts flowing again, something shifts in the texture of how communities relate to the larger world.

NPCs who live near a newly restored Crystal Network node don't immediately say they feel more connected. They say smaller things: that they've heard from a scholar in another realm for the first time. That they finally understood why their traditional seed-preparation ritual works, because a botanical record explained it. That they sent their daughter to study in the Sky Citadel, because it finally felt worth doing.

These are not metrics. They are how belonging returns: sideways, through practical things, through the reestablishment of a sense that the larger world is real and responsive.

### 7. Can This Wound Be Fully Healed?

[PROPOSAL: The Fragmentation cannot be declared closed. The work of knowledge-sharing is not a restoration project with a completion date — it is a civilizational practice that must be actively maintained. A world where the Crystal Network is fully restored is not a world where the Wound is healed; it is a world where the conditions that allow the Wound to be held at bay are present. Knowledge must keep flowing. The Archive must keep receiving. Guardians who understand this are not discouraged by it. They understand that civilization's work never finishes — it is continued. **Flag for creator confirmation.**]

---

## Wound II — The Isolation (Wound of Discovery)

**Pillar:** Discovery | **House:** Astra | **Harmony Index Axis:** Discovery Harmony

### 1. Current World State

The Isolation looks, from a certain distance, like simple geography. The Twilight Frontier and the Crystal Forest feel unreachably far from each other — not because the distance has grown but because the routes between them are unmapped, overgrown, or held only in the failing memory of a Lantern Keeper in her eighties who has no apprentice.

In the Restoration Era, Pathfinders still exist. Some are celebrated in their home communities. But many work alone, carrying discoveries back to places that have no formal mechanism to receive them. The joy of return — which was always half the joy of exploration — has dimmed. A Pathfinder who maps a new passage in the Frozen Expanse comes home to a community that is glad to see them but doesn't know what to do with what they found.

Some Realm boundaries have become effective walls. Not by decree. By neglect. The road simply stopped being maintained, and then the road was gone.

### 2. What Healing Looks Like

Recovery from the Isolation is the return of the infrastructure of return — the routes, waypoints, communities, and Archive connections that make discovery a shared project rather than a solitary one.

**Early stage:** A Guardian maps a forgotten route between two realms and records it in the Archive. A single Lantern waypoint on a major trail is restored. Pathfinders begin cautiously using the route; communities at either end begin exchanging messages.

**Middle stage:** Inter-realm travel becomes more common. Astra scholars establish a Pathfinder Registry — a living document of who is exploring where, what they have found, and what routes they have confirmed. Discoveries begin reaching the Archive within weeks of being made rather than years, if ever.

**Later stage:** Communities along restored routes develop new civic relationships — not instant friendship, but the gradual familiarity of people who see each other regularly at waypoints and festivals. The experience of discovery becomes social again: a Pathfinder returns, and there are people waiting to hear what they found, mechanisms to record it, and ways to share it with the realms that need it.

### 3. Guardian Actions

- **Route mapping:** Physically traversing unmapped or forgotten routes and contributing the maps to the Archive — not just completing the path but documenting what is along it.
- **Waypoint restoration:** Finding and restoring Lantern waypoints that once marked safe passage, making routes usable again for travelers who cannot pioneer their own path.
- **Discovery contribution:** Bringing something found in one realm to the community or Archive in another — completing the social circuit of discovery that the Isolation severed.
- **Pathfinder support:** Assisting a Pathfinder NPC who is working alone and needs a partner, a translator, or simply someone to help carry what they found back safely.

### 4. Puzzle Integration

**Puzzle type:** Wayfinding Puzzles — reconstructing routes from partial maps, historical records, and physical environmental clues.

*Puzzle Design Test applied:*
- **Why does it exist?** The original route markers were created by First Harmony Pathfinders as a shared resource. The puzzle is the partial survival of that system: fragments of a map that was designed to be whole.
- **Who created it?** Early Pathfinders, guided by Astra House tradition, who believed routes belonged to civilization and should be documented clearly enough for anyone to follow.
- **What purpose does it serve?** Not to test navigation skill but to reconstruct a path that people need — the puzzle's solution is the route itself, not a reward that appears afterward.
- **What does it reveal?** Each restored route reveals what communities were connected by it, what passed between them, and what has been separated since it fell into disuse.

Secondary: **Environmental Reading Puzzles** — areas of the world that contain physical evidence of former routes (worn stone, old Lantern housings, distinctive plantings along what was once a maintained path). The puzzle is recognizing and interpreting these signs.

### 5. World Response

When a route is restored and recorded:

- NPCs in communities on either end of the route begin referencing travelers who came through — small mentions, heard-it-from-someone quality, the texture of word beginning to spread.
- Astra scholars update the Pathfinder Registry. A route's entry changes from "Status: Unknown" to "Status: Confirmed. Last verified: [Guardian name], [date]."
- Lantern Keepers along restored routes begin maintaining their sites with more regularity — the return of travelers gives the work meaning it had been lacking.
- If a significant route is restored connecting two previously isolated realms, a small inter-realm delegation eventually forms — not a diplomatic event, just people deciding to meet. A quest can be built around this first contact.

### 6. Belonging Connection

The Isolation's Belonging cost is loneliness — not the personal kind but the civilizational kind. Communities that cannot easily reach each other stop imagining that other communities exist in the full, textured way they once did. They stop considering what those communities might need, might know, might be building.

When routes are restored and Pathfinders begin returning with discoveries, something quieter happens alongside: citizens start imagining the larger world again. A parent tells their child about the Frozen Expanse as though it is a real place one might actually go. A community's local festival invites, for the first time in decades, travelers passing through on a Lantern route.

The Wound of Belonging is not healed by routes. But routes are one of the things that make belonging possible, because belonging requires the ability to reach each other.

### 7. Can This Wound Be Fully Healed?

[PROPOSAL: The Isolation cannot be declared closed. Routes require maintenance; new routes must continue to be discovered and mapped; communities must actively choose to remain in contact across the distance that separates them. A civilization where all routes are mapped and all waypoints are active is not immune to re-isolation — it is a civilization where people are currently choosing connection. That choice must be renewed. **Flag for creator confirmation.**]

---

## Wound III — The Decay (Wound of Growth)

**Pillar:** Growth | **House:** Verdance | **Harmony Index Axis:** Growth Harmony

### 1. Current World State

The Decay is the most domestic of the Five Wounds. It shows up at kitchen tables and in schoolrooms and in the quiet devastation of a community that has excellent traditions and no idea why they exist.

In the Restoration Era, mentors still teach. Communities still raise their children with care. Traditions are observed. But the scope of what is being prepared for has narrowed enormously. A young person growing up in the Frozen Expanse is prepared to contribute to the Frozen Expanse. The idea that they might study at a school in the Sky Citadel, or bring their skills to the Ember Depths where they're more needed, or return to their community with knowledge gained elsewhere — that idea is not quite thinkable. Not forbidden. Just outside the available imagination.

The forms of growth survive. The civilizational orientation of growth — the sense that personal development serves something beyond one's immediate community — has gone quiet.

### 2. What Healing Looks Like

Recovery from the Decay is the return of civilizational ambition to growth — the restoration of the sense that developing one's capacity is an act that matters beyond one's immediate circle.

**Early stage:** A cross-realm mentorship is established. A young person travels to study under a Master in another realm and returns changed — not better than their community, but connected to a larger frame of reference. The community responds cautiously: they are glad to have them back, uncertain what the change means.

**Middle stage:** Verdance scholars begin a Mentorship Registry — not a formal certification system but a living record of who is teaching whom across realm boundaries, and what knowledge is being transmitted. Traditions in multiple communities begin finding new meaning as they make contact with related traditions in other realms that they didn't know were practicing something parallel.

**Later stage:** The next generation grows up with a different expectation: that they will, at some point, contribute to something larger than their immediate community. Not because they are told to, but because they have seen it modeled. The Decay does not produce a sudden absence; its recovery does not produce a sudden flourishing. It is slow, and it shows up most clearly in what children take for granted that their parents could not.

### 3. Guardian Actions

- **Mentorship facilitation:** Connecting a skilled practitioner in one realm with a learner who cannot access those skills locally — creating the relationship, supporting the exchange, recording what is transmitted.
- **Tradition research:** Investigating a community's practice whose meaning has been forgotten, tracing it to its origin in another realm or in a First Harmony institution, and helping the community understand what they are actually doing and why.
- **Community development projects:** Supporting Verdance House initiatives in specific communities — restoration of a teaching garden, reconstruction of an apprenticeship program, establishment of a community Archive alcove.
- **Civilizational horizon expansion:** Helping a young NPC understand that there is more to contribute to than they can currently see — not by telling them, but by creating conditions in which they encounter it.

### 4. Puzzle Integration

**Puzzle type:** Tradition Puzzles — a community practice whose meaning has been lost. The puzzle is reconstructing the original purpose from surviving fragments: partial records, physical objects whose use has been forgotten, oral accounts that have lost key context.

*Puzzle Design Test applied:*
- **Why does it exist?** The tradition was created with a purpose — to transmit specific knowledge, to mark a developmental milestone, to maintain a community's connection to something larger. The puzzle exists because the purpose was separated from the practice.
- **Who created it?** A specific community during the First Harmony, guided by Verdance House principles about how growth should be celebrated and transmitted.
- **What purpose does it serve?** Recovering the meaning allows the tradition to be practiced fully again — not just as form but as understanding.
- **What does it reveal?** The tradition often reveals a cross-realm connection that the community has forgotten: the practice originated in contact with another realm's tradition, or the milestone it marks was once shared across multiple communities.

### 5. World Response

When a mentorship connection is established or a tradition's meaning is restored:

- The community's Archive record is updated with a new entry — the tradition's origin documented, its purpose recorded for the first time in the Restoration Era.
- The mentor NPC describes the experience of teaching someone from outside their community as different from teaching their own — more energizing, more questioning, more alive.
- Over time, the learner NPC's home community begins to change in small, unannounced ways: different things are possible for them to know, because someone came back knowing them.
- Verdance scholars track restored mentorship connections on a living map. When enough connections exist in a region, the map begins to show something like a network — not quite the Crystal Network's precision, but a pattern of growth transmission that was not there before.

### 6. Belonging Connection

The Decay's Belonging consequence is invisible to the communities inside it: a world that does not expect you to contribute to something larger cannot make you feel that contribution to something larger is available to you. Citizens in communities deep in the Decay do not feel excluded from civilization. They feel, simply, that civilization is not really available to them — that it is somewhere else, for other people.

When growth reconnects to civilizational scope, belonging follows as a consequence. A young person who has studied in another realm and returned carries, in their body, the knowledge that the larger world is real and that they can move through it. They cannot transmit this through speech alone; they transmit it through how they are. Communities change when someone like this comes home.

### 7. Can This Wound Be Fully Healed?

[PROPOSAL: The Decay cannot be declared closed. Growth is not a destination; it is a continuous process. A civilization where all communities are actively connected to civilizational scope of growth is a civilization that is currently doing the work of maintaining that connection — not a civilization that has finished the work. The work of growth, like the work of tending, never ends. **Flag for creator confirmation.**]

---

## Wound IV — The Forgetting (Wound of Memory)

**Pillar:** Memory | **House:** Borealis | **Harmony Index Axis:** Memory Harmony

### 1. Current World State

The Forgetting is the Wound that most resembles grief, because the thing that was lost is also the record of the loss.

The Archive in the Restoration Era is both the most complete repository of civilization's knowledge and a monument to incompleteness. Volume IV of the Book of Harmony — the volume on Memory — is the most damaged of all surviving copies. The Archive's index contains thousands of entries for documents that cannot be found. Historians regularly discover that something they believed was established fact is actually an assumption built on a missing source.

The Crystal Network, when dormant nodes are restored, sometimes reveals what they were holding: records that existed nowhere else, memories that Companions had been carrying alone for decades because the written record had gone dark, traditions preserved only in oral form by Lantern Keepers who were never sure their memory was accurate.

There is a specific quality of silence in the Archive reading rooms — the silence of people sitting with gaps in records that should be complete, trying to work out what the gap means.

### 2. What Healing Looks Like

Recovery from the Forgetting is one recovered fragment at a time. There is no moment at which historians declare the record complete; they only describe it as more complete than it was.

**Early stage:** A Companion's memory is formally recorded for the first time — an account of an event for which no written record existed, now added to the Archive with care and notation about its source. A dormant Crystal Network node is restored and found to be carrying records thought permanently lost.

**Middle stage:** Borealis scholars establish a Reconstruction Project — an effort to fill the Archive's index entries by locating missing documents across all realms. Some gaps are filled. Many are confirmed as permanently closed. The Archive of Unanswered Questions grows as closed mysteries are replaced by new ones revealed by the recovered records.

**Later stage:** A culture of careful attribution develops. Historians begin distinguishing clearly between what is documented, what is inferred, and what is simply unknown. This precision, which would seem like failure in another context, is recognized in the Restoration Era as a form of honesty that the Forgetting made necessary — and that civilization is better for.

### 3. Guardian Actions

- **Crystal Network node recovery:** Each restored node has a chance of carrying records thought lost. The Guardian does not know what a node is holding until it is restored — the recovery is the act of care; the discovery of what was held is the reward.
- **Companion testimony recording:** A Companion NPC carries memories of the First Harmony that exist nowhere in written form. The Guardian creates the conditions in which that testimony is given and recorded — sitting with the Companion, asking the right questions, ensuring the testimony reaches the Archive.
- **Fragment verification:** Archive records often contain assertions that were never properly sourced. A Guardian researches whether a claimed event actually occurred, finding the supporting documentation or confirming the gap.
- **Book of Harmony recovery:** Finding surviving passages of the Book's damaged volumes — particularly Volume IV — in ruined libraries, encoded in Crystal Network nodes, preserved in Lantern Keeper oral tradition. Each recovered passage is one of the most significant contributions available to a Guardian.

### 4. Puzzle Integration

**Puzzle type:** Memory Reconstruction Puzzles — reassembling fragmented records from multiple partial sources, each of which contains something the others lack.

*Puzzle Design Test applied:*
- **Why does it exist?** The record was damaged when the Crystal Network failed — information that was distributed across multiple nodes became partial in every copy because the connections between copies were severed.
- **Who created it?** First Harmony Chroniclers, who distributed records precisely to prevent total loss. The distribution worked; the connections that allowed reconstruction did not survive.
- **What purpose does it serve?** Reconstructing the record is the purpose — not recovering a key from a box, but recovering knowledge that people have been living without.
- **What does it reveal?** Memory Reconstruction Puzzles often reveal something specific about a community's history that changes how they understand themselves — not as shocking revelation but as the quiet reorientation of knowing something you didn't.

Secondary: **Companion Memory Puzzles** — a Companion NPC has a fragmented memory of a First Harmony event. The puzzle is helping the Companion recover the full memory through prompts, artifacts, and locations that trigger recall.

### 5. World Response

When a significant record is recovered:

- The Archive's index entry for that document changes from red (missing) to blue (recovered). A small notice appears in the Archive's daily distribution: what was found, where, by whom. Citizens who consult the Archive in the days after begin encountering the recovered record without announcement — it is simply there now.
- Borealis scholars send acknowledgment — specific, noting what the record allows them to understand that they couldn't before.
- If a Companion's testimony was recorded, the Companion's behavior changes subtly: they no longer carry that memory alone. They have been witnessed. Something in how they move through the world is slightly different.
- Archive reading rooms become, over time, slightly less silent. Historians who have spent years working around a gap suddenly have something to work with. The sound is not celebration; it is the quiet sound of work that was stalled beginning to move again.

### 6. Belonging Connection

The Forgetting has the most direct Belonging consequence of any Wound, because memory is what makes belonging possible across time. A civilization that cannot remember itself cannot make its citizens feel that their contributions will be remembered — and therefore cannot make them feel that contributing is worth it.

When the Archive recovers records, it is not just filling gaps. It is demonstrating, repeatedly, that the civilization considers its past worth recovering. That demonstrating is itself a form of care — a way of saying to living citizens: *what you do will also be preserved.* Companions who have their memories formally recorded report, in various ways, that they feel witnessed for the first time. That feeling is belonging. The Wound of Belonging does not heal from memory recovery alone, but it cannot heal at all without it.

### 7. Can This Wound Be Fully Healed?

[PROPOSAL: The Forgetting cannot be declared closed, for two reasons. First, some records are permanently lost; the gaps in the Archive's index that will never be filled are a permanent feature of civilization's self-knowledge. Second, memory is not a fixed body of material — it requires continuous contribution, continuous care. A civilization that stops contributing to its memory will find the Forgetting returning within a generation. The Archive's ongoing work is not restoration only; it is the maintenance of civilization's relationship with its own past. **Flag for creator confirmation.**]

---

## Wound V — The Division (Wound of Belonging)

**Pillar:** Belonging — Hidden Eighth | **House:** None | **Harmony Index Axis:** None — no visible metric

### 1. Current World State

The Division is the hardest Wound to see because it does not produce visible damage. Communities in the grip of the Division function. They maintain themselves, raise their children, observe their traditions, contribute to their immediate neighbors. They are not broken in any way that a damage assessment could identify.

They are hollow in a way that the people inside them often cannot name.

In the Restoration Era, there are communities where citizens describe feeling that something is missing but cannot say what. Where festivals are observed but feel like obligations. Where the Archive is used but not loved. Where Companions are present but somewhat apart. Where young people leave not because they are seeking something specific but because they feel, obscurely, that there should be something more — and they cannot articulate what.

The Wound of Belonging is felt most clearly in contrast: a citizen from one of these communities who travels to the Arena Realm and spends time in a community where the Lantern Network is active, where inter-realm visitors are common, where the Archive is contributed to daily — that citizen often describes the experience as disorienting, then clarifying. *I had forgotten what it felt like to be part of something.* Sometimes they return home and cannot explain what they felt. Sometimes the inability to explain it is itself the Division, still present.

### 2. What Healing Looks Like

The Division does not have a healing process in the way the other four Wounds do. It has a healing *condition*: all the other Wounds healing simultaneously, plus the specific acts that no metric can capture.

What healing looks like is not progress on a bar. It is:

- A festival that people choose to attend rather than feel they must.
- A citizen who contributes to the Archive without being asked, because it occurred to them that someone should.
- A community that begins hosting travelers not as a civic obligation but as something they want.
- A Companion who is greeted by name, whose memory is known, who is asked for their perspective rather than their function.
- A Guardian who does their work over a long period of time and one day notices that the community around them has changed — not in any single thing, but in the texture of how people relate to each other and to the world.

There is no moment when the Division is healed. There is only the ongoing accumulation of moments when it is a little less present.

### 3. Guardian Actions

The Wound of Belonging requires a fundamentally different orientation from a Guardian than the other four Wounds. There are no puzzles that address it directly. There are no quest chains designed to heal it. It heals through how a Guardian is — across all their other work.

Specific practices that contribute:

- **Showing up over time.** A Guardian who returns to a community repeatedly, who is known there, who is remembered — that return is itself a form of belonging restored. The community has someone who keeps coming back. That matters in ways that are not measurable.
- **Listening.** The Archive has formal mechanisms for recording testimony. But before testimony can be recorded, it must be given. A Guardian who makes space for a citizen's or Companion's story — without rushing to the quest objective — is doing restoration work that no other system can do.
- **Festival participation.** Festivals in GemVerse are not cutscenes. They are the mechanism by which communities practice belonging. A Guardian who participates in a community festival is not taking time away from restoration work. They are doing restoration work.
- **Honoring Companion memories.** When a Guardian treats a Companion's memory as important — seeks out the location a Companion remembers, records their testimony, acknowledges what they have carried — the Companion's experience of being witnessed ripples into the community around them.
- **Not requiring recognition.** Belonging is cultivated, not rewarded. A Guardian who contributes without requiring the world to celebrate each contribution is modeling what the Book of Harmony described: "No one told me I was part of something. I just kept showing up, and one day I looked around and saw that something had grown around me."

### 4. Puzzle Integration

There are no puzzles designed specifically to heal the Wound of Belonging. This is intentional.

Belonging is not a puzzle. It does not have a solution. Designing a puzzle to heal it would be a category error — it would suggest that belonging can be achieved through skill or cleverness, which is precisely the misunderstanding the Wound exists to correct.

What puzzles *can* do is create the conditions for belonging to emerge: a puzzle whose solution reveals a piece of a community's history that they had lost and that, recovered, gives them something to recognize themselves in. A puzzle that requires collaboration between Guardian and NPC, not just Guardian alone. A puzzle that, in its resolution, produces a story — something that can be shared, retold, added to the Archive.

The test for any puzzle's Belonging contribution is not "does it heal the Division?" but "does it create a moment that feels worth belonging to?"

### 5. World Response

The world's response to healing the Division is qualitative and ambient:

- NPCs who, early in the game, responded to greetings with minimal engagement begin, over extended time, to say specific things — recognizing the Guardian, asking about something the Guardian did previously, referencing a conversation that happened much earlier.
- Festival attendance in communities where the Guardian has been active increases. Not dramatically; incrementally.
- Citizens begin making Archive contributions without Guardian involvement — the contribution behavior spreads, because communities where people are contributing tend to make other people feel that contribution is worth doing.
- Companions who have been lonely in their knowledge — carrying memories that no one has asked about — become, over time, slightly more present. More willing to volunteer observations. More willing to be known.
- The Harmony Index does not reflect any of this. The numbers may not change. The world changes anyway.

### 6. The Belonging Problem — A Design Note

The Wound of Belonging creates a specific challenge for game design: the most important healing in GemVerse has no visible progress indicator and cannot be directly targeted. For designers, writers, and quest teams:

**What this is not:** A bug or an oversight. The absence of a metric is the design. A Belonging meter would imply that belonging can be achieved through sufficient input of the right kind — which would make it a transaction rather than a condition. The game would begin optimizing for the number rather than for what the number was meant to represent.

**What Guardian play looks like from the inside:** A Guardian who understands the Division plays differently from a Guardian who does not. They make time for things that do not move any visible metric. They return to communities. They listen. They treat Companion memory as important rather than instrumental. They are, in a small way, practicing the civilization the game is asking them to help restore.

**What the world provides instead of a bar:** Environmental storytelling. NPC behavioral change over time. Companion depth. Festival experiences that feel qualitatively different as the Division heals. The recognition, for players who are paying attention, that the communities around them have changed — not in any single way, but in aggregate.

**The Final Test applied:** If a player who has never tracked a Belonging metric looks back at their time in a community and feels that they were part of something there — that is the design working.

---

## Cross-Wound Relationships

The Five Wounds are not independent systems. They share conditions, and healing one Wound changes the environment in which the others operate.

| If this Wound heals... | ...it helps this Wound because... |
|---|---|
| **Fragmentation (Knowledge)** | Discovery becomes more meaningful — Pathfinders have places to bring what they find and knowledge networks to route it through. Memory heals faster — the Crystal Network carries records as well as current knowledge. |
| **Isolation (Discovery)** | Knowledge flows more freely — cross-realm connection is the mechanism by which knowledge reaches the communities that need it. Growth reconnects to civilizational scope — communities that can reach each other begin preparing their members to move through a real, accessible world. |
| **Decay (Growth)** | Memory is better maintained — communities that understand the civilizational scope of their growth invest in memory preservation as civic work. Belonging deepens — communities that are growing in relationship with civilization feel they are part of something. |
| **Forgetting (Memory)** | Knowledge is safer — records that survive can be distributed rather than held in one vulnerable location. Belonging deepens — communities that are remembered by civilization feel witnessed. |
| **Division (Belonging)** | Everything else heals faster — communities that feel they are part of something contribute to knowledge, discovery, growth, and memory with a motivation that cannot be manufactured by any other system. |

The reverse is also true: a Wound that is ignored while others heal will begin to constrain the healing of the healed Wounds. Communities that have reconnected their knowledge but still feel the Division will eventually slow their knowledge contribution, because sharing requires a sense that sharing matters. Guardians who focus on one Wound exclusively will find their work increasingly limited by the ones they haven't attended to.

---

## The Belonging Problem

*A dedicated section on the design implications of an unmeasured Wound.*

The Wound of Belonging presents a philosophical challenge to the standard model of game progress: the most important thing in the game cannot be tracked.

This is not an accident, and it should not be solved by adding a tracker. The reason Belonging has no metric is that belonging is not a quantity. It is a quality — an emergent condition of a world working well. Civilizations that try to measure belonging tend to produce things that look like belonging from the outside and feel hollow from the inside. This is, in fact, what the First Harmony was beginning to do in its final years: optimizing for institutional function while the felt quality of connection quietly drained away.

**For Guardian play:** Guardians who only do things that move visible metrics will, over long play, notice that something in the world hasn't changed — a quality of distance, of communities that function without warmth. Guardians who attend to Belonging — who return to communities, who listen, who participate in festivals, who honor Companion memory — will find that the world around them has changed in ways they cannot point to on any chart.

This is intentional. It is a design argument about what matters.

**For writers:** Every scene, every NPC, every piece of environmental writing is an opportunity to either reinforce the Division or contribute to healing it. The question is not "does this scene address the Wound of Belonging?" but "does this scene make the world feel more worth belonging to?" A piece of writing that passes the Final Test is contributing to Belonging's healing whether or not it is explicitly about Belonging.

**For quest designers:** No quest should be designed to "heal Belonging" as its primary goal. Quests can create conditions for Belonging to emerge — they can produce moments that feel worth belonging to, build NPC relationships that deepen over time, create community experiences that are genuinely shared rather than solitary. The Belonging contribution of a quest is its atmospheric and relational residue, not its deliverable.

**The central paradox:** The Wound of Belonging is the deepest Wound and the one that most determines whether healing the other four Wounds means anything. And it is the one wound that cannot be directly targeted. The design solution is to make the other four Wounds rich enough, and the Guardian's relationship with the world deep enough, that Belonging emerges as a consequence of genuine restoration — not as a reward, but as a condition.

---

## Restoration Pacing

Healing civilization-scale fractures over the arc of a long game without producing either a sense of meaningless grind or hopeless futility requires deliberate pacing design.

### The Macro Arc: Contribution, Not Completion

The Restoration Era is not a story that ends when the Five Wounds are healed. It is a story about what it means to live in a world that is healing. Guardians do not arrive at a fixed endpoint. They deepen their relationship with a world that is continuously, gradually becoming more itself.

Pacing implications:
- Early play should make visible contributions feel significant without implying the work is nearly done. A Guardian's first Crystal Network restoration should feel like a real act that mattered — not a drop in a bucket, and not a heroic save. A restored connection. One of many needed. Real.
- Middle play should reveal the scale of the work more fully — the interconnection of the Wounds, the depth of what was lost, the complexity of what healing requires. This is not discouraging; it is clarifying. The Guardian understands better what they are part of.
- Late play should not feel like endgame. It should feel like legacy. The Guardian is no longer the newest contributor; they are one of the ones who has been here long enough to see change. The world has responded to their presence. Other Guardians are doing this work alongside them.

### The Micro Arc: Visible, Layered, Non-Linear

Within sessions, healing should feel:

- **Visible at the scale of each contribution.** When a node is restored, something changes. The Guardian does not have to wait to see the consequence of what they did.
- **Layered over time.** The consequences of earlier contributions continue to unfold. A route restored three weeks ago has produced new NPC relationships. A testimony recorded last month has enabled an Archive reconstruction that is completing now. The world is always slightly behind the Guardian's contributions — responding to work they've already done.
- **Non-linear.** A Guardian cannot heal the Wounds in order. Working on the Fragmentation creates openings in the Isolation. Addressing the Decay produces consequences for Memory. The interconnection is not a game mechanic; it is a worldbuilding truth that the game reflects.

### On Avoiding Grind

The work of restoration risks feeling like grind when it loses specificity. The antidote is always the same: the reason why.

When a Guardian restores a Crystal Network node, the healing is not in the node. It is in the record the node was holding. The record that the Ember Depths research circle has been missing. The passage of the Book of Harmony that the Archive has had an index entry for since the Shattering. When that is the experience — not "restore node: +1 Crystal Network" but *"you restored the node. It was holding the account of the Third Festival of Return. The Archive has been looking for this for sixty years"* — the work has meaning.

Specificity is the pacing mechanism. The world's response is the pacing mechanism. The Guardian's relationship with the communities they return to is the pacing mechanism.

The Wounds do not need to be fully healed for the game to feel meaningful. The game is meaningful when each contribution leaves a specific trace in a world that responds to it. That can be true from the first session to the ten-thousandth.

---

## Review Checklist

- [ ] Does every Wound's restoration logic frame the Guardian as a contributor rather than a hero or savior?
- [ ] Is the Wound of Belonging's absence from the Harmony Index explained clearly enough for quest designers, writers, and developers to implement correctly?
- [ ] Does the "Can This Wound Be Fully Healed?" section for each Wound avoid both false hope (yes, fully) and false despair (no, never)? The intended answer is: the work continues — and that is meaningful, not tragic.
- [ ] Do the Puzzle Integration entries pass the Puzzle Design Test? Every puzzle should have a worldbuilding reason — not just a solution but a *reason it exists in the world*.
- [ ] Does the Cross-Wound Relationships table reflect the established canon that all Five Wounds deepen and heal together?
- [ ] Does the Belonging Problem section give quest designers clear enough guidance to avoid designing a Belonging quest incorrectly?
- [ ] Does the Restoration Pacing section support long-game engagement without implying the game is endless in a discouraging way?
- [ ] Does any language in this document drift toward chosen-one framing, power escalation, or combat resolution? If so: remove.
- [ ] Does this document pass the Final Test: would this make GemVerse feel more worth belonging to?
- [ ] Are all [PROPOSAL] items flagged clearly for creator review before any are locked?

---

*IMP #2 — Five Wounds Restoration Model | v1.0 | Draft — Awaiting Creator Review*
*Dependencies: Five Wounds (Tier 1), Crystal Network (Tier 1), Lantern Network (Tier 1)*
*Feeds into: Quest Design, Puzzle Catalog (Task 8), Harmony Index, Narrative Bible (Tier 5)*
