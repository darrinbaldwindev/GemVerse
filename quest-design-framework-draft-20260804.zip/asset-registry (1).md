# GemVerse Asset Registry
**Version:** 2.0 — Updated from Visual Asset Transfer Intake (Task 10)
**Last Updated:** 2026-06-01
**Maintained by:** Computer (Task 1 — Asset Registry Auto-Updater)
**Status Labels:** Pending | Concept | Draft | Transferred | Approved
**Human Approval Required:** Any change to Approved status. Any visual canon change.

---

## Registry Rules

- Computer may update any status EXCEPT Approved.
- Computer may add new assets to the registry with status Pending, Concept, Draft, or Transferred.
- Computer may NOT mark anything Approved without explicit creator confirmation.
- If an asset appears with a conflicting status across sources, Computer stops and flags — does not resolve.

---

## CHANGELOG — v2.0 (2026-06-01)

Updated from Visual Asset Transfer Intake (Task 10). Source images processed: Construct 3 Development Bible (Image 1), Art Bible v1.0 + UI Wireframes (Image 2), Art Bible v1.0 main (Image 3), Consolidated Art Bible / Summary Sheet (Image 4).

Changes from v1.0:
- Construct 3 Development Bible added as Transferred
- Verdant updated from Pending → Transferred (first visual confirmed)
- Lumi, Ember, Frosty: already Transferred — notes updated to reflect visual confirmation in Companion Collection Preview
- Realm environments: Twilight Frontier and Celestial Nexus updated from Concept → Transferred; "Heart of the Core" added as NEW FLAGGED ENTRY
- Brand colour palette: full Art Bible palette documented; canon conflict note added
- Power-up/booster entries: expanded with named items and canon risk escalated
- Achievement badges: expanded with individual names
- Realm Map: already Transferred — notes updated
- "Assets Flagged for Human Review" section: 5 new flags added
- 3 new canon-risk tagline entries added
- Story screen narrative text flagged (Critical)
- Kael's Art Bible description updated to confirm Conflict 3 in visual canon
- Museum / navigation screen tab documented

---

## A — BRAND ASSETS

| Asset | Type | Status | Notes |
|---|---|---|---|
| GemVerse Logo (primary) | Logo | Transferred | Cinzel Semibold confirmed. Visible in Art Bible v1.0 + Consolidated Art Bible. Not yet finalized as approved vector. |
| GemVerse Logo (secondary wordmark) | Logo | Transferred | Alternate smaller variant confirmed in Art Bible v1.0. |
| GemVerse App Icon | Icon | Transferred | 4 variants shown in Art Bible: (1) "GV" letters with crystal shard, (2) Crystal fox/companion motif, plus 2 additional. None marked Approved. |
| Lantern Gold colour spec | Colour | Approved | Canonical primary brand colour — warmer/more amber than #C9A227. |
| Archive Blue colour spec | Colour | Approved | Canonical secondary — deeper than Lumina #1F4E79. |
| Crystal Blue colour spec | Colour | Transferred | Confirmed in Art Bible v1.0 and Consolidated Art Bible. Relationship to Lantern Gold / Archive Blue canonical palette requires creator confirmation. |
| Emerald Green colour spec | Colour | Transferred | Confirmed in Art Bible v1.0. |
| Amethyst Purple colour spec | Colour | Transferred | Confirmed in Art Bible v1.0. |
| Sunset Orange colour spec | Colour | Transferred | Confirmed in Art Bible v1.0. |
| Pure White colour spec | Colour | Transferred | Confirmed in Art Bible v1.0. |
| Deep Indigo colour spec | Colour | Transferred | Confirmed in Art Bible v1.0 as sixth colour. |
| Unnamed dark colour (5th/6th) | Colour | Transferred | Shown in Consolidated Art Bible — unnamed. Creator confirmation of full palette order required. |
| Cinzel Semibold typography (logo) | Typography | Approved | Confirmed in Brand Guidelines and Art Bible v1.0. |
| Satoshi / Cabinet Grotesk (body/display) | Typography | Transferred | Confirmed as secondary font in Art Bible v1.0 and Consolidated Art Bible. Formally transferred; not yet Approved for in-game use. |
| Brand tagline: "Restore Realms. Build Your Legacy." | Copy | Approved | Locked canon. Confirmed in Art Bible v1.0 and Consolidated Art Bible. |
| Brand promise: "A world worth belonging to." | Copy | Approved | Locked canon. |
| Brand tagline variant: "One Puzzle. Countless Realms." | Copy | Transferred | ⚠️ New variant — shown in Consolidated Art Bible. Not yet reviewed against approved tagline. Use of "Puzzle" in tagline reduces GemVerse identity. Not Approved. |
| Brand tagline variant: "Challenge Your Mind. Save the Realms." | Copy | Transferred | ⛔ CANON RISK — "Save the Realms" is savior/hero framing. Violates Rules 1.5, 5.1. Do not use. Flag for creator. |
| Brand style tags: Magical, Inspiring, Welcoming, Premium, Adventurous | Copy | Transferred | Confirmed in Consolidated Art Bible. Consistent with franchise tone. |
| Icon Style Guide (6 styles) | Visual Guide | Transferred | Heroic Silhouette, Gem Topped, Crystal Available, Glow Friendly, Puzzle Master, Academy. Shown in Art Bible v1.0. |

---

## B — CHARACTER ART

| Asset | Character | Type | Status | Notes |
|---|---|---|---|---|
| Spark character sheet (full) | Spark | Character Sheet | Transferred | Full sheet with expressions (Happy, Curious, Excited, Thinking, Tired, Angry) and poses (sitting, running, leaping, surprised). Received in Art Bible v1.0 (Image 2 & 3). ⚠️ Canon Risk: role described as "helps complete puzzles and is the narrator of the realm" — puzzle-helper framing conflicts with companion-as-witness canon (Rules 4.1, 4.2). Reframe required before Approved. |
| Aurora character sheet (full) | Aurora | Character Sheet | Transferred | Silver/white/pale blue palette (5 swatches confirmed). Expressions: Calm, Sad, Determined, Surprised. Role "Guardian Guide. Story Teller." is canon-consistent. Full-body art confirmed transferred. |
| Kael character art (full body) | Kael | Character Art | Transferred | Arena Champion. Full-body art confirmed in Consolidated Art Bible (Image 4). ⛔ CANON RISK HIGH: Art Bible v1.0 text reads "Kael helps you defeat the Arena Realm and is the strength of the group" — combat framing + power role. Violates Rules 1.3, 5.1, 5.4. Conflict 3 now confirmed in visual canon. Reframe required before Approved. |
| Lyra character art (full body) | Lyra | Character Art | Transferred | Realm Explorer. Full-body art confirmed in Consolidated Art Bible (Image 4). Art Bible description "Curious and adventurous, she helps you explore new Realms and discover new edges and mysteries" is canon-consistent. |
| Lumi companion art | Lumi | Concept Art | Transferred | Visual confirmed in Companion Collection Preview (Images 3 & 4). Described as glowing orb/spirit creature. ⚠️ Canon status unresolved — Conflict 6. Not in confirmed launch list of 8 companions. Creator confirmation required. |
| Ember companion art | Ember | Concept Art | Transferred | Visual confirmed in Companion Collection Preview (Images 3 & 4). Shown as fire fox/creature. ⚠️ Canon status unresolved — Conflict 6. Creator confirmation required. |
| Frosty companion art | Frosty | Concept Art | Transferred | Visual confirmed in Companion Collection Preview (Images 3 & 4). Shown as ice bear cub. ⚠️ Canon status unresolved — Conflict 6. Creator confirmation required. |
| Verdant companion art | Verdant | Concept Art | Transferred | **UPDATED v2.0** — First visual received in Companion Collection Preview (Images 3 & 4). Green plant creature. Previously Pending. |
| Nimbus companion art | Nimbus | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |
| Frostpaw companion art | Frostpaw | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |
| Prism companion art | Prism | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |
| Bloomtail companion art | Bloomtail | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |
| Galewing companion art | Galewing | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |
| Echo companion art | Echo | Concept Art | Pending | Name confirmed in canon. Visual not yet received. |

---

## C — ENVIRONMENT / REALM ART

| Asset | Realm | Type | Status | Notes |
|---|---|---|---|---|
| Arena Realm environment | Arena Realm | Concept Art | Transferred | Art Bible description: "A lush realm of ancient strength." ⚠️ LOW-MEDIUM risk — "strength" framing inconsistent with civic/contribution identity under Kael Option A resolution. |
| Crystal Forest environment | Crystal Forest | Concept Art | Transferred | Art Bible description: "A crystalline realm filled with living crystal and harmony." Canon-consistent. |
| Sky Citadel environment | Sky Citadel | Concept Art | Transferred | Art Bible description: "A sky realm of boundless discovery and adventure." Canon-consistent. |
| Frozen Expanse environment | Frozen Expanse | Concept Art | Transferred | Art Bible description: "A realm of silence and deep memory." Canon-consistent — excellent alignment with Memory theme. |
| Ember Depths environment | Ember Depths | Concept Art | Transferred | Art Bible description: "A fiery realm of primal strength." ⚠️ LOW-MEDIUM risk — "primal strength" framing conflicts with Resilience/Determination canon identity for Ember Depths. |
| Twilight Frontier environment | Twilight Frontier | Concept Art | Transferred | **UPDATED v2.0** — Art Bible description: "Mysterious lands with untold stories and awakening quests." Canon-consistent. Previously Concept. |
| Celestial Nexus environment | Celestial Nexus | Concept Art | Transferred | **UPDATED v2.0** — Art Bible description: "Where stars align and wisdom grows." Canon-consistent. Previously Concept. |
| Legacy Realm environment | Legacy Realm | Concept Art | Pending | Not visible in transferred assets. Confirmed in locked canon. |
| Memory Ocean environment | Memory Ocean | Concept Art | Pending | Open mystery — no visual development. Not visible in transferred assets. |
| Heart of the Core environment | UNKNOWN | Concept Art | Transferred | **NEW — FLAGGED.** ⚠️ CANON RISK: "Heart of the Core" shown as 8th realm environment in Art Bible v1.0 with description "The realm at the very heart of the world." This name does not appear in locked canon. The nine known realms are: Arena Realm, Crystal Forest, Sky Citadel, Frozen Expanse, Ember Depths, Twilight Frontier, Celestial Nexus, Legacy Realm, Memory Ocean. This could be a 9th Realm, a rename of Memory Ocean, or a rename of Legacy Realm. Cannot proceed without creator confirmation. |
| Realm Map (overview) | All Realms | Map | Transferred | Isometric realm map showing 7+ realms with connecting paths. Confirmed in Art Bible (Image 2) and Consolidated Art Bible (Image 4). |

---

## D — UI / UX ASSETS

| Asset | Type | Status | Notes |
|---|---|---|---|
| Home Screen mockup | UI Mockup | Transferred | Shows: Guardian name, gem counts, resource bars (Crystal/Ember/Star — see flag below), level indicator, PLAY button, Daily Puzzle tile, Story Progress. Navigation tabs confirmed: Story, Quests, Companions, Realms, Academy, Museum. |
| Match-3 board mockup | UI Mockup | Transferred | Board with coloured gem grid (Green, Blue, Purple, Red, Yellow, White confirmed), goal bar, score tracking, Spark companion shown in corner. Prototype-phase design — retain as reference. |
| Daily Puzzle screen mockup | UI Mockup | Transferred | "Today's Puzzle is Live!" — Stats: Accuracy 64%, Average 20.4, Win Time 1:32, Streak 18 moves, Average 1:18, Days 27. Play Puzzle button. |
| Story screen mockup | UI Mockup | Transferred | Aurora portrait (large, detailed). ⛔ CANON RISK CRITICAL: Story text reads "Long ago, the Crystal Heart unified all realms. When it shattered, darkness spread. Together, we will restore the light." — Introduces named artifact "Crystal Heart" as cause of Shattering AND uses "darkness spread" antagonist framing. Violates Rules 2.1, 2.2, 2.3. Most significant conflict in transfer. Do not proceed with this text. |
| Level Complete screen | UI Mockup | Transferred | Score, gems earned, Continue button. |
| Profile screen | UI Mockup | Transferred | Shows: Guardian level, streak, gems, companions. |
| UI component library | Components | Transferred | Primary Button, Secondary Button, Resource Bar, Task Medallion confirmed. Visible in Art Bible v1.0. |
| Navigation bar | Components | Transferred | **UPDATED v2.0** — Tabs confirmed: Home, Quests, Companions, Realms, Academy, Museum. "Museum" is a confirmed named screen — likely Archive interface. Previously Concept. |
| Guardian Card | Components | Transferred | Shown in UI Components panel (Art Bible v1.0 Image 3). |
| Realm Card | Components | Transferred | Shown in UI Components panel (Art Bible v1.0 Image 3). |
| Resource bars (Crystal/Ember/Star) | UI Element | Transferred | ⚠️ CANON RISK: UI Home Screen shows resource bars for Crystal, Ember, and Star currency types. If these function as energy systems that block play, violates Rule 1.6. If they are collection resources (not gating), may be canon-consistent. Creator clarification required. |

---

## E — LORE / WRITING ASSETS

| Asset | Type | Status | Notes |
|---|---|---|---|
| Book of Harmony (full entry) | Lore Doc | Draft | `/gemverse-docs/tier1/04-book-of-harmony.md` — awaiting final upload approval. |
| First Harmony (full entry) | Lore Doc | Draft | `/gemverse-docs/tier1/05-first-harmony.md` — duration (3–4 centuries) and Threshold model pending creator confirmation. |
| Canon Map | Reference Doc | Draft | `/gemverse-docs/01-canon-map.md` — v1.0 in Space. |
| Conflicts & Decisions Log | Reference Doc | Draft | `/gemverse-docs/02-conflicts-log.md` — v1.0. |
| Tier 1 Readiness Report | Reference Doc | Draft | `/gemverse-docs/03-tier1-readiness.md` — v1.0 in Space. |
| Five Wounds (full entry) | Lore Doc | Pending | Tier 1 — next in queue. |
| Crystal Network (full entry) | Lore Doc | Pending | Tier 1. |
| Lantern Network (full entry) | Lore Doc | Pending | Tier 1. |
| Restoration Era (full entry) | Lore Doc | Pending | Tier 1. |
| Companion Encyclopedia — Spark | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Verdant | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Nimbus | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Frostpaw | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Prism | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Bloomtail | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Galewing | Lore Doc | Pending | Tier 3. |
| Companion Encyclopedia — Echo | Lore Doc | Pending | Tier 3. |

---

## F — VISUAL BIBLE / ART DIRECTION

| Asset | Type | Status | Notes |
|---|---|---|---|
| Art Bible v1.0 (full — Images 2 & 3) | Art Direction | Transferred | Full 11-panel main version + 8-panel UI wireframe version received and processed. Brand, characters, UI, realms, companions, power-ups, achievements. |
| Construct 3 Development Bible | Technical Bible | Transferred | **NEW v2.0** — 6-panel overview received (Image 1). Confirms: mobile-first (iOS/Android), Construct 3 platform, scene structure (MainMenu, GamePlay, Story, Realm_CF, Realm_FE, Realm_ED, Realm_AR), 8 puzzle types, Match-3 board as primary mechanic, event sheets per puzzle, cascade system. |
| Consolidated Art Bible / Summary Sheet | Art Direction | Transferred | **NEW v2.0** — Full summary sheet (Image 4) received. Consolidates all characters, colour palette, brand, UI mockups, companion collection, realm map, power crystals, achievement badges. |
| House colour specs (all 7) | Colour Reference | Approved | Locked in Canon Map. |
| Companion colour language (all 7 families) | Colour Reference | Approved | Locked in Canon Map. |
| Visual Canon Hierarchy (7 levels) | Reference | Approved | Locked — Approved Final Artwork wins all conflicts. |
| Match-3 gem types (7 types confirmed in Dev Bible) | Visual Spec | Transferred | Dev Bible (Image 1) confirms: Fire, Water, Earth, Air, Light, Dark, Rainbow. Art Bible (Image 3) confirms 6 colours: Blue, Green, Purple, Red, Gold, White. ⚠️ Discrepancy in gem count — 7 types vs 6 colours. Creator clarification required on final gem set. |
| Match-3 gem effect specs | Visual Spec | Transferred | Match Effect, Crystal Effect, Bonus Pop-up, Victory Effect — visual style references shown. Prototype-phase — retain as reference. |
| Special gems (Bomb Gem, Lightning Gem, Rainbow Gem) | Visual Spec | Transferred | ⚠️ CANON RISK — confirmed in Dev Bible (Image 1). Named power-up mechanics (bomb/lightning destroy effects). Violates Rule 1.4 (power escalation). Flag for creator. |
| Power-up / booster visual concepts | Visual Spec | Transferred | ⛔ CANON RISK CONFIRMED. Named items (Image 3): Harmony Blast, Star Blast, Colour Bomb, Sparkle, Crystal Pearl. Named in Consolidated Art Bible (Image 4): Moonlight Blast, Vertical Blast, Arial Blast, Colour Bomb, Crystal Pearl. These are framed as power advantages with visual effects, not puzzle tools. Violates Rules 6.1, 1.4. Cannot be tagged Approved. Awaiting creator determination: puzzle tools (safe) or power advantages (not safe). |
| Achievement badge preview (8 badges) | Visual Spec | Transferred | **UPDATED v2.0** — Individual badges confirmed: First Steps, Puzzle Master, Streak Keeper, Realm Restorer, Academy Graduate, Collection Guardian, Daily Pal, Daily Dedicated. Most are canon-consistent (contribution/recognition framing). ⚠️ LOW risk: "Collection Guardian" may imply collectible/gacha framing rather than relationship-building. Creator to note. |
| Scoring / combo system visual spec | Visual Spec | Transferred | **NEW v2.0** — Dev Bible (Image 1) confirms: base score per match, multipliers, bonus scores, combo system (2x, 3x, 4x+). ⚠️ CANON RISK — combo multiplier system is power-escalation framing. Violates Rule 1.4. Flag for creator. |

---

## G — AUDIO (PLACEHOLDER)

| Asset | Type | Status | Notes |
|---|---|---|---|
| The Great Song | Music | Pending | Concept established; no composition begun. |
| Lantern theme | Music | Pending | |
| Archive theme | Music | Pending | |
| Companion themes (×8) | Music | Pending | |
| Realm themes (×8) | Music | Pending | |

---

## ASSETS FLAGGED FOR HUMAN REVIEW

The following items require creator attention before registry status can be updated:

| # | Asset | Flag | Severity | Action Required |
|---|---|---|---|---|
| 1 | Story Screen text — "Crystal Heart" narrative | ⛔ CRITICAL Canon Risk — introduces named artifact as cause of Shattering; "darkness spread" = antagonist framing. Violates Rules 2.1, 2.2, 2.3. | CRITICAL | Creator must rewrite story screen text. No version of this text may be used as-is. |
| 2 | Kael character art + Art Bible description | ⛔ HIGH Canon Risk — "defeat the Arena Realm / strength of the group" = combat + power role. Conflict 3 now confirmed in visual canon. Violates Rules 1.3, 5.1, 5.4. | HIGH | Creator to confirm Kael reframe direction (Option A locked — civic contribution). Reframe descriptor text before art can be tagged Approved. |
| 3 | Power-ups and boosters (all named items) | ⛔ HIGH Canon Risk — "power advantage" framing with visual blast effects. Named items: Harmony Blast, Star Blast, Colour Bomb, Sparkle, Crystal Pearl, Moonlight Blast, Vertical Blast, Arial Blast. Violates Rules 6.1, 1.4. | HIGH | Creator to confirm: are these puzzle tools (canon-safe) or power advantages (not safe)? |
| 4 | Spark role framing — "helps complete puzzles" | ⚠️ MEDIUM Canon Risk — puzzle-helper framing reduces Spark from witness/partner to mechanic. Violates Rules 4.1, 4.2. | MEDIUM | Creator to confirm reframed Spark role descriptor before character sheet can be tagged Approved. |
| 5 | "Challenge Your Mind. Save the Realms." tagline variant | ⛔ HIGH Canon Risk — "Save the Realms" = savior/hero framing. Violates Rules 1.5, 5.1. | HIGH | Do not use. Approved tagline is "Restore Realms. Build Your Legacy." Creator to confirm this variant is retired. |
| 6 | "Heart of the Core" — unknown realm name | ⚠️ MEDIUM Canon Risk — realm name not in locked canon. Could be 9th Realm, rename of Memory Ocean, or rename of Legacy Realm. | MEDIUM | Creator to identify: Is this a new realm, a rename, or a working title? Cannot tag Approved without confirmation. |
| 7 | Resource bars (Crystal/Ember/Star) | ⚠️ MEDIUM Canon Risk — unknown function. If energy-gating: violates Rule 1.6. | MEDIUM | Creator to confirm: collection resource (safe) or energy/play-blocking system (not safe)? |
| 8 | Gem types — count discrepancy (6 vs 7) | ⚠️ LOW-MEDIUM flag — Dev Bible shows 7 gem types; Art Bible shows 6 colours. | LOW-MEDIUM | Creator to confirm final gem set and names. |
| 9 | Special gems (Bomb Gem, Lightning Gem, Rainbow Gem) | ⚠️ MEDIUM Canon Risk — named destruction mechanics suggest power escalation. Violates Rule 1.4. | MEDIUM | Creator to confirm framing — destruction tools or puzzle solutions? |
| 10 | Scoring / combo system (2x, 3x, 4x+) | ⚠️ MEDIUM Canon Risk — power-escalation reward framing. Violates Rule 1.4. | MEDIUM | Creator to confirm: is the combo system reframeable as a harmony/flow reward, not a power reward? |
| 11 | Lumi, Ember, Frosty companion art | ⚠️ MEDIUM — canon status unresolved (Conflict 6). Visual presence confirmed but launch status unknown. | MEDIUM | Creator to confirm: launch companions, future companions, or concept only? |
| 12 | Match-3 board mockup | ⚠️ LOW — prototype superseded by civilization adventure direction | LOW | Retain as reference or archive? Creator to confirm. |
| 13 | Book of Harmony doc | ⏳ Upload pending | — | Creator approval needed to upload to Space. |
| 14 | First Harmony doc | ⏳ Duration + Threshold model pending | — | Creator to confirm 3–4 century duration and Threshold framing. |
| 15 | "Collection Guardian" achievement badge | ⚠️ LOW — "collection" may imply gacha rather than relationship-building for companions. | LOW | Creator to note and confirm intent. |
| 16 | "One Puzzle. Countless Realms." tagline variant | ⚠️ LOW — "Puzzle" in tagline may reduce franchise identity vs "Restore Realms. Build Your Legacy." | LOW | Creator to confirm whether this variant is retired or a permitted secondary tagline. |
