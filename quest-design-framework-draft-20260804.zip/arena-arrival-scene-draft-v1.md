# Arena Arrival Scene Draft v1

**Project:** GemVerse  
**Mode:** GemVerse Art Studio / Narrative Support  
**Scope:** First-arrival beat sheet and dialogue draft for Arena Realm onboarding  
**Status:** Production-safe working draft derived from current Space canon

---

## Purpose

This document combines the current Arena onboarding guardrails, the Lantern Keeper packet, and the Quiet Ledger puzzle spec into a practical first-scene draft.

It is intended to help narrative, onboarding, UI, and environment teams align on the emotional sequence of the Guardian's arrival in the Arena Realm.

---

## Core scene rule

The scene must introduce GemVerse through **welcome, care, and participation** before mystery, scale, or system explanation.

The Guardian is not framed as a chosen one, conqueror, or rescuer.

---

## Scene goals

This arrival scene should accomplish five things:

1. Establish that someone has been taking care of things.
2. Introduce the Arena Realm as a civic place, not a challenge zone.
3. Give the player a warm first human connection through the Keeper.
4. Open the question: **What was here before?**
5. Transition naturally into the first restorative puzzle.

---

## Emotional order

The emotional order should remain:

- welcome
- care
- orientation
- curiosity
- participation
- only then larger civic scale

If the scene feels like a dramatic reveal, heroic summoning, or test of worth, it is off-canon.

---

## Beat sheet

### Beat 1 — Lantern arrival
The Guardian arrives at a small still-burning Lantern site. The light is steady, the space is intimate, and the immediate environment shows maintenance: swept stone, repaired edges, and a path that is clearly used.

### Beat 2 — First voice
Before any grand architecture dominates the frame, the Keeper notices the Guardian and speaks. The first interaction should feel calm, local, and unsurprised, as though arrivals matter here even when they are infrequent.

### Beat 3 — Human-scale orientation
The Keeper offers a simple welcome and grounds the player in the place through ordinary detail rather than exposition-heavy lore. The scene should imply that the Realm has routines, memory, and people who keep it going.

### Beat 4 — First hint of incompleteness
The Keeper draws attention to a nearby partial ledger, civic surface, or Archive-linked record. The incompleteness should feel intriguing, not alarming.

### Beat 5 — Invitation, not assignment
The Guardian is invited to help notice and restore something small. This should feel like participation in care, not acceptance of a quest from a superior figure.

### Beat 6 — Wider glance
Only after the invitation does the scene widen enough to suggest Harmony Plaza and the larger Arena Realm beyond. Scale is earned after trust.

---

## Recommended staging

### Environment
- Keep the first playable or readable space close and human-scaled.
- Show at least two visible routes leading further into the Realm.
- Include small signs of repeated upkeep near the Lantern site.
- Let Archive presence appear as a nearby trace, not an overwhelming institution.

### Keeper behavior
- The Keeper should already be doing something useful when the Guardian arrives.
- Good activities: trimming wick, checking chalk marks, adjusting a ledger surface, setting a small item in order, glancing down a path.
- Avoid static gatekeeper posing or ceremonial welcome choreography.

### Camera / composition intent
- Lantern first, Keeper second, wider Realm third.
- Use light to gather attention rather than spotlight revelation.
- Keep the Hall and major civic scale as a later visual expansion.

---

## Dialogue draft

### Minimal version

**Keeper:** You're not late. This place waits well.

**Keeper:** We keep the lantern lit for arrivals, even when we don't know who is coming.

**Keeper:** You're in Arena Realm. People used to arrive from every direction. Some still do.

**Keeper:** Not every record survives in the Archive. Some stay in paths, habits, and what people leave ready for each other.

**Keeper:** This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square.

---

### Slightly fuller version

**Keeper:** You're not late. This place waits well.

**Keeper:** The lantern stays lit. Better to be ready than surprised.

**Keeper:** You're in Arena Realm — the kind of place built for people to meet, pass through, and stay a little longer than they meant to.

**Keeper:** It used to fill faster. Market days, council voices, festival nights, companions underfoot, neighbors stopping for no grand reason at all.

**Keeper:** Some of that remains in the record. Some of it remains in the square itself.

**Keeper:** If you have a moment, help me with something small. That's often where remembering begins.

---

## Interaction bridge to puzzle

After the dialogue, the Keeper leads or gestures the Guardian toward the incomplete ledger.

The first interaction prompt should feel observational and gentle, such as:

- Notice what the square still remembers.
- Restore the missing gathering patterns.
- Match the traces left in the plaza.

Avoid prompts that sound combative, gamified, or victory-driven.

---

## Environmental clue starters

The first puzzle space can surface these clues within a short walking radius:

- lantern-string anchor points
- worn trade marks in stone
- faded seating arcs
- route markings from multiple directions
- stall-hook placements
- a companion perch trace
- an Archive fragment embedded into a civic surface

The point is not ruin archaeology.
The point is visible memory through ordinary use.

---

## UI tone notes

Use language such as:
- remember
- restore
- notice
- gather
- trace
- shared life
- welcome
- plaza
- ledger
- record

Avoid language such as:
- defeat
- clear
- conquer
- dominate
- challenge
- victory
- power
- boss

---

## Success feeling

When the player completes the first interaction, the response should be soft and meaningful.

Suggested outcomes:
- a portion of the ledger becomes legible
- a nearby Archive element glows faintly
- ambient sound warms slightly
- the Keeper acknowledges the restored memory without exaggeration

Suggested Keeper follow-up:

**Keeper:** There. Not all at once. Just enough to know the square still remembers.

---

## Guardrails

This draft must not be revised into:
- a prophecy scene
- a chosen-one welcome
- a heroic reveal of the Realm
- a combat tutorial in disguise
- an exposition dump that delays human connection
- a gatekeeper trial or worthiness test

If a revision reduces welcome or increases spectacle, it should be rejected.

---

## Best immediate uses

This draft is ready to support:
- first-scene scripting
- onboarding storyboard passes
- UI prompt drafting
- environment clue planning
- voice and tone review
- Keeper dialogue refinement

---

## Next recommended actions

1. Choose the preferred dialogue length: minimal or fuller.
2. Select the exact first interaction model for The Quiet Ledger.
3. Decide whether the Keeper stays role-only or receives a personal name.
4. Build a companion onboarding variant if a Companion is intended to appear in the first five minutes.
