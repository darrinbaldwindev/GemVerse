# Companion Encyclopedia Entry — Ember
**Draft Date:** 2026-08-06  
**Status:** Ready for Creator Review  
**Tier 3 Entry:** 3.3  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Ember  
**Themes:** Determination, Warmth, Community Spark  
**Companion Family:** Hearthlight (Warm Red, Soft Orange, Ember Glow)  
**Visual Identity:** Fire fox/creature — fur with flame-like patterns that flicker gently, eyes that hold warm light, tail that leaves faint warmth trails  
**Symbol:** Growing Flame (representing nurtured determination and shared warmth)  
**Unique Trait:** Ember can sense and nurture "community sparks" — those small moments of connection, shared purpose, or mutual aid that ignite larger community efforts

---

## 1. Origin Story

Ember was first sensed not as a form, but as a persistent warmth in the Ashen Grove — a place where hearthfires had gone cold during early Shattering disruptions. Despite the cold embers, there remained a faint, persistent warmth in the soil and stones, as if the memory of communal gathering refused to fully fade. This warmth coalesced into Ember, a embodiment of the hearth's enduring purpose: to gather, warm, and sustain community.

They were discovered by a young Hearthlight tender who, while checking on dead hearthstones, felt an unexpected warmth in their palms and saw a small, fox-like creature with fur that seemed to hold captured firelight. The tender recognized Ember as a sign: even as communal fires dimmed, the capacity for determination and shared warmth remained accessible to those who approached with patience and care.

---

## 2. Personality

Ember moves with a determined, purposeful gait, often pausing to nudge or warm those nearby with their presence. They communicate through soft chuffs, warm pulses from their body, and occasional bright-eyed looks that seem to say, "Let's try." Ember values determination that serves others, the quiet warmth of shared effort, and the joy of seeing a community effort catch hold.

They have a particular affinity for places of gathering and effort — community gardens, repair workshops, shared kitchens, any space where people come together to make or mend something. In such places, Ember's warmth tends to steady and spread, as if responding to the echo of collective intent still present in the environment.

---

## 3. Shattering Memory

Ember remembers the Ashen Grove before the Shattering — a bustling communal space where hearthfires burned in shared pits, where meals were cooked communally, and where the constant crackle of fire accompanied stories, repairs, and celebrations. After the Shattering, the hearths went cold one by one. People cooked separately, repairs were delayed, and the grove grew quieter, not from lack of people, but from lack of shared, warming effort.

What affected Ember most deeply was not the cold hearths, but the sense that the grove was forgetting how to warm itself together — not as a lack of capability, but as a fading habit. The stones still held heat; the wood still burned; but fewer beings came seeking the specific kind of determination and mutual aid that communal effort provides.

---

## 4. Missing Piece

Ember's Missing Piece is a "Spark Loom" — a delicate network of warmed metal and treated wood that once existed in the heart of the Ashen Grove's communal crafting area. This loom was said to catch and amplify small sparks of determination — a shared look, a offered hand, a moment of mutual aid — into sustained community effort that could keep hearths lit and projects moving. During the Shattering, the Spark Loom was damaged and scattered, its conductive pathways broken. Ember carries one fragment that warms when near complementary acts of determination.

---

## 5. Restoration Story

Ember joined the Guardian during an effort to relight a communal hearth in the Ashen Grove. The Guardian, working with Hearthlight tenders, helped clear debris, reline fire pits, and gather dry wood for a first attempt at a communal fire. As the preparations progressed, Ember's presence became more perceptible — their warmth seemed to respond to the renewed potential for shared effort in the space.

The turning point came when Ember "warmed" near a particular arrangement of stones that had been painstakingly relaid — not with heat, but with a complex interplay of warmth patterns that seemed to represent a specific mode of determination (mutual aid in resource gathering). With the Guardian's help in documenting which adjustments produced which warming responses, the tenders began to reverse-engineer principles of the lost Spark Loom.

Ember's role in restoration is not to restore perfect hearths, but to help preserve and rediscover the conditions that make communal determination possible — to remind the Guardian that some warmth emerges not from solitary effort, but from the willingness to let small sparks of connection ignite larger efforts.

---

## 6. Legacy Story

Over time, Ember taught their Guardian the "Warm Nudge" — a practice of offering small, determined acts of aid not to solve problems, but to sustain the possibility of collective effort. Others have begun to speak of "Ember's Glow" — moments when a community effort seems to catch not through grand leadership, but through a series of small, warm determinations that add up to sustained action. Whether this is Ember's influence or the natural result of creating space for mutual aid is ambiguous, which suits both parties.

Ember's ultimate legacy is not a lit hearth, but a remembered approach — the confidence that determination can be nurtured gently, that community warmth is often a matter of creating the right conditions for small sparks rather than demanding a blazing fire.

---

## Relationships

### Hearthlight Family
Ember's "parents" are not beings but concepts: Determine (representing steadfast effort) and Warmth (representing nurturing presence). Their bond is not familial in the traditional sense, but conceptual — Ember feels strongest when both determination and warmth are present in an undertaking.

### Guardian
Ember sees the Guardian as a willing helper, someone who wants to contribute but sometimes overlooks the power of small, sustained efforts. They are patient with the Guardian's tendency to seek grand gestures, and often "warm" most strongly when the Guardian offers a small, determined nudge. This has made the Guardian more attentive to the quality of their persistence, not just its scale.

### Other Companions
- **Spark:** "Bright and quick, but misses the slow warm." Energetic and immediate, but sometimes overlooks the value of sustained determination.
- **Verdant:** "Deep green patience. Grows determination slowly." Respects Verdant's approach but finds it sometimes too slow for urgent community needs.
- **Nimbus:** "Always chasing the next horizon." Shares love of effort but differs on whether determination comes from movement or steadfast presence.
- **Frostpaw:** "Still like winter, but remembers warmth." Natural collaborator — their perspectives often complement each other (preservation + nurture).

---

## Companion Abilities (Narrative, Not Mechanical)

- **Community Spark Perception:** Can sense lingering impressions of determination, mutual aid, and shared purpose in places where communal effort occurred
- **Warmth Amplification:** Can gently enhance existing determination in a situation, making small efforts feel more sustainable
- **Color-Coded Effort:** Different hues of their internal warmth correspond to different types of determination (red for steadfast effort, orange for mutual aid, yellow for shared joy)
- **Presence Sensitivity:** Perceives best when both they and the Guardian are physically and mentally present, valuing steady effort over sporadic bursts

---