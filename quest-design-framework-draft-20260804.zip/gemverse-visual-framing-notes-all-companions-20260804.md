# GemVerse Visual Framing Notes — All Companions
**Version:** 1.0  
**Date:** 2026-08-04  
**Purpose:** Comprehensive visual framing guide for all completed Companion Encyclopedia entries

---

## Overview

This document provides visual framing guidance for all eight launch companions based on their completed encyclopedia entries. Each companion's visual identity, thematic elements, and narrative context are described in ways that maintain GemVerse's restorative, non-combat aesthetic while highlighting their unique civilizational roles.

---

## Companion Visual Profiles

### 1. Verdant (Forestkin - Growth Family)

**Visual Identity:**
- Form: Plant-based creature with moss-furred body and bark-textured skin
- Color Palette: Green (primary), Leaf Green (secondary), Earth Brown (accent)
- Distinctive Features: Leaf-shaped ears, bioluminescent sap-trail markings
- Movement Quality: Slow, deliberate, grounded

**Thematic Elements:**
- Symbol: Spiral Fern (representing slow, steady growth and return to center)
- Environmental Context: Verdant Vale, communal groves, bioluminescent trees
- Visual Metaphors: Growing patterns, root networks, seasonal changes

**Narrative Visual Cues:**
- Growth pulse visualization (subtle light patterns indicating health/emotional state)
- Seasonal appearance changes (different leaf patterns for different times)
- Connection to wooden/organic environments and tools

**UI/Interaction Design:**
- Companion Card: Showcasing growth stage progression
- Interaction Icons: Watering can, pruning shears, seasonal indicators
- Emotional State Indicators: Color shifts in bioluminescent markings

---

### 2. Nimbus (Skykin - Discovery Family)

**Visual Identity:**
- Form: Cloud-formed body with definable shape and silver lining edges
- Color Palette: Sky Blue (primary), Cloud White (secondary), Silver (accent)
- Distinctive Features: Translucent core that shimmers with wind currents
- Movement Quality: Floating, flowing, responsive to air movement

**Thematic Elements:**
- Symbol: Drifting Cloud with Silver Lining (representing limitless horizons)
- Environmental Context: Sky Citadel platforms, wind currents, altitude variations
- Visual Metaphors: Wind patterns, air pressure visualization, thermal updrafts

**Narrative Visual Cues:**
- Wind-current reading visualization (air movement patterns made visible)
- Weather memory associations (different appearances for different weather "memories")
- Partial mist-form capability (transparency levels indicating mood/readiness)

**UI/Interaction Design:**
- Companion Card: Wind direction indicators, altitude preferences
- Interaction Icons: Wind sock, barometer, weather symbols
- Pathfinding Assistance: Route visualization overlays

---

### 3. Frostpaw (Frostkin - Memory Family)

**Visual Identity:**
- Form: Small ice bear cub with crystalline fur
- Color Palette: Ice Blue (primary), Moon Silver (secondary), White (accent)
- Distinctive Features: Crystalline fur that shifts opacity with emotions, ice-trail paw prints
- Movement Quality: Deliberate, careful, leaving frost traces

**Thematic Elements:**
- Symbol: Crescent Moon with Ice Crystals (representing night-reflection and clarity)
- Environmental Context: Frozen Expanse ice formations, Memorial Glades, preservation chambers
- Visual Metaphors: Ice crystal growth, frost patterns, layered transparency

**Narrative Visual Cues:**
- Memory resonance visualization (faint images in ice-trail markings)
- Emotional layer separation (different opacity levels for different memory types)
- Temperature-based communication (color shifts indicating emotional states)

**UI/Interaction Design:**
- Companion Card: Memory clarity indicators, preservation status
- Interaction Icons: Ice crystal, memory fragment, temperature gauge
- Archive Work Interface: Ice-sculpture manipulation tools

---

### 4. Prism (Crystalkin - Knowledge Family)

**Visual Identity:**
- Form: Faceted crystalline being with geometric limbs
- Color Palette: Gold (primary), White (secondary), Crystal Blue (accent)
- Distinctive Features: Core that shifts color based on environment and emotional state
- Movement Quality: Geometric, precise, light-reflective

**Thematic Elements:**
- Symbol: Refracted Light Spectrum (representing multifaceted truth)
- Environmental Context: Crystal Forest nodes, Archive terminals, light-filled spaces
- Visual Metaphors: Light refraction, harmonic patterns, multi-perspective views

**Narrative Visual Cues:**
- Truth-refraction visualization (multiple simultaneous light patterns)
- Perspective mapping (showing same scene from different angles)
- Memory crystallization (forming multi-faceted memory-fragments)

**UI/Interaction Design:**
- Companion Card: Perspective variety indicators, knowledge depth meters
- Interaction Icons: Prism, light beam, multiple viewpoint symbols
- Knowledge Work Interface: Light-pattern communication display

---

### 5. Bloomtail (Forestkin - Community Family)

**Visual Identity:**
- Form: Small, rabbit-like creature with expressive features
- Color Palette: Emerald (primary), Leaf Green (secondary), Earth Brown (accent)
- Distinctive Features: Flower-petal ears that change color with seasons, blooming tail
- Movement Quality: Quick, energetic, garden-responsive

**Thematic Elements:**
- Symbol: Interwoven Flowers and Roots (representing interconnected growth)
- Environmental Context: Community gardens, Circle Gardens, seasonal celebration spaces
- Visual Metaphors: Flower blooming, root networking, seasonal color changes

**Narrative Visual Cues:**
- Empathic bloom-reading visualization (flower patterns indicating community health)
- Seasonal awareness (different ear colors for different seasons/holidays)
- Growth harmony facilitation (encouraging coordinated visual elements in environment)

**UI/Interaction Design:**
- Companion Card: Community health indicators, seasonal activity levels
- Interaction Icons: Flower, garden tools, group symbols
- Community Work Interface: Garden planning and coordination tools

---

### 6. Galewing (Skykin - Exploration Family)

**Visual Identity:**
- Form: Bird-like with specialized wing structure
- Color Palette: Sky Blue (primary), Cloud White (secondary), Silver (accent)
- Distinctive Features: Iridescent wing-feathers that shimmer with wind-patterns
- Movement Quality: Dynamic flight, wind-riding, aerial agility

**Thematic Elements:**
- Symbol: Soaring Bird with Wind Trails (representing freedom of movement)
- Environmental Context: Aerial routes, migration paths, high-altitude waystations
- Visual Metaphors: Wind trails, migration patterns, path-singing visualization

**Narrative Visual Cues:**
- Path-singing visualization (temporary wind-guides made visible)
- Wind-pattern reading (air current visualization for navigation)
- Journey harmony indication (flight pattern coordination displays)

**UI/Interaction Design:**
- Companion Card: Flight range indicators, route knowledge maps
- Interaction Icons: Bird silhouette, wind compass, path markers
- Exploration Interface: Aerial navigation and route mapping tools

---

### 7. Echo (Frostkin - History Family)

**Visual Identity:**
- Form: Ethereal, mist-like with core presence
- Color Palette: Ice Blue (primary), Moon Silver (secondary), Distant Starlight (accent)
- Distinctive Features: Core that flickers like distant starlight, ability to partially solidify
- Movement Quality: Flowing, atmospheric, presence-based rather than physical

**Thematic Elements:**
- Symbol: Sound Wave with Fading Notes (representing preserved voices)
- Environmental Context: Memory-rich locations, Archive spaces, sound-sensitive areas
- Visual Metaphors: Sound visualization, memory echoes, temporal layering

**Narrative Visual Cues:**
- Resonance-catchment visualization (faint replay of conversation fragments)
- Memory-tuning indication (clarity adjustments in voice quality)
- Emotional echoing (matching the emotional tone of relevant memory fragments)

**UI/Interaction Design:**
- Companion Card: Memory clarity levels, voice quality indicators
- Interaction Icons: Sound wave, echo symbol, voice recording
- Memory Work Interface: Audio preservation and playback systems

---

### 8. Spark (Crystalkin - Hope Family)

**Visual Identity:**
- Form: Small, energetic creature with expressive features
- Color Palette: Crystal Blue (primary), White (secondary), Gold (accent)
- Distinctive Features: Sparkling energy effects, expressive eyes, quick movements
- Movement Quality: Energetic, quick, attention-grabbing

**Thematic Elements:**
- Symbol: Spark or Small Flame (representing beginnings and curiosity)
- Environmental Context: Learning spaces, new discovery areas, community gathering points
- Visual Metaphors: Energy sparks, light flashes, curiosity indicators

**Narrative Visual Cues:**
- Energy level visualization (sparkle intensity indicating engagement)
- Curiosity indicators (eye sparkle patterns showing interest levels)
- Enthusiasm expression (movement speed and energy effect variations)

**UI/Interaction Design:**
- Companion Card: Energy levels, curiosity indicators, excitement meters
- Interaction Icons: Sparkle, lightning bolt, question mark
- Learning Interface: Interactive discovery and engagement tools

---

## Cross-Companion Visual Consistency

### Family-Based Visual Elements

**Crystalkin Family (Prism, Spark):**
- Geometric forms and crystalline structures
- Light-refractive properties and color-shifting capabilities
- Association with knowledge and insight environments
- Clean, precise visual presentation

**Forestkin Family (Verdant, Bloomtail):**
- Organic, plant-based forms with natural textures
- Green and earth-tone color palettes
- Association with growth and community spaces
- Dynamic, living appearance changes

**Skykin Family (Nimbus, Galewing):**
- Air-based forms with floating or flying capabilities
- Sky and cloud color palettes
- Association with exploration and discovery environments
- Flowing, atmospheric movement qualities

**Frostkin Family (Frostpaw, Echo):**
- Ice-based or atmospheric forms with crystalline elements
- Blue and silver color palettes
- Association with memory and preservation environments
- Cool-toned, reflective visual qualities

### Unified Visual Language

**Emotional Expression System:**
- All companions use color shifts to indicate emotional states
- Movement quality reflects personality and current focus
- Environmental interaction shows affinity for their thematic elements

**Civilizational Integration:**
- Companions appear appropriately in their affiliated Realm environments
- Visual design connects to civilizational infrastructure (Crystal Network, Archive, etc.)
- Companion interactions with citizens shown through complementary visual cues

**Restorative Aesthetic:**
- No combat-related visual elements
- No power-level indicators or escalation imagery
- All visual elements support collaborative, nurturing activities
- Design emphasizes contribution rather than competition

---

## Implementation Guidelines

### Character Art Development
1. **Consistent Core Identity**: Each companion should be recognizable in silhouette
2. **Thematic Color Coding**: Family affiliations should be visually apparent
3. **Emotional Clarity**: Current emotional state should be readable through visual cues
4. **Environmental Integration**: Companions should look appropriate in their affiliated settings
5. **Activity Appropriateness**: Visual design should support their narrative functions without suggesting inappropriate activities

### UI/Interface Design
1. **Companion Cards**: Should show relevant thematic elements and current status indicators
2. **Interaction Icons**: Should clearly represent each companion's primary abilities
3. **Progress Indicators**: Should reflect civilizational contribution rather than power levels
4. **Relationship Displays**: Should visualize companion connections without suggesting dependency
5. **Contextual Integration**: UI elements should match the restorative fantasy aesthetic

### Environmental Integration
1. **Realm-Specific Appearances**: Companions should look appropriate in their affiliated Realms
2. **Activity-Appropriate Contexts**: Visual presentation should match their narrative functions
3. **Civilizational Consistency**: All visual elements should support the GemVerse aesthetic
4. **Cultural Authenticity**: Companion appearances should reflect First Harmony cultural values
5. **Restoration Support**: Visual design should enhance rather than distract from restoration activities

---

## Review Checklist

### Canon Compliance
- [ ] All companions avoid combat or power-escalation imagery
- [ ] Visual design supports witness/partner rather than tool/instrument roles
- [ ] Family affiliations are consistent with established color languages
- [ ] Environmental contexts align with Realm themes and functions
- [ ] No energy-gating or pay-to-win visual suggestions

### Aesthetic Consistency
- [ ] Visual language is unified across all companions
- [ ] Family-based design elements are recognizable
- [ ] Emotional expression system works across all characters
- [ ] Activity-appropriate visual presentation maintained
- [ ] Restorative fantasy aesthetic consistently applied

### Technical Implementation
- [ ] Character art guidelines are clear and implementable
- [ ] UI design recommendations support gameplay functions
- [ ] Environmental integration suggestions are practical
- [ ] Cross-companion consistency is maintained in all contexts
- [ ] Visual framing supports narrative and mechanical goals

---

This visual framing guide ensures that all companions are presented in ways that enhance their civilizational roles while maintaining GemVerse's distinctive restorative fantasy aesthetic.