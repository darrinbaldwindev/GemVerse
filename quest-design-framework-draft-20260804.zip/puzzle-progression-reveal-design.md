# Puzzle Progression & Reveal Design
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.5  
**Linked Files:** `puzzle-catalog.md`, `companion-encyclopedia-*.md` (all 8), `realm-packet-*.md` (all 8), `harmony-index-system-design.md`, `great-archive-ux-specification.md`, `companion-interaction-system-design.md`

---

## Overview

Puzzles in GemVerse are **archaeological fragments of a civilization's memory** — not obstacles to overcome, but invitations to remember, understand, and participate in restoration. The progression system reflects this: puzzles reveal more of the civilization's story and the player's role in it, rather than increasing in difficulty for difficulty's sake.

### Core Philosophy

1. **Revelation Over Difficulty** — Each puzzle reveals something meaningful. "Harder" puzzles reveal deeper or more complex truths, not just more complex mechanics.

2. **Participation Over Solution** — The goal is engaging with the puzzle's meaning, not just reaching the solution state. The process is the point.

3. **Connection Over Isolation** — Puzzles connect to companions, realms, citizens, and other puzzles. No puzzle exists in isolation.

4. **Accessibility Over Exclusion** — Every puzzle can be engaged with meaningfully by every citizen, regardless of cognitive, visual, or motor abilities.

5. **Restoration Over Completion** — Puzzles are never "finished" — they're restored, tended, and revisited as understanding deepens.

---

## Puzzle Type Progression (8 Types)

Each puzzle type has a **revelation arc** across three tiers:

### 1. Crystal Resonance → Harmonic Attunement → Network Synthesis
**Core Mechanic:** Aligning gem frequencies with environmental/crystal patterns

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Crystal Resonance** | Single crystal, single frequency, immediate feedback | Basic pattern matching, one variable | **Spark** — "Feel the hum. Match it." |
| **Harmonic Attunement** | Multiple crystals, chord structures, environmental resonance | Chord theory, environmental variables | **Prism** — "Each crystal sings its own note. Together they make a chord." |
| **Network Synthesis** | Full Crystal Network node restoration, cross-realm resonance | Network topology, historical layers, companion synthesis | **All Crystalkin + Verdant** — "The Network remembers. Help it sing again." |

### 2. Verdance Cultivation → Ecosystem Restoration → Biome Harmony
**Core Mechanic:** Nurturing growth through appropriate conditions

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Verdance Cultivation** | Single plant, basic needs (light, water, soil, companion) | Condition matching, patience | **Verdant** — "She needs morning light and your patience." |
| **Ecosystem Restoration** | Interdependent species, soil web, water cycles, companion roles | Systems thinking, multiple variables, time | **Bloomtail** — "Nothing grows alone. See the connections." |
| **Biome Harmony** | Full realm biome restoration, cross-realm species exchange, climate adaptation | Complex systems, long-term stewardship, civilizational scale | **Verdant + Bloomtail + Solen** — "A healed biome serves all who dwell in it." |

### 3. Harmony Alignment → Systemic Balance → Civilizational Equilibrium
**Core Mechanic:** Balancing competing needs in systems

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Harmony Alignment** | Two-three elements, visible imbalance, direct adjustment | Trade-off recognition, simple balance | **Solen** — "Too much here, too little there. Adjust gently." |
| **Systemic Balance** | Interconnected systems, hidden feedback loops, delayed consequences | Systems mapping, prediction, iterative adjustment | **Solen + Prism** — "Change ripples. Watch the whole pond." |
| **Civilizational Equilibrium** | Cross-realm resource flows, cultural practices, companion needs, mystery factors | Civilizational-scale systems, mystery integration, aspirational balance | **Solen + All Harmonists** — "Balance is not static. It's a dance we all join." |

### 4. Fragment Assembly → Narrative Reconstruction → Memory Restoration
**Core Mechanic:** Reassembling fragmented knowledge/memory

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Fragment Assembly** | 3-5 fragments, single narrative, clear connections | Pattern recognition, narrative logic | **Echo** — "Each piece holds a voice. Listen for how they answer each other." |
| **Narrative Reconstruction** | 10+ fragments, multiple perspectives, contradictory accounts | Perspective synthesis, gap navigation, emotional logic | **Echo + Prism** — "Truth isn't in one fragment. It's in how they all lean toward each other." |
| **Memory Restoration** | Civilizational-scale memory, companion deep memories, mystery integration | Multi-layer synthesis, mystery preservation, restoration planning | **Echo + Frostpaw + All Companions** — "Some memories were never recorded. They were lived." |

### 5. Pathfinder's Mark → Route Restoration → Network Reweaving
**Core Mechanic:** Finding and restoring connections between places

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Pathfinder's Mark** | Single route, visible markers, companion guidance | Observation, mark interpretation, companion trust | **Nimbus** — "The wind shows the way. Learn its language." |
| **Route Restoration** | Damaged route, environmental obstacles, community needs | Engineering, ecology, community coordination | **Galewing** — "A path serves those who walk it. Ask them what they need." |
| **Network Reweaving** | Full Lantern Network sector, cross-realm coordination, mystery currents | Network topology, civilizational planning, mystery navigation | **Nimbus + Galewing + Lantern Keepers** — "The Network is a promise. Keep it." |

### 6. Community Pattern → Collaborative Design → Civilizational Weaving
**Core Mechanic:** Understanding and designing for community needs

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Community Pattern** | Single community, visible patterns, direct participation | Social observation, pattern recognition, facilitation | **Rowan** — "Watch how they move together. The pattern is in the between." |
| **Collaborative Design** | Multiple communities, conflicting needs, shared resources | Multi-stakeholder facilitation, creative synthesis | **Mira + Bloomtail** — "Design with them, not for them. The best designs grow from conversation." |
| **Civilizational Weaving** | Cross-realm cultural integration, festival design, aspirational structures | Civilizational-scale facilitation, mystery integration, legacy thinking | **Rowan + Mira + All Mentors/Harmonists** — "We weave the civilization anew. Every thread matters." |

### 7. Legacy Seal → Commitment Verification → Aspirational Anchoring
**Core Mechanic:** Engaging with civilizational commitments across time

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Legacy Seal** | Single Time Capsule, clear contents, direct verification | Seal interpretation, commitment assessment, historical context | **Frostpaw** — "They sealed this for you. What does it ask of you?" |
| **Commitment Verification** | Multiple capsules, evolving commitments, partial fulfillment | Cross-generational analysis, commitment genealogy | **Echo + Frostpaw** — "Promises change as we grow. The question is: did we grow toward them?" |
| **Aspirational Anchoring** | Civilizational commitments, future-oriented promises, mystery integration | Aspiration synthesis, threshold ceremonies, legacy planning | **All Legacy Realm Citizens + Companions** — "What will you seal for those who come after?" |

### 8. Echo Sequence → Resonance Mapping → Deep Memory Communion
**Core Mechanic:** Attuning to emotional/historical resonance

| Tier | Revelation Focus | Complexity | Companion Guide |
|------|-----------------|------------|-----------------|
| **Echo Sequence** | Single resonance, clear emotional tone, direct memory | Emotional attunement, memory witnessing, companion guidance | **Echo** — "Close your eyes. Feel what happened here. It's still speaking." |
| **Resonance Mapping** | Multiple resonances, overlapping emotions, historical layers | Emotional cartography, layer navigation, companion synthesis | **Echo + Frostpaw** — "Grief and joy can occupy the same space. Map both." |
| **Deep Memory Communion** | Civilizational unconscious, pre-history memories, mystery horizons | Deep attunement, mystery communion, aspirational resonance | **Echo + Frostpaw + Memory Ocean** — "The Ocean remembers what we forgot we knew." |

---

## REV-001 to REV-012 Integration (Puzzle Catalog Reveal System)

Each REV (Revelation) entry in the Puzzle Catalog represents a **specific puzzle instance** that reveals a specific piece of the civilization's story. They are not "levels" — they are **story beats** delivered through puzzle engagement.

### REV Structure
```json
{
  "revId": "REV-001",
  "title": "The First Resonance",
  "puzzleType": "Crystal Resonance",
  "tier": 1,
  "realm": "Arena Realm",
  "location": "Lantern Tower Base",
  "companionGuide": "Spark",
  "revelation": "The Lantern Network's core frequency — the 'heartbeat' that synchronizes all lanterns",
  "storyContext": "Spark guides you to the Tower's base crystal. When you match its frequency, you hear the Network's rhythm for the first time in generations.",
  "restorationImpact": "Activates the Lantern Tower's local synchronization. Nearby communities report clearer lantern signals.",
  "companionMemory": "Spark creates a Memory Crystal: 'The first time you heard the Network's heart. I felt it too — through you.'",
  "followUpRevelations": ["REV-002", "REV-005"],
  "accessibility": {
    "visual": "Frequency shown as color, shape, vibration patterns",
    "audio": "Frequency heard as tone, rhythm, harmonic richness",
    "cognitive": "Single variable, immediate feedback, Spark guidance always available",
    "motor": "Single tap/hold/drag, no timing pressure, alternative inputs"
  }
}
```

### REV-001 to REV-012 Overview

| REV | Title | Type | Tier | Realm | Companion | Key Revelation |
|-----|-------|------|------|-------|-----------|----------------|
| **REV-001** | The First Resonance | Crystal Resonance | 1 | Arena | Spark | Lantern Network heartbeat |
| **REV-002** | The Seed That Waited | Verdance Cultivation | 1 | Crystal Forest | Verdant | Dormant Crystal Network node seed |
| **REV-003** | The Balance of Breath | Harmony Alignment | 1 | Ember Depths | Solen | Community cooling system equilibrium |
| **REV-004** | The Whisper in the Ice | Fragment Assembly | 1 | Frozen Expanse | Echo | Pre-Shattering memory fragment |
| **REV-005** | The Wind's Old Path | Pathfinder's Mark | 1 | Sky Citadel | Nimbus | Dormant Lantern route to Crystal Forest |
| **REV-006** | The Circle's First Turn | Community Pattern | 1 | Arena Realm | Rowan | Harmony Circle facilitation structure |
| **REV-007** | The Promise Unsealed | Legacy Seal | 1 | Legacy Realm | Frostpaw | Founding generation's unopened Time Capsule |
| **REV-008** | The Song Beneath Silence | Echo Sequence | 1 | Memory Ocean shore | Echo | Civilizational unconscious first contact |
| **REV-009** | The Chord of Three Realms | Harmonic Attunement | 2 | Crystal Forest | Prism | Tri-realm Crystal Network chord |
| **REV-010** | The Garden That Connects | Ecosystem Restoration | 2 | Ember Depths | Bloomtail | Cross-realm vent-garden species exchange |
| **REV-011** | The Route That Heals | Route Restoration | 2 | Twilight Frontier | Galewing | Provisionally manifested path to Memory Ocean |
| **REV-012** | The Question That Grows | Fragment Assembly | 2 | Celestial Nexus | Prism | Unanswered Question that generates its own fragments |

---

## Difficulty ≠ Revelation Depth

**Critical Design Rule:** Puzzle mechanical complexity does not gate revelation depth.

- A Tier 1 puzzle can reveal a profound civilizational truth
- A Tier 3 puzzle might reveal a beautiful but specific ecological detail
- **Revelation is designed independently from mechanical complexity**
- Citizens can experience all revelations regardless of puzzle skill
- **Assist modes** (not "easy modes") ensure full revelation access:
  - **Companion Guidance**: Companions can perform mechanical steps while citizen focuses on meaning
  - **Automated Resolution**: Citizen can choose to witness the revelation without mechanical engagement
  - **Collaborative Resolution**: Multiple citizens/companions can work together
  - **Narrative Bypass**: Great Archive provides revelation context for citizens who cannot engage mechanically

### Assist Mode Philosophy
> "You are not less of a citizen because you experience the story differently. The civilization needs every way of knowing."

---

## Progression Structure (Non-Linear)

### No Central Progression Track
- Citizens encounter puzzles organically through exploration, companion invitation, community need
- No "puzzle menu" or "level select"
- Puzzles appear in the world where they belong

### Revelation Web (Not Tree)
- REVs connect in a **web**, not a tree
- Multiple paths to any revelation
- Some revelations only accessible through specific companion relationships
- Some revelations only accessible through specific community participation
- Some revelations only accessible through specific festival engagement

### Discovery Tracking (Personal, Not Comparative)
```json
{
  "citizenPuzzleJourney": {
    "revsExperienced": ["REV-001", "REV-004", "REV-006"],
    "revsWitnessed": ["REV-002", "REV-008"],
    "revsCollaborated": ["REV-003", "REV-005"],
    "revelationsUnderstood": [
      { "revId": "REV-001", "personalMeaning": "string", "companionReflection": "string" },
      { "revId": "REV-004", "personalMeaning": "string", "companionReflection": "string" }
    ],
    "puzzleTypesEngaged": ["Crystal Resonance", "Fragment Assembly", "Community Pattern"],
    "companionGuides": ["Spark", "Echo", "Rowan"],
    "preferredAssistModes": ["companionGuidance", "collaborativeResolution"]
  }
}
```

---

## Companion-Guided Progression

Each companion guides citizens through their specialty puzzle types:

### Spark → Crystal Resonance pathway
- Introduces Crystal Resonance (REV-001)
- Invites to Harmonic Attunement when relationship deepens
- Facilitates Network Synthesis at Partner/Kindred layer

### Verdant → Verdance Cultivation pathway
- Introduces Verdance Cultivation (REV-002)
- Guides to Ecosystem Restoration through community projects
- Co-facilitates Biome Harmony with Bloomtail at civilizational scale

### Solen → Harmony Alignment pathway
- Introduces Harmony Alignment (REV-003)
- Guides to Systemic Balance through community facilitation
- Co-facilitates Civilizational Equilibrium at Harmony Convergence

### Echo → Fragment Assembly & Echo Sequence pathways
- Introduces both Tier 1 types (REV-004, REV-008)
- Guides through all three tiers of both types
- Deep Memory Communion only at Kindred layer

### Nimbus → Pathfinder's Mark pathway
- Introduces Pathfinder's Mark (REV-005)
- Guides to Route Restoration through joint exploration
- Co-facilitates Network Reweaving with Galewing

### Rowan → Community Pattern pathway
- Introduces Community Pattern (REV-006)
- Guides to Collaborative Design through mentorship
- Co-facilitates Civilizational Weaving at Harmony Convergence

### Frostpaw → Legacy Seal pathway
- Introduces Legacy Seal (REV-007)
- Guides to Commitment Verification through Archive work
- Co-facilitates Aspirational Anchoring at Threshold of Tomorrow

### Prism → Cross-Type Synthesis
- Does not have a "primary" type
- Facilitates synthesis across types (REV-009, REV-012)
- Helps citizens see connections between different revelation pathways
- Essential for Tier 3 puzzles requiring multi-perspective integration

---

## Festival Puzzle Integration

Each festival features special puzzle instances:

| Festival | Puzzle Focus | Special Revelation |
|----------|-------------|-------------------|
| Festival of Beginnings | Introductory puzzles (all 8 types, Tier 1) | "Welcome to the work" — first puzzle memories |
| Lantern Gathering | Pathfinder's Mark + Crystal Resonance | Lantern Network route + frequency synchronization |
| Harmony Week | Harmony Alignment + Community Pattern | Cross-community balance + collaborative design |
| Mentor Celebration | Legacy Seal + Fragment Assembly | Intergenerational wisdom + mentorship memories |
| Growth Festival | Verdance Cultivation + Ecosystem Restoration | Seasonal planting + biome connection |
| Discovery Festival | Pathfinder's Mark + Fragment Assembly | New route discovery + knowledge recovery |
| Memory Festival | Fragment Assembly + Echo Sequence | Ancestral memory + deep resonance |
| Resilience Festival | Harmony Alignment + Legacy Seal | Adaptation patterns + commitment verification |
| Imagination Festival | Community Pattern + Fragment Assembly | Vision collaboration + possibility fragments |
| Wonder Festival | Crystal Resonance + Echo Sequence | Cosmic perspective + deep memory communion |

---

## Long-Term Puzzle Content Strategy

### Seasonal Revelation Cycles
- Each season brings new REV instances (not "new levels")
- Tied to festivals, companion cycles, environmental changes
- 12-24 new REVs per year across all types
- Each REV is a permanent addition to the civilization's story

### Companion-Driven Revelation
- As companion relationships deepen, new REV pathways open
- Kindred-layer companions unlock unique REV sequences
- Companion Memory Crystals become REV sources

### Community-Driven Revelation
- Communities can commission REV instances for their specific needs
- Collaborative REVs require multiple citizens
- Civilizational-scale REVs emerge from Harmony Convergence

### Mystery-Driven Revelation
- Unanswered Questions in Great Archive generate REV pathways
- Tending a Question may reveal a Fragment Assembly REV
- Deep Memory Communion REVs emerge from Mystery Ocean engagement

---

## Technical Implementation

### Puzzle Engine (Construct 3)
- **Modular Puzzle Framework**: Each type = plugin with standardized interface
- **Revelation System**: Separate from puzzle mechanics — triggers on engagement milestones
- **Assist Mode Framework**: Built into every puzzle type
- **Companion Integration**: Companion behavior modules plug into puzzle framework
- **Archive Integration**: REV completion creates Archive entries automatically
- **Memory Crystal Creation**: Integrated into REV completion flows
- **Relationship Tracking**: Puzzle collaboration updates companion relationships

### Event Sheet Organization
- `Puzzle_Framework.es` — Core engine, state management, assist modes
- `Puzzle_CrystalResonance.es` through `Puzzle_EchoSequence.es` — 8 type implementations
- `Puzzle_REVSystem.es` — REV definitions, revelation triggers, tracking
- `Puzzle_CompanionIntegration.es` — Companion guidance, collaboration, memory creation
- `Puzzle_Accessibility.es` — All assist modes, alternative inputs, sensory options
- `Puzzle_Archive.es` — Archive entry creation, revelation logging, citizen journey
- `Puzzle_Festival.es` — Festival-specific REV instances, seasonal cycles
- `Puzzle_Progression.es` — Revelation web, companion pathways, discovery tracking

### Asset Requirements per Puzzle Type
- **Base Mechanics Assets**: Reusable across all tiers
- **Tier-Specific Visuals**: Environmental context, scale indicators
- **Companion Guidance Assets**: Unique per companion per type
- **Revelation VFX/Audio**: Unique per REV (12+ per year)
- **Memory Crystal Shaders**: Per companion family + collaborative
- **Archive Integration UI**: Revelation display, journey visualization

---

## Accessibility Implementation (Per Puzzle Type)

### Crystal Resonance
- **Visual**: Color + shape + vibration + numerical frequency display
- **Audio**: Tone + harmonic richness + visual waveform
- **Cognitive**: Single variable, companion shows target, no failure state
- **Motor**: Tap/hold/drag, auto-align option, voice control

### Verdance Cultivation
- **Visual**: Plant health indicators (color, posture, particles), condition meters
- **Audio**: Growth sounds, condition alerts, companion voice guidance
- **Cognitive**: One plant at a time, Verdant shows needs, no time pressure
- **Motor**: Simple placement, auto-care option, companion can tend

### Harmony Alignment
- **Visual**: System diagram, flow indicators, imbalance highlights
- **Audio**: System hum changes with balance, Solen vocal guidance
- **Cognitive**: 2-3 elements max, Solen explains trade-offs, undo always available
- **Motor**: Slider/adjustment, auto-balance option, voice control

### Fragment Assembly
- **Visual**: Fragment shapes, connection highlights, narrative preview
- **Audio**: Fragment "voices," connection chimes, Echo narration
- **Cognitive**: 3-5 fragments, Echo suggests connections, no wrong answers
- **Motor**: Drag/snap, auto-connect option, voice-directed assembly

### Pathfinder's Mark
- **Visual**: Wind trails, mark glow, route preview, Nimbus aerial view
- **Audio**: Wind sounds change with route quality, Nimbus sings path
- **Cognitive**: Single route, Nimbus guides, no dead ends
- **Motor**: Path drawing, auto-route option, companion flies route

### Community Pattern
- **Visual**: Community map, pattern overlays, relationship threads
- **Audio**: Community soundscape, Rowan facilitation voice
- **Cognitive**: One pattern at a time, Rowan explains, collaborative option
- **Motor**: Map interaction, auto-pattern option, voice-directed

### Legacy Seal
- **Visual**: Capsule 3D model, content display, commitment timeline
- **Audio**: Seal opening resonance, Frostpaw narration, commitment echoes
- **Cognitive**: Single capsule, Frostpaw contextualizes, no judgment
- **Motor**: Seal opening gesture, auto-open option, voice-directed

### Echo Sequence
- **Visual**: Resonance waves, memory fragments, emotional color coding
- **Audio**: Memory voices, resonance tones, Echo guidance
- **Cognitive**: Single resonance, Echo witnesses with you, no interpretation required
- **Motor**: Attunement gesture, auto-attune option, voice-directed

---

## Monetization Boundary (Explicit)

**The Puzzle System is entirely outside monetization.**
- No puzzle unlocks for purchase
- No assist mode purchases (all free)
- No REV acceleration
- No revelation skipping
- No puzzle cosmetics for purchase (earned through participation)
- No data analytics on puzzle engagement patterns

---

## Implementation Priority

### Phase 1 (MVP)
- All 8 puzzle types at Tier 1 (REV-001 to REV-008)
- Full assist mode framework
- Spark, Echo, Verdant, Nimbus, Rowan, Frostpaw as guides
- Basic revelation tracking (citizen journey)
- Festival integration for 4 launch festivals
- Full accessibility suite

### Phase 2 (Post-Launch)
- Tier 2 puzzles (REV-009 to REV-012 + new seasonal REVs)
- All 8 companions as guides (Prism, Bloomtail, Galewing, Solen, Mira, Taren, Lyra)
- Full revelation web (cross-type connections)
- Companion pathway gating (relationship-based)
- Community-commissioned REVs
- Advanced Memory Crystal integration

### Phase 3 (Long-term)
- Tier 3 puzzles (civilizational scale)
- Mystery-driven REV generation
- Inter-generational REV sequences
- Companion-initiated REVs
- Civilizational REV synthesis (Harmony Convergence outcomes)
- Puzzle practice as cultural export