# Citizen Encyclopedia Entry — Rowan
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.9  
**Linked Files:** `01-canon-map.md`, `imp-03-citizen-life-layer.md`, `imp-04-companion-relationship-web.md`

---

## Overview

**Name:** Rowan  
**Themes:** Community, Reliability, Stewardship  
**Path Alignment:** Mentor Path (Community Pillar)  
**Visual Identity:** [Pending - Character art not yet available]  
**Symbol:** Interlocking Hands (representing reliable support and community connection)  
**Notable Traits:** Unwavering reliability, exceptional listening skills, natural community organizer

---

## 1. Background

Rowan grew up in a mixed community settlement in the Arena Realm, where citizens from different Realms came together to work on restoration projects. Their early experiences with diverse groups taught them to find common ground and build consensus among people with different backgrounds and perspectives.

They showed early aptitude for noticing when community members were struggling or when group dynamics were becoming unbalanced. By their late teens, other citizens were naturally seeking out Rowan's advice on interpersonal conflicts and community organization challenges.

Rowan's formal training began when they were accepted as an apprentice to an established Mentor Path practitioner who recognized their natural ability to help groups work together effectively. Their training emphasized not just conflict resolution but also proactive community building - creating conditions where conflicts were less likely to arise in the first place.

---

## 2. Role in Society

Rowan serves as a **Community Facilitation Specialist** in the Arena Realm, working with citizen groups on collaborative restoration projects. Their role involves:

- **Group Process Guidance**: Helping citizen teams work together more effectively on restoration tasks
- **Conflict Prevention**: Identifying potential interpersonal issues before they disrupt community work
- **Community Integration**: Welcoming new citizens and helping them connect with established community members
- **Resource Coordination**: Ensuring that community projects have the support and materials they need

Rowan is particularly valued for their ability to work with diverse groups. The mixed-community environment of the Arena Realm means that citizens from different Realms with different cultural backgrounds often need help finding shared approaches to collaborative work.

They also serve as a bridge between different age groups in the community, helping younger citizens learn from elders while ensuring that older community members remain engaged with current projects and concerns.

---

## 3. Relationships

### Companion Connections

Rowan has developed particularly strong relationships with several companions:

- **Bloomtail**: Natural partners in community garden and Circle Garden projects. Bloomtail's intuitive understanding of community needs complements Rowan's organizational skills.
- **Spark**: Appreciates Spark's energy for bringing people together, though sometimes needs to help channel that energy into sustainable community building rather than temporary enthusiasm.
- **Echo**: Works with Echo to preserve community stories and traditions that help maintain group cohesion over time.
- **Verdant**: Collaborates on environmental restoration projects that serve both ecological and community-building purposes.

### Citizen Relationships

- **Mentor**: Rowan's original teacher, now a colleague and occasional collaborator on complex community challenges
- **Peers**: Several other Mentor Path practitioners in the Arena Realm who share case consultations and learning
- **Community Members**: Known and trusted by citizens across different neighborhoods and project groups
- **Younger Citizens**: Often sought out by newer community members for advice on fitting in and contributing meaningfully

### Institutional Relationships

- **Archive Representatives**: Works with Archive Chroniclers to document community practices and lessons learned
- **Realm Coordination Council**: Serves as a community voice in Realm-level planning discussions
- **Restoration Project Leaders**: Collaborates with citizens leading specific restoration initiatives

---

## 4. Personal Goal

Rowan's current personal goal is to develop a **Sustainable Community Integration Framework** - a replicable approach to helping new citizens from different Realms feel welcomed and valued while also maintaining the established community's identity and practices.

This involves:
- Creating structured onboarding processes for new community members
- Developing cross-cultural understanding resources
- Establishing mentorship programs pairing new arrivals with established citizens
- Documenting best practices for inclusive community decision-making

They're working on this project in collaboration with Archive scholars who are interested in preserving effective community practices, and with companions who can offer different perspectives on what makes communities thrive.

---

## 5. Contribution Story

Rowan's most significant contribution to the Restoration Era effort came during a challenging period when resources were limited and some community members were becoming frustrated with slow progress on restoration projects.

Rather than trying to solve resource shortages directly, Rowan recognized that the real challenge was maintaining community morale and cooperation under stress. They organized a series of **Community Resilience Workshops** that helped citizens acknowledge their frustrations while also celebrating small wins and maintaining focus on long-term goals.

These workshops led to the development of several innovations:
- **Micro-Restoration Projects**: Small-scale activities that could be completed with limited resources but still contributed meaningfully to overall restoration
- **Skill-Sharing Networks**: Citizens teaching each other skills they'd learned from their home Realms, building both practical capacity and community bonds
- **Progress Documentation Systems**: Ways of recording and celebrating incremental advances that might otherwise go unnoticed

The success of these initiatives was measured not just in completed projects but in community cohesion - citizens who might have left the Arena Realm community chose to stay and contribute to longer-term restoration efforts.

---

## 6. Legacy Story

Rowan's approach to community facilitation is beginning to influence practices in other Realms. Citizens from the Crystal Forest and Sky Citadel have visited the Arena Realm specifically to learn from Rowan's methods, and some of these practices are being adapted to those communities' different contexts.

Archive scholars have documented Rowan's **Community Integration Framework** as a significant contribution to civilizational knowledge about cross-cultural collaboration. The framework is being tested in several other mixed-community settlements with promising results.

Rowan themselves hopes their legacy will be communities that can maintain their distinct identities while also contributing to larger civilizational restoration goals - proving that unity doesn't require uniformity, and that diversity can be a strength rather than a challenge.

---

## Citizen Abilities (Narrative, Not Mechanical)

- **Community Pattern Recognition**: Can quickly identify group dynamics and potential collaboration opportunities
- **Conflict Prevention Sensitivity**: Notices interpersonal tensions before they become disruptive
- **Inclusive Facilitation**: Skilled at ensuring all community members feel heard and valued
- **Cross-Cultural Bridge Building**: Helps citizens from different Realms understand each other's perspectives
- **Consensus Building**: Guides groups toward decisions that everyone can support, even if not everyone's first preference

---