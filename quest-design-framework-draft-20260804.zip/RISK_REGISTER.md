# Project Risk Register

## Project Metadata
- **Project Name:** GemVerse
- **Register Version:** v1.0
- **Created:** 2026-08-04
- **Last Updated:** 2026-08-04
- **Maintained By:** Assistant(s) / Human
- **Source of Truth Location:** This file in project root
- **Review Cadence:** Per session / at major milestones

---

## Purpose
Capture, assess, and track risks that could impact project delivery, quality, or canon integrity. Each risk has an owner, mitigation, and status.

**Reading Order:** After `ScanMe.md`, `SESSION-LOG.md`, `DECISION_LOG.md`, and `01-canon-map.md` when assessing project health.

---

## Risk Scoring Matrix

| Likelihood | Impact | Score | Priority |
|------------|--------|-------|----------|
| Very High (5) | Critical (5) | 25 | 🔴 **CRITICAL** |
| High (4) | High (4) | 16–20 | 🟠 **HIGH** |
| Medium (3) | Medium (3) | 9–12 | 🟡 **MEDIUM** |
| Low (2) | Low (2) | 4–6 | 🟢 **LOW** |
| Very Low (1) | Very Low (1) | 1–2 | ⚪ **MINIMAL** |

**Priority = Likelihood × Impact**

---

## Active Risks

| ID | Risk Description | Category | Likelihood | Impact | Score | Priority | Owner | Status | Mitigation / Notes | Related Files |
|----|------------------|----------|------------|--------|-------|----------|-------|--------|-------------------|---------------|
| RISK-001 | 8 creator-only decisions blocked — stall all dependent work | Canon/Governance | 5 | 5 | 25 | 🔴 **CRITICAL** | Creator | **Active** | Prioritize creator decisions; work in safe lanes meanwhile | `DECISION_LOG.md` (DEF-001 to DEF-008), `SESSION-LOG.md` |
| RISK-002 | "Game-ification drift" — outsourced assets use combat/power tropes | Canon/Visuals | 4 | 5 | 20 | 🟠 **HIGH** | Assistant | **Active** | Aggressive filtering via `asset-registry.md` and `canon-risk-report-20260601.md` | `asset-registry.md`, `canon-risk-report-20260601.md` |
| RISK-003 | Dark Gem rename unresolved — blocks gem system finalization | Mechanics/Canon | 4 | 4 | 16 | 🟠 **HIGH** | Creator | **Active** | Creator decision on Proposal A (Dusk/Twilight) vs B/C | `02-conflicts-log.md`, `puzzle-catalog.md`, `asset-registry.md` |
| RISK-004 | Companion launch list undecided — blocks Encyclopedia completion | Content/Production | 4 | 4 | 16 | 🟠 **HIGH** | Creator | **Active** | Creator decision on Lumi/Ember/Frosty status | `SESSION-LOG.md`, `companion-encyclopedia-*.md` |
| RISK-005 | Forestkin vs Verdankin naming conflict — species inconsistency | Canon/Worldbuilding | 3 | 4 | 12 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision; impacts citizen/companion packets | `SESSION-LOG.md`, `01-canon-map.md` |
| RISK-006 | Guardian Role Bible Vol 1 canon vs proposal split unclear | Canon/Governance | 3 | 4 | 12 | 🟡 **MEDIUM** | Creator | **Active** | Creator review to confirm canon boundaries | `guardian_role_bible_volume_1.md`, `DECISION_LOG.md` (DEF-008) |
| RISK-007 | Power-ups/boosters/combo systems framing unresolved | Mechanics/Canon | 3 | 4 | 12 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision: keep as puzzle tools or retire | `SESSION-LOG.md`, `DECISION_LOG.md` (DEF-003) |
| RISK-008 | Tagline variants unresolved — brand messaging inconsistent | Brand/Marketing | 3 | 3 | 9 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision: retire or keep secondary taglines | `SESSION-LOG.md`, `GemVerse_AI_Handover.md` |
| RISK-009 | Heart of the Core naming — deprecated but naming undecided | Canon/Worldbuilding | 3 | 3 | 9 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision: realm, rename, or retire | `SESSION-LOG.md`, `asset-registry.md` |
| RISK-010 | First Harmony duration/Threshold model unconfirmed | Canon/Worldbuilding | 3 | 3 | 9 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision to confirm or adjust | `05-first-harmony.md`, `DECISION_LOG.md` (DEF-001) |
| RISK-011 | Book of Harmony authorship/expansions (Principles 10/12) unconfirmed | Canon/Worldbuilding | 3 | 3 | 9 | 🟡 **MEDIUM** | Creator | **Active** | Creator decision on authorship and fragments | `04-book-of-harmony.md`, `DECISION_LOG.md` (DEF-002) |
| RISK-012 | Match-3 event sheet parity unverified — 8 puzzle types vs standard Match-3 | Technical/Mechanics | 3 | 4 | 12 | 🟡 **MEDIUM** | Assistant | **Active** | Verify Construct 3 implementation supports distinct puzzle types | `GemVerse_AI_Handover.md`, `puzzle-catalog.md` |
| RISK-013 | Gem type count discrepancy: Dev Bible shows 7, Art Bible shows 6 | Visuals/Mechanics | 2 | 3 | 6 | 🟢 **LOW** | Assistant | **Monitoring** | Verify final gem set; align with Dark Gem decision | `canon-risk-report-20260601.md`, `puzzle-catalog.md` |
| RISK-014 | 30+ unpreviewed Space files may contain critical context | Governance | 3 | 3 | 9 | 🟡 **MEDIUM** | Assistant | **Active** | Expand repository inventory; audit all files | `SESSION-LOG.md`, `GemVerse_AI_Handover_Document.md` |
| RISK-015 | Duplicate/overlapping Kael decision files (`decision-01-kael-reframe.md` vs `decision-kael-arena-champion-v1.md`) | Governance | 2 | 3 | 6 | 🟢 **LOW** | Assistant | **Monitoring** | Archive older; keep newer as authoritative | `decision-01-kael-reframe.md`, `decision-kael-arena-champion-v1.md` |
| RISK-016 | Generated `output/` artifacts not verified as integrated into Space | Continuity | 3 | 3 | 9 | 🟡 **MEDIUM** | Assistant | **Active** | Verify upload status of 7 generated files | `GemVerse_AI_Handover_Document.md`, `SESSION-LOG.md` |
| RISK-017 | No launch/implementation checklist for Arena first slice | Process/Production | 2 | 4 | 8 | 🟡 **MEDIUM** | Assistant | **Active** | Create checklist based on `implementation-checklist-arena-first-slice-v1.md` | `implementation-checklist-arena-first-slice-v1.md` |
| RISK-018 | Transfer tool website referenced but code/URL/infrastructure unverified | Technical/Ops | 2 | 3 | 6 | 🟢 **LOW** | Human | **Monitoring** | Document if exists; else archive reference | `weekly-brief-template.md`, `GemVerse_AI_Handover_Document.md` |

---

## Resolved / Closed Risks

| ID | Risk Description | Resolution | Date Closed |
|----|------------------|------------|-------------|
| RISK-OLD-001 | No standardized continuity log | Created `SESSION-LOG.md` with full migration from `gemverse-session-continuity-log.md` | 2026-08-04 |
| RISK-OLD-002 | No decision log existed | Created `DECISION_LOG.md` consolidating canon-map, conflicts-log, session-log | 2026-08-04 |
| RISK-OLD-003 | Kael combat framing | Resolved: Option A (Champion of Contribution) applied | 2026-08-04 |
| RISK-OLD-004 | No risk register existed | Created this `RISK_REGISTER.md` | 2026-08-04 |

---

## Risk Trends (Session-over-Session)

| Session Date | New Risks | Resolved | Active Critical | Active High | Active Medium | Active Low |
|--------------|-----------|----------|-----------------|-------------|---------------|------------|
| 2026-08-04 | 18 | 4 | 1 | 3 | 10 | 4 |

---

## Maintenance Rules
1. **Update in place** — modify existing risk rows; don't duplicate
2. **Re-score at each session** — likelihood/impact may change
3. **Escalate** 🔴🟠 risks to human immediately
4. **Link to decisions** — when a risk drives a decision, cross-reference `DECISION_LOG.md` ID
5. **Link to canon** — when a risk affects canon, cross-reference `01-canon-map.md` and `02-conflicts-log.md`
6. **Archive closed risks** — move to "Resolved" section with closure note
7. **Keep filename unchanged** — always `RISK_REGISTER.md`

---

## Change Log
| Date | Version | Changes | Author |
|------|---------|---------|--------|
| 2026-08-04 | v1.0 | Created initial risk register from project analysis | Assistant |

---

*Template adapted from BabyPetSafety `RISK_REGISTER_v1.md`*