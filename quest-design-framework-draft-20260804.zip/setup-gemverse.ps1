﻿# setup-gemverse.ps1 content here - but this is huge, better to use Notepad
