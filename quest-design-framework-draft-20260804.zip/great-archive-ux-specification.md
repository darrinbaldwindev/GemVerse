# Great Archive UI/UX Specification
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.3  
**Linked Files:** `01-canon-map.md`, `04-book-of-harmony.md`, `07-crystal-network.md`, `08-lantern-network.md`, `imp-01-first-harmony-daily-life.md`, `realm-packet-arena-realm.md`, `realm-packet-legacy-realm.md`

---

## Overview

The Great Archive is the **civilization's living memory** — not a static library, but an active, participatory space where citizens engage with knowledge, contribute their own understanding, and discover what the civilization has learned and what it still wonders about.

Located in the Arena Realm (with distributed nodes in every Realm), the Great Archive serves as the primary Anchor for the Lantern Network's Archive Succession and the central hub for the Crystal Network's knowledge distribution.

### Design Principles

1. **Participation Over Consumption** — Citizens don't just read; they annotate, connect, question, and contribute.
2. **Wonder Over Completion** — The Archive celebrates questions as much as answers. Unanswered Questions are a featured section.
3. **Relationship Over Retrieval** — Knowledge is experienced through connections to people, places, companions, and stories.
4. **Accessibility Over Mastery** — No "expert mode." Every citizen can engage meaningfully regardless of background.
5. **Restoration Over Preservation** — The Archive serves the living work of restoration, not just the storage of the past.

---

## Information Architecture

### Primary Sections (7 Wings)

```
GREAT ARCHIVE
├── 1. HALL OF LEGENDS
│   ├── Guardian Chronicles (Book of Guardians)
│   ├── Companion Histories
│   ├── Citizen Legacies
│   └── Restoration Heroes
├── 2. CHRONICLE WING
│   ├── Realm Histories (8 Realms + Memory Ocean)
│   ├── Festival Records (10 festivals)
│   ├── Restoration Timeline
│   └── Cross-Realm Events
├── 3. FESTIVAL ARCHIVES
│   ├── Festival of Beginnings
│   ├── Lantern Gathering
│   ├── Harmony Week
│   ├── Mentor Celebration
│   ├── Growth Festival
│   ├── Discovery Festival
│   ├── Memory Festival
│   ├── Resilience Festival
│   ├── Imagination Festival
│   └── Wonder Festival
├── 4. COMPANION ARCHIVES
│   ├── Crystalkin (Spark, Prism)
│   ├── Forestkin (Verdant, Bloomtail)
│   ├── Skykin (Nimbus, Galewing)
│   └── Frostkin (Frostpaw, Echo)
├── 5. KNOWLEDGE VAULT
│   ├── Crystal Network Records
│   ├── Environmental Knowledge
│   ├── Cultural Practices
│   ├── Technical Innovations
│   └── Lost & Recovered Fragments
├── 6. ARCHIVE OF UNANSWERED QUESTIONS
│   ├── Foundational Mysteries
│   ├── Realm-Specific Questions
│   ├── Companion Mysteries
│   ├── Civilizational Questions
│   └── Personal Questions (citizen-submitted)
└── 7. MEMORY CRYSTAL VAULT
    ├── Personal Memory Crystals
    ├── Community Memory Crystals
    ├── Companion Memory Crystals
    └── Realm Memory Crystals
```

---

## User Experience Flows

### First-Time Visitor Flow (New Guardian/Citizen)

```
Entry → Orientation Companion (Spark/Echo) → 
Personal Interest Selection (Path, Realm, Companion) → 
Guided Tour of Relevant Wings → 
First Contribution Prompt (Memory Crystal or Annotation) → 
Community Connection Suggestion → 
Ongoing Visit Rhythm Established
```

**Key UX Decisions:**
- No "tutorial" — guidance comes from companions and citizens
- Orientation adapts to selected interests
- First contribution is always possible (no prerequisites)
- Social connection suggested immediately

### Regular Visitor Flow

```
Entry → Personal Dashboard (Recent Activity, Suggestions) → 
Wing Selection → 
Deep Engagement (Read, Annotate, Connect, Question) → 
Contribution Opportunity → 
Social Interaction (Discuss, Collaborate, Mentor) → 
Reflection Prompt → Exit
```

**Key UX Decisions:**
- Dashboard shows relationships, not statistics
- Suggestions based on Path, companions, recent interests
- Deep engagement encouraged (no time limits, no "read more" clicks)
- Contribution always visible and invited
- Social interaction integrated, not separate
- Reflection prompt closes each visit meaningfully

### Companion-Guided Flow

```
Companion Invitation → Joint Archive Visit → 
Companion Shares Personal Connection → 
Collaborative Exploration → 
Shared Memory Crystal Creation → 
Relationship Deepening
```

**Key UX Decisions:**
- Companions initiate visits based on relationship
- Companions share their own Archive connections
- Collaboration is the primary mode
- Creates permanent shared artifact
- Relationship deepens through shared attention

---

## Wing Specifications

### 1. Hall of Legends
**Purpose:** Honoring extraordinary contributors to the civilization

**Visual Design:**
- Grand but intimate — personal scale despite significance
- Each entry is a "life room" — immersive space representing the person
- Lighting responds to visitor presence (warm, welcoming)
- Companion portraits integrated (they knew these people)

**Interaction Model:**
- Enter a life room → experience their story through multiple perspectives
- Add your own reflection (becomes part of their legacy)
- Connect their story to your current work
- Share with others (creates conversation, not broadcast)

**Content Structure per Legend:**
- **Core Narrative**: Their contribution story (written by Chroniclers)
- **Perspective Gallery**: How different people experienced them
- **Companion Testimony**: What companions who knew them remember
- **Legacy Threads**: How their work continues today
- **Visitor Reflections**: Accumulated citizen responses
- **Your Connection**: Space for your personal reflection

### 2. Chronicle Wing
**Purpose:** Civilizational history as living narrative

**Visual Design:**
- Timeline as landscape — geography and time intertwined
- Realms as distinct but connected territories
- Events as landmarks you can visit
- Restoration progress visible as healing landscape

**Interaction Model:**
- Walk the timeline landscape
- Enter any event → multi-perspective experience
- Trace connections between events across Realms
- Add your perspective to any event
- See how events connect to current restoration work

**Content Structure per Event:**
- **What Happened**: Factual core (minimal, verified)
- **How It Was Experienced**: Multiple citizen/companion perspectives
- **What It Changed**: Ripple effects across Realms and time
- **What It Teaches**: Lessons for current restoration (not morals)
- **Open Questions**: What remains unknown or debated
- **Your Reflection**: Space for your understanding

### 3. Festival Archives
**Purpose:** Living record of the civilization's celebrations

**Visual Design:**
- Each festival as a seasonal space — changes with the year
- Participatory elements prominent — you can "join" past festivals
- Sensory richness — sounds, colors, textures of each festival
- Future festival planning visible

**Interaction Model:**
- Select festival → enter its seasonal space
- Experience festival through participant memories
- Contribute your own festival memories
- Help plan upcoming festivals
- Connect festival traditions to current community needs

**Content Structure per Festival:**
- **Origins & Evolution**: How it began, how it changed
- **Participant Stories**: Memories from across generations
- **Traditions & Innovations**: What stayed, what adapted
- **Companion Roles**: How each companion participates
- **This Year's Planning**: Current community preparations
- **Your Festival Memory**: Space for your contribution

### 4. Companion Archives
**Purpose:** Deep relationship with each companion family

**Visual Design:**
- Each family has distinct aesthetic (crystal, forest, sky, frost)
- Companion "presence" felt — not just information about them
- Shared memories accessible through companion invitation
- Relationship depth reflected in accessible content

**Interaction Model:**
- Choose companion/family → enter their space
- Experience their history through their eyes
- Share your memories with them (they respond)
- Access relationship-specific content
- Deepen bond through shared Archive attention

**Content Structure per Companion:**
- **Essence**: Who they are (their words, not descriptions)
- **History**: Their journey with the civilization
- **Family Dynamics**: How they relate to companion family
- **Citizen Partnerships**: Stories of meaningful collaborations
- **Shared Memories**: Moments you've experienced together
- **Your Relationship**: Unique to each citizen-companion pair

### 5. Knowledge Vault
**Purpose:** Practical knowledge for restoration work

**Visual Design:**
- Organized by restoration challenge, not academic discipline
- Visual knowledge maps showing connections
- "Living documents" — visibly updated by community
- Clear paths from knowledge to action

**Interaction Model:**
- Select restoration challenge → see relevant knowledge
- Browse knowledge maps → discover unexpected connections
- Contribute your practical knowledge
- Request knowledge on specific challenges
- Form knowledge-sharing groups

**Content Structure per Topic:**
- **Current Understanding**: What we know (with confidence levels)
- **Practical Applications**: How this knowledge serves restoration
- **Community Experiences**: Real examples from citizens
- **Companion Insights**: What companions contribute
- **Open Questions**: What we still need to learn
- **Your Knowledge**: Space for your contribution

### 6. Archive of Unanswered Questions
**Purpose:** Honoring mystery as civilizational strength

**Visual Design:**
- Questions as living entities — they grow, connect, sometimes resolve
- Visual representation of question networks
- Beauty in uncertainty — not frustration
- Clear distinction: mysteries to preserve vs. questions to pursue

**Interaction Model:**
- Browse question network → follow connections
- Sit with a question → experience its depth
- Add your own question (personal or civilizational)
- Join question-tending groups
- Celebrate when questions transform (not just "answered")

**Content Structure per Question:**
- **The Question**: Phrased precisely, context provided
- **Why It Matters**: Civilizational significance
- **What We've Learned**: Partial understandings, related insights
- **Who's Tending It**: Citizens/companions engaged with it
- **Related Questions**: Network connections
- **Your Relationship**: Your wonder, your insights, your tending

### 7. Memory Crystal Vault
**Purpose:** Personal and collective memory preservation

**Visual Design:**
- Crystals as physical/digital objects — beautiful, unique
- Each crystal holds a memory with full sensory richness
- Crystals can be shared, combined, gifted
- Vault feels sacred but accessible

**Interaction Model:**
- Create memory crystal from current experience
- Visit your crystals → relive with full presence
- Share crystals with specific people/companions
- Combine crystals → create collective memory
- Gift crystals → relationship deepening
- Archive crystals → contribute to civilizational memory

**Memory Crystal Structure:**
- **Core Memory**: The experience itself (multi-sensory)
- **Context**: When, where, who, why it matters
- **Emotional Resonance**: How it felt (not labeled, but felt)
- **Connections**: Links to other crystals, Archive entries, people
- **Sharing History**: Who you've shared it with, their responses
- **Archive Status**: Personal, shared, community, civilizational

---

## Cross-Wing Integration Features

### Companion-Guided Connections
Companions suggest cross-wing explorations:
- "This Festival memory connects to a Companion Archive story..."
- "The Question you're tending relates to Knowledge Vault research..."
- "Your Memory Crystal belongs in the Hall of Legends context..."

### Citizen Collaboration Spaces
Each wing has integrated collaboration areas:
- **Annotation Layer**: Citizen notes visible to those who choose to see them
- **Discussion Threads**: Conversations anchored to specific content
- **Project Spaces**: Groups working on restoration using Archive resources
- **Mentorship Corners**: Experienced citizens guiding newcomers

### Restoration Project Integration
Active restoration projects have Archive presence:
- **Project Memory Crystals**: Documenting progress
- **Knowledge Vault Links**: Relevant practical knowledge
- **Question Connections**: Unanswered Questions the project addresses
- **Citizen Contributions**: Recognizing all participants

---

## Technical Specifications

### Data Models

#### ArchiveEntry (Base)
```json
{
  "id": "uuid",
  "wing": "hall-of-legends|chronicle|festival|companion|knowledge|questions|memory",
  "title": "string",
  "coreContent": { "text": "string", "media": ["mediaRefs"] },
  "perspectives": [
    { "author": "citizenId|companionId", "content": "string", "type": "experience|analysis|memory|question" }
  ],
  "connections": [
    { "targetId": "uuid", "type": "causal|thematic|personal|companion|restoration", "strength": "strong|moderate|subtle" }
  ],
  "contributors": ["citizenIds"],
  "companionLinks": ["companionNames"],
  "restorationRelevance": ["woundNames"],
  "accessLevel": "personal|shared|community|civilizational",
  "createdDate": "ISO date",
  "lastUpdated": "ISO date"
}
```

#### MemoryCrystal
```json
{
  "id": "uuid",
  "owner": "citizenId",
  "coreMemory": {
    "sensory": { "visual": "mediaRef", "audio": "mediaRef", "haptic": "patternRef", "emotional": "resonancePattern" },
    "context": { "date": "ISO", "location": "realmId", "participants": ["citizenIds", "companionNames"] }
  },
  "significance": "personal|shared|community|civilizational",
  "sharedWith": [
    { "recipient": "citizenId|companionName", "date": "ISO", "theirResponse": "memoryCrystalRef|null" }
  ],
  "connections": ["archiveEntryIds"],
  "isArchived": "boolean",
  "archiveDate": "ISO date|null"
}
```

#### CitizenArchiveProfile
```json
{
  "citizenId": "uuid",
  "path": "scholar|pathfinder|steward|chronicler|mentor|harmonist",
  "companions": ["companionNames"],
  "visitedWings": ["wingNames"],
  "contributions": ["archiveEntryIds"],
  "memoryCrystals": ["memoryCrystalIds"],
  "questionsTended": ["questionIds"],
  "collaborations": ["projectIds"],
  "mentorships": ["citizenIds"],
  "preferences": {
    "companionGuide": "companionName|null",
    "interestTags": ["topicStrings"],
    "accessibilityNeeds": ["needStrings"]
  }
}
```

### Construct 3 Implementation

#### Scene Structure
```
GreatArchive_Scene
├── Entrance_Hall (hub)
├── HallOfLegends_Wing
├── Chronicle_Wing
├── FestivalArchives_Wing
├── CompanionArchives_Wing
├── KnowledgeVault_Wing
├── UnansweredQuestions_Wing
├── MemoryCrystalVault_Wing
├── Collaboration_Spaces (persistent across wings)
└── Personal_Dashboard (overlay)
```

#### Event Sheet Organization
- `Archive_Navigation.es` — Wing transitions, hub logic
- `Archive_Content.es` — Entry loading, perspective display, connection visualization
- `Archive_Interaction.es` — Annotation, discussion, contribution flows
- `Archive_Companion.es` — Companion-guided visits, relationship content
- `Archive_MemoryCrystal.es` — Creation, viewing, sharing, combining
- `Archive_Collaboration.es` — Real-time citizen collaboration
- `Archive_Restoration.es` — Project integration, progress visualization
- `Archive_Accessibility.es` — All accessibility features

#### Asset Requirements
- **Backgrounds**: 7 wing environments + entrance hub + collaboration spaces
- **UI Components**: Perspective cards, connection lines, contribution forms, crystal shaders
- **Companion Sprites**: Archive-specific poses/expressions for each companion
- **VFX**: Crystal glow, connection pulses, perspective transitions, memory immersion
- **Audio**: Wing-specific ambient, companion voices, memory resonance sounds, UI feedback
- **Localization**: All text in external files, context metadata for translators

---

## Accessibility Features

### Visual
- High contrast mode for all wings
- Text scaling (100%-300%) without layout break
- Colorblind-safe palettes (all connection types distinguishable)
- Motion reduction (disable crystal animations, connection pulses)
- Focus indicators for all interactive elements

### Auditory
- Full captioning for all companion voices
- Audio descriptions for visual content
- Volume controls per audio type (ambient, voice, UI, memory)
- Visual alternatives for all audio cues

### Motor
- Full keyboard/gamepad navigation
- Touch targets minimum 48x48dp
- Adjustable interaction timing
- Voice control support (iOS/Android native)
- Single-switch scanning support

### Cognitive
- Plain language options for all content
- Configurable information density
- No time limits on any interaction
- Clear wayfinding (always know where you are, how to return)
- Companion guidance always available
- Memory aids (visit history, contribution log, question tending list)

---

## Monetization Boundary (Explicit)

**The Great Archive is entirely outside monetization.**
- No premium wings or content
- No paid Memory Crystal slots
- No "expert" perspectives for purchase
- No question-tending boosts
- No Archive cosmetic purchases (cosmetics earned through participation only)
- No data analytics on citizen Archive behavior

---

## Festival Integration

Each festival creates Archive content:
- **Festival of Beginnings**: New citizen Memory Crystals, Hall of Legends entries for mentors
- **Lantern Gathering**: Chronicle Wing entries for journeys, Connection maps
- **Harmony Week**: Community Harmony Circle records, Unanswered Questions updates
- **Mentor Celebration**: Mentor Legacy threads, Companion Archive mentorship stories
- **Growth Festival**: Knowledge Vault environmental entries, Memory Crystals of gardens
- **Discovery Festival**: Knowledge Vault exploration records, new Unanswered Questions
- **Memory Festival**: Hall of Legends ancestor entries, Memory Crystal gifting
- **Resilience Festival**: Knowledge Vault adaptation records, Question tending groups
- **Imagination Festival**: Unanswered Questions aspiration stars, Companion Archive visions
- **Wonder Festival**: Civilizational Harmony Map updates, Chronicle Wing perspective shifts

---

## Companion Integration Deepening

Each companion family has unique Archive behaviors:

### Crystalkin (Spark, Prism)
- **Spark**: Illuminates connections — "This relates to that thing you loved!"
- **Prism**: Shows multiple perspectives — "The Chroniclers saw it this way, but the Pathfinders saw it that way..."

### Forestkin (Verdant, Bloomtail)
- **Verdant**: Grows knowledge — "This understanding has been developing for seasons..."
- **Bloomtail**: Tends community memory — "Your neighbor added a beautiful reflection to this..."

### Skykin (Nimbus, Galewing)
- **Nimbus**: Brings distant knowledge — "Wind carries word of a similar challenge in the Frozen Expanse..."
- **Galewing**: Facilitates Archive journeys — "Let me show you the path to that Memory..."

### Frostkin (Frostpaw, Echo)
- **Frostpaw**: Preserves deep context — "This question has been tended for three generations..."
- **Echo**: Shares lost voices — "A citizen who visited fifty years ago asked this same question..."

---

## Implementation Priority

### Phase 1 (MVP)
- Entrance Hall + 4 core wings (Hall of Legends, Chronicle, Festival Archives, Companion Archives)
- Basic Memory Crystal creation/viewing/sharing
- Citizen contribution (annotations, reflections, questions)
- Companion-guided visits (Spark, Echo as primary guides)
- Basic collaboration spaces (discussion threads)
- Full accessibility suite

### Phase 2 (Post-Launch)
- Knowledge Vault (practical restoration knowledge)
- Archive of Unanswered Questions (full question network)
- Memory Crystal Vault (advanced: combining, gifting, archiving)
- Cross-wing companion integration (all 8 companions)
- Restoration project integration
- Advanced search/discovery (by connection, companion, question, emotion)

### Phase 3 (Long-term)
- Inter-Realm Archive synchronization (Crystal Network integration)
- Living Chronicle (events added in real-time as citizens experience them)
- Companion Memory Crystals (companions create/share their own memories)
- Civilizational Question Tendings (coordinated multi-community question work)
- Archive as cultural practice (exportable framework for other civilizations)