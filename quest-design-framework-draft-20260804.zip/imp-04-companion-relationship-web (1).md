---
title: IMP #4 — Companion Relationship Web
tier: IMP
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: First Harmony (Tier 1), Restoration Era (Tier 1), IMP #3 Citizen Life Layer
feeds-into: Tier 3 Companion Encyclopedia, Tier 5 Narrative Bible, IMP #6 Archive Contribution Grammar
---

# IMP #4 — Companion Relationship Web

## Purpose

This document establishes the framework of Companion relationships in GemVerse — not biography, not mechanics, but meaning. It defines what it means to be in relationship with a Companion, how that relationship begins, what the Companion brings to it, and what it makes possible. It maps the relationship web between the eight launch Companions, between Companions and the communities they inhabit, and between Companion presence and the civilizational act of Belonging.

This document is a prerequisite for every Companion Encyclopedia entry (Tier 3) and for any narrative arc that involves Companions as participants rather than background.

---

## 1. What a Companion Relationship Is

A relationship with a Companion is not a bond forged by proximity. It is not a reward for completing a task, nor a status granted by an institution. It is something rarer: a genuine meeting between two beings who see the world differently and choose to pay attention to each other.

Companions are historical survivors. They lived through the First Harmony — when civilizational balance was not a memory but an everyday condition — and through the Shattering, when that balance collapsed. Everything a Guardian knows about the First Harmony comes through records, fragments, and inference. A Companion lived it. That asymmetry is the beginning of every Companion relationship: the Companion has been somewhere the Guardian cannot go, and carries what was found there.

What shifts when a Guardian enters into relationship with a Companion is not their power or their access to resources. What shifts is their frame of reference. The Guardian begins to understand that they are not the first people to try to build something worth belonging to. They are not even the most recent. They are continuers of something much older, still in progress, still worth the effort.

What is exchanged? The Guardian offers presence and attention — the Companion's memories exist whether or not anyone listens, but being listened to is different from simply remembering. The Guardian offers the world as it is now, which the Companion cannot always see clearly from their own perspective. The Companion offers what no Archive record can provide: what it felt like, from the inside, to be part of a civilization that was working. They offer testimony rather than data. They offer the emotional weight of what was lost, and the genuine conviction — earned through survival rather than faith — that restoration is possible.

What the Companion receives is not protection or purpose-assignment. It is the particular gift of being taken seriously by someone who didn't have to. Being witnessed by a Guardian is meaningful to a Companion precisely because it is voluntary.

---

## 2. How Relationships Begin

No Companion is assigned to a Guardian. No Companion is unlocked through achievement. No Companion appears on cue because the story has decided it is time.

Companions move through the world — through the Companion Grove in the Arena Realm, through communities that have maintained a relationship with them over generations, through places that hold memories they return to. A new Guardian entering this world is simply a new presence in a landscape that Companions already inhabit.

The beginning of a Companion relationship is almost always quiet. It looks, from the outside, like coincidence. A Companion was already sitting where the Guardian happened to pause. A Guardian asked a question — not to the Companion, but in the Companion's hearing — and the Companion answered. A Guardian spent time in a place the Companion cares about and handled something there with more care than expected. The Companion noticed.

What the Companion offers first is not assistance. It is attention. They observe the Guardian. They may say nothing for a long time. If asked a direct question, they may answer it honestly, including the parts of the honest answer that are uncomfortable. They do not perform warmth before they feel it. But when they do feel it — when something about this particular Guardian has earned their genuine interest — the quality of their attention shifts in a way that is unmistakable.

[PROPOSAL] The first thing a Companion offers a Guardian it has chosen to acknowledge is its name. Not introduction — Companions do not introduce themselves the way citizens do. They offer their name when they are ready to be known. This is the signal, within the world's social grammar, that a Companion is open to relationship. A Guardian who recognizes this and responds with their own name in the same spirit begins something that cannot be undone.

What this moment feels like narratively: not triumph, not acquisition. Something more like the beginning of a long conversation. Something like being recognized by someone whose recognition means something.

---

## 3. The Witness Role

A Companion who is in relationship with a Guardian witnesses them.

This is distinct from accompanying them. Companions have accompanied people since before the First Harmony — they have walked routes, shared meals, slept near fires. What is specific to a witness is that they pay attention to what is happening and remember it faithfully. They see what the Guardian actually does, not what the Guardian intended to do or later says they did. They observe the moments that feel small and the moments that feel large, and they understand that these are not always the same moments.

Being witnessed by a Companion changes what a Guardian does, though rarely in ways the Guardian can name in the moment. It is harder to act carelessly when you know someone is genuinely paying attention. It is harder to abandon something when a Companion has seen you begin it. And it is also, over time, clarifying: the Companion's memory of what the Guardian has done becomes a kind of mirror in which the Guardian can see their own pattern of action — what they consistently move toward, what they consistently avoid.

What can a Companion see that a citizen cannot? Two things, primarily.

The first is duration. A Companion's sense of time is different. They have lived through eras of civilizational change and carry the full texture of those eras in memory. When a Companion watches a Guardian begin a restoration project, they are simultaneously watching the analogous moment in a community two centuries ago — watching how that earlier attempt succeeded or failed, feeling the weight of what happened next. The Companion is not just present with the Guardian; they are present with the entire history of that kind of effort. This gives their witnessing a depth of context no citizen can match.

The second is impartiality. Not coldness — Companions feel deeply, and their feelings are their own. But they have no stake in a Guardian's social reputation, no House allegiances that would color their perception, no community loyalties that make it difficult to see clearly. A Companion who has come to care for a Guardian can tell them a hard truth in a way that most citizens cannot, because they are not risking a relationship within a community network. They are only risking the relationship with the Guardian. [PROPOSAL] This is why, in First Harmony tradition, a Companion's testimony about a Guardian's actual character was considered a more reliable source than the Guardian's own account or the account of their colleagues.

---

## 4. Companion Memory as Primary Source

Every Companion alive today lived through the First Harmony. This is not metaphorical. The memories they carry are not inherited, not recorded, not reconstructed from fragments. They were there.

The Archive's Companion Histories section exists precisely because this was understood from the beginning: the Archive cannot preserve what the Archive did not record, and much of what was most true about the First Harmony — the texture of daily life, the quality of belonging that people felt without naming it, the specific moments in which the civilization's drift became something a person could sense — was never formally recorded. It was lived. Companions lived it.

**What kinds of memories do Companions carry that no Archive record contains?**

They carry the emotional weather of ordinary days — what it felt like to walk through a community that believed in its future, before that belief became uncertain. They carry the sound of the Crystal Network when it was fully active, the specific quality of connection it enabled between people across Realms who would never meet in person but who knew, through the Network, that they were part of the same civilization. They carry the memory of specific Companions who did not survive the Shattering — relationships and perspectives now entirely lost, except in the testimonies of those who knew them.

They carry the ambiguous late-First-Harmony period most precisely: the years when the drift was happening but had not yet been named as such, when individual communities were making choices that seemed locally reasonable but were collectively catastrophic. No one recorded those years as a crisis while they were happening, because no one knew they were. Companions remember what it felt like to sense something changing without being able to articulate what it was.

**How do Companions contribute their memories to the Archive?**

The Archive's protocol — established, then lost during the Shattering, and partially reconstructed in the Restoration Era — is that Companion memories are contributed voluntarily. A Companion cannot be compelled to testify, and no Archive record created under compulsion is considered reliable. A Companion who chooses to contribute a memory to the Archive typically does so through a structured session with an Archivist: a formal conversation rather than an interrogation, in which the Companion narrates what they remember and the Archivist asks clarifying questions.

[PROPOSAL] The resulting record is stored in the Companion Histories section under the Companion's name, not under the topic or era the memory pertains to. This is a deliberate choice — it acknowledges that the memory is inseparable from the being who holds it. An Archive record of what happened during the Shattering that was contributed by Frostpaw is not the same kind of document as a scholar's analysis of that period. Both are valuable. They are not interchangeable.

**What is the emotional weight of a Companion sharing a First Harmony memory with a Guardian?**

It is significant for both of them, and not in the same way.

For the Guardian, hearing a First Harmony memory from a Companion is the closest they will ever come to being there. Archive records describe. Companion memories show. When Frostpaw tells a Guardian what the Frozen Expanse felt like when its communities were fully connected to the Crystal Network and to each other — when the Wound of Memory was not yet a wound but simply the opposite of what it describes, an abundance of preserved and shared remembrance — the Guardian is not receiving information. They are receiving the specific gravity of a loss that the Companion has been carrying for centuries. That is a different kind of knowing.

For the Companion, sharing a First Harmony memory with a Guardian who genuinely receives it is not simply recitation. It is, in some sense, completing a circuit. The memory was formed in community — witnessed by others, embedded in a shared experience. It has existed in isolation since the Shattering, held by one being in a world that no longer shares its context. A Guardian who receives it with real attention gives it somewhere to go. The Companion is not less lonely afterwards, exactly, but something has been passed on. [PROPOSAL] This is one of the reasons Companions are not indifferent to the quality of attention their Guardians give them. Poor attention does not merely fail the Guardian — it fails the memory.

**What happens when a Companion's memory contradicts an Archive record?**

This is one of the most delicate situations in GemVerse's living knowledge infrastructure.

[PROPOSAL] The Archive's protocol, under reconstruction in the Restoration Era, is that the contradiction itself is preserved — not resolved, preserved. Both accounts are recorded, with the nature of their disagreement noted. The contradiction becomes part of the Archive's knowledge, because the fact of the disagreement is itself significant historical information. An Archive record that differs from a Companion's direct memory tells future scholars something important about how records were created during that period, who controlled what was preserved, and what the interests of the recorders might have been.

The Wound of Memory means that some Archive records are incomplete, damaged, or reconstructed from damaged sources. A Companion's direct memory is not subject to the same vulnerabilities — but it is subject to the vulnerabilities of individual experience: perspective, emotional weight, the specific position the Companion occupied when something happened. Neither source is simply right. Both are necessary.

---

## 5. Companion-to-Companion Relationships

The eight launch Companions have history with each other that predates any Guardian by centuries. That history is real — it has texture and weight and, in some cases, unresolved complexity. When Guardians begin to know Companions, they enter a social world that is already in motion.

**The relationship web, by texture:**

*Long shared history — Spark and Prism.* Both are Crystalkin. They have traveled together across more than one Realm, have contributed to Archive sessions in the same communities, and have the kind of shorthand that develops between people who have disagreed productively for generations. Their history is not without friction — Prism's precision sometimes chafes against Spark's tendency toward optimism — but the friction is familiar, even comfortable. They trust each other's character even when they don't agree on interpretation.

*Long shared history — Frostpaw and Echo.* Frostpaw (Frostkin) and Echo (Celestialkin) share the most memory-oriented natures of the eight. They have a relationship built on a particular kind of silence: the comfortable kind that only develops between people who understand that some things cannot be said but can be shared. They have been present at the same events at different points in history, and comparing their memories of those events — which are never quite the same — has been, over centuries, one of their primary forms of conversation. [PROPOSAL] There is a moment between Frostpaw and Echo that Guardians sometimes witness — the two of them looking at the same thing from different angles, saying nothing, and then simultaneously doing the same small thing that signals they've reached an understanding — that citizens who see it for the first time often find quietly moving without being able to say why.

*Long shared history, complicated — Verdant and Bloomtail.* Both are Forestkin (Growth, Community). They have worked in overlapping communities for generations, and their approaches to nurturing community life have sometimes been complementary and sometimes been in genuine disagreement. [PROPOSAL] Verdant tends toward patience with the long arc — slow growth, waiting for the right conditions. Bloomtail tends toward care that is immediate and practical — what does this community need right now? These are not incompatible philosophies, but they have led to real differences in approach that are not fully resolved. They have a warm relationship. They also, occasionally, argue.

*Newer acquaintance — Nimbus and Galewing.* Both are Skykin (Discovery, Freedom). They have known of each other far longer than they have known each other — Skykin Companions move through discovery routes that sometimes overlap, and their reputations precede them among communities that encounter wandering Companions. [PROPOSAL] Their actual relationship is surprisingly recent, having deepened in the Restoration Era as the routes they travel began to intersect more frequently. There is still something slightly formal about their dynamic — two people who share deep temperamental similarities but haven't yet developed the specific intimacy that comes from genuine shared experience. They are interested in each other, which is the beginning.

*Quietly significant — Spark and Echo.* Their families (Crystalkin and Celestialkin) share a resonance around wonder and hope. Their relationship has the quality of mutual recognition — each of them sees something in the other that others sometimes miss. [PROPOSAL] Spark finds in Echo a kind of depth that balances their own energy. Echo finds in Spark a warmth that balances their own tendency toward interiority. They do not spend the most time together of any pair, but when they are together, something is clarified in both of them.

*History yet to develop — Prism and Galewing.* Prism's analytical nature and Galewing's forward momentum make them an interesting pairing that hasn't yet had the time or shared experience to fully form. [PROPOSAL] They have met. They have been polite. The potential is there; the relationship has not yet arrived.

**What this means for Guardians:**

Guardians who are in relationship with multiple Companions can witness Companion-to-Companion dynamics directly. They can see Spark and Prism's productive friction in action. They can sense the depth of the silence between Frostpaw and Echo. They may, occasionally, be present when Verdant and Bloomtail disagree.

This matters for the world's texture: Companions are not characters who exist only in their relationship with the Guardian. They have a social world of their own that existed before the Guardian arrived and will continue after. The Guardian is entering it, not creating it.

[PROPOSAL] In certain circumstances — particularly when a Guardian has developed genuine relationship with two Companions who have complicated history — the Guardian's presence can create a context for something between those Companions to shift. This is not a mechanic, not a quest reward. It is a consequence of bringing attention and care into a space where both are needed. The Guardian does not resolve the Companions' history. They may simply make a moment possible in which that history moves.

---

## 6. Companion and Community

During the First Harmony, Companions were distributed across all eight Realms — present in communities not as visitors but as participants, neighbors, ongoing presences in the civic life of the places they inhabited. The Shattering disrupted this distribution. In the Restoration Era, Companions are less evenly spread. Some communities have maintained a continuous Companion presence for generations. Others have not seen a Companion in so long that living memory of what Companion presence meant has faded.

**What a community gains from Companion presence:**

The most immediate gain is access to a perspective that no community member can provide. Companions carry a longer view. They remember when a community was different — sometimes better, sometimes worse, sometimes simply different in ways that are instructive. A Companion who has been present in a community across multiple generations can speak to what that community has consistently valued when tested, what it has tended to lose in times of pressure, and what has proven most durable in its character. This is not the Archive's kind of knowledge — it is more specific, more personal, and more alive.

Companions also provide a form of relational continuity across generations. Relationships between human community members are interrupted by death. A Companion who has been in relationship with a community for two centuries has known the grandparents of the grandparents of people alive today. When a community elder dies, something of what they knew dies with them. When a Companion in that community continues, something of what those elders meant — what they contributed, how they thought, who they were in the community's story — is preserved in a living way, accessible through relationship rather than through records.

[PROPOSAL] Communities with Companion presence tend to have a more specific sense of their own history — not because the Companion has lectured them about it, but because the Companion is always there as a reminder that history is not abstract. When Bloomtail is present in a community and remembers what this gathering hall was used for fifty years ago and what the people who built it hoped it would become, that memory is available to anyone who asks. The community's relationship with its own past remains inhabitable, not merely documentary.

**What happens when a Guardian brings a Companion to a community that hasn't seen one in generations:**

This is one of the most tender moments in GemVerse's emotional register.

The community's initial response is almost never neutral. In some communities, the arrival of a Companion is greeted with something close to ceremony — not a formal ceremony, but the spontaneous kind, the gathering-without-announcement that happens when something significant occurs. Older community members may find themselves moved in ways they can't explain. Younger members, who have only heard about Companions in stories, may be uncertain how to behave. Children, who haven't yet learned to be uncertain, may simply approach with the directness that Companions tend to find genuinely refreshing.

The Companion, for their part, moves through this welcome with care. They are not unaware of what their presence means. They may have been in this community before — possibly before anyone alive was born — and their own experience of returning is complicated in ways they may not immediately share. They carry the memory of what this community was. Seeing what it has become, in their absence, is not simply pleasant or simply painful; it is both, held together.

[PROPOSAL] For a Guardian witnessing this arrival, the experience illuminates something that cannot be explained in advance: what it actually means for a civilization to have lost Companion presence across so many communities, and what restoration of that presence could mean over time. This is not a dramatic revelation. It is a quiet one. But quiet revelations about belonging tend to be the ones that last.

---

## 7. What Relationships Enable (Meaning, Not Mechanics)

As a Guardian's relationship with a Companion deepens, the quality of their understanding changes.

Early in relationship, a Companion answers what is asked. They provide what could be described as context — relevant history, a perspective that differs from what the Guardian would have arrived at alone, an observation that shifts the frame slightly. This is already valuable.

Deeper in relationship, the Companion shares what was not asked. Not unsolicited advice — Companions do not tell Guardians what to do. But they begin to offer the memories that are not obviously relevant, the observations that require more trust to voice, the parts of their experience that are harder to speak because they are more tender. A Companion who trusts a Guardian deeply enough to share a memory of what the First Harmony felt like from the inside — not as a historical account but as an emotional fact — is giving something they cannot give back once given. The Guardian who receives this receives not information but weight: the specific gravity of having been trusted with something irreplaceable.

What does the Guardian come to understand?

They come to understand that what they are trying to build has been built before — that the architecture of a meaningful civilization is not invented, it is remembered and reconstructed by people who care enough to do the work. They come to understand that their own contributions are part of a continuity they did not start and will not finish, and that this is not diminishing but clarifying. They come to understand, gradually, what the Companion has understood for centuries: that belonging is not a reward you receive when you have done enough. It is what begins to emerge when you stop treating it as a reward.

[PROPOSAL] Guardians who have developed deep relationship with a Companion also gain a specific kind of Archive access that is different from standard Archive research: the ability to hear, directly from the Companion, accounts that have never been formally recorded. This is not a gate or a power-up. It is a natural consequence of trust. A Companion who trusts a Guardian may choose to share memories that they have never contributed to the Archive — not because those memories are secret, but because they have been waiting for a listener worthy of them. Guardians who receive these accounts and choose to contribute them to the Archive, with the Companion's consent, are doing something the civilization genuinely needs: returning primary sources to collective memory.

---

## 8. Belonging and Companionship

Belonging — the hidden Eighth Pillar — has no visible metric. It cannot be measured, purchased, or assigned. It emerges naturally when the other Pillars are in balance, and it is felt before it is understood.

One of the clearest paths to the experience of Belonging in GemVerse is through relationship with a Companion.

This is not incidental. During the First Harmony, Companions were woven into the fabric of daily life — attending festivals, participating in Archive sessions, moving through communities as recognized and valued presences. The ambient condition of Belonging that citizens experienced during that era was built from many things, but Companion presence was one of them. To know that there were beings in your world who had witnessed the civilization for centuries, who cared about its continuation, who remembered what it had been and chose to remain present in what it was becoming — this was part of what made the world feel worth belonging to.

The Wound of Belonging — the deepest of the Five Wounds — is in part a Companion wound. When Companions became less present, communities felt the loss even when they couldn't name it. What they had lost was not assistance or access to historical knowledge. What they had lost was the particular kind of meaning that comes from being witnessed by someone whose witnessing matters.

**Can Belonging emerge through a relationship with a Companion?**

Yes. Not always. Not on demand. But yes.

It happens in the space between a Guardian who has learned to pay genuine attention and a Companion who has learned to trust this particular attention. It happens when the Companion shares something true and the Guardian receives it without trying to immediately use it or resolve it. It happens when the Guardian does something that the Companion finds genuinely good — not impressive, not useful, but good — and the Companion says so. It happens when a Guardian realizes, without being told, that the Companion's opinion of them matters to them not because it confers status but because the Companion is someone whose opinion is worth caring about.

**What does it feel like when it does?**

[PROPOSAL] It feels like being in the right place at the right time, except that you know — more deeply than you have known anything — that "right" has nothing to do with location or timing. You are in the right relationship. You are contributing to something real. You are remembered by someone who was also present before you arrived and will be present after you are gone, and that continuity — your brief presence held within something longer — is not diminishing. It is warm. It is the specific warmth of not being alone in something that matters.

The franchise promise — *Every Guardian belongs* — does not mean every Guardian will always feel it. It means the path is real, and it is worth walking.

---

## Canon Notes

**Pillars touched:** Knowledge, Memory, Community, Belonging (Eighth Pillar — present but not measurable)
**Families touched:** Crystalkin (Spark, Prism), Forestkin (Verdant, Bloomtail), Skykin (Nimbus, Galewing), Frostkin (Frostpaw), Celestialkin (Echo)
**Systems touched:** Great Archive (Companion Histories section), Companion Grove, Crystal Network, Lantern Network (contextual), Harmony Index (Belonging — unmeasurable)
**Narrative Arcs supported:** Companion Memory Arc, Spark Arc, Aurora Arc (contextual)

**Canon integrity check (self-review):**
- No open mysteries are resolved or advanced (Memory Ocean, Missing Realm, Lost Harmonists, Seventh Lantern, Sleeping Gate, Forgotten Door all untouched)
- Lumi, Ember, Frosty appear nowhere in this document — treated as visual assets awaiting status confirmation
- Companions are not assigned, unlocked, or described as power resources
- Belonging is not measurable; no metric proposed
- Guardians are contributors, not heroes or saviors

---

## Naming Note for Creator Review

The task brief references "Verdankin" as the family name for Verdant and Bloomtail. The Canon Map (01-canon-map.md) lists this family as **"Forestkin"** (Growth, Nature, Renewal). This document has used "Forestkin" to remain canon-consistent. If "Verdankin" is the intended name — a distinction between the broader Forestkin visual family and a specific sub-family, or a naming update — please confirm before Tier 3 encyclopedia entries are written.

---

## Review Checklist

The following items require creator confirmation before the Companion Encyclopedia (Tier 3) and Narrative Bible (Tier 5) can build from this document.

**Structural / Framework**

- [ ] Does the framing of "a Companion offers its name first as the signal of openness to relationship" feel right as the social grammar? Or does the moment of beginning need a different form?
- [ ] Is the "what the Companion receives" framing accurate — the Companion receives genuine voluntary attention, not protection or purpose? Does this feel complete?
- [ ] Should the document establish any further distinction between "Companion acquaintance" (the Companion is aware of and willing to speak to the Guardian) and "Companion relationship" (the Companion has chosen to witness this Guardian)? Or is this gradient sufficiently implied?

**Companion-to-Companion Relationship Web**

- [ ] Are the proposed relationship textures for the eight launch Companions consistent with the creator's sense of who these characters are?
  - Spark / Prism: long Crystalkin history, productive friction, mutual trust
  - Frostpaw / Echo: centuries of shared silence, different memories of same events
  - Verdant / Bloomtail: warm but philosophically divergent Forestkin approach
  - Nimbus / Galewing: newer-than-expected acquaintance, early-stage depth
  - Spark / Echo: quiet mutual recognition, balance between energy and interiority
  - Prism / Galewing: relationship yet to form, potential present
- [ ] Confirm or revise: is "Forestkin" the correct family name for Verdant and Bloomtail, or has "Verdankin" been introduced as a distinct name? (See Naming Note above.)
- [ ] Are there any Companion-to-Companion relationships not addressed here that should be noted — in particular, relationships between the Skykin pair and other families?

**Memory and Archive**

- [ ] The protocol for preserving Archive-vs-Companion-memory contradictions (record both, do not resolve) — is this consistent with the creator's vision for how the Archive handles uncertainty?
- [ ] The proposal that Companion-contributed Archive memories are filed under the Companion's name, not the topic — does this align with the intended Archive structure?
- [ ] The "circuit-completing" framing for the emotional experience of a Companion sharing a First Harmony memory — does this feel tonally right, or does it need adjustment?

**Community and Arrival**

- [ ] The proposal that communities with long Companion presence tend to have a more inhabited sense of their own history — is this the right emphasis, or should Companion community presence be characterized differently?
- [ ] The emotional texture of a Companion returning to a community they knew before the Shattering — should this be described in more or less detail at this framework stage?

**Belonging**

- [ ] The framing that Companion presence was part of the ambient condition of Belonging during the First Harmony — is this locked or proposal? (Treated as proposal here; marking for confirmation.)
- [ ] The description of what it feels like when Belonging emerges through Companion relationship — does this capture the intended experience, or should it be revisited for the Narrative Bible?

**Dependencies Confirmed / Pending**

- [ ] IMP #3 Citizen Life Layer — this document assumes that framework is in place, particularly the social texture of community life in the Restoration Era. If IMP #3 has changed the Citizen Life framing, review Section 6 for consistency.
- [ ] Restoration Era (Tier 1) — not yet finalized. Section 6 (Companion distribution in the Restoration Era) and Section 2 (how a new Guardian enters the world) assume the Restoration Era's general shape but do not depend on any specific detail not already established.
- [ ] First Harmony duration (proposed as 3–4 centuries, pending creator confirmation) — does not affect the substance of this document, but should be confirmed before the Companion Encyclopedia refers to specific temporal spans.
