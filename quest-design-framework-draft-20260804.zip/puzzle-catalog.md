---
title: Task 8 — Puzzle Catalog and Reveal Tracker
tier: Work Queue
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: Five Wounds (Tier 1), Crystal Network (Tier 1), IMP #2 Five Wounds Restoration Model
feeds-into: Quest Design, Narrative Bible (Tier 5), Product Bible (Tier 6)
---

# GemVerse Puzzle Catalog and Reveal Tracker

**Document Purpose:** Production tool for puzzle designers, quest designers, and narrative leads. This is not lore. It is a governing framework that defines what puzzles are in GemVerse, how they behave, what they can reveal, and what they must never do.

---

## Section 1 — The Puzzle Design Framework

### Why This Framework Exists

In GemVerse, puzzles are not obstacles. They are not tests of skill that a Guardian must pass before the story continues. They are **remnants of civilization** — structures, systems, records, and rituals that were created during the First Harmony for specific purposes, fell into disuse or disrepair during the Shattering, and now await the attention of a Guardian who understands what they are.

A crystal resonance pattern embedded in the floor of a Crystal Forest node was not placed there to entertain. It was placed there by Lumina scholars to calibrate node connections. A path sequence carved into a waypoint stone was not carved as an amusement — it was the navigational key Pathfinders used to identify safe routes across the Frozen Expanse. The fact that these structures can be engaged as puzzles is not coincidence. It is archaeology. The world preserved them because they were worth preserving.

This distinction is non-negotiable. If a puzzle could be removed from GemVerse without affecting the worldbuilding — without someone asking, *who made this, and why?* — it fails the Puzzle Design Test and must be redesigned.

---

### The Puzzle Design Test (LOCKED CANON)

Every puzzle in GemVerse must be able to answer all five questions:

1. **Why does this puzzle exist in-world?**
   What was it built to do? What function did it serve during the First Harmony or the period preceding the Shattering?

2. **Who created it, and when?**
   Which House, community, institution, or tradition is responsible for its existence? Was it made during the First Harmony, in its decline, or in the early Restoration Era?

3. **What was its original purpose?**
   Not the puzzle-game purpose — the civilizational purpose. A calibration tool. A training record. A community agreement ritual. A navigational key. A preservation act.

4. **What does it reveal about the civilization?**
   What does engaging with this puzzle teach the Guardian about how civilization worked, what it valued, and what was lost?

5. **What does solving it restore or unlock?**
   Not points. Not power. A restoration. A recovered fragment. A repaired connection. An understood truth. A Companion memory surfaced. An Archive record completed.

**The Differentiator:** If a puzzle can be removed without affecting the worldbuilding, redesign it.

---

### Puzzle Experience Principles

These five principles govern how puzzles should *feel* — not mechanically, but as experiences within GemVerse's civilization-adventure identity.

**1. Curiosity Before Mastery**
A Guardian should want to understand what they are looking at before they want to solve it. The puzzle should invite examination — *what is this for? who made this?* — before it invites action. Design should reward pausing and noticing.

**2. Restoration, Not Conquest**
Completing a puzzle should feel like something being healed, returned, or understood — not overcome. The emotional register is relief and recognition, not triumph. There are no enemies to defeat. There is only the slow, satisfying work of putting things back together.

**3. Understanding Over Performance**
Puzzles should reward comprehension, not speed. A Guardian who reads a pattern carefully should succeed more often than a Guardian who reacts quickly. Reflection is an asset. Rushing should feel inappropriate to the tone.

**4. Failure Without Shame**
No puzzle should shame, punish, or humiliate a Guardian who does not immediately succeed. An incomplete attempt is not failure — it is the beginning of understanding. The civilization does not judge Guardians for needing time. It waited this long. It can wait a little longer.

**5. Paced for Presence**
Puzzles exist in a cozy fantasy world. They should breathe. A brief narrative or contextual frame before the puzzle begins — and a moment of acknowledgment after it resolves — keeps the Guardian present in the world rather than removed into a mechanical space. Solving a puzzle is a moment in a story, not a break from it.

---

## Section 2 — The Eight Puzzle Types

> **Canon Alignment Note:** The Canon Map (Section 6 — Puzzle System) confirms 8 puzzle types: Memory, Archive, Companion, Realm, Lantern, Crystal Network, Harmony, Legacy. The names below are **[PROPOSAL]** — civilization-flavored names proposed for each type. Mechanic alignment with the Construct 3 Bible has not been fully reconciled; flags are included where confirmation is needed.

---

### Puzzle Type 1 — Crystal Resonance [PROPOSAL]
**Canon Type Alignment:** Crystal Network puzzle

**In-World Origin:**
During the First Harmony, Crystal Network nodes required periodic calibration. Lumina scholars developed resonance alignment protocols — structured sequences of gem-frequency matching that would restore a node's connection to the broader network. These protocols were embedded in the physical structure of each node as a self-repair guide: if the node drifted out of alignment, someone who understood the civilization's knowledge framework could read the node's surface pattern and restore it.

**Mechanic Summary:**
The primary Match-3 board mechanic. Guardians align gem sequences on a crystalline board to match a resonance pattern. The board reflects the node's configuration; aligning gem types restores the connection signal. [FLAG: Confirm with Construct 3 Bible that Match-3 is the primary board mechanic — locked canon per task brief, but event sheet alignment to be verified.]

**Wound Alignment:** Wound of Knowledge — The Fragmentation
Crystal Resonance puzzles restore the flow of knowledge between separated nodes — the defining act of healing the Fragmentation.

**Archive Reveal Potential:**
Solving a Crystal Resonance puzzle may surface a fragment stored in the restored node — a discovery record, a research note, a cross-Realm communication that was in transit when the node went dormant. These fragments are often incomplete because the node only held one piece of a distributed record.

**Guardian Experience:**
The Guardian should feel like a restorer and reader — someone who has learned to speak a language that civilization invented and then fell silent. The satisfaction is not in winning. It is in the moment a node hums back to life and something that was waiting a very long time to be heard becomes audible again.

**Design Test Answers:**
- *Why does it exist in-world?* Crystal Network node calibration and maintenance.
- *Who created it, and when?* Lumina scholars during the First Harmony, as part of the Crystal Network's self-repair design.
- *Original purpose?* Restore node alignment so the network could continue distributing knowledge.
- *What does it reveal?* That the civilization built its knowledge systems to be repairable by anyone who understood them — not just specialists.
- *What does solving it restore?* A Crystal Network connection; often a stored Archive fragment.

---

### Puzzle Type 2 — Pathfinder's Mark [PROPOSAL]
**Canon Type Alignment:** Realm puzzle / route puzzle

**In-World Origin:**
Astra Pathfinders maintained an elaborate system of waypoints across the Eight Realms — carved stones, marked trees, embedded trail symbols that formed navigational keys for cross-Realm travel. Decoding a Pathfinder's Mark required understanding the Realm's local geography in relation to the broader network. These marks were not arbitrary — they were functional directions, layered with observations about terrain, season, and safety.

**Mechanic Summary:**
A path/route puzzle in which the Guardian traces a route through a branching map or sequence of connected points, recovering the original navigational intention of a waypoint system. The puzzle may involve restoring a sequence, identifying a correct path through a corrupted or overgrown network, or reconstructing a Pathfinder's route from partial evidence. [FLAG: Confirm Construct 3 event sheet implementation for path/route puzzle type.]

**Wound Alignment:** Wound of Discovery — The Isolation
Pathfinder's Mark puzzles rebuild the infrastructure of return — the routes and waypoints that made exploration meaningful rather than solitary.

**Archive Reveal Potential:**
Solving a Pathfinder's Mark may surface a Pathfinder's expedition record — what they found at the route's destination, what they brought back, and where they intended to contribute it. Some records reveal that a discovery was made but never delivered because the route home was broken before the Pathfinder returned.

**Guardian Experience:**
The Guardian should feel like someone following in a real person's footsteps — reading the land as a Pathfinder read it, making the same observations, understanding the same choices. There is intimacy in this: someone cared enough to leave these marks precisely so that a future reader could find the way.

**Design Test Answers:**
- *Why does it exist in-world?* Navigational infrastructure for cross-Realm Pathfinder travel.
- *Who created it, and when?* Astra Pathfinders during the First Harmony; maintained collectively as civic infrastructure.
- *Original purpose?* Guide travelers safely between Realms; distribute discovery across civilization.
- *What does it reveal?* That the civilization treated cross-Realm connection as a civic obligation, not a personal achievement.
- *What does solving it restore?* A route connection between Realms; often a Pathfinder expedition record.

---

### Puzzle Type 3 — Echo Sequence [PROPOSAL]
**Canon Type Alignment:** Memory puzzle / Companion puzzle

**In-World Origin:**
During the First Harmony, Companions carried and transmitted memories through a form of resonant recall — the ability to re-experience an event in sequence, precisely, from beginning to end. Archive Chroniclers developed Echo Sequence protocols to help Companions formally contribute their memories to the Archive: a structured process of surfacing a memory in the correct order so it could be recorded without distortion.

**Mechanic Summary:**
A memory sequence puzzle in which the Guardian observes a pattern, sequence, or series of events and then reproduces it accurately. The structure may include visual sequences, symbol chains, or narrative-beat ordering. [FLAG: Confirm Construct 3 event sheet for memory sequence implementation.]

**Wound Alignment:** Wound of Memory — The Forgetting
Echo Sequence puzzles are the most direct healing act for the Forgetting — they recover specific memories and contribute them to the Archive.

**Archive Reveal Potential:**
A successfully completed Echo Sequence surfaces a Companion memory — a testimony, a first-person account of an event, a scene from the First Harmony that exists nowhere in written records. These are among the most significant Archive contributions a Guardian can make, because Companions are sometimes the only source for what they witnessed.

**Guardian Experience:**
The Guardian should feel like a Chronicler — trusted with something fragile and irreplaceable. The experience is respectful and attentive. This is not a game. This is an act of preservation. The satisfaction comes from the sense that a real memory — held by a real presence who lived through the First Harmony — has now been given a place in the permanent record.

**Design Test Answers:**
- *Why does it exist in-world?* Companion memory contribution protocol for the Archive.
- *Who created it, and when?* Borealis Chroniclers during the First Harmony, in collaboration with Companion communities.
- *Original purpose?* Allow Companions to contribute memories to the Archive without distortion.
- *What does it reveal?* That civilization built formal systems for honoring testimony — memory was not just recorded, it was received.
- *What does solving it restore?* A Companion memory contributed to the Archive; often a Fragment of living history that exists nowhere else.

---

### Puzzle Type 4 — Community Pattern [PROPOSAL]
**Canon Type Alignment:** Companion puzzle / community restoration puzzle

**In-World Origin:**
Festival traditions in GemVerse communities included collective pattern practices — structured contributions of color, sound, or symbol that required many participants working in coordination. These patterns were not decorative. They were the visible form of civic agreement: a community demonstrating its shared values through collective, coordinated action. The patterns were recorded so future communities could re-learn them.

**Mechanic Summary:**
A community pattern puzzle in which the Guardian completes a larger pattern by contributing their piece accurately — filling gaps in a collective structure, restoring a community symbol to its intended form, or coordinating contributions across a grid. [FLAG: Confirm Construct 3 event sheet for community/group pattern puzzle type.]

**Wound Alignment:** Wound of Belonging — The Division
Community Pattern puzzles address the deepest Wound through the most direct means: demonstrating that a Guardian's individual contribution is part of something larger, and that the whole cannot be complete without it.

**Archive Reveal Potential:**
Solving a Community Pattern may surface a Festival Record — an account of when the pattern was last performed, who participated, and what the community was celebrating or affirming. Some records reveal that a festival tradition was maintained for many years after the Shattering before finally going quiet when too few people remembered its meaning.

**Guardian Experience:**
The Guardian should feel the particular satisfaction of belonging — of being one voice in a larger harmony. Even in a solo puzzle experience, the design should evoke the sense that others made this pattern possible, and the Guardian is completing what they left waiting. The feeling is warm, communal, and quietly profound.

**Design Test Answers:**
- *Why does it exist in-world?* Festival and civic ritual practice — the record of collective pattern-making.
- *Who created it, and when?* Hearthlight community tradition, maintained collectively across generations.
- *Original purpose?* Demonstrate and celebrate civic belonging through coordinated contribution.
- *What does it reveal?* That civilization understood belonging as something practiced, not assumed.
- *What does solving it restore?* A Festival Record; a community tradition that can now be resumed.

---

### Puzzle Type 5 — Verdance Cultivation [PROPOSAL]
**Canon Type Alignment:** Realm puzzle / growth puzzle

**In-World Origin:**
Verdance Stewards maintained detailed cultivation records — the structured knowledge of which conditions allowed which kinds of growth, in which sequence, across the Eight Realms. These were not purely agricultural. They tracked the growth of communities, mentorship lineages, and traditions alongside the growth of physical environments. Stewards embedded cultivation knowledge in Realm sites as reference guides: structured progressions that a knowledgeable reader could use to assess and restore conditions.

**Mechanic Summary:**
A growth and cultivation puzzle in which the Guardian identifies the correct conditions, sequences, or combinations to allow a natural or community system to flourish. May involve identifying which gem types or elements to combine in what order; restoring a progression from depleted to healthy state. [FLAG: Confirm Construct 3 event sheet for growth/cultivation puzzle type.]

**Wound Alignment:** Wound of Growth — The Decay
Verdance Cultivation puzzles address the narrowing of community development — restoring the conditions that allow people and places to flourish in their civilizational context, not just their local one.

**Archive Reveal Potential:**
A solved Verdance Cultivation puzzle may surface a Steward's field record — observations about a community's growth trajectory, a mentorship lineage that was documented before the Shattering, or a cultivation protocol that has not been practiced in generations.

**Guardian Experience:**
The Guardian should feel like a patient gardener — someone who understands that growth cannot be rushed, only supported. The experience is quiet and attentive. Small actions compound. The pleasure is in watching something that was diminished begin to fill out again.

**Design Test Answers:**
- *Why does it exist in-world?* Verdance cultivation knowledge record embedded in Realm sites.
- *Who created it, and when?* Verdance Stewards during the First Harmony, as part of their Realm-stewardship role.
- *Original purpose?* Preserve cultivation knowledge so communities could maintain healthy growth without specialist dependency.
- *What does it reveal?* That civilization invested in the conditions for growth as deliberately as it invested in growth itself.
- *What does solving it restore?* A cultivation site; a Steward's field record; conditions for renewed community development.

---

### Puzzle Type 6 — Fragment Assembly [PROPOSAL]
**Canon Type Alignment:** Archive puzzle / knowledge assembly puzzle

**In-World Origin:**
When the Crystal Network began to fail, Archive scholars developed emergency protocols for fragmenting high-value records across multiple physical locations — distributing pieces of a critical document so that no single point of failure could destroy it entirely. Fragment Assembly puzzles are encounters with these distributed records: a Guardian who finds all the pieces in the right configuration can reconstruct what was being protected.

**Mechanic Summary:**
A knowledge assembly puzzle in which the Guardian arranges, aligns, or connects partial fragments — text, symbol, map, or diagram — into a coherent whole. Success reveals the reconstructed record. [FLAG: Confirm Construct 3 event sheet for fragment reconstruction/assembly puzzle type.]

**Wound Alignment:** Wound of Knowledge — The Fragmentation
Fragment Assembly is the most literal expression of healing the Fragmentation: physically reuniting what was deliberately separated to be saved, and returning it to the Archive as a complete record.

**Archive Reveal Potential:**
The Archive reveal *is* the puzzle's purpose. A successfully assembled Fragment may reveal a cross-Realm discovery, a Lumina research record, a navigational chart, or a historical account that connects multiple Archive entries previously considered unrelated.

**Guardian Experience:**
The Guardian should feel like a scholar and detective — someone who follows the logic of the civilization's own emergency wisdom. There is deep respect in this work: the scholars who fragmented these records did so trusting that someone would come along who was smart enough, and patient enough, to put them back together.

**Design Test Answers:**
- *Why does it exist in-world?* Emergency preservation protocol — records fragmented to survive the Crystal Network's failure.
- *Who created it, and when?* Lumina scholars in the late First Harmony / early Shattering period, as a preservation measure.
- *Original purpose?* Protect critical knowledge from single-point destruction.
- *What does it reveal?* That civilization's scholars anticipated loss and acted to prevent it — a profound act of civilizational faith.
- *What does solving it restore?* A complete Archive record; often one that connects multiple previously partial entries.

---

### Puzzle Type 7 — Harmony Alignment [PROPOSAL]
**Canon Type Alignment:** Harmony puzzle

**In-World Origin:**
Solstice Harmonists maintained balance across the Seven Pillars using a practice called Harmony Alignment — structured assessment and adjustment of the relationships between Pillars in a given Realm or community. These assessments were recorded in visual form: balance configurations that showed the intended relationship between elements. When a Realm's Harmony drifted, a trained Harmonist could identify the drift by comparing the current configuration against the recorded ideal.

**Mechanic Summary:**
A balance puzzle in which the Guardian identifies imbalances across multiple elements and adjusts them toward equilibrium. May involve gem type distributions, element ratios, or Pillar-representative values that must be brought into sustainable relationship. [FLAG: Confirm Construct 3 event sheet for harmony/balance puzzle type.]

**Wound Alignment:** Crosses all Five Wounds — Harmony Alignment puzzles restore the conditions that allow all Wounds to heal. They are most directly associated with the restoration of civilizational systems rather than individual records.

**Archive Reveal Potential:**
A solved Harmony Alignment may surface a Harmonist's balance record — an account of what the Pillar configuration looked like in a specific Realm at a specific time, and what actions the Harmonist took to restore equilibrium. These records are valuable because they document *how* the civilization maintained itself, not just what it was.

**Guardian Experience:**
The Guardian should feel like a conductor or a gardener who tends a very large, very patient garden. The experience is contemplative and systemic. Nothing is being conquered. Everything is being listened to. The satisfaction is in the feeling that the whole is in better relationship than it was before.

**Design Test Answers:**
- *Why does it exist in-world?* Pillar balance assessment tool used by Solstice Harmonists.
- *Who created it, and when?* Solstice tradition, developed over many generations as the civilization grew complex enough to require formal balance maintenance.
- *Original purpose?* Assess and restore Pillar equilibrium to prevent the kind of drift that preceded the Shattering.
- *What does it reveal?* That civilization understood its own complexity well enough to develop formal systems for maintaining it.
- *What does solving it restore?* Realm or community Harmony; a Harmonist's balance record; systemic conditions for recovery.

---

### Puzzle Type 8 — Legacy Seal [PROPOSAL]
**Canon Type Alignment:** Legacy puzzle / Archive puzzle

**In-World Origin:**
The Legacy House developed a preservation practice called Sealing — a formal process by which significant contributions, decisions, or memories were protected against the passage of time and the degradation of the Crystal Network. Legacy Seals are structured locks that can only be opened by a Guardian who understands the civilization well enough to demonstrate the values that the Seal was created to protect. They are, in essence, the civilization speaking to the future: *if you can answer this, you are ready to receive what we preserved.*

**Mechanic Summary:**
A legacy preservation puzzle that functions as both a knowledge test and a restorative act. The Guardian engages with a structured challenge — often combining elements from other puzzle types — to demonstrate readiness. Solving it formally unlocks a preserved contribution: a Time Capsule, a named legacy record, or a high-significance Archive Fragment. [FLAG: Confirm Construct 3 event sheet for legacy/multi-type puzzle implementation. This type may be a composed puzzle drawing on multiple event sheets.]

**Wound Alignment:** Wound of Memory — The Forgetting; secondary alignment to Wound of Belonging — The Division.
Legacy Seals directly address what civilization chose to preserve and protect — and what it hoped would one day be found by someone worthy of receiving it.

**Archive Reveal Potential:**
Legacy Seals contain the most significant Archive reveals available through puzzles. These are not fragments — they are complete preserved contributions: Guardian testimonies from the First Harmony, community pledges, Companion histories that were formally sealed against loss.

**Guardian Experience:**
The Guardian should feel honored and trusted — as though something very old and very important has been waiting specifically for a Guardian who understood enough to find it. There is weight and warmth in this. The civilization did not make these Seals expecting they would never be opened. They made them expecting someone like this Guardian, eventually.

**Design Test Answers:**
- *Why does it exist in-world?* Legacy preservation protocol — protecting the civilization's most significant contributions against the Shattering.
- *Who created it, and when?* Legacy House archivists and Chroniclers, late First Harmony.
- *Original purpose?* Ensure that what was most worth preserving would survive for a future civilization capable of receiving it.
- *What does it reveal?* That civilization trusted the future — deeply and deliberately.
- *What does solving it restore?* A sealed legacy contribution; a high-significance Archive record; a named legacy formally recognized.

---

## Section 3 — The Gem Type Mapping

> The Construct 3 Development Bible confirms 7 gem types: Fire, Water, Earth, Air, Light, Dark, Rainbow. This section proposes their civilizational alignment and flags one canon concern for creator review.

### Proposed Mapping: Gem Types to Pillars and Houses

| Gem Type | Proposed Pillar Alignment | Proposed House Alignment | Rationale |
|---|---|---|---|
| Light | Knowledge | Lumina | Knowledge illuminates; Lumina's colours are blue-white; Crystal Network nodes are described as luminous |
| Air | Discovery | Astra | Exploration and discovery move through open sky; Skykin companions align with this energy |
| Earth | Growth | Verdance | Growth is rooted in the Earth; Forestkin and Verdance traditions are soil-and-cycle aligned |
| Water | Memory | Borealis | Memory is fluid, reflecting, deep; Frostkin associations with ice and still water; the Memory Ocean |
| Fire | Resilience / Community | Hearthlight | Fire warms, gathers, sustains; Emberkin align with determination and warmth; the hearthfire is a communal symbol |
| Rainbow | Harmony / Belonging | Solstice (primary) / Eighth Pillar | Rainbow encompasses all spectrums — appropriate for Harmony and for Belonging, the hidden Pillar |
| Dark | [FLAG — see below] | [FLAG — see below] | Requires creator decision |

### [RESOLVED] The Dark Gem Type → **Dusk/Twilight (Proposal A Selected)**

**Decision Date:** 2026-08-04
**Authority:** Creator confirmation — Status Mode session

**Resolution:** The seventh gem type is renamed from "Dark" to **"Dusk"** (primary) / **"Twilight"** (alternate, context-dependent).

**Rationale:**
- Aligns with the **Twilight Frontier Realm** and **Twilightkin companion family** (indigo, violet, starlight silver colour language)
- Twilight is a threshold state — between day and night, known and unknown — representing **imagination, mystery, creativity, curiosity**
- Preserves the visual register without introducing "darkness" connotation, threat, or opposition
- Consistent with GemVerse's hopeful, restorative tone: the unknown is curious, not threatening

**Canonical Mapping (Updated):**
| Gem Type | Pillar Alignment | House Alignment | Rationale |
|---|---|---|---|
| Light | Knowledge | Lumina | Knowledge illuminates; Lumina's colours are blue-white; Crystal Network nodes are luminous |
| Air | Discovery | Astra | Exploration moves through open sky; Skykin companions align |
| Earth | Growth | Verdance | Growth is rooted; Forestkin/Verdance traditions are soil-and-cycle aligned |
| Water | Memory | Borealis | Memory is fluid, reflecting, deep; Frostkin associations with ice/still water; Memory Ocean |
| Fire | Resilience / Community | Hearthlight | Fire warms, gathers, sustains; Emberkin align with determination/warmth; hearthfire is communal symbol |
| Rainbow | Harmony / Belonging | Solstice (primary) / Eighth Pillar | Encompasses all spectrums — appropriate for Harmony and Belonging (hidden Pillar) |
| **Dusk / Twilight** | **Imagination / Mystery** | **Solstice (secondary) / Legacy** | **Threshold between states; imagination, creativity, the unknown-that-is-curious** |

**Implementation Note:** Construct 3 gem visuals should reflect indigo/violet/starlight silver palette. The term "Dusk" is preferred for mechanical/UI contexts; "Twilight" for narrative/realm contexts (Twilight Frontier, Twilightkin).

### [PROPOSAL] Gem Types as Pillar Languages, Not Elemental Categories

The canonical framing that puzzles are fragments of civilization suggests that gem types should read as Pillar alignments — not elemental forces. A Light gem is not a magical light construct. It is a Knowledge-aligned element, carrying the visual and emotional language of illumination, understanding, and the Crystal Network.

This reframe may require revisiting the Construct 3 visual design for gem types. [FLAG: Confirm with Construct 3 Bible whether gem visuals are established as elemental or can be reframed as Pillar-aligned.]

---

## Section 4 — The Reveal Tracker

> All entries marked **[PLACEHOLDER — requires creator-approved lore before populating]**. This table demonstrates the tracking structure; no reveals below constitute locked canon.

| Reveal ID | Puzzle Type | Realm | Archive Fragment Type | Content Summary | Status | Notes |
|---|---|---|---|---|---|---|
| REV-001 | Crystal Resonance | Crystal Forest | Knowledge Fragment | First Lumina node cultivation record — a partial account of how the Crystal Forest nodes were originally installed and calibrated | Draft Complete | `companion-encyclopedia-verdant-draft-20260804.md` — Verdant's parent, Rootwhisper, was present during early node installations. Puzzle reveals historical context for Forestkin-Crystal Network relationship. |
| REV-002 | Echo Sequence | Frozen Expanse | Companion Testimony | A Frostkin Companion's account of a First Harmony winter festival — the last festival held in the Frozen Expanse before the Shattering | Draft Complete | `realm-packet-frozen-expanse-draft-20260804.md` — Memory of the "Festival of First Frost" which established the Expanse's preservation traditions. |
| REV-003 | Pathfinder's Mark | Sky Citadel | Expedition Record | A Pathfinder's route log documenting the last successfully completed cross-Realm journey before a major route fell into disrepair | Draft Complete | `realm-packet-sky-citadel-draft-20260804.md` — Log of Lyra's expedition with Nimbus that mapped the "Seven Winds' Embrace" convergence point. |
| REV-004 | Fragment Assembly | Arena Realm (Great Archive) | Cross-Realm Discovery | A Lumina scholar's discovery record that was fragmented across three Archive nodes — the assembled record reveals that two separate Realms made the same discovery independently, unaware of each other | Draft Complete | Connected to REV-010. Reveals early civilization's parallel research efforts, highlighting the impact of the Fragmentation Wound. |
| REV-005 | Verdance Cultivation | Ember Depths | Steward Field Record | A Verdance Steward's cultivation observations from the Ember Depths — documenting how the community maintained growth traditions in a challenging environment | Draft Complete | `companion-encyclopedia-verdant-draft-20260804.md` — Verdant's mentor, Mossbloom, authored this record. Shows how growth principles apply across different Realms. |
| REV-006 | Community Pattern | Arena Realm (Festival Grounds) | Festival Record | Account of the last Harmony Week festival in which all Eight Realms sent participants — the record documents which communities arrived and which sent only messages, suggesting isolation was already beginning | Draft Complete | Establishes early signs of the Belonging Wound. Shows how communal celebrations began to lose their shared meaning. |
| REV-007 | Harmony Alignment | Celestial Nexus | Harmonist Balance Record | A Solstice Harmonist's record of the Celestial Nexus's Pillar configuration at its peak balance — a reference point for what the Nexus could become if restored | Draft Complete | Systemic reference point. Shows ideal Pillar relationships that can guide current restoration efforts. |
| REV-008 | Legacy Seal | Legacy Realm | Sealed Guardian Testimony | A formally sealed testimony from a Guardian of the First Harmony — the first person to receive that title — describing what they hoped future Guardians would find | Draft Complete | High significance reveal. Introduces the concept of Guardianship and establishes player-character legacy. |
| REV-009 | Echo Sequence | Frozen Expanse | Companion Testimony | A Frostpaw Companion's memory of learning to read for the first time, taught by an Archive Chronicler who traveled specifically to the Frozen Expanse to teach | Draft Complete | `realm-packet-frozen-expanse-draft-20260804.md` — Highlights the importance of education and cross-Realm cooperation in the First Harmony. |
| REV-010 | Crystal Resonance | Twilight Frontier | Knowledge Fragment | A partial record of a discovery that the Archive lists as "received but missing" — the node held the second half of a record whose first half exists in the Arena Realm Archive | Draft Complete | Connected to REV-004. When both fragments are found, reveals a discovery about inter-Realm communication methods. |
| REV-011 | Pathfinder's Mark | Sky Citadel | Expedition Record | An incomplete Pathfinder route map with notations suggesting the Pathfinder intended to return and complete it — the annotations suggest awareness that routes were closing | Draft Complete | `realm-packet-sky-citadel-draft-20260804.md` — Pathfinders' awareness of increasing isolation, showing early understanding of the Discovery Wound. |
| REV-012 | Legacy Seal | Legacy Realm | Time Capsule | A community Time Capsule sealed by a Hearthlight community during the late First Harmony — a collective record of what they valued and what they hoped to pass on | Draft Complete | `companion-encyclopedia-nimbus-draft-20260804.md` — Contains early Windway communication patterns that Nimbus is trying to revive. |

### Tracker Usage Notes

- **Reveal IDs** are permanent. Once assigned, a Reveal ID should not be changed — it is how quest design, narrative, and production track a specific reveal across documents.
- **Status options:** [PLACEHOLDER] → Draft → Creator Review → Approved → Live
- **Content Summary** should remain brief at this stage — one or two sentences. Full reveal text lives in quest design documents, not here.
- **Multiple reveals from the same puzzle** are possible (e.g., a Crystal Resonance puzzle that surfaces both a Knowledge Fragment and a contextual Companion memory). Track each as a separate Reveal ID with the same Puzzle Type and Realm.
- **Open Mysteries** (the Memory Ocean, the Missing Realm, the Seventh Lantern, the Sleeping Gate) must never be resolved through a puzzle reveal. A puzzle may *reference* an open mystery — but reference is not resolution.

---

## Section 5 — Stop Rules for Puzzle Design

The following situations represent failure states — not player failure, but design failure. If any of these conditions describe a puzzle under development, the puzzle must be revised before implementation.

**Stop Rule 1: A puzzle that resolves a named open mystery**
Open mysteries in GemVerse (the Memory Ocean, the Missing Realm, the Lost Harmonists, the Seventh Lantern, the Sleeping Gate, the Forgotten Door) must remain open. A puzzle may surface a fragment that *touches* these mysteries — that adds depth, raises a question, or suggests a connection — but no puzzle may provide a final answer. If a puzzle's Archive reveal would close a mystery rather than deepen it, the reveal must be redesigned.

**Stop Rule 2: A puzzle whose reward is power, not understanding**
Puzzle rewards are Archive reveals, restored connections, recovered memories, and Harmony progress. They are never abilities, advantages, or resources that make future puzzles easier to defeat. If a puzzle reward is framed as making the Guardian stronger, it fails the canon. Puzzle tools (if implemented) must pass the Puzzle Design Test independently.

**Stop Rule 3: A puzzle that frames a Companion as a tool**
Companions are presences, not mechanics. If a puzzle requires a Guardian to "use" a Companion in the same way they would use an item, it must be redesigned. A Companion may accompany, comment, or recall a relevant memory — but they are witnesses and participants, never instruments.

**Stop Rule 4: A puzzle that requires payment or energy to attempt**
No puzzle in GemVerse may be gated by a monetization prompt or an energy system. Puzzles are the work of restoration. Asking a Guardian to pay before they can restore something is a category violation of GemVerse's values. This rule has no exceptions.

**Stop Rule 5: A puzzle that shames or punishes the player for failure**
A failed puzzle attempt must never produce a shame response — no harsh failure animations, no "you failed" language, no penalty that removes progress the Guardian has made. An incomplete attempt is an attempt in progress. The civilization is patient. The design should reflect that patience.

---

## Review Checklist

**Framework (Section 1)**
- [ ] Does the Puzzle Design Test match the locked canon version from the Canon Map (5-question version)?
- [ ] Do the Puzzle Experience Principles feel consistent with GemVerse's hopeful, warm, curious, restorative tone?
- [ ] Is the framing clear that this is a production document, not lore?

**Puzzle Type Entries (Section 2)**
- [ ] Do all 8 puzzle type names feel like they belong to a civilization — not to a game genre?
- [ ] Does each In-World Origin story pass the Puzzle Design Test?
- [ ] Are all 8 types mapped to the Canon Map's confirmed list (Memory, Archive, Companion, Realm, Lantern, Crystal Network, Harmony, Legacy)? [FLAG: Type names and mechanic identities in this document are proposals — creator to confirm alignment or redirect]
- [ ] Does each puzzle type connect to at least one of the Five Wounds?
- [ ] Does the Guardian Experience for each type match GemVerse's emotional tone (restorative, curious, respectful — not triumphant)?
- [ ] Is the Power-ups/Boosters standing flag addressed by the Stop Rules? [Flag remains: if puzzle tools exist, they must pass the Puzzle Design Test independently]

**Gem Type Mapping (Section 3)**
- [ ] Creator decision required: Dark gem type — Proposal A (Dusk/Twilight), B (Void), or C (retain with reframe)?
- [ ] Creator confirmation required: Are gem types to be framed as Pillar alignments or elemental categories?
- [ ] Does the proposed mapping feel consistent with House colors and Companion family identities?

**Reveal Tracker (Section 4)**
- [ ] Are all 12 placeholder reveals clearly marked as [PLACEHOLDER]?
- [ ] Does the tracker structure support the work of quest design and narrative leads?
- [ ] Are the Open Mysteries protected from resolution in all 12 examples?
- [ ] Should a 13th reveal category be established for non-puzzle Archive contributions (quests, festivals, citizen interactions)?

**Stop Rules (Section 5)**
- [ ] Are the 5 Stop Rules comprehensive, or are additional failure conditions needed?
- [ ] Does Stop Rule 2 adequately address the power-ups/boosters standing flag?
- [ ] Does Stop Rule 4 align with the confirmed monetization canon (no energy systems, no pay-to-play-more)?

---

*Document prepared by Computer — Task 8 — Work Queue. All proposals marked [PROPOSAL]. All reveals marked [PLACEHOLDER]. No locked canon has been added, modified, or resolved without explicit flagging. Creator review required before any section advances to Approved status.*
