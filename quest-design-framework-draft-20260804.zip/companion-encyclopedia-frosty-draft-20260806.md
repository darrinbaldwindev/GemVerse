# Companion Encyclopedia Entry — Frosty
**Draft Date:** 2026-08-06  
**Status:** Ready for Creator Review  
**Tier 3 Entry:** 3.4  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Frosty  
**Themes:** Preservation, Quiet Strength, Enduring Memory  
**Companion Family:** Frostkin (Ice Blue, Pale Silver, Frost White)  
**Visual Identity:** Ice bear cub — fur with ice-crystal patterns that catch and refract light, eyes that hold deep calm, paws that leave faint frost trails  
**Symbol:** Enduring Snowflake (representing preserved memory and quiet resilience)  
**Unique Trait:** Frosty can perceive and gently amplify "memory resonances" — lingering impressions of events, emotions, and patterns of behavior left in places where significant experiences occurred

---

## 1. Origin Story

Frosty coalesced in the Still Waters of the Frozen Expanse during a period when the Memory Wound was beginning to affect recollection. These waters were known as places where memories seemed to settle and reflect with unusual clarity — favored spots for Borealis Chroniclers to contemplate important events and community decisions. As the Forgetting Wound began to weaken memory fidelity, the waters' reflective properties dimmed, but Frosty emerged from the remaining stillness as an embodiment of the waters' enduring purpose: to preserve what matters.

They were first perceived not as a distinct form, but as a particularly clear reflection that seemed to take shape — a moment of remembrance that refused to fade. The Borealis Chroniclers who encountered Frosty recognized them as a sign: even as memories weakened, the capacity for clear recollection and gentle preservation remained accessible to those who approached with patience and respect.

---

## 2. Personality

Frosty moves with a deliberate, steady grace, often pausing as if listening to silent memories. They communicate more through shifts in their internal frost patterns — clarity, intensity, and subtle movements — than through sound, though they can produce soft, crackling tones like ice settling when pleased or concerned. Frosty values preservation, patience in understanding, and the quiet strength of enduring what cannot be changed.

They have a particular affinity for places of memory and reflection — quiet shores, still waters, ancient trees where community gatherings once occurred. In such places, Frosty's frost patterns tend to become clearer and more steady, as if responding to the echo of meaningful experiences still present in the environment.

---

## 3. Shattering Memory

Frosty remembers the Still Waters before the Shattering — vast icy expanses where Chroniclers would come to meditate on community history, where the very air seemed to help memories connect and clarify. After the Shattering, the waters grew less still. The reflective properties that amplified understanding weakened. Chroniclers visited less frequently, and when they did, they found their recollections more prone to distortion, less able to sustain deep focus on meaningful events.

What affected Frosty most deeply was not the disturbance of water, but the sense that the waters were being forgotten — not as physical places, but as sites of purpose. Fewer beings came seeking the specific kind of clarity the waters offered for understanding the past. The waters still existed, but their reason for being seemed to be fading from memory.

---

## 4. Missing Piece

Frosty's Missing Piece is a "Memory Loom" — a delicate ice structure that once existed in the deepest part of the Still Waters. This loom was said to weave together fragments of memory from different experiences into coherent wholes, allowing collaborative recollection that no single mind could achieve alone. During the Shattering, the Memory Loom fractured into numerous shards, each carrying a tendency toward a particular type of memory (sensory detail, emotional context, sequential pattern, etc.). Frosty carries one shard that resonates when near complementary approaches to recollection.

---

## 5. Restoration Story

Frosty joined the Guardian during an effort to restore stillness to a disturbed section of the Still Waters. The Guardian, working with Borealis Chroniclers, helped clear debris and stabilize ice formations that had shifted during early Shattering tremors. As the waters settled, Frosty's presence became more perceptible — their frost patterns seemed to respond to the renewed potential for clear recollection in the space.

The turning point came when Frosty "resonated" with a particular ice formation that had been painstakingly realigned — not with clarity, but with a complex interplay of patterns that seemed to represent a specific mode of recollection (sensory-rich episodic memory). With the Guardian's help in documenting which adjustments produced which resonant responses, the Chroniclers began to reverse-engineer principles of the lost Memory Loom.

Frosty's role in restoration is not to restore perfect memory, but to help preserve and rediscover the conditions that make collaborative recollection possible — to remind the Guardian that some truths emerge not from solitary effort, but from the willingness to let different perspectives illuminate each other's recollections.

---

## 6. Legacy Story

Over time, Frosty taught their Guardian the "Still Pause" — a practice of briefly stilling one's own thoughts to better perceive what a place or situation might be trying to reveal about its past. Others have begun to speak of "Frosty's Glow" — moments when understanding of past events seems to arrive not through struggle, but through a sudden, gentle clarity that feels like remembering something already known. Whether this is Frosty's influence or the natural result of creating space for recollection is ambiguous, which suits both parties.

Frosty's ultimate legacy is not a perfect memory, but a remembered approach — the confidence that understanding can emerge gently, that clarity is often a matter of creating the right conditions rather than forcing a result.

---

## Relationships

### Frostkin Family
Frosty's "parents" are not beings but concepts: Recall (representing clear recollection) and Preserve (representing gentle maintenance). Their bond is not familial in the traditional sense, but conceptual — Frosty feels strongest when both clear recollection and gentle preservation are present in an undertaking.

### Guardian
Frosty sees the Guardian as a willing learner, someone who values understanding but sometimes mistakes effort for insight. They are patient with the Guardian's tendency to push through confusion, and often "glow" most strongly when the Guardian pauses to simply observe. This has made the Guardian more attentive to the quality of their attention, not just its intensity.

### Other Companions
- **Spark:** "Bright and quick, but misses the deep quiet." Energetic and immediate, but sometimes overlooks the value of patient recollection.
- **Verdant:** "Deep green patience. Grows understanding slowly." Respects Verdant's approach but finds it sometimes too slow for urgent questions needing quick insight.
- **Nimbus:** "Always chasing the next horizon." Shares love of discovery but differs on whether insight comes from movement or stillness.
- **Echo:** "Many-layered memory. Holds complex patterns." Natural collaborator — their perspectives often complement each other perfectly (episodic + semantic memory).

---

## Companion Abilities (Narrative, Not Mechanical)

- **Memory Resonance Perception:** Can sense lingering impressions of events, emotions, and patterns of behavior in places where significant experiences occurred
- **Frost Amplification:** Can gently enhance existing clarity in a situation, making subtle memories more perceptible
- **Pattern-Coded Memory:** Different configurations of their internal frost correspond to different types of memory (linear for episodic, web-like for semantic, cyclical for procedural)
- **Stillness Sensitivity:** Perceives best when both they and the Guardian are physically and mentally still, valuing receptive quiet over active searching

---