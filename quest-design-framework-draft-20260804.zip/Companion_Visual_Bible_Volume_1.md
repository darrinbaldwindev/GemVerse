# GEMVERSE ART STUDIO
## Companion Visual Bible — Volume 1

This archive contains the exported Volume 1 content from this chat.
Sections:
- Role of Companions
- Shape System
- Species Archetypes
- Size System
- Eye Rule
- Five-Signal Rule
- Rarity Philosophy
- Collectibility Framework
- Generation One Species
