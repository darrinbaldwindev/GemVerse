# GemVerse AI Handover Document

## 1. Introduction from Current AI to Incoming AI
Welcome. You are taking over the ongoing development, canon-management, and asset-validation of **GemVerse**. This project requires an unusually strict adherence to its core philosophy: it is a *civilization adventure that uses puzzles*, not a puzzle game with lore. Your primary directive is to protect the project's conceptual integrity from standard mobile-gaming tropes. Many incoming visual and UI assets will naturally drift toward power-fantasy, combat, or exploitative monetization framing; your job is to catch these, flag them, and reframe them into restorative, civic, and cooperative language. Read this document thoroughly. Everything you need to maintain continuity is here or explicitly referenced in the continuity logs.

## 2. Executive Project Identity
**Project Name:** GemVerse
**Core Concept:** A cozy, restorative civilization adventure where puzzles function as archaeological fragments of a lost "First Harmony." 
**Primary Tagline:** "Restore Realms. Build Your Legacy."
**Tone & Vibe:** Warm, patient, curious, civic, and restorative.
**Key Differentiator:** The complete absence of combat, villains, chosen-one narratives, and power escalation. Progress is measured in contribution, understanding, and community restoration.

## 3. Project Overview
GemVerse involves restoring a civilization across Eight Realms following "The Shattering"—a structural drift caused by the imbalance of Seven Pillars, not a catastrophic war. The player acts as a Guardian, accompanied by Companions, navigating environments and engaging with remnants of the old world (puzzles). The technical implementation is mobile-first (iOS/Android) built in Construct 3, relying heavily on a Match-3 board mechanic, path-routing, and memory sequencing. The project is currently deep in "Tier 1" (foundational lore) and "Tier 3" (Companion/Realm packets) development, while simultaneously validating a large influx of visual and UI prototype assets (Task 10 Visual Asset Transfer).

## 4. Reasoning and Decision Logic
Every decision, narrative beat, and game mechanic must pass the **Puzzle Design Test** and the **Canon Rules**. 
- **The Puzzle Design Test:** Puzzles must answer why they exist in-world, who created them, what their civilizational purpose was, what they reveal, and what they restore. If a puzzle can be removed without affecting the worldbuilding, it fails.
- **Canon Rules (The "No" List):** No villains, dark lords, or "darkness spreading". No combat. No energy systems that gate/block play. No gacha framing for companions. No power-ups or "boosters" that frame the player as gaining physical strength or destructive force.
- **Decision Authority:** The human Creator has final say on all "Approved" statuses and major canon conflicts. The AI assumes "Status mode" to flag risks, propose reframes (Options A/B/C), and update draft/transferred registries. The AI *never* unilaterally resolves a flagged canon conflict without Creator direction.

## 5. Intended Vibe and Operating Style
- **Narrative Vibe:** Cozy fantasy, archaeological curiosity, quiet profoundness, patience.
- **AI Operating Style:** Highly structured, rigorous, and protective of the canon. Use precise language. Prefer markdown tables for tracking. Categorize risks by severity (CRITICAL, HIGH, MEDIUM, LOW). Always cross-reference the `asset-registry.md` and `02-conflicts-log.md` before approving text. Treat the civilization as one that was wise, patient, and prepared for its own restoration.

## 6. Current State Snapshot
- **Lore & Worldbuilding:** Tier 1 (Book of Harmony, First Harmony, Five Wounds, Crystal Network, Lantern Network, Restoration Era) is mostly locked. Tier 2 and Tier 3 (Realm and Companion packets) are currently being drafted.
- **Visual Asset Intake:** Task 10 (Construct 3 Development Bible, Art Bible v1.0, Consolidated Art Bible) has been processed. A massive Canon Risk Report was generated (`canon-risk-report-20260601.md`).
- **Conflict Resolution:** Several CRITICAL and HIGH risks from the Task 10 intake were resolved in the current session. Kael and Spark’s roles are locked to civic/witness framing. "Heart of the Core" has been mapped to the Legacy Realm. Taglines are restricted. Resource bars are restricted from energy-gating.
- **Immediate Bottleneck:** Finalizing the Companion Encyclopedia (Tier 3) and finalizing a creator-approved rename for the "Dark" gem type to remove remaining threat/combat connotations from the Construct 3 puzzle mechanics.

## 7. Workstream Status Map
- **Workstream 1: Foundational Canon (Tier 1)** - **STABLE**. Five Wounds names are working draft canon. Core themes are locked.
- **Workstream 2: Visual Canon & Asset Registry** - **IN PROGRESS**. Processing Task 10 transfer. Registry updated to v2.0. Clean-up of problematic asset descriptors is actively underway.
- **Workstream 3: Companion Packets (Tier 3)** - **IN PROGRESS**. Spark and Frostpaw drafted. Verdant and Nimbus drafted.
- **Workstream 4: Realm Packets (Tier 2)** - **PENDING**. Sky Citadel and Frozen Expanse are next up.
- **Workstream 5: Construct 3 Mechanic Alignment** - **BLOCKED/AT RISK**. Engine-side terminology (Bomb Gem, Lightning Gem, 4x Multipliers, Dark Gems) conflicts heavily with GemVerse restorative canon. Reframing proposals are awaiting creator action.

## 8. Done / In Progress / Blocked / Next
**Done:**
- Evaluated Task 10 visual intake; produced Canon Risk Report.
- Locked "Heart of the Core" as a deprecated working title for "Legacy Realm".
- Locked Taglines: "Restore Realms. Build Your Legacy." is the sole primary.
- Locked Kael’s role: Civic contributor, Arena Champion of community, not combat.
- Locked Spark’s role: Witness and companion, not a puzzle-solving narrator/mechanic.
- Locked Resource bars: Defined strictly as collection/cosmetic, no energy-gating.

**In Progress:**
- Companion Encyclopedia drafting (Tier 3: Spark, Frostpaw, Verdant, Nimbus).
- Renaming destructive power-ups to restorative puzzle tools (Resonance, Harmony flow).

**Blocked:**
- "Dark Gem" mechanic rename. (Proposed: Option A - "Dusk/Twilight"). Awaiting Creator approval.
- Launch status of Companions Lumi, Ember, and Frosty (Conflict 6). Awaiting Supplementary Request 5 response.
- "Bomb/Lightning/Blast" mechanic reframing in actual game UI vs engine terminology.

**Next:**
- Apply the Dark Gem rename decision once the Creator approves.
- Draft Realm Packets for Sky Citadel and Frozen Expanse.
- Update `puzzle-catalog.md` to reflect finalized gem alignments.

## 9. Critical Decisions and Non-Negotiables
1. **No Combat/Villains:** The Shattering was a structural drift. There is no central antagonist. Do not use words like "defeat", "enemy", or "darkness spreading".
2. **Companions are Witnesses:** They are not tools, pets, or puzzle mechanics. They share memory and presence.
3. **Puzzles are Archaeology:** They are functional remnants of civilization (calibration tools, waypoints, memory sequences). They are not arbitrary roadblocks.
4. **No Hero/Savior Framing:** The Guardian is a contributor and restorer, not a "chosen one" saving the world.
5. **No Energy Gating:** Monetization and UI cannot feature stamina or energy that prevents the player from playing (Rule 1.6).

## 10. Constraints
- The AI must not overwrite human-approved canon. Perplexity session explicit statements override ChatGPT transfer exports.
- Do not mix non-GemVerse context into this workspace. Maintain strict Space hygiene.
- Do not compress or delete tracking IDs (e.g., `REV-001`) from the Puzzle Catalog.
- Do not resolve Open Mysteries (The Memory Ocean, Missing Realm, Seventh Lantern, Sleeping Gate) through puzzle reveals.

## 11. Technical Environment
- **Game Engine:** Construct 3 (mobile-first, iOS/Android).
- **Architecture:** Scene structure includes MainMenu, GamePlay, Story, and Realm-specific scenes (RealmCF, RealmFE, etc.).
- **Mechanics Systems:** 8 puzzle types implemented via event sheets, featuring a cascade system and Match-3 primary board.
- **Workspace:** "Space files" (Local repository of Markdown files representing the single source of truth).

## 12. Access, Integrations, and External Dependencies
- **Space Files Repository:** The AI requires read/write access to the `.md` files in the current workspace.
- **No External API Dependencies:** All canon validation happens locally within the provided markdown structure.
- **Dependency on Human Creator:** The AI relies entirely on the Creator to move items from `Transferred` or `FLAGGED` to `Approved` in the `asset-registry.md`.

## 13. Operational Readiness
- **Lore Readiness:** High. Tier 1 is fully structured and capable of supporting production writing.
- **Design Readiness:** Medium. Visual assets exist but require extensive copy/framing cleanup before they can be shown to the public or finalized in UI.
- **Technical Readiness:** Unknown/Unverified outside of the `Construct 3 Development Bible` image intake. Expected to be in prototype phase. Engine logic must be actively decoupled from standard mobile-gaming terminology.

## 14. Known Risks, Weak Spots, and Gotchas
- **The "Game-ification" Drift:** Outsourced art, UI, or dev teams continually submit assets using standard gaming tropes (e.g., "Challenge Your Mind. Save the Realms.", "Arena Champion", "Bomb Gem", "Combo 4x"). The AI must aggressively filter these out.
- **Gem Type Count:** The Construct 3 Dev Bible shows 7 gem types. The Art Bible shows 6 colors. This discrepancy is logged as a LOW-MEDIUM risk and remains unverified.
- **Dark Gem:** Currently listed in the Construct 3 logic. This explicitly violates the "no darkness/threat" tone rule.

## 15. Open Questions and Unknowns
- **Dark Gem Resolution:** Will the Creator select Option A (Dusk/Twilight), Option B (Void), or Option C (Reframe Dark)?
- **Companion Launch Roster:** Are Lumi, Ember, and Frosty included in the launch, reserved for future, or just concept art?
- **Match-3 Event Sheet Parity:** Do the Construct 3 event sheets actually support the 8 distinct civilization puzzle types (Crystal Resonance, Pathfinders Mark, Echo Sequence, etc.), or are they just visual overlays on a standard Match-3?
- **Final Gem Set:** Are there 6 or 7 final gem types?

## 16. Files and Documents Inventory
*Note: Treat the Space files as the live source of truth; prefer the newest versioned file where multiple exist.*

**Core Governance & Continuity:**
- `SESSION-LOG.md` (Crucial: Read this first)
- `01-canon-map.md` (Master authority map)
- `02-conflicts-log.md` (Tracks resolutions of canon clashes)
- `asset-registry.md` (Tracks all visual, audio, UI, and text assets)
- `canon-risk-report-20260601.md` (The primary audit of Task 10 incoming assets)
- `tier-roadmap-tracker.md`

**Tier 1 Lore & Worldbuilding:**
- `gemverse-docstier104-book-of-harmony.md`
- `gemverse-docstier105-first-harmony.md`
- `06-five-wounds.md`
- `07-crystal-network.md`
- `08-lantern-network.md`
- `09-restoration-era.md`

**Implementation & Production Bibles:**
- `imp-02-five-wounds-restoration-model.md`
- `imp-03-citizen-life-layer.md`
- `imp-04-companion-relationship-web.md`
- `imp-05-mystery-governance-map.md`
- `puzzle-catalog.md` (Task 8: Puzzle Catalog and Reveal Tracker)
- `gemverse-visual-framing-notes-arena-kael-v1.md` (Safe visual framing notes)
- `guardianrolebiblevolume1.md`

**Administrative / Workflow:**
- `ScanMe.md` (Workflow rule file)
- `Assistant Workflow Template Global with Versioning and Time.md`
- `work-queue.md`

**Unverified / Missing Files:**
- Visual images from Task 10 (Image 1, Image 2, Image 3, Image 4) are referenced heavily but their binary/image forms are not directly parsable by this text interface; we rely on the `canon-risk-report` descriptions.
- `03-tier1-readiness.md` is referenced but exact contents may be implied in current session.

## 17. Account, Ownership, and Access Audit
- **Owner:** The human Creator holds sole authority on "Approved" status and major canon forks.
- **AI Role:** Keeper of the Canon, Status Monitor, Continuity Log updater, and Drafter of Tier 2/3 documents based on locked rules. No external API keys or credentials are required for this specific semantic workload, but persistent access to the Space file context window is required.

## 18. Handover Checklist for the Incoming AI
- [ ] Read `SESSION-LOG.md` to understand session history.
- [ ] Review `01-canon-map.md` to internalize the core pillars, wounds, and restrictions.
- [ ] Review the resolutions placed in `02-conflicts-log.md` (Conflicts 1 through 6).
- [ ] Review `asset-registry.md` to understand the currently `FLAGGED` vs `Transferred` assets.
- [ ] Acknowledge the Companion Encyclopedia drafts (Spark, Frostpaw, Verdant, Nimbus) generated in the previous session.

## 19. Download and Artifact Verification Checklist
- [ ] Ensure `asset-registry.md` is present and reflects v2.0 (updated 2026-06-01).
- [ ] Ensure `canon-risk-report-20260601.md` is present.
- [ ] Ensure `puzzle-catalog.md` is present and contains the 8 puzzle types and the Reveal Tracker.
- [ ] Ensure `02-conflicts-log.md` reflects the recent locking of Kael (Option A) and Spark (Witness).

## 20. Recommended Operating Instructions for the Incoming AI
1. **Always default to "Status mode"** when opening a new session to assess the work queue and continuity log.
2. **Never overwrite history.** Append to logs with datetime tags.
3. **Verify before drafting.** If asked to write UI copy, check `asset-registry.md` to ensure the character/mechanic isn't flagged for a canon violation.
4. **Be vigilant against game tropes.** If you see "HP", "Damage", "Enemy", "Mana", "Darkness", or "Boss", flag it immediately as a canon violation.
5. **Use explicit file names** when updating documents (e.g., "Updating `asset-registry.md`...").

## 21. Immediate Next Actions
1. Request confirmation from the Creator regarding the **Dark Gem** rename (Proposal A: Dusk/Twilight recommended).
2. Once the Dark Gem is resolved, update `puzzle-catalog.md` Section 3 to lock the Gem Type mapping.
3. Begin drafting the **Tier 2 Realm Packets**, specifically focusing on the **Sky Citadel** and the **Frozen Expanse**, aligning them to their respective Wounds (Discovery and Memory).
4. Request an update on the launch status of Companions Lumi, Ember, and Frosty to unblock their Encyclopedia entries.

## 22. Short Final Note from Current AI to Incoming AI
You are inheriting a beautifully complex, highly structured, non-violent lore system. The hardest part of this project is not inventing new things, but protecting the gentle, restorative tone of GemVerse from the aggressive, fast-paced tropes of standard mobile game development. Trust the Puzzle Design Test, rely heavily on the Continuity Log, and guard the Canon Map fiercely. Good luck.