# Quest Design Framework
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.6  
**Linked Files:** `festival-encyclopedia-draft-20260804.md`, `companion-interaction-system-design.md`, `harmony-index-system-design.md`, `great-archive-ux-specification.md`, `puzzle-progression-reveal-design.md`, `realm-packet-*.md` (all 8)

---

## Overview

Quests in GemVerse are **invitations to participate in restoration** — not tasks to complete for rewards. They emerge from the needs of communities, the curiosity of companions, the mysteries of the Archive, and the rhythms of the festivals. There is no quest log, no exclamation marks, no "complete 10 bear asses." There is only the work that needs doing, and the choice to help.

### Core Philosophy

1. **Emergence Over Scripting** — Quests arise from world state, not designer scripts. A community needs help with their cooling system? That's a quest. A companion wants to explore a dormant route? That's a quest. The Archive has a new Unanswered Question? That's a quest.

2. **Participation Over Completion** — Engaging with a quest is valuable regardless of "outcome." The attempt, the learning, the relationships built — these are the real rewards.

3. **Integration Over Isolation** — Quests connect to puzzles, festivals, companion relationships, community harmony, Archive research. No quest exists in a vacuum.

4. **Rhythm Over Urgency** — Quests have natural timing (seasonal, communal, companion-driven). No timers, no "limited time only," no FOMO.

5. **Restoration Over Accomplishment** — The measure of a quest is what it restores, not what it completes.

---

## Quest Categories (6 Types)

### 1. Narrative Quests — Character Arcs & Mystery Hooks
**Source:** Companion relationship deepening, Archive Unanswered Questions, Realm mystery hooks  
**Nature:** Long-form, multi-session, deeply personal  
**Structure:** Acts (not objectives) — each act is a phase of understanding

**Examples:**
- **Spark's First Light** (Companion): Help Spark understand what "hope" means in a restoring civilization. Acts: Meeting → Shared Exploration → Memory Creation → Understanding Moment → Kindred Offering
- **The Silent Archive Wing** (Archive Mystery): Investigate the sealed wing of the Great Archive. Acts: Discovery → Research → Companion Perspectives → Physical Investigation → Revelation → New Questions
- **The Missing Guardian** (Realm Mystery): The Hall of Guardians has an empty space. Who was erased? Acts: Archive Research → Legacy Realm Journey → Frostpaw Communion → Truth Fragment → Commitment Decision

**No "Completion":** Narrative quests evolve. They may resolve into new understandings, new questions, or ongoing practices.

### 2. Restoration Quests — Realm-Specific Healing Work
**Source:** Community needs, environmental damage, Wound manifestations, Harmony Index assessments  
**Nature:** Tangible, collaborative, measurable restoration impact  
**Structure:** Phases (Assessment → Planning → Action → Tending → Celebration)

**Examples:**
- **Ember Depths Cooling Restoration** (Community Need): A district's cooling system is failing. Phases: Diagnose with Solen → Design with Verdant → Build with Community → Monitor → Celebrate at Resilience Festival
- **Crystal Forest Node Reactivation** (Wound: Knowledge Fragmentation): A Crystal Network node is dormant. Phases: Locate with Prism → Understand History with Echo → Restore with Verdant/Spark → Synchronize with Nimbus → Integrate at Lantern Gathering
- **Twilight Frontier Path Manifestation** (Wound: Discovery Isolation): A community is imaginatively isolated. Phases: Dream with Mira → Map with Nimbus → Manifest with Galewing → Celebrate at Imagination Festival

**Restoration Metrics (Qualitative):**
- Community reports improved conditions
- Companions note environmental change
- Harmony Index reflects improvement
- Festival celebrations acknowledge the work

### 3. Festival Quests — Seasonal Community Participation
**Source:** Festival calendar, community preparation needs, companion festival roles  
**Nature:** Time-bound (festival season), celebratory, preparatory  
**Structure:** Preparation → Participation → Reflection → Integration

**Examples (Per Festival):**
- **Festival of Beginnings**: Welcome new citizens → Create community map → Share future vows → Integrate newcomers into Harmony Circles
- **Lantern Gathering**: Maintain lanterns → Share traveler stories → Map connections → Light-sharing ceremony
- **Harmony Week**: Facilitate Harmony Circles → Create community tapestry → Plan collaborations → Convergence preparation
- **Mentor Celebration**: Honor mentors → Share skills → Record wisdom → Plan mentorship pairings
- **Growth Festival**: Tend gardens → Share growth stories → Plant future projects → Assess environmental health
- **Discovery Festival**: Present discoveries → Plan explorations → Celebrate mysteries → Innovation workshops
- **Memory Festival**: Remembrance circles → Legacy projects → Preserve stories → Plan continuity
- **Resilience Festival**: Share strength stories → Adaptation workshops → Build support networks → Cultivate hope
- **Imagination Festival**: Share visions → Collaborative creation → Explore possibilities → Cultivate wonder
- **Wonder Festival**: Perspective sharing → Pattern recognition → Renew aspirations → Gratitude circles

**No "Missed Festival":** Festivals are annual cycles. Preparation for next year begins immediately. Late participation is still participation.

### 4. Companion Quests — Personal Growth & Missing Pieces
**Source:** Companion relationship deepening, companion personal needs, companion-companion dynamics  
**Nature:** Intimate, relationship-specific, often puzzle-integrated  
**Structure:** Invitation → Shared Journey → Vulnerability Exchange → Mutual Growth → Relationship Deepening

**Examples (Per Companion):**
- **Spark**: "Show me a beginning that matters." → Joint project initiation → Spark shares fear of not being enough → Citizen shares own beginning story → Kindred moment
- **Prism**: "Help me see what I'm missing." → Multi-perspective investigation → Prism reveals blind spot → Citizen offers missing perspective → Partnership deepened
- **Verdant**: "This grove remembers what I've forgotten." → Grove tending → Verdant accesses ancestral memory → Citizen witnesses → Growth cutting exchanged
- **Bloomtail**: "The circle has a gap." → Community care mapping → Bloomtail reveals exhaustion → Citizen organizes care rotation → Trust token received
- **Nimbus**: "There's a wind I can't read." → Joint exploration → Nimbus shares uncertainty → Citizen offers grounded perspective → Wind chime gifted
- **Galewing**: "A route needs singing that I can't sing alone." → Route restoration journey → Galewing teaches path-singing → Citizen adds their voice → Journey map created
- **Frostpaw**: "A memory is fading that must not be lost." → Deep memory communion → Frostpaw shares crystalline vulnerability → Citizen helps preserve → Resonance crystal formed
- **Echo**: "A voice has been silent too long." → Archive of Unanswered Questions → Echo guides voice recovery → Citizen helps amplify → Story circle completed

**Relationship-Gated:** Companion quests only available at specific understanding layers (Friend+). They deepen the relationship — they don't "unlock" it.

### 5. Citizen Quests — Community Building & Skill Sharing
**Source:** Citizen needs, Path progression, mentorship requests, community Harmony Circle outcomes  
**Nature:** Social, skill-focused, community-strengthening  
**Structure:** Request → Collaboration → Skill Exchange → Community Integration → Ongoing Connection

**Examples (Per Citizen):**
- **Rowan (Mentor)**: "Help me welcome the new guardians." → Orientation design → Skill: facilitation → New guardians integrated
- **Elara (Scholar)**: "This knowledge needs translation for the Frozen Expanse." → Knowledge adaptation → Skill: accessibility translation → Cross-realm understanding
- **Mira (Harmonist)**: "The community is stuck in old conflict patterns." → Creative mediation → Skill: metaphorical reframing → Harmony restored
- **Taren (Pathfinder)**: "A new route needs community input before we build." → Collaborative planning → Skill: community-integrated exploration → Route serves all
- **Solen (Harmonist)**: "The cooling system upgrade affects three districts." → Systemic balance facilitation → Skill: multi-stakeholder harmony → Equitable solution
- **Lyra (Pathfinder)**: "The Archive needs this discovery documented with full context." → Narrative documentation → Skill: significance assessment → Archive enriched

**Path Progression:** Citizen quests are how citizens advance on their Paths — not through XP, but through recognized contribution.

### 6. Daily Rhythm Quests — Ongoing Participation
**Source:** World state, companion daily routines, community needs, personal practice  
**Nature:** Lightweight, repeatable, integrated into daily play  
**Structure:** Notice → Choose → Engage → Reflect → Continue

**Examples:**
- **Morning Lantern Check** (with Nimbus): Walk the lantern path, note any dimming, report/fix
- **Garden Tending** (with Verdant/Bloomtail): Water, observe, record growth, share observations
- **Harmony Circle Prep** (with Rowan/Solen): Set up space, prepare prompts, welcome participants
- **Archive Contribution** (with Echo/Prism): Add reflection, connect entries, tend a Question
- **Companion Visit** (any): Spend time with companion, share presence, create micro-memory
- **Community Check-In** (any): Visit neighbors, ask "what are you building today?", offer help
- **Personal Harmony Map Update** (self): Reflect on Path prompts, add to map, share if desired

**No Obligation:** These are invitations, not dailies. No streaks, no penalties for skipping, no rewards for consistency.

---

## Quest Discovery (No Quest Log)

### How Citizens Find Quests

1. **Companion Invitations**: Companions directly invite based on relationship and current focus
2. **Community Notice Boards**: Physical/digital boards in each community (citizen-posted)
3. **Harmony Circle Outcomes**: Needs identified during circles become quest invitations
4. **Festival Announcements**: Seasonal preparation needs shared communally
4. **Archive Unanswered Questions**: Questions marked "seeking tending" appear in citizen's Archive view
5. **Environmental Observation**: Noticing something that needs care (dim lantern, struggling plant, tense community)
6. **Companion State Awareness**: Companions in "concerned" or "focused" state may need support
7. **Cross-Realm Messages**: Lantern Network carries requests from other Realms

### Discovery UI (Minimal, Diegetic)
- **No quest markers on map**
- **No quest list**
- **Journal** (personal, optional): Citizens can record what they're engaged with
- **Companion Dialogue**: "I'm heading to the vent gardens. Want to come?"
- **Community Conversation**: "The cooling system's been tricky lately..."
- **Archive Notification**: "A Question you're tending has new fragments."

---

## Quest Engagement Flow

```
NOTICE → CHOOSE → ENGAGE → REFLECT → CONTINUE/COMPLETE
```

### Notice
Citizen becomes aware of a need/opportunity through any discovery channel.

### Choose
Citizen decides to engage. No pressure. Can say "not now," "not me," "let me think."

### Engage
Active participation. This IS the quest. No objective checklist — just the work itself.
- May involve puzzles, travel, conversation, creation, tending, listening
- May be solo, with companion, with citizens, with community
- Duration: minutes to seasons

### Reflect
After engagement session (or phase), citizen reflects:
- What happened?
- What did I learn?
- What relationships deepened?
- What needs tending next?
- Recorded in Journal (optional) or Memory Crystal (with companion)

### Continue/Complete
- **Continue**: Quest has next phase → return to Engage
- **Complete**: Quest reaches natural conclusion → Celebration/Integration → New needs may emerge
- **Pause**: Citizen steps away → Quest remains in world state → Can return later
- **Transform**: Quest reveals deeper layer → Becomes different quest type

---

## Quest Rewards (Non-Traditional)

### No XP, Gold, Loot, Gear, Power

### Instead:

**Relationship Deepening**
- Companion understanding layer progression
- Citizen friendship/mentorship development
- Community trust building

**Memory Crystals**
- Created during significant moments
- Shared with companions/citizens
- Archived in Great Archive

**Harmony Index Contribution**
- Personal map updates
- Community tapestry threads
- Civilizational map blooms

**Festival Recognition**
- Acknowledgment during festival ceremonies
- Cosmetic tokens (earned, not purchased)
- Community role recognition

**Skill Development**
- Actual skill improvement (facilitation, cultivation, navigation, documentation)
- Recognized by mentors/community
- Path progression markers

**Restoration Impact**
- Visible environmental/community improvement
- Companion acknowledgment
- Civilizational momentum

**Archive Enrichment**
- New entries, connections, perspectives
- Question tending contributions
- Legacy building

---

## Technical Implementation

### Quest State System (World-Based, Not Player-Based)

```json
{
  "questId": "ember-depths-cooling-restoration-district-7",
  "type": "restoration",
  "source": "harmony-circle-assessment",
  "realm": "ember-depths",
  "location": "district-7",
  "state": "assessment|planning|action|tending|celebration|complete|paused",
  "initiators": ["citizenId", "companionName"],
  "participants": ["citizenIds", "companionNames"],
  "relatedPuzzles": ["REV-003", "REV-010"],
  "relatedFestival": "resilience-festival",
  "harmonyIndexImpact": {
    "personal": ["citizenId:growth"],
    "community": "district-7:improved",
    "civilizational": "ember-depths:stabilized"
  },
  "memoryCrystalsCreated": ["crystalIds"],
  "archiveEntries": ["entryIds"],
  "seasonalWindow": "deep-winter",
  "naturalConclusion": "system-stable-community-celebrating",
  "transformedInto": "questId|null"
}
```

### No Player Quest Log
- Quest state lives in **world**, not player data
- Player data only tracks **participation history** and **personal reflections**
- Multiple citizens can participate in same quest independently
- Quest progresses based on **world state changes**, not player objective completion

### Event Sheets (Construct 3)
- `Quest_WorldState.es` — Quest spawning, state transitions, world integration
- `Quest_Discovery.es` — Notice board, companion invitations, environmental cues
- `Quest_Engagement.es` — Participation flow, puzzle integration, companion collaboration
- `Quest_Reflection.es` — Reflection prompts, journal integration, memory crystal creation
- `Quest_Restoration.es` — Restoration impact calculation, harmony index updates
- `Quest_Festival.es` — Festival quest cycles, seasonal windows, celebration integration
- `Quest_Companion.es` — Companion quest triggers, relationship gating, mutual growth
- `Quest_Citizen.es` — Citizen quest triggers, path progression, skill recognition
- `Quest_Rhythm.es` — Daily rhythm invitations, lightweight engagement
- `Quest_Accessibility.es` — All accessibility features

---

## Accessibility Features

### Discovery Accessibility
- **Multiple Channels**: Every quest discoverable through ≥3 channels
- **Companion Guidance**: Companions can highlight relevant quests
- **Community Support**: Citizens can invite others to join
- **Archive Accessibility**: Questions filterable by type, realm, companion

### Engagement Accessibility
- **Pacing Control**: No time limits, no phase deadlines
- **Assist Modes**: All puzzle assist modes available in quest contexts
- **Collaboration Options**: Solo, companion, citizen, community — all valid
- **Alternative Contributions**: Non-mechanical participation always valued

### Reflection Accessibility
- **Multiple Formats**: Text, audio, visual, haptic, companion-shared
- **No Required Reflection**: Optional, not gated
- **Companion Co-Reflection**: Companions can help structure reflection

### Cognitive Accessibility
- **Clear Purpose**: Every quest's "why" is communicated
- **Manageable Scope**: Phases are naturally bounded
- **Progress Visibility**: World state shows restoration progress
- **No Hidden Mechanics**: Transparent systems

---

## Monetization Boundary (Explicit)

**The Quest System is entirely outside monetization.**
- No quest unlocks for purchase
- No quest acceleration
- No "premium" quest lines
- No reward purchases (all earned through participation)
- No daily quest skips
- No data analytics on quest engagement patterns

---

## Festival Integration Deepening

Each festival **generates** and **concludes** quest cycles:

| Festival | Quest Generation | Quest Conclusion |
|----------|-----------------|------------------|
| Festival of Beginnings | New citizen orientation, community mapping | Welcoming complete, vows integrated |
| Lantern Gathering | Lantern maintenance routes, connection mapping | Network synchronization celebrated |
| Harmony Week | Harmony Circle facilitation, collaboration planning | Tapestries complete, Convergence reps chosen |
| Mentor Celebration | Mentorship pairing, skill-sharing circles | Mentorships active, wisdom recorded |
| Growth Festival | Garden projects, environmental assessments | Plantings established, health improved |
| Discovery Festival | Exploration planning, mystery tending | Discoveries shared, Archive enriched |
| Memory Festival | Legacy projects, story preservation | Memories archived, continuity planned |
| Resilience Festival | Adaptation workshops, support networks | Systems stabilized, hope cultivated |
| Imagination Festival | Vision sharing, collaborative creation | Visions archived, possibilities mapped |
| Wonder Festival | Perspective gathering, aspiration renewal | Aspirations anchored, gratitude expressed |

---

## Long-Term Quest Content Strategy

### Seasonal Quest Cycles
- Each season brings new restoration needs, companion focuses, community projects
- Tied to festivals, environmental cycles, civilizational rhythms
- 20-40 active quests per realm at any time (most lightweight)

### Companion-Driven Quest Evolution
- As companion relationships deepen, quest invitations become more personal
- Kindred-layer companions co-design quests with citizen
- Companion-companion dynamics create multi-companion quests

### Community-Driven Quest Emergence
- Harmony Circles directly generate quests from identified needs
- Citizens can post needs on community boards
- Cross-realm requests via Lantern Network

### Mystery-Driven Quest Generation
- Unanswered Questions in Archive generate "tending" quests
- Deep Memory Communion creates unique exploration quests
- Mystery Ocean engagement produces unprecedented quest types

### Civilizational Quest Arcs
- Harmony Convergence identifies civilization-scale quests
- Multi-realm, multi-year restoration projects
- Aspirational anchoring at Threshold of Tomorrow

---

## Implementation Priority

### Phase 1 (MVP)
- All 6 quest types functional
- Discovery through companions, notice boards, Archive, environment
- Engagement flow (Notice → Choose → Engage → Reflect)
- Basic world-state quest tracking
- Festival integration for 4 launch festivals
- Companion quests for Spark, Echo, Verdant, Nimbus, Rowan
- Full accessibility suite

### Phase 2 (Post-Launch)
- All 8 companions with full quest lines
- All 6 citizens with full quest lines
- All 10 festivals with full quest cycles
- Cross-realm quest coordination (Lantern Network)
- Community board system (citizen-posted quests)
- Advanced reflection tools (Memory Crystal co-creation)

### Phase 3 (Long-term)
- Civilizational quest arcs (Harmony Convergence outcomes)
- Mystery-driven procedural quest generation
- Inter-generational quest continuity (citizens passing work to others)
- Quest practice as cultural export (framework for other civilizations)
- Living world where quests emerge from simulation, not design