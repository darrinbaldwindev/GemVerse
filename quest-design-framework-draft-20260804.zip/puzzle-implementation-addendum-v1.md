# GemVerse Puzzle Implementation Addendum v1

**Status:** Draft proposal  
**Scope:** Implementation guidance only; no new canon decisions  
**Related files:** `puzzle-catalog.md`, `guardian_role_bible_volume_1.md`, `imp-02-five-wounds-restoration-model.md`, `Arena_Realm_PRS_Context_v1.md`, `puzzle-arena-the-quiet-ledger-v1.md`, `canon-risk-report-20260601.md`[cite:20][cite:24][cite:13][cite:32][cite:26][cite:16]

This addendum consolidates puzzle-lane guidance into one implementation-facing document so designers, writers, and producers can apply GemVerse puzzle rules without searching across multiple files.[cite:20][cite:24][cite:32] It is a production support document, not a lore source and not a creator-decision file.[cite:20][cite:33]

## Purpose

GemVerse frames puzzles as remnants of civilization rather than abstract obstacles, and the Guardian Role Bible frames Guardians as contributors rather than saviors.[cite:20][cite:24] This addendum translates those principles into a compact set of implementation checks for puzzle specs, onboarding writing, UX copy, and review passes.[cite:20][cite:13][cite:32]

## Guardian and puzzle role

Guardians are contributors, learners, guests, builders, and restorers; they are not rulers, commanders, or heroes who save the world through force.[cite:24] Puzzles are civilizational structures, records, rituals, and systems that still matter in-world; if a puzzle can be removed without affecting worldbuilding, it fails the Puzzle Design Test.[cite:20]

Implementation filter:

- A puzzle is on-tone when the player experience is: “this mattered to someone, and restoring it teaches something.”[cite:20]
- A puzzle is off-tone when the player experience is: “this is a challenge to beat so the player can feel stronger.”[cite:20][cite:16]

## Extended stop rules

The existing Puzzle Catalog already forbids puzzles that resolve named open mysteries, reward power instead of understanding, frame Companions as tools, require payment or energy to attempt, or shame the player for incomplete attempts.[cite:20] This addendum extends those guardrails in response to risks recorded in the canon risk report.[cite:16]

### Stop Rule 6 — Power-fantasy mechanics

A puzzle fails canon if its core satisfaction loop depends on destruction, domination, or escalating power rather than restoration, recognition, or attunement.[cite:16][cite:20] This includes bomb/blast/lightning fantasies, numeric power multipliers framed as strength escalation, and Companion behaviors described as helping complete puzzles.[cite:16]

Use this review test for any proposed special mechanic:

- Can the mechanic answer the five Puzzle Design Test questions by itself?[cite:20]
- Does it leave the board or puzzle state more aligned, legible, connected, or healed rather than simply emptier?[cite:20][cite:13]
- Would the design still make sense as a civilizational remnant if the mechanic were removed?[cite:20]

If the answer to any of those questions is no, the mechanic should be redesigned or removed.[cite:20][cite:16]

### Stop Rule 7 — Monetization in restoration

No puzzle may require payment, energy, stamina, or spendable resource bars to attempt or complete.[cite:20][cite:16] Any visible resource system must be clearly non-gating and must not be framed as “spend to restore.”[cite:16]

## Special gems and combo posture

Transferred materials currently include power-up and special-gem language such as Harmony Blast, Star Blast, Colour Bomb, Moonlight Blast, Bomb Gem, Lightning Gem, Rainbow Gem, and a 2x–4x combo multiplier system, all of which are flagged as canon risks in their current framing.[cite:16] Until the creator decides whether these elements are retired or formally reframed, puzzle design should treat them as blocked for core implementation.[cite:16][cite:33]

Current safe posture:

- Do not require destructive board-clear fantasies in any puzzle spec.[cite:16]
- Do not write tutorial or reward copy that celebrates blasts, explosions, or power chains.[cite:16]
- Do not use Companions as puzzle-solving tools.[cite:16][cite:24][cite:20]
- Do not describe combo continuation as “more power”; if future discussion preserves some continuation reward, its emotional logic should be continuity or harmony flow, not dominance.[cite:16][cite:13]

## Special gem reframe sketchpad [PROPOSAL]

These are non-binding design thought experiments only and do not resolve any creator-only decision.[cite:16][cite:33] They exist to help teams think in restoration language rather than power language.[cite:20]

| Risky mechanic family | Unsafe framing | Safer thought direction [PROPOSAL] | Why it is safer |
|---|---|---|---|
| Bomb / blast clearers | Blow up part of the board for advantage.[cite:16] | Crystal Chorus Gem: realigns a mis-tuned cluster into a harmonious state.[cite:20] | Suggests calibration and repair rather than detonation.[cite:20] |
| Lightning / line clearers | Zap rows or columns to destroy them.[cite:16] | Trace Line Gem: sends a diagnostic signal along one pathway and stabilizes or reveals a pattern.[cite:20][cite:13] | Reads as infrastructure testing and restoration rather than attack.[cite:20] |
| Rainbow wildcard | Matches anything as pure power.[cite:16] | Harmony Keystone Gem: joins separated groups into a single balanced structure.[cite:20] | Aligns with Harmony and Belonging as connection, not supremacy.[cite:20][cite:13] |

No special-gem concept should be implemented without explicit creator sign-off on naming, behavior, and visual framing.[cite:16][cite:33]

## Wounds integration shorthand

IMP-02 explains how each Wound heals in practice and what types of puzzle interactions best support that healing.[cite:13] The following shorthand is for fast implementation tagging in puzzle specs.[cite:13][cite:20]

| Wound | Puzzle contribution shorthand | Typical puzzle families |
|---|---|---|
| Fragmentation / Knowledge | Restore pathways between knowledge that already exists but cannot currently circulate.[cite:13] | Crystal Resonance, Fragment Assembly, Archive-heavy reconstruction.[cite:20][cite:13] |
| Isolation / Discovery | Restore routes, waypoints, and return paths so discovery becomes social again.[cite:13] | Pathfinder’s Mark, route reconstruction, waypoint restoration.[cite:20][cite:13] |
| Decay / Growth | Restore conditions that let people, traditions, and communities flourish over time.[cite:13] | Verdance Cultivation, tradition puzzles, civic schedule/arrangement puzzles.[cite:20][cite:13] |
| Forgetting / Memory | Recover specific memories, records, testimonies, and missing context.[cite:13] | Echo Sequence, Memory Reconstruction, Companion testimony structures.[cite:20][cite:13] |
| Division / Belonging | Never directly solved by a puzzle; puzzles only create moments worth belonging to.[cite:13] | Community-adjacent effects across many puzzle types, never a direct “Belonging puzzle.”[cite:13][cite:20] |

Implementation note: do not write that a puzzle “heals Belonging directly.”[cite:13] Write that it contributes to conditions in which belonging becomes more possible or more felt.[cite:13]

## Arena Realm puzzle guidance

Arena Realm is the civic heart of GemVerse, its theme is Community, and it is the canonical first Realm a Guardian enters.[cite:32] Its framing must prioritize warmth, care, welcome, shared presence, and civic memory before scale, grandeur, or spectacle.[cite:32]

### Arena puzzle guardrail note

For any Arena puzzle:

- The Realm fantasy is gathering, memory, and shared life, not battle, tournament, or challenge-zone spectacle.[cite:32][cite:26]
- The Guardian role is helper, reader, and restorer, not champion, fighter, or savior.[cite:32][cite:24]
- Rewards are understanding, clarified records, restored routes, healthier civic patterns, and gentle world responses rather than power or advantage.[cite:20][cite:26]

### Arena writing tone

Arena puzzle writing should feel warm, observant, civic, restorative, and quietly hopeful.[cite:32][cite:26] Retry language should invite attention rather than punish mistakes, and success language should emphasize memory restored rather than player superiority.[cite:26][cite:20]

Recommended verbs:

- help
- notice
- restore
- remember
- re-thread
- listen
- put back in order[cite:26][cite:20]

Avoid verbs and phrases such as:

- beat
- conquer
- dominate
- clear the level
- save the Realm
- defeat the Arena Realm[cite:26][cite:16][cite:25]

### Arena one-page checklist

Use this checklist for any Arena puzzle spec, especially first-hour content.[cite:32][cite:26]

- [ ] Supports Arena as a civic heart / assembly realm, not battleground or spectacle.[cite:32]
- [ ] Presents the Guardian as helper / reader / restorer, not savior or fighter.[cite:32][cite:24]
- [ ] Answers the full Puzzle Design Test clearly.[cite:20]
- [ ] Feels welcoming, gentle, civic, and quietly meaningful.[cite:26]
- [ ] Uses noticing, matching, restoring, arranging, or re-threading as core verbs.[cite:26][cite:20]
- [ ] Rewards understanding and soft world response, not power, shortcuts, or stronger future play.[cite:20][cite:16]
- [ ] Avoids power-up, bomb, blast, lightning, and combo fantasies.[cite:16]
- [ ] Avoids Companion-as-tool framing.[cite:20][cite:24][cite:16]
- [ ] Avoids visual language of battle damage, gladiatorial staging, fortress geometry, or triumphal presentation.[cite:26][cite:32]

## Arena early puzzle arc shorthand [PROPOSAL]

Arena’s first-hour puzzle flow can already be described as a civic-memory arc without locking any creator-only details.[cite:32][cite:26] The Quiet Ledger establishes the question “What was here before?” and teaches the player that Arena was shaped by many forms of gathering and can be remembered through attention rather than force.[cite:26][cite:32] Follow-up Arena puzzle seeds should continue that pattern by restoring routes into shared spaces and arrangements that let daily life flourish together.[cite:20][cite:13][cite:32]

## Suggested use in review workflow

When a new puzzle idea appears, review it in this order:

1. Check Guardian role fit in `guardian_role_bible_volume_1.md`.[cite:24]
2. Check Puzzle Design Test and Stop Rules in `puzzle-catalog.md`.[cite:20]
3. Check Wound behavior and world response in `imp-02-five-wounds-restoration-model.md`.[cite:13]
4. If the puzzle is in Arena, check `Arena_Realm_PRS_Context_v1.md` and `puzzle-arena-the-quiet-ledger-v1.md` for tone, first-hour logic, and anti-combat framing.[cite:32][cite:26]
5. If the design touches power-ups, special gems, combos, resource bars, or Kael, stop and return it for creator review rather than resolving it in implementation.[cite:16][cite:25][cite:33]

## Closing note

This addendum exists to reduce drift, not to replace source documents.[cite:33][cite:20] The authoritative canon and PRS files remain the source of truth, and any creator-only issue stays open until explicitly approved by the creator.[cite:33][cite:25]
