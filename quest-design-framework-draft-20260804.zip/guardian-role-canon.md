# Guardian Role — Locked Canon
**Version:** 1.0
**Status:** APPROVED — Canon Locked
**Source:** Conflict 10 Resolution (2026-08-04)
**Authority:** Creator confirmation — Status Mode session

---

## Purpose
This document contains **only** the Guardian concepts that are locked as canon. All exploratory, proposed, or未定 elements have been moved to `guardian-role-proposals.md`.

---

## Locked Canon — Guardian Identity

### 1. Guardians Are Contributors, Not Heroes
- Guardians earn recognition through **civic contribution** — building, restoring, organizing, preserving
- No combat loops, no power escalation, no competition as core mechanic
- "Strength" refers to collective/community strength, not individual power
- **Source:** Core philosophy; Conflict 3 (Kael reframe)

### 2. "Arena Champion" = Civic Contribution Honorific
- The Arena is a civic crossroads — place of community gathering and achievement
- Kael's championship recognizes what he **built, restored, or organized** — not what he defeated
- Title is honorific, not martial
- **Source:** Conflict 3 resolution (Option A)

### 3. Guardians Work With Companions as Witnesses/Partners
- Companions are **presences, not mechanics** (Rules 4.1, 4.2)
- Guardians do not "use" Companions as tools
- Relationship is mutual witnessing, shared restoration, organic partnership
- **Source:** Companion canon; Puzzle Design Test (Stop Rule 3)

### 4. Guardians Restore Civilizational Systems
Primary restoration targets:
- **Crystal Network** — knowledge flow between Realms (Wound of Knowledge)
- **Lantern Network** — connection and guidance across thresholds (Wound of Discovery)
- **Great Archive** — memory preservation and truth-telling (Wound of Memory)
- **Festival Traditions** — civic belonging practices (Wound of Belonging)
- **Verdance Cultivation** — growth conditions for communities (Wound of Growth)
- **Source:** Tier 1 canon; Five Wounds; IMP-02

### 5. Great Archive Contains the Book of Guardians
- **Book of Guardians** (inside Great Archive, Arena Realm): written record of Guardian contributions — names, deeds, legacies
- A living chronicle maintained by Archive Chroniclers
- Records what Guardians restored, not what they conquered
- **Source:** Conflict 2 resolution

### 6. Legacy Realm Contains the Hall of Guardians
- **Hall of Guardians** (inside Legacy Realm): physical commemorative space — architecture, installations, tributes
- The embodied memory of extraordinary contributors
- The Archive records; the Legacy Realm honors
- **Source:** Conflict 2 resolution

---

## Canonical Boundaries — What Is NOT Defined Here

The following are **explicitly not canon** and reside in `guardian-role-proposals.md`:
- Guardian classes, specializations, or formal roles
- Guardian progression/recognition system (badges, ranks, titles beyond "Guardian")
- Guardian arrival / first contact experience
- Guardian tools / equipment (lantern, journal, resonance device, etc.)
- Guardian-Companion bonding mechanics
- Guardian cross-Realm authority / recognition
- Guardian Council or governance role
- Relationship to Harmony Council

---

## Practical Implications for Production

| Area | Canon Constraint |
|------|------------------|
| **Arena Onboarding** | Guardian arrives as contributor; no "chosen one" framing; first acts are civic/restorative |
| **Great Archive (Book of Guardians)** | Records contributions only; no combat records, no power metrics |
| **Hall of Guardians (Legacy Realm)** | Commemorates civic achievement; architecture reflects restoration, not victory |
| **Companion Interactions** | Partnership dialogue; no "equip/use" mechanics; Companions comment, witness, recall |
| **Puzzle Engagement** | Guardian restores; puzzles are civilizational remnants; tools are restorative aids |
| **Narrative Arcs** | Guardian legacy = what was restored; Aurora Arc follows contribution thread |

---

## Change Control
- **No additions to this document** without explicit Creator decision logged in `02-conflicts-log.md`
- Proposals for expansion → `guardian-role-proposals.md` with clear "PROPOSAL" labeling
- Any future canonization requires new Conflict entry and Creator confirmation

---

**Status: CANON LOCKED — Do not modify without Conflict Log entry and Creator approval**