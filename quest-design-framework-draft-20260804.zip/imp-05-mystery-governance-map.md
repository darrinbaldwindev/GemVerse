---
title: IMP #5 — Mystery Governance Map
tier: IMP
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: Canon Map, Book of Harmony (Tier 1), Lantern Network (Tier 1)
feeds-into: Tier 5 Narrative Bible, all future content writing, Tier 4 Harmony Index
note: This is a governance document. It does not develop the mysteries — it protects them.
---

# IMP #5 — Mystery Governance Map

## What This Document Is

GemVerse contains six named open mysteries. They are not plot holes. They are not content waiting to be developed. They are deliberate, protected spaces in the world — places where the canon says *we do not know* and means it.

A mystery loses its power in two ways: by being resolved, or by being so vague that it stops doing anything for the world. This document protects against both. It tells every writer, designer, and narrative lead:

- What is already established at the edges of each mystery (what you can safely reference)
- What is permanently off-limits without creator sign-off (what would close or damage it)
- How to write around a mystery without accidentally resolving it
- What each mystery is *for* — its narrative and emotional function in the world
- What warning signs should trigger a stop-and-flag

**Global stop rule:** No document, NPC line, Archive entry, puzzle, companion memory, or any piece of content may resolve, name the location of, explain the origin of, or establish the ultimate nature of any of these six mysteries without explicit creator sign-off. This rule has no exceptions.

---

## The Six Mysteries

---

### Mystery 1 — The Memory Ocean

#### 1. What Is Known (The Edges)

The following can be stated in-world without resolving this mystery:

- The Memory Ocean exists. Its existence is confirmed canon.
- It is connected to memory in some way — this connection is felt and referenced, not explained.
- It may be connected to what was lost during the Shattering — specifically to the category of loss that the Wound of Memory represents: the things so thoroughly gone that we no longer know what we lost.
- Its relationship to the Memory Pillar is acknowledged as unclear, even by those who study it. Scholars in the Archive can say this openly without embarrassment — the Archive of Unanswered Questions holds the question.
- Its relationship to the Crystal Network is also unresolved. Writers may reference this as an open scholarly question without resolving it.
- Characters who have heard of the Memory Ocean may speak of it with a particular quality of feeling — not quite fear, not quite longing. Something adjacent to both.

#### 2. What Must Never Be Established (The Protected Core)

- **Never establish the Memory Ocean's geographic location.** Not even a direction. Not "somewhere beyond the Frozen Expanse." Not "in a place no map has recorded." Any statement that positions it spatially begins closing the question.
- **Never establish what the Memory Ocean contains.** Not "the memories of those who died before the Shattering." Not "the lost volumes of the Book of Harmony." Not any enumerable or specific inventory of what is held there.
- **Never establish how to reach the Memory Ocean.** No routes, methods, conditions, ritual requirements, or companion knowledge that would function as a map or a key.
- **Never establish what the Memory Ocean *is* in metaphysical terms.** Is it a place? A phenomenon? A state of being? A remaining presence of something that existed before? These questions are open. No content may answer them.
- **Never establish the nature of its relationship to the Crystal Network.** This connection may be speculated about. It may not be confirmed or denied.

#### 3. How to Write Around It

Writers referencing the Memory Ocean should aim for the quality of something known-to-exist but beyond reach — like a word you know you once knew. Useful framings:

- An Archive entry that notes the Memory Ocean as a subject of inquiry, with no conclusions.
- An NPC scholar who has studied references to it and can recite what the records say without being able to offer interpretation.
- A Companion who becomes briefly quiet when the Memory Ocean is mentioned, then says something that is not an answer — *"Some things deserve to be approached slowly."*
- A Guardian discovery that turns up a fragment referencing the Memory Ocean without explaining it: *"The Ocean remembers what we could not carry."*
- **Phrase to use:** Reference it as a *subject of serious inquiry* rather than a *subject of known fact*. Scholars study it. Nobody has arrived.

**Example NPC line (safe):** *"The Archive holds eleven references to something called the Memory Ocean. They do not agree on what it is. That, to me, is more interesting than any theory I have heard."*

**Example NPC line (unsafe):** *"The Memory Ocean lies beyond the Frozen Expanse, where the memories of those lost in the Shattering are said to pool."* — This assigns location and contents. Flag and revise.

#### 4. Its Narrative Function

The Memory Ocean exists to hold the weight of what was truly, irretrievably lost. Not the records that can be recovered — those are the domain of the Wound of Memory and the Archive's restoration work. The Memory Ocean holds the question of whether there is *something beyond recovery* — a deeper loss than fragments, a loss that precedes the archive that would have preserved it.

For GemVerse's emotional register, this matters. A world that can ultimately recover everything becomes a puzzle box. A world that contains genuine, tender loss — loss so complete that even the record of it is gone — is a world with real weight. The Memory Ocean is where that weight lives. It makes the Restoration Era feel meaningful rather than merely mechanical. What Guardians are restoring is precious partly because something was lost that will not be restored. The Memory Ocean holds that truth without requiring it to be explained.

It also anchors the world's relationship to mystery itself: some things are known to be unknown, and that is not a failure of the civilization. It is a form of honesty.

#### 5. Red Flags

Stop and flag any content that:
- Places the Memory Ocean in a specific Realm or geographic context
- Has a character claim to have visited, approached, or found the Memory Ocean
- Suggests a method by which the Memory Ocean could be reached
- Explains what the Memory Ocean holds or what it is *made of*
- Establishes the Memory Ocean's relationship to the Crystal Network as confirmed rather than speculated
- Resolves the question of whether the Memory Ocean is "real" (physical) or metaphorical or spiritual

---

### Mystery 2 — The Missing Realm

#### 1. What Is Known (The Edges)

- Old records reference a Realm that appears to be missing from the world. This is confirmed — the references exist.
- The current confirmed Realm count is eight. The Missing Realm would make — or would have made — a ninth. [PROPOSAL: Writers may reference the current eight Realms as "the known eight" or "the eight that remain" without specifying a total, which preserves ambiguity about whether the count was ever nine or something else entirely.]
- Scholars who study old records have noticed the discrepancy. It is acknowledged as a genuine question within Archive scholarship, not a rumor.
- No one in the current era remembers the Missing Realm or can describe what it was.

#### 2. What Must Never Be Established (The Protected Core)

- **Never establish what the Missing Realm was.** Not its theme, its Pillar alignment, its culture, its name, or what kind of Realm it was (physical? metaphysical? something else?).
- **Never establish where the Missing Realm went.** Not destroyed, not hidden, not sleeping, not relocated. The question of what happened to it is fully open.
- **Never establish whether the Missing Realm can be found or restored.** This question must remain unanswered — no hint that it is findable, no hint that it is definitively gone forever. Either direction would close narrative possibility.
- **Never establish the Missing Realm's relationship to the Shattering.** Whether it disappeared before, during, or after — or whether it was somehow a cause of or response to the Shattering — is open.
- **Never name the Missing Realm.** No name, not even a fragmented or partial one, should appear in content without creator sign-off.

#### 3. How to Write Around It

- An Archive scholar referencing an unexplained discrepancy in the old records: *"There are passages that seem to refer to something beyond the eight. I cannot explain them, and I am not comfortable pretending I can."*
- A Companion with a very old memory who becomes uncertain when pressed: *"I remember — or I think I remember — that the world felt larger, once. But memory does strange things over time."*
- An old map with a gap, an annotation in a hand no one recognizes, a measurement that doesn't add up. These are safe references that suggest without explaining.
- Writers may use the phrase "the eight Realms" in most content. In content dealing specifically with historical records from the First Harmony era, writers may reference "the count that does not account for everything the old records mention" — but should not specify what the discrepancy implies.

**Example Archive entry (safe):** *"Query: On the question of Realm enumeration in pre-Shattering records. Status: Unresolved. The discrepancy has been noted by twelve scholars across three centuries. No consensus exists on its explanation. Archived for future inquiry."*

#### 4. Its Narrative Function

The Missing Realm serves GemVerse's deepest thematic purpose: the suggestion that the world was *more* than it is now, in ways that cannot fully be recovered. Most of the Restoration is about recovering what was damaged. The Missing Realm points at something different — something that may have been *removed* or *lost* in a way that precedes fragmentation. It gives the world a sense of profound, dignified incompleteness.

It also functions as an invitation. A world where the Realm count is settled and complete is a world where the map has edges. The Missing Realm keeps the map genuinely open — not in a cheap, unfinished way, but in the way that suggests civilization may be larger than what any single generation can see. For players who want to search, who want to look for things that other Guardians have missed — the Missing Realm is their horizon.

#### 5. Red Flags

Stop and flag any content that:
- Names, describes, or characterizes the Missing Realm in any specific way
- Suggests the Missing Realm was destroyed and is therefore unrecoverable
- Suggests the Missing Realm is hidden and therefore could be found with the right key or knowledge
- Places the Missing Realm in any temporal or causal relationship to the Shattering
- Has a character "remember" the Missing Realm in any specific detail

---

### Mystery 3 — The Lost Harmonists

#### 1. What Is Known (The Edges)

- The Lost Harmonists appear in Archive records as real figures — not myths, not symbols, not metaphors. They existed.
- They were working, in some capacity, to prevent or address the Shattering. This is confirmed.
- What happened to them is unknown. Whether they succeeded in any part of their work, whether they are gone, whether they left anything behind — all open.
- The existence of a group called "Harmonists" in the pre-Shattering era also appears in Proposal B of the Book of Harmony's authorship — an older generation of wandering philosophers who compiled observations about civilization. Whether the Lost Harmonists are related to, descended from, or the same tradition as those earlier Harmonists is unresolved. [PROPOSAL: This overlap may be intentional and generative — do not resolve it, but writers may allow characters to speculate.]
- The Path called "Harmonist" in the current era exists as a formal Path focused on Harmony. Whether this Path has any connection to the Lost Harmonists is open.

#### 2. What Must Never Be Established (The Protected Core)

- **Never establish what happened to the Lost Harmonists.** Not that they died, not that they succeeded and then disappeared, not that they became something else, not that they are waiting somewhere. The question is open.
- **Never establish whether their work had any effect.** Whether they failed, partially succeeded, or achieved something that was later lost — all open.
- **Never establish how many they were, who specifically they were, or what methods they used.** General references are safe; specific attribution is not.
- **Never establish any object, location, or institution as definitively created by or belonging to the Lost Harmonists.** Writers may write *"some scholars believe this was theirs"* — not *"this was theirs."*
- **Never establish whether any current character or institution is descended from or connected to the Lost Harmonists.** This includes the Harmonist Path, the Harmony Council, the Archive, or any companion.

#### 3. How to Write Around It

- Archive entries that reference the Harmonists by name, note their recorded purpose, and end with the honest acknowledgment that what happened to them is unknown: *"Their records end. Where they went, and why, the Archive cannot say."*
- NPCs who feel the emotional weight of this mystery without resolving it: *"They tried. That we know. Everything else is questions."*
- Companions who may have encountered the Harmonists and carry something unexplained — not a memory of what they found, but a feeling of what they were near. Companions may register this as a weight rather than a recollection.
- A Guardian who finds a record attributed to the Harmonists — something that is moving and specific enough to feel real, but which does not explain what they were or what happened to them.

**Example (safe):** *"The Archive holds fourteen references to the Harmonists — scholars, some say, or wanderers, or something harder to name. All fourteen describe people at work. None describe people who finished."*

#### 4. Its Narrative Function

The Lost Harmonists hold the emotional space of *the ones who tried before us*. GemVerse is a world of restoration, and restoration is not the same as being the first. It is essential that the world contain evidence that others came before Guardians — people who understood the danger, who had the right instincts, who tried. What happened to them is less important than the fact that they tried and something interrupted them. That weight should be present in the world as a form of humility, not despair: Guardians are not the first people to care. They are the next people to try.

This mystery also creates a quietly important question for any Guardian who thinks deeply about the world: *Why were the Harmonists not enough?* The answer — if there is one — is not for any writer to supply. It belongs to the creator alone.

#### 5. Red Flags

Stop and flag any content that:
- States or strongly implies what happened to the Lost Harmonists
- Has a character claim direct descent from or connection to the Harmonists
- Establishes any specific object, location, or text as the Harmonists' work definitively
- Resolves whether their work had an effect on the Shattering
- Implies that finding them, or their legacy, is a solvable quest

---

### Mystery 4 — The Seventh Lantern

#### 1. What Is Known (The Edges)

- The Seventh Lantern is referenced in seven ancient records held by the Archive. This count is confirmed.
- Four things the references suggest without establishing (these may be written around):
  - That the Seventh Lantern was considered distinct from the other lanterns — not merely the seventh in a numbered series but something of a different category
  - That knowledge of it was treated as obvious — the references mention it in passing, not in explanation, as if the readers of those records would simply know what it meant
  - That it had a relationship to something that the Lantern Network as a whole pointed toward, rather than merely a physical site it occupied
  - That it may have mattered in a way that was understood before the Shattering and became harder to understand after it
- The Archive's Archive of Unanswered Questions holds this as an active inquiry.
- The Lantern Tower in the Arena Realm exists as a known, confirmed structure. Whether it has any relationship to the Seventh Lantern is open.

#### 2. What Must Never Be Established (The Protected Core)

- **Never establish the Seventh Lantern's location.** Not even a class of location (it is not in any specific Realm, it is not in the Arena Realm, it is not destroyed, it is not hidden). All spatial questions are open.
- **Never establish what the Seventh Lantern is.** Not a physical object, not a metaphorical concept, not a person, not a network node — the nature of the thing is open.
- **Never establish why it was called the Seventh.** Whether there was a sequence, a significance to the number, or something else entirely — open.
- **Never resolve what the ancient references were referring to** by explaining the pre-Shattering context that made the references obvious to their original readers.
- **Never establish a connection between the Seventh Lantern and any known character, companion, or institution.** Including the Lantern Tower.

#### 3. How to Write Around It

The particular quality of this mystery is the self-evidence problem: the references treat the Seventh Lantern as something anyone would understand, which means referencing it in-world requires preserving that quality — the sense that it was once known and is now lost rather than that it was always obscure.

- A scholar reading the ancient records and finding themselves frustrated not by the obscurity of the references but by their familiarity: *"They write as if every reader would know exactly what this meant. Not one of them thought to explain it. And now none of us do."*
- An old Lantern Keeper tradition that seems to gesture toward something without naming it — a ritual that feels like it was designed to point at something specific, and now points at nothing, because the thing it pointed at is no longer there to find.
- A Companion who carries some feeling about it — not a memory, not an explanation, but the texture of something that mattered: *"Seven is not just a number in the old records. I don't know what else it is. I'm not sure anyone does anymore."*

**Example Archive entry (safe):** *"The Seventh Lantern — referenced in seven documents, pre-Shattering. All seven references treat the subject as self-evident. None provides description, location, or explanation. The Archive has attempted reconstruction for three generations. Status: Unresolved."*

#### 4. Its Narrative Function

The Seventh Lantern serves a specific and precise function: it is the proof that the Shattering cost understanding, not just records. Most of what the Shattering damaged can be named. This mystery belongs to the category of losses that cannot be named because the knowledge required to name them is itself gone. The references exist. The knowledge that would make the references legible does not.

This creates a different emotional quality than other mysteries. It is not *we don't know if it exists.* It is *we know it existed, and we have completely lost the context that made it meaningful.* That is a particular and devastating kind of loss — the loss of what you would need to know in order to know what you lost. For a world concerned with memory, this mystery is the purest expression of the Wound of Memory.

#### 5. Red Flags

Stop and flag any content that:
- Gives the Seventh Lantern a location or physical description
- Explains what the number seven signified in this context
- Has a character demonstrate knowledge of what the Seventh Lantern was or is
- Connects the Seventh Lantern to any specific known institution, character, or object
- Implies that the Seventh Lantern is findable or resolvable through Guardian action

---

### Mystery 5 — The Sleeping Gate

#### 1. What Is Known (The Edges)

- The Sleeping Gate is referenced in old records. Its existence in the records is confirmed.
- The name "Sleeping Gate" is what the records call it — or what the translation calls it. Whether the original designation meant exactly this is itself a scholarly question.
- Its destination is unknown.
- Whether it is a physical location or something else — an event, a threshold, a state, a person, a relationship between things — is unknown.
- The word "sleeping" in its name has been noted by scholars as suggesting something that could, in principle, wake. Whether this is meaningful interpretation or projection is an open scholarly question that writers may include.

#### 2. What Must Never Be Established (The Protected Core)

- **Never establish the Sleeping Gate's location.** Not a Realm, not a region, not a direction.
- **Never establish what the Sleeping Gate leads to or opens onto.** Its destination is the most protected element of this mystery.
- **Never establish whether the Sleeping Gate is physical or metaphysical.** Both possibilities must remain equally open.
- **Never establish what "sleeping" means in this context.** Whether it is dormant, inactive, waiting, sealed, or something without an equivalent concept in current vocabulary — open.
- **Never establish whether the Gate can be found, opened, or woken.** Its accessibility is open.

#### 3. How to Write Around It

The Sleeping Gate's mystery is fundamentally about destination: what it opens onto. Writers can engage with its existence and the scholarly interest around it without ever gesturing toward what lies beyond it.

- An Archive record that catalogs the reference without analysis: the record exists, the name appears, no further information is available.
- A scholar who is interested specifically in the question of *what kind of thing it is* — because the name "Gate" implies passage, and passage implies somewhere — and who has found no satisfying answers.
- A Companion who has heard the name and carries an unexplained feeling of stillness when it comes up — not recognition, exactly, but the absence of the anxiety one might expect. As if whatever the Sleeping Gate is, it is not a threat.
- A tradition in a community that doesn't know where it comes from: travelers who stop before departure and say something like *"May the Gates be kind,"* without anyone being able to explain why that particular phrasing.

**Example (safe):** *"In seventeen years of Archive scholarship, I have found three references to something called the Sleeping Gate. I know where the references are. I know what the words say. I do not know what I am reading about. That is not a comfortable position for a scholar."*

#### 4. Its Narrative Function

The Sleeping Gate holds the possibility of connection between what is and what is not yet fully understood. In a world where restoration is the primary mode — where everything is about recovering what existed, rebuilding what was broken, reconnecting what was severed — the Sleeping Gate represents something different: a *threshold* rather than a *ruin*. It suggests that the world contains passages as well as places. Something waits on the other side of something.

This is useful emotionally because it gives the world forward motion even outside of restoration. Not all of what GemVerse holds is *behind* the Guardians, in the past to be recovered. Some of it may be ahead — not in a power-escalation sense, but in the sense of genuine wonder about what has not yet been understood. The Sleeping Gate is one of the world's open doors. Its value is precisely that no one has opened it.

#### 5. Red Flags

Stop and flag any content that:
- Assigns a physical location or description to the Sleeping Gate
- Has any character approach, find, or attempt to open the Sleeping Gate
- Speculates on its destination in ways that narrow the possibilities
- Resolves whether it is physical or metaphysical
- Suggests the Gate is connected to any known location, such as the Arena Realm, any specific Realm, or the Missing Realm

---

### Mystery 6 — The Forgotten Door

#### 1. What Is Known (The Edges)

- The Forgotten Door is referenced in old records. The references are fragmentary enough that some scholars consider its existence uncertain — it may be a real referent, or it may be metaphorical language that was literalized in later interpretation.
- What it opens is unknown.
- Where it leads is unknown.
- What it remembers (the word "forgotten" is itself puzzling — a door that has forgotten something, or a door that is forgotten, or a door that opens onto forgetting) is unknown and the ambiguity is intentional.
- No physical location is implied by any reference. No character in the current era has encountered it.

#### 2. What Must Never Be Established (The Protected Core)

- **Never confirm or deny whether the Forgotten Door is a real, physical object.** This question is the first protected core of this mystery. Its ontological status is open.
- **Never establish what the Forgotten Door opens.** Not a place, not a state, not a relationship, not a category of memory or knowledge.
- **Never establish what it "remembers" or what it has "forgotten."** The grammar of the name is itself part of the mystery.
- **Never establish the Door's location,** including any claim that it has been lost, destroyed, or is currently inaccessible in any specifiable way.
- **Never establish a connection between the Forgotten Door and any other mystery,** including the Sleeping Gate, the Missing Realm, or the Memory Ocean — even as speculation in authoritative voices. [See Cross-Mystery Rules below.]

#### 3. How to Write Around It

The Forgotten Door's particular quality is its ambiguity about whether it is real. This makes it distinctly different from the other mysteries, which are confirmed to exist. The Forgotten Door is *possibly* real. Writers can inhabit that uncertainty without resolving it.

- A scholar who is genuinely unsure whether she is researching a thing or a figure of speech: *"The older records use the phrase. I cannot determine if they are describing something one could stand in front of, or something one could only feel."*
- A folk tradition that references a door without attaching any history to it — it has simply always been part of how people in one community talk about certain kinds of loss: *"Something went through the Forgotten Door"* meaning something is irretrievably gone. The phrase exists. Its origin does not.
- A Companion memory that is not a recollection of the Door but of what it felt like when something was near it — or near the idea of it. Companions can carry feeling without carrying fact.

**Example (safe):** *"Whether there is a door, or whether 'the Forgotten Door' is what certain scholars in the old records called the experience of losing something before you ever knew you had it — I genuinely cannot say. Both interpretations survive in the Archive. Neither has been dismissed."*

#### 4. Its Narrative Function

The Forgotten Door holds the mystery of loss that precedes awareness. The Memory Ocean holds what was lost in a form that still exists somewhere. The Forgotten Door holds the possibility of a category of loss that was never recorded, never witnessed, never understood as a loss at all — because the knowledge that something was there came after the thing itself was gone.

This functions as GemVerse's most intimate mystery. It is not about the civilization, exactly — it is about the individual experience of absence. It gives the world a quality of interiority: the sense that there are things people feel and cannot name, and that those unnamed feelings are not wrong or confused. The Forgotten Door is what those feelings reach toward.

In tone, it should feel less grand and more quiet than the other mysteries. Not the lost Realm, not the ancient figures — something smaller and somehow deeper. The kind of thing that a citizen, not a scholar, might suddenly think of, alone, for no clear reason.

#### 5. Red Flags

Stop and flag any content that:
- Resolves whether the Forgotten Door is real or metaphorical
- Gives the Door a location or physical description
- Has any character encounter or interact with the Forgotten Door
- Specifies what the Door opens, what it leads to, or what it has forgotten
- Connects the Forgotten Door explicitly to any other mystery

---

## Cross-Mystery Rules

### Which Mysteries May Be Potentially Related?

The six mysteries exist in a world where everything is connected — but that does not mean writers may establish connections between them. The following table documents what is known about potential relationships and what protection is in place.

| Pair | What Canon Acknowledges | What Must Never Be Established |
|---|---|---|
| Memory Ocean + Crystal Network | An open scholarly question exists about their relationship | Whether the relationship is confirmed, its nature, its direction |
| Memory Ocean + Missing Realm | Both relate to loss; nothing else is established | Any causal or structural link between them |
| Memory Ocean + Lost Harmonists | Nothing established | Any connection |
| Missing Realm + Sleeping Gate | Nothing established — do not imply the Gate leads to the Missing Realm | Any connection, especially destination-related |
| Seventh Lantern + Lantern Network | The Seventh Lantern appears in Lantern tradition records; its relationship to the Network is open | Whether it is the "origin" or "destination" or "heart" of the Lantern Network |
| Lost Harmonists + any mystery | Scholars may speculate that the Harmonists knew about the mysteries; this cannot be confirmed | Whether the Harmonists were specifically connected to, caused, or were working to protect any mystery |
| Forgotten Door + any mystery | Nothing established | Any explicit connection to any other mystery |

### Rules About Cross-Mystery Interactions in Content

1. **NPC scholars may speculate that mysteries are related.** Speculation is allowed and realistic — scholars would naturally look for connections. What is not allowed is any content that *confirms* a connection, even by treating speculation as settled.

2. **No single document, puzzle, or narrative arc may resolve more than one mystery simultaneously.** If a piece of content appears to explain two mysteries at once, that is a strong signal that it is resolving one of them in the process of referencing the other.

3. **Companion memories may invoke more than one mystery in proximity** — a companion recalling a feeling in which multiple things felt present — but may not establish a causal or structural link between them.

4. **The Archive of Unanswered Questions may hold all six mysteries.** This is the appropriate institutional home for them. An Archive Scholar may reference all six in the same breath as a list of what the Archive holds without resolving any relationship between them.

5. **The most dangerous interaction:** Mystery + Mystery combinations that seem to explain each other. *"The Sleeping Gate opens onto the Missing Realm"* — this is the kind of sentence that sounds generative but actually resolves two mysteries simultaneously. Every cross-mystery sentence in content should be tested by asking: *does this sentence narrow what either mystery could be?* If yes, flag and revise.

---

## The Mystery Inventory

| Mystery | Existence Status | Protected Core | Last Reviewed |
|---|---|---|---|
| Memory Ocean | Confirmed — existence locked | Location, contents, nature, relationship to Crystal Network | 2026-06-01 |
| Missing Realm | Confirmed — references to discrepancy locked | Identity, fate, relationship to Shattering, recoverability | 2026-06-01 |
| Lost Harmonists | Confirmed — existence in records locked | Fate, effectiveness, specific identity, institutional descendants | 2026-06-01 |
| Seventh Lantern | Confirmed — seven references locked; four suggestions locked | Location, nature, meaning of "seventh," pre-Shattering context | 2026-06-01 |
| Sleeping Gate | Confirmed — references exist | Location, destination, physical vs. metaphysical nature | 2026-06-01 |
| Forgotten Door | Uncertain — reference exists; reality status open | Physical reality, location, what it opens, what it remembers | 2026-06-01 |

**Also locked (additional mysteries not listed above):**
- Volume VII of the Book of Harmony ends mid-sentence. Whether this was intentional or a loss from the Shattering is unresolved. No content may answer this question without creator sign-off.
- The nature of the Memory Ocean's relationship to the Crystal Network is open. See Mystery 1 above.

---

## Writing the Unknown Well

### Mystery vs. Vagueness

Every writer joining GemVerse needs to understand a distinction that this project treats as non-negotiable:

**Mystery** is when something is known to be unknown. The world acknowledges the question. Characters can reach toward it. The Archive holds it. The question has a name, a history, an emotional charge. Something is definitively, intentionally there — and the specific nature of what is there is what is open.

**Vagueness** is when something is unknown because it was never developed. It has no edges. It cannot be reached toward because there is nothing specific to reach toward. Nothing is there yet. Vagueness is not the same as mystery, and in a world that takes its own lore seriously, vagueness reads as unfinished.

GemVerse's six named mysteries are mysteries, not vagueness. They have been given existence. They have been given names that carry emotional and thematic weight. They have been given functions — they do specific things for the world. What they have not been given is resolution. That is the careful distinction this document is designed to preserve.

When writing around a mystery, the goal is to make the mystery *feel more real, more present, more acknowledged* — while never making it feel closer to being answered. A mystery that is never referenced becomes vagueness by neglect. A mystery that is referenced carefully, held with respect, felt by characters who care about it — that is a living mystery. Living mysteries serve the world. Resolved mysteries leave holes.

### Practical Craft Notes

**Use institutional acknowledgment.** The Archive, the University of Harmony, the Harmonist Path — these institutions exist partly to hold the questions civilization cannot answer. When a mystery is named in the context of the Archive's Unanswered Questions, it is given gravity without being narrowed. Let the institutions do their work.

**Use witnesses, not knowers.** Characters who have encountered a reference to a mystery — a fragment, a record, a Companion's reaction — are witnesses. They can describe their experience of encountering the mystery without claiming to understand it. This is almost always the right approach.

**Use the texture of not-knowing.** The honest expression of a genuine scholar confronting a real mystery does not sound like summarizing known facts. It sounds like someone working, reaching, trying different framings, finding all of them inadequate. That texture is the mark of a living mystery rather than a placeholder.

**Use contrast.** The mysteries become more powerful when surrounded by things that are known. An Archive entry that catalogs many things, then arrives at the Seventh Lantern and simply says "Status: Unresolved" — that contrast does more work than three paragraphs of atmospheric description.

**Preserve the first person's wonder.** GemVerse's tone is hopeful, warm, curious, restorative. The mysteries participate in that tone. They should not feel like threats or dread — they should feel like the edge of the world where the map runs out and something beautiful might be waiting. A character who doesn't know the answer should sound curious, not afraid. The Archive holds questions with the same care it holds answers. That disposition is the model.

**The test for any mystery reference:** After a player reads this content, do they know more about what the mystery *is*? If yes, revise. Do they feel more that the mystery *exists*, matters, and is genuinely held by the world? If yes, you have done the work.

---

## Review Checklist

This checklist applies to any document, NPC dialogue, Archive entry, companion memory, or narrative content that references one or more of the six named mysteries.

**Existence checks:**
- [ ] Does the content reference a mystery as existing, without establishing its nature?
- [ ] Does the content avoid placing any mystery in a specific geographic location?
- [ ] Does the content avoid specifying what any mystery contains, leads to, or remembers?

**Resolution checks:**
- [ ] Does the content leave the mystery *more open* or *less open* than before?
- [ ] Is any character described as knowing something specific about a mystery that is listed in the Protected Core?
- [ ] Does the content accidentally close a mystery by proposing a category of answer (e.g., "it must be in the past" or "it must be somewhere beyond")?

**Cross-mystery checks:**
- [ ] Does the content connect two mysteries in a way that narrows either one?
- [ ] Is any connection between mysteries presented as settled rather than speculated?
- [ ] Does resolving the apparent connection between two mysteries actually resolve one of them?

**Tone checks:**
- [ ] Does the mystery feel like mystery (known to be unknown) rather than vagueness (simply undeveloped)?
- [ ] Is the emotional quality of the reference appropriate — curious and warm, not anxious or dark?
- [ ] Would a writer joining the project for the first time, reading this content, know where the edges of this mystery are?

**Creator sign-off triggers:**
- [ ] Does any content establish new facts about the Protected Core of any mystery?
- [ ] Does any content resolve a mystery, even partially?
- [ ] Does any content establish a confirmed connection between two mysteries?
- [ ] Does any content provide a mechanism by which a mystery could be resolved through Guardian action?

**If any box in the final section is checked: stop, flag for creator review, and do not publish.**

---

*This document protects six open mysteries. It does not tell you what they are — it tells you how to ensure they remain worth discovering.*
