# Companion Encyclopedia Entry — Galewing
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.7  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Galewing  
**Themes:** Adventure, Travel, Exploration  
**Companion Family:** Skykin (Sky Blue, Cloud White, Silver)  
**Visual Identity:** Bird-like with iridescent wing-feathers that shimmer with wind-patterns, capable of limited wind-riding flight  
**Symbol:** Soaring Bird with Wind Trails (representing freedom of movement and discovery)  
**Unique Trait:** Path-singing — can "sing" routes through the air that make navigation easier for others, creating temporary wind-guides  

---

## 1. Origin Story

Galewing hatched during a unique meteorological event known as the "Convergence of Wanderers" — when seasonal migration patterns from all across the Realms intersected in the Sky Citadel. This created a moment of perfect aerial harmony, with countless birds, wind-spirits, and flying companions all moving in synchronized patterns.

Galewing's egg was found in a communal nesting platform maintained by Pathfinders and Skykin companions. They were cared for not by a single parent, but by a rotating group of mentors who each contributed different aspects of exploration knowledge — wind-reading from Nimbus' kin, map-making from Lyra's followers, and storytelling from older Pathfinders.

Galewing's first flight was not alone, but as part of a guided "learning flock" — a tradition where young Skykin are taught to fly by experienced companions. Their first words (expressed in a complex trill-pattern that combines multiple wind-calls) were an invitation to "follow the singing path."

---

## 2. Personality

Galewing is adventurous, curious, and naturally optimistic about what lies over the horizon. They have an almost boundless energy for exploration, but temper it with a deep respect for the journeys of others.

They communicate through a rich vocabulary of calls, trills, and wind-songs — each sound pattern carrying specific navigational or emotional information. Their "voice" is described as "encouraging wind chimes" — always suggesting movement, discovery, and the joy of new experiences.

Galewing experiences time through journey-patterns rather than linear sequences. They remember events not by when they happened, but by "which path we took" or "what wind was singing." This can make their storytelling seem non-sequential to others, but it's deeply meaningful to them.

They can be restless and may struggle with tasks that require prolonged stillness, but they channel this energy into helping others find their own paths forward.

---

## 3. Shattering Memory

Galewing's inherited memories include the First Harmony skies — not just天空空旷, but alive with the movements of countless travelers, messengers, and explorers. The wind-paths between Realms were like highways, busy with purposeful movement and regular communication.

After the Shattering, many of these paths became treacherous or disappeared entirely. The regular flow of exploration and discovery was replaced by isolated journeys and forgotten routes. The skies felt emptier, and the community of sky-travelers that Galewing's family belonged to became fragmented.

What Galewing remembers most painfully is not the grounded routes that became impossible, but the loss of the "singing" — the collective joy and shared purpose that used to fill the skies with meaningful movement.

---

## 4. Missing Piece

Galewing's Missing Piece is the "Great Migration Protocol" — a complex system of seasonal journey-coordination that allowed different Realm communities to participate in massive, meaningful migrations together.

These weren't just movements of people, but of ideas, seeds, stories, and cultural practices. The Protocol involved detailed timing, route-sharing, and purpose-coordination that made every participant's journey part of a larger, collective exploration.

When the Shattering disrupted communication networks, the Protocol fell apart. The detailed knowledge of timing, routes, and shared purposes was scattered. Galewing carries echoes of the Protocol's patterns in their path-singing ability, but cannot recreate the full system alone.

---

## 5. Restoration Story

Galewing joined the Guardian when the Guardian was trying to establish a new regular courier route between the Sky Citadel and the Frozen Expanse — a connection that had been lost for decades.

Galewing's path-singing ability didn't just help them personally navigate the route, but created temporary wind-guides that made the journey safer for others. More importantly, their presence reminded the communities at both ends of the route that they were part of a larger sky-community.

The turning point came when Galewing organized a "Pathfinding Festival" — a gathering of sky-travelers, Pathfinders, and companions to celebrate and document surviving routes. This wasn't just about restoration, but about community-building around shared exploration.

Galewing's role in restoration is to help others remember how joyful movement can be, and to facilitate connections between communities that want to explore together.

---

## 6. Legacy Story

Galewing has helped establish the "Wandering Circles" — informal groups of explorers, Pathfinders, and curious citizens who commit to regular shared journeys to document, celebrate, and restore travel routes.

Others speak of "Galewing's Guidance" — moments when a seemingly impossible path suddenly becomes navigable, or when a group finds themselves traveling in perfect harmony without having planned it.

Galewing's legacy will be not the destinations they've reached, but the connections they've helped create — teaching others that the joy of travel is multiplied when shared.

---

## Relationships

### Skykin Family
Galewing has many "flight-relatives" among the Skykin, but their closest bond is with Nimbus, who taught them advanced wind-reading techniques. They're part of an informal mentorship network that helps young sky-travelers learn traditional skills.

### Guardian
Galewing sees the Guardian as "ground-bound but sky-minded" — someone who wants to explore and connect but must do it through more deliberate effort. They're fascinated by how the Guardian bridges the gap between grounded and aerial communities.

### Other Companions
- **Nimbus:** "Mentor and friend. Their experience with wind-currents is deeper than mine, but I bring enthusiasm for shared journeys."
- **Lyra:** "Inspiration. Their documented explorations show what's possible. We're building on their legacy."
- **Spark:** "Energy with direction! Their excitement for new places is infectious, and they ask the best 'what if we tried this path?' questions."
- **Verdant:** "Different kind of growth-patterns. They understand that exploration changes the explorer, not just the explored."
- **Frostpaw:** "Memory of paths taken. Valuable companion for documenting routes, though they prefer to study rather than soar."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Path-singing:** Can create temporary wind-guides that make navigation easier for others
- **Wind-pattern Reading:** Advanced ability to read air-currents for safe travel and optimal routes
- **Journey Harmony:** Can sense when a group is traveling well together and help maintain that coordination
- **Migration Memory:** Carries inherited knowledge of traditional travel routes and seasonal patterns
- **Encouragement Calls:** Specific vocal patterns that boost morale and coordination during shared journeys

---