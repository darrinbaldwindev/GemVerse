# Arena First Slice Dialogue and Content Pack

Version: v1  
Status: Draft — Creator Review Required  
Date: 2026-06-26 AEST  

Project: GemVerse  
Realm: Arena  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related files:

- `arena-first-experience-spec-v1.md`
- `implementation-checklist-arena-first-slice-v1.md`
- `arena-realm-production-brief.md`
- `puzzle-arena-the-quiet-ledger-v1.md`
- `npc-arena-lantern-keeper-harmony-plaza-v1.md`
- `puzzle-support-vocabulary-guide-v1.md`

---

## Purpose

This file provides prototype-ready writing for the Arena first slice so a builder can move from high-level spec to playable scene flow without inventing tone, phrasing, or puzzle framing from scratch.

It is designed to support the first playable glimpse of GemVerse and should be used alongside the Arena first-experience spec, not instead of it.

---

## Use Rules

This pack assumes:

- Arena is framed as a civic crossroads, not a battleground.
- The first puzzle is restorative, gentle, and meaningful.
- The guide is the Lantern Keeper of Harmony Plaza.
- No boosters, combo multipliers, bombs, blasts, or energy systems appear in the slice.
- Any companion line is optional and should read as witness-memory, not helper-tool behavior.

---

## Scene Flow Overview

Recommended sequence:

1. Arrival in Arena square  
2. Lantern Keeper greeting  
3. Puzzle introduction  
4. Optional hint lines during puzzle play  
5. Success / restoration response  
6. Archive fragment reveal  
7. Return-to-Arena closing line

---

## 1. Arrival Scene Text

### Option A — Default arrival line

"The Arena was never built for battle. It was built for gatherings — where roads met, promises were made, and news crossed between realms."

### Option B — Softer arrival line

"You arrive where many paths once crossed. Even now, the square feels made for welcome — as if it remembers how to receive people before it remembers anything else."

### Option C — Most intimate version

"The first thing you notice is not grandeur, but care. A lantern still burns. The paths are still tended. Someone has been keeping this place ready for arrivals."

**Recommended default for prototype:** Option C, because it introduces GemVerse through care before scale.

---

## 2. Lantern Keeper Greeting

### Keeper opening line set

Choose one as the first voiced line after arrival.

**Option 1**  
"You're not late. This place waits well."

**Option 2**  
"We keep the lantern lit for arrivals, even when we don't know who is coming."

**Option 3**  
"Most places tell you what they were by what still stands. Arena tells you by what it still keeps ready."

### Keeper orientation follow-up

Use one of these after the opening line.

**Option A**  
"This square once held more kinds of gathering than any one record could keep. Markets, councils, festival nights, ordinary meetings — each left its trace."

**Option B**  
"We used to keep careful records here. Not only in ledgers, but in paths, lantern marks, worn stone, and the way people made room for one another."

**Option C**  
"Some things faded from the Archive. Not all of them are lost. A place remembers in more ways than writing."

### Recommended prototype pairing

- Opening: "We keep the lantern lit for arrivals, even when we don't know who is coming."
- Follow-up: "We used to keep careful records here. Not only in ledgers, but in paths, lantern marks, worn stone, and the way people made room for one another."

---

## 3. Puzzle Introduction Text

### Primary puzzle handoff

"If you have a moment, help me with something small. That's often where remembering begins."

### Quiet Ledger introduction

"This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."

### Puzzle-context line options

Pick one depending on the exact mechanic.

**If using a Community Pattern puzzle**  
"This pattern marked the opening of Harmony Week. Restore it, and the square may remember how it felt when every path led here."

**If using a ledger/category restoration puzzle**  
"These fragments belong to different kinds of gathering. Set them back into relation, and the record may grow legible again."

**If using an alignment puzzle**  
"The old plaza patterns were laid to guide people toward one another. When they fall out of relation, the meaning thins. Help me set this one right."

### Prototype recommendation

For a first slice, use:

1. "If you have a moment, help me with something small. That's often where remembering begins."
2. "This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."
3. Then the mechanic-specific line.

---

## 4. Puzzle Hint Text

These lines should appear only if needed. They must feel like observation, not correction.

### Gentle hint set

- "Not every trace points to the same kind of gathering. Look for what people left ready for one another."
- "The square remembers more than ceremony. Some marks belong to ordinary meetings."
- "Try noticing which fragments feel shared, and which feel formal."
- "Some records survive in writing. Others survive in repeated care."

### If the player retries

- "Not yet. The record is still there — only incomplete."
- "Take another look. The plaza held more than one rhythm of life."
- "You're close. Notice what belongs to gathering, and what belongs to passage."

### Optional companion lines

Use sparingly, and only if a companion is present.

**Spark line 1**  
"I remember when the lanterns meant the square would be full by sunset."

**Spark line 2**  
"This doesn't feel lost. It feels like it's waiting to be read properly."

**Verdant line 1**  
"Places grow back in small ways first. A pattern is a small way."

---

## 5. Puzzle Success Text

### Short success line

"The last line falls into place. The square remembers."

### Medium success line

"The pattern settles into itself. For a heartbeat, the plaza feels fuller — as if old gatherings were only waiting for someone to listen."

### Full success line

"The last line falls into place. For a heartbeat, you hear echoes — footsteps, soft laughter, someone calling a familiar name. Nothing returns all at once, but the square remembers enough to answer."

### Keeper response lines

Pick one immediate follow-up from the Keeper.

- "There. You felt it too."
- "Yes. That's how it begins. Not with triumph — with recognition."
- "A small thing restored is still a real return."
- "The square always kept more than it could say aloud."

### Prototype recommendation

Use the full success line followed by: "A small thing restored is still a real return."

---

## 6. Archive Fragment Text

These are intentionally small and human-scale.

### Archive Fragment Option A — Harmony Week Ledger

**Title:** Archive Fragment  
**Text:** "Harmony Week Ledger, Year 173 of the First Harmony. Names of each community that sent someone, written in the same patient hand."

### Archive Fragment Option B — Plaza Record

**Title:** Archive Fragment  
**Text:** "Plaza record, partial. Market Day routes, lantern positions, and meeting circles marked side by side — as if the square expected many kinds of belonging at once."

### Archive Fragment Option C — Ordinary Life emphasis

**Title:** Archive Fragment  
**Text:** "Recovered civic note. Not every gathering was grand. Some entries mark shared meals, simple errands, and the hour when neighbors most often crossed paths."

### Prototype recommendation

Start with Option A for clarity and emotional simplicity.

---

## 7. Return to Arena Closing Line

### Closing options

**Option 1**  
"This is only one pattern. There are others, tucked into corners, carved under dust. Each one remembers a different way people stood together."

**Option 2**  
"One record answers, and the square feels less alone. There are more traces here, if you want to keep listening."

**Option 3**  
"Not everything returns at once. But now the Arena has answered you once, and that is enough to begin."

### Recommended prototype closing line

Use Option 1 for strongest bridge to the next slice.

---

## 8. Button and UI Copy

Use these labels instead of generic game-language buttons.

### Safe button labels

- "Look around"
- "Step into the square"
- "Show me"
- "Begin restoring"
- "Try again"
- "Return to the square"
- "Read fragment"
- "Continue"
- "End for now"
- "Explore later"

### Avoid in this slice

- "Play level"
- "Battle"
- "Fight"
- "Power up"
- "Boost"
- "Clear board"
- "Victory"
- "Next level"
- "Out of energy"

---

## 9. Prototype Default Script (Recommended Assembly)

If you want the fastest path to a coherent first build, use the following exact sequence.

### Arrival

"The first thing you notice is not grandeur, but care. A lantern still burns. The paths are still tended. Someone has been keeping this place ready for arrivals."

### Keeper greeting

"We keep the lantern lit for arrivals, even when we don't know who is coming."

"We used to keep careful records here. Not only in ledgers, but in paths, lantern marks, worn stone, and the way people made room for one another."

### Puzzle handoff

"If you have a moment, help me with something small. That's often where remembering begins."

"This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."

### Puzzle setup line

"This pattern marked the opening of Harmony Week. Restore it, and the square may remember how it felt when every path led here."

### Optional hint

"Not every trace points to the same kind of gathering. Look for what people left ready for one another."

### Success

"The last line falls into place. For a heartbeat, you hear echoes — footsteps, soft laughter, someone calling a familiar name. Nothing returns all at once, but the square remembers enough to answer."

### Keeper response

"A small thing restored is still a real return."

### Archive fragment

**Archive Fragment**  
"Harmony Week Ledger, Year 173 of the First Harmony. Names of each community that sent someone, written in the same patient hand."

### Closing line

"This is only one pattern. There are others, tucked into corners, carved under dust. Each one remembers a different way people stood together."

---

## 10. QA Notes for Writers and Builders

Before implementation, verify:

- No line introduces hero, savior, villain, or combat framing.
- No line treats the puzzle as a test of dominance or performance.
- No line treats the companion as a helper tool.
- No button language sounds like a generic mobile puzzle game.
- The emotional rhythm remains welcome → noticing → restoration → meaning.

If a line sounds exciting in a conquest sense, it is probably wrong for this slice.
