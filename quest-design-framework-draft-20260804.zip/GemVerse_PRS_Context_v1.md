# GemVerse PRS Context

Version: v1

Repository Type: Project Intelligence Repository

Repository Status: Active

Last Updated: 2026-06-03 AEST

---

# PURPOSE

This repository exists to preserve, organize, explain, transfer, and restore GemVerse project intelligence.

GemVerse project intelligence includes:

- Canon knowledge
- Design decisions
- Session history
- Assets
- Relationships between systems
- Project context
- Workflows
- Risks
- Open questions
- AI contributions

---

# OPERATING PRINCIPLES

1. Preserve history.
2. Record decisions.
3. Preserve assets.
4. Maintain continuity.
5. Support AI portability.
6. Preserve rationale.
7. Support recovery after context loss.
8. Never delete important information.
9. Prefer versioning over replacement.
10. Preserve project intelligence.
11. Treat Space files as live assistant-readable context.
12. Read scan and workflow files before making project-specific recommendations.

---

# REPOSITORY IDENTITY

Project Name: GemVerse
Project Owner: Darrin Baldwin
Repository Version: v1
Created Date: 2026-06-03 AEST

---

# MISSION

Preserve the evolving intelligence of GemVerse so any human or AI collaborator can understand the world, current priorities, major decisions, and next steps without losing continuity.

---

# VISION

What success looks like in:

- 6 months: Tier 1 canon foundations, supporting implementation packets, and core project rules are organized, recoverable, and easy for assistants to resume.
- 1 year: GemVerse has a durable project memory spanning canon, systems, assets, decisions, and workstreams, with low context loss across sessions and tools.
- 5 years: GemVerse remains portable across contributors, software, and AI platforms while retaining coherent project identity, history, and rationale.

---

# CURRENT STATE

GemVerse already has a live Space-based working environment with scan rules, workflow governance, session continuity logging, canon files, implementation packets, and asset tracking. The current assistant-readable source of truth is the active Space, with scan behavior anchored by `ScanMe.md` and the global workflow template.

---

# REPOSITORY METRICS

repository_metrics:

- age_days: 0
- sessions: active and ongoing
- decisions: multiple; some locked, some pending creator review
- assets: tracked in asset registry
- contributors: creator plus multiple AI assistants
- ai_systems: ChatGPT, Claude, Perplexity, Gemini, Grok
- repository_health: healthy but early-stage PRS setup
- continuity_score: high at Space level, improving at PRS level
- last_snapshot: 2026-06-03 AEST

---

# ACTIVE WORKSTREAMS

- Canon consolidation and authority mapping.
- Tier 1 readiness and foundational lore stabilization.
- Implementation packet expansion for puzzles, companions, worlds, and citizen life.
- Asset tracking, risk flagging, and creator-review gating.
- Assistant continuity and multi-session recovery workflow.

---

# OPEN DECISIONS

- Kael reframe final choice and any Arena Realm framing that risks combat or power-fantasy language.
- Power-ups, boosters, special gems, combo systems, and resource-bar framing: canon-safe puzzle tools vs retirement.
- Brand tagline variant status beyond the locked main tagline.
- Heart of the Core naming decision.
- Companion launch list status for Lumi, Ember, Frosty, and others.
- Forestkin vs Verdankin naming conflict.
- Guardian Role Bible Volume 1: what is canon versus proposal.

---

# OPEN QUESTIONS

- Which project or realm should receive the first fully populated PRS sub-repository?
- Which pending Tier 1 details should be locked next by creator review?
- How should PRS files map onto existing Space files without duplicating effort?
- What should be tracked in `PROJECT_STATE.md` versus the session log versus decision files?

---

# RISKS

- Important context may remain scattered across chat and files if PRS is not adopted consistently.
- Arena Realm and Kael-related material may drift into blocked combat/power framing if not tightly governed.
- Asset status confusion may grow if transferred, concept, pending, and approved states are not maintained carefully.
- Multiple assistants may diverge if they do not start with Space scan rules and current context files.

---

# KEY KNOWLEDGE

Critical GemVerse knowledge currently includes:

- Tone and franchise exclusions: no villain, no chosen one, no power fantasy, no grimdark.
- The Eight Pillars, the Five Wounds, and the Shattering as structural drift.
- Tier 1 concept foundations: Book of Harmony, First Harmony, Five Wounds, Crystal Network, Lantern Network, Restoration Era.
- Implementation scaffolds already exist for wound restoration, citizen life, companion relationships, mystery governance, and puzzle alignment.
- Space files currently function as the live assistant-readable source of truth.

---

# ASSET SUMMARY

Important tracked asset groups include:

- Brand assets and copy.
- Character and companion concept art.
- Realm and environment concept art.
- UI and UX mockups.
- Lore writing assets.
- Audio placeholders.
- Asset registry entries requiring creator review.

---

# DECISION SUMMARY

Current known decision status includes:

- Several core canon foundations are treated as locked or stable in current Space context.
- Multiple creator-only decisions remain open and should not be resolved by assistants without sign-off.
- Versioned Space files are currently the operational source of truth for active GemVerse work.

---

# SESSION SUMMARY

Recent sessions established the always-scan rule, confirmed workflow governance, added a continuity log, and continued organizing GemVerse canon and implementation context into durable Space files.

---

# AI COMPATIBILITY LAYER

ai_roles:

ChatGPT:
- strategy
- architecture
- implementation

Claude:
- deep review
- synthesis

Perplexity:
- research
- verification

Gemini:
- analysis
- validation

Grok:
- ideation
- challenge assumptions

---

# REPOSITORY STRUCTURE

GemVerse_PRS/

- GemVerse_PRS_Context_v1.md
- PROJECT_STATE.md
- DECISIONS/
- SESSIONS/
- ASSETS/
- HANDOFFS/
- SNAPSHOTS/
- EXPORTS/
- ARCHIVE/

---

# HISTORY PRESERVATION POLICY

- Never delete important history.
- Preserve decisions.
- Preserve sessions.
- Preserve assets.
- Preserve specifications.
- Use versioning instead of replacement whenever possible.
- Add rather than overwrite when preserving continuity matters.

---

# PROJECT ASSET PRESERVATION POLICY

Assets include:

- Documents
- Images
- Artwork
- PDFs
- Presentations
- Spreadsheets
- Audio
- Video
- Source code
- Data files
- AI-generated content
- User-uploaded content

All significant assets should be retained, tracked, and status-labeled where possible.

---

# RECOVERY INSTRUCTIONS

To resume the project:

1. Read `ScanMe.md`.
2. Read `Assistant Workflow Template Global with Versioning and Time.md`.
3. Read this file.
4. Read `PROJECT_STATE.md`.
5. Review `gemverse-session-continuity-log.md`.
6. Review recent decisions and asset registry.
7. Summarize understanding and continue work.

---

# HANDOFF INSTRUCTIONS

Generate:

- Current State
- Recent Decisions
- Open Decisions
- Active Tasks
- Risks
- Recent Assets
- Recommended Next Actions
- Files Read

---

# SESSION START PROTOCOL

1. Read `ScanMe.md`.
2. Read the global workflow template.
3. Read this file.
4. Read project state.
5. Review recent sessions.
6. Review recent decisions.
7. Summarize understanding.
8. Identify priorities.
9. Continue work.

---

# SESSION END PROTOCOL

Generate:

- Session Summary
- Decisions
- Tasks
- Risks
- Assets Created or Reviewed
- Recommended Next Actions
- File Updates

Append to repository.

---

# NEXT RECOMMENDED ACTIONS

- Upload this file to the Space so assistants can treat it as a project-specific shared context file.
- Create `PROJECT_STATE.md` as the short-form live status companion to this context file.
- Create first decision files for the currently blocked creator-only choices.
- Define whether GemVerse PRS is global for the whole franchise or the parent layer above realm-specific PRS subrepositories.

---

# CONTINUITY PROMISE

Any human or AI should be able to understand, continue, and evolve GemVerse regardless of elapsed time, participant changes, software changes, or AI platform changes.

This repository exists to preserve GemVerse project intelligence.
