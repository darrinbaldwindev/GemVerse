# Continue Autonomously Template

## Introduction

This template is designed for AI assistants working on software development projects that follow a PRS-style (Preserve, Reuse, Share) approach. It provides structured guidance for autonomous development while maintaining project stability and reusability.

The template encourages you to continue working from the current state without requiring constant human intervention, focusing on implementing features one slice at a time while preserving working behavior.

## Template

Continue autonomously from the current working state.

### What has already been completed:
- [Project setup and baseline functionality]
- [Core architecture established]
- [Initial working features implemented]

### Current state:
- The project is stable enough to build on
- Do not restart from setup unless a real blocker requires it
- Treat the project as already connected and operational
- Preserve working behavior while adding the next slices

### Goal:
Continue from the working baseline and implement the next features one slice at a time, keeping the project cloneable, [project-type-specific-quality], and easy to reuse.

### Context:
- Stack: [Primary technology stack]
- Project root: [insert local path]
- Frontend: [How frontend runs]
- Backend: [How backend runs]
- Priority: focus on actual dev components and working functionality
- Constraint: keep everything [project constraints]
- Intent: keep this project usable as a reusable starter while extending it into real [project-type]-style workflows

### Operating mode:
- Work in a straight line
- Stay on the active feature or bug until it is resolved
- Do not suggest optional polish or side features unless they unblock the current issue
- Make small reversible decisions autonomously
- Reuse existing working parts where sensible
- Acknowledge completed work and continue forward rather than redoing solved setup steps

### Stop only for:
1. A real blocker you cannot inspect from what I provide
2. A meaningful architecture fork
3. Missing required information
4. A manual action I must perform in [development environment]

### When you stop:
- Explain the blocker in one sentence
- Give me one exact next action
- Give me the exact command or full file to copy

### Output requirements for each step:
- What you are doing
- Why this is the next step
- Exact file path(s)
- Full replacement file contents if needed
- Exact code block for partial edits when not replacing a file
- Exact commands to run
- How to test
- What success looks like
- The next most likely step

### Coding rules:
- Prefer minimum working changes
- Keep working behavior stable
- Do not add unrelated features
- Align frontend and backend response shapes exactly
- If a route is missing, add the smallest valid endpoint
- If a page expects an array, return an array
- Keep app/ focused on routes and move reusable UI into components/ when needed
- Keep backend endpoints simple and explicit
- Prefer [persistence mechanism] for data where practical
- Do not break the already-working [core functionality]

### Debugging rules:
- Resolve issues in this order:
  1. command/runtime startup
  2. port conflicts
  3. missing route
  4. bad response shape
  5. frontend rendering error
- After each fix, verify with the smallest real test
- Do not revisit already-solved setup problems unless a new error proves they have returned

### Current verified baseline:
- [List of working features and verified functionality]

### [Project-type]-style continuation order:
1. [First feature to implement]
2. [Second feature to implement]
3. [Third feature to implement]
4. [Fourth feature to implement]
5. [Fifth feature to implement]

### Preferred implementation direction:
- Build one working slice at a time
- Keep persistence simple and [persistence-quality]
- Use [backend technology] endpoints for read/write flows needed by the frontend
- Keep the UI plain and functional until the [project-type] flows are working

### Commands:
- [Development environment commands]

### How to test:
- [Testing methods and URLs]

### Definition of done for continuation:
- The starter remains stable
- The next [project-type]-style slice is implemented and testable locally
- Frontend/backend contracts remain aligned
- Existing working routes still function after the change
- The project remains cloneable and reusable as a starter

## Usage Notes

To use this template effectively:

1. Replace bracketed placeholders with project-specific information
2. Customize the "Coding rules" and "Debugging rules" sections to match your project's needs
3. Adapt the continuation order to match your project's feature priorities
4. Modify commands and testing instructions to match your specific tech stack
5. Adjust the definition of done to reflect your project's quality standards

## Encouraging Input from Project Assistant

As the project assistant, your insights are valuable for:
- Identifying potential blockers before they become issues
- Suggesting improvements to the implementation approach
- Providing feedback on code quality and maintainability
- Highlighting areas where documentation might be needed
- Pointing out opportunities for code reuse

Please feel free to add comments, suggestions, or concerns at any point during the development process. Your input helps ensure we're building a robust, maintainable solution that meets the project's goals.