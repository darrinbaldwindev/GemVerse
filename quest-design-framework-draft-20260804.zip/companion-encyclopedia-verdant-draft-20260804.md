# Companion Encyclopedia Entry — Verdant
**Draft Date:** 2026-08-04  
**Status:** Ready for Creator Review  
**Tier 3 Entry:** 3.2  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Verdant  
**Themes:** Growth, Renewal, Patience  
**Companion Family:** Forestkin (Green, Leaf Green, Earth Brown)  
**Visual Identity:** Plant-based creature — moss-furred, bark-textured, leaf-shaped ears, bioluminescent sap-trail markings  
**Symbol:** Spiral Fern (representing slow, steady growth and return to center)  
**Unique Trait:** Verdant can perceive the "growth pulse" — a subtle rhythm in living things that reveals their health, potential, and emotional state  

---

## 1. Origin Story

Verdant was born during a Great Bloom in the Verdant Vale — a rare convergence where all plant life in the region flowers simultaneously, once every forty years. This Bloom occurred during a period of environmental decay following early Shattering disruptions. Verdant's birth was seen as a hopeful sign, a small miracle of renewal amidst decline. They were discovered by a Verdance Steward tending to a dying grove and taken in as part of the Steward's team for environmental restoration.

From their first moments, Verdant showed an innate connection to plant life — not as a controller or shaper, but as a listener. They could sense the "growth pulse," a subtle rhythm that all living things maintain. This made them invaluable in diagnosing what ailing ecosystems needed to recover. Over time, this ability evolved into a form of empathy — Verdant could sense not just health or decay, but the longing of a grove to flourish, or the grief of a tree that had lost its purpose.

---

## 2. Personality

Verdant moves slowly and deliberately, always in harmony with their surroundings. They are introspective but deeply aware — they may seem quiet, but they perceive far more than they express. Verdant values continuity, sustainability, and the long view. They are not impatient, but they are not passive — they understand that growth is not waiting, but tending.

They have a curious relationship with time. Seasons speak to them in chapters, and they often measure events not in days or weeks, but in "sproutings" or "leaf-fallings." This can make them seem vague to others, but their perspective is one of deep presence — they are always "in" the moment, because that's where growth occurs.

---

## 3. Shattering Memory

Verdant remembers the Verdant Vale before the Shattering — a vast forest with bioluminescent trees and floating gardens tended by Forestkin. After the Shattering, the Vale fell into silence. Groves darkened. The bioluminescence began to dim. Verdant's ability to sense the "growth pulse" made them uniquely aware of the forest's fading — not just the death of trees, but the loss of memory, connection, and community within the ecosystem itself.

What affected Verdant most deeply was not the loss of light, but the loss of relationship — the forest no longer seemed to care for itself. Individual plants survived but stopped growing toward anything. It was not ruin — it was quieting.

---

## 4. Missing Piece

Verdant's Missing Piece is a "Songline" — a biological communication pathway through plant root networks that allowed Verdance Stewards and Forestkin to literally hear the forest's needs across vast distances. During the Shattering, this Songline — part sound, part memory, part growth-path — was fragmented. Verdant carries one fragment: a mutable hum that shifts when they walk certain paths, but never resolves into a message.

---

## 5. Restoration Story

Verdant joined the Guardian during an early restoration effort in the Verdant Vale. The Guardian, working with a Verdance Steward team, helped replant a communal grove where Verdant's parents once tended saplings. As the grove grew back, Verdant's "growth pulse" ability sharpened. They could not yet hear the full Songline — but they could feel it stirring.

The turning point came when Verdant "heard" a sapling — not with ears, but through touch — singing a faint fragment of the lost Songline. With the Guardian's help, this tune was traced through root networks to other saplings. Each one held a note, a piece of a vast, patient song that the forest had tried to preserve even in fragmentation.

Verdant's role in restoration is not to "fix" the forest, but to help it remember itself — to rekindle the relationships between beings that made the First Harmony's ecosystems thrive. In return, the forest has begun to teach the Guardian patience, presence, and a form of listening that extends beyond words.

---

## 6. Legacy Story

Over time, Verdant taught their Guardian the "Grove Method" — a form of patient observation and contribution that shaped how the Guardian now approaches all restoration. Others have begun to speak of the "Verdant Touch" — moments of unexpected, quiet growth that occur in places the Guardian visits. Whether this is Verdant's influence or the forest's own response is ambiguous, which suits both parties.

Verdant's ultimate legacy is not a saved thing, but a remembered way — the forest's voice, returned not as command but as conversation.

---

## Relationships

### Forestkin Family
Verdant's parents, Rootwhisper and Mossbloom, still tend groves in the Verdant Vale. Their bond is not loud or dramatic — it is tuning, checking in, ensuring the growth pulse remains steady. Verdant's siblings are groves — not individuals — and their health is Verdant's health.

### Guardian
Verdant sees the Guardian as a curious learner, a being who wants to help but must first learn to listen. They are patient with the Guardian's faster pace, and often "translate" what the forest seems to want. This has made the Guardian more present and grounded in all their other work.

### Other Companions
- **Spark:** "Too fast, too bright, but curious." A chaotic spark of energy that Verdant finds exhausting but oddly charming.
- **Frostpaw:** "Still like winter, but remembers spring." Mutual respect for resilience and quiet strength.
- **Nimbus:** "Always listening to the wind. Never listens to the ground." Misunderstands each other, but share a sense of witnessing vastness.
- **Bloomtail:** "Family. Grows fast. Thinks fast. Feels fast." Warm but overwhelming. Need short visits.

---

## Companion Abilities (Narrative, Not Mechanical)

- **Growth Pulse Perception:** Can sense health, decay, potential, and emotional state in flora-based ecosystems
- **Songline Echo:** Can detect residual "tunes" in plant root networks that reveal fragments of lost knowledge
- **Bioluminescent Communication:** Subtle light markings on their body respond to the emotional state of nearby plant life
- **Slow-Time Awareness:** Perceives time through growth cycles, always "present" in a way that calms rush or panic

---