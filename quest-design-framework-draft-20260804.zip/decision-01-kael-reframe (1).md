---
title: Decision Brief #1 — Kael Reframe Proposal
tier: Block 3 Decisions
status: Draft — Awaiting Creator Decision
version: 1.0
date: 2026-06-01
stop-rule: Do not resolve, lock, or approve. Present options only.
---

# Decision Brief #1 — Kael Reframe Proposal

**GemVerse Block 3 Decision Support Document**
Prepared by Computer | 2026-06-01
Status: Draft — Awaiting Creator Decision

---

## Overview

This document compiles all known references to Kael across GemVerse canon sources, identifies the specific risks of the current Art Bible framing, proposes a full reframe of his identity in line with Conflict 3 Option A (now locked), and presents the creator with the specific decisions needed to lock Kael's final identity.

Computer does not resolve or approve anything in this document. The creator approves his final identity.

---

## Section 1 — All Kael References, Compiled

Every confirmed reference to Kael across known sources, flagged by canon status.

---

### Source: Canon Map (gemverse-docs/01-canon-map.md)

| Reference | Status |
|---|---|
| Name: Kael | **Locked Canon** |
| Visual identity: full body character art transferred | **Locked Canon** |
| Visual: young man, capable, determined expression, teal/green clothing | **Locked Canon** |
| Title: "Arena Champion" | **Locked Canon** (title locked; meaning under reframe) |
| Current framing "as Arena Champion" noted as conflicting | **Canon Risk** — Canon Map explicitly flags: "Combat framing conflicts with no-combat canon; needs reframing toward contribution" |
| Full backstory: Missing / TODO | **Unknown** — not written in ChatGPT or transfer volumes |
| Canon Map categorizes Kael under "Characters / Companions" section | **Locked Canon** |

---

### Source: Art Bible v1.0 (visual asset, transferred)

| Reference | Status |
|---|---|
| Title in Art Bible: "Arena Champion" | **Canon Risk** — title is locked as a name, but the martial/competitive meaning attached to it in the Art Bible is not |
| Description: "Brave, determined and adventurous, Kael helps you defeat the Arena Realm and is the strength of the group" | **Canon Risk** — flagged in task brief as combat framing and power-role framing. Do not treat as canon. |
| Personality traits listed: Brave, determined, adventurous | **Proposal** — traits themselves are good; they need civic recontextualization. Flagged here as proposal-status until creator confirms they carry forward. |
| Full body character art: teal/green clothing, young man, capable and determined expression | **Locked Canon** — visual is transferred and treated as the character's confirmed appearance |

---

### Source: Construct 3 Development Bible (transferred asset)

| Reference | Status |
|---|---|
| Kael listed as NPC that "grants bonus gems for certain puzzle types" | **Canon Risk** — flagged in task brief. This is the combat/power framing translated into mechanic form: Kael as a power boost, not a person. Directly conflicts with no-power-fantasy canon and the principle that Companions and NPCs are contributors, not tools or power-ups. Do not treat as canon. |

---

### Source: Conflict 3 Resolution (locked this session)

| Reference | Status |
|---|---|
| Resolution: Option A — Contribution Honor | **Locked Canon** |
| Arena = place of civic gathering, not combat | **Locked Canon** |
| "Arena Champion" = honorific for extraordinary civic contribution, NOT martial achievement | **Locked Canon** |
| This resolution does not reopen the title question — it reframes what the title means | **Locked Canon** |

---

### Source: Arena Realm Packet (drafted this session)

| Reference | Status |
|---|---|
| Arena Realm = Realm of civic gathering — neutral meeting ground where all Houses could speak | **Locked Canon** (Realm theme: Community) |
| Kael maintained or rebuilt the Great Gathering Hall during the worst period of post-Shattering isolation | **Proposal** — flagged in Arena Realm Packet as a proposal, not yet locked |
| Kael's presence gives the Arena Realm a human face | **Proposal** — framing direction proposed, not locked |

---

### Source: Tier 1 Readiness Report (gemverse-docs/03-tier1-readiness.md)

| Reference | Status |
|---|---|
| "What is Kael's reframed role?" listed as Priority 6 open question — blocks all character and Arena Realm narrative work | **Locked Canon** (the block itself is locked; the answer is not) |
| All Arena Realm narrative writing that involves Kael is blocked until Conflict 3 is resolved | **Locked Canon** (the block condition; now partially met by Conflict 3 Option A) |

---

### Source: Asset Registry (gemverse-docs/work-queue/asset-registry.md)

| Reference | Status |
|---|---|
| Kael character art: status "Transferred" | **Locked Canon** |
| Registry note: "Arena Champion framing pending reframe decision — Conflict 3" | **Canon Risk** (flagged, not resolved) |
| Registry note: "Creator to confirm reframe direction Option A or B before Kael art can be tagged correctly" | **Locked Canon** (process requirement; now partially met — Option A locked) |

---

### Source: Weekly Brief (2026-06-01)

| Reference | Status |
|---|---|
| "Kael — All character work and Arena Realm narrative work that involves Kael is blocked until Conflict 3 is resolved" | **Locked Canon** (block condition) |
| Conflict 3 listed as Priority 3 open question: "Kael reframe Option A contribution honor or Option B redemption arc?" | **Locked Canon** (the prioritization; Option A now locked) |

---

## Section 2 — The Problem Statement

The Art Bible description reads: *"Brave, determined and adventurous, Kael helps you defeat the Arena Realm and is the strength of the group."*

Every phrase in that sentence creates a specific risk for GemVerse's identity. None of them are individually catastrophic. Together, they pull Kael — and by association the entire Arena Realm — in a direction that is structurally incompatible with what GemVerse is.

**"Defeat the Arena Realm."** GemVerse is not about defeating anything. Realms are not enemies, obstacles, or levels to clear. They are communities in various states of restoration. Introducing defeat-language for the Arena Realm — the Community Realm, the civic heart of the world — is the single most direct contradiction of GemVerse's franchise identity. If the Arena Realm can be defeated, the implicit message is that civilization can be defeated. That is not the game.

**"Strength of the group."** GemVerse explicitly excludes power-role framing. The franchise's development rule is: *Wonder, Belonging, Community, Memory, Legacy* strengthens the project; *Power, Combat, Competition, Dominance* weakens it. A character who functions as the group's strength is a power asset, not a civic contributor. He becomes a stat, not a person. This framing also risks slipping into a savior narrative — the strong one who carries others — which is explicitly excluded from GemVerse's philosophy. Guardians are contributors, not heroes. That principle applies equally to NPCs.

**"Arena Champion" in a combat context.** The title itself is not the problem — the meaning being assigned to it is. If the Art Bible framing persists, "Arena Champion" will be read as a combat achievement by every writer, designer, and player who encounters it. That meaning compounds over time: dialogue will call back to it, art direction will reinforce it, and Kael's role in the civic fabric of the Arena Realm will be displaced by the assumption that he fights.

**What drifts if this is not corrected now.** The Arena Realm is the MVP Realm — the only Realm in scope for launch. Kael is the human face of that Realm. Every narrative beat set in the Arena Realm, every dialogue exchange, every puzzle and restoration event in the launch window flows through the tone and identity established by Kael's presence. If his framing remains combat-inflected, GemVerse's first, most-played, most-seen Realm will communicate: *this world has a champion, and strength is what earns recognition here.* That is not a world worth belonging to. That is a world with a hierarchy.

The reframe is not urgent because the Art Bible is wrong. The Art Bible is a transferred visual asset — it reflects an earlier phase of development before the franchise's civic identity was fully defined. The reframe is urgent because production writing, design specs, and player experience all depend on Kael being legible as a civic character before anything in the Arena Realm is built.

---

## Section 3 — The Reframe Proposal

*Everything in this section is flagged [PROPOSAL]. The creator approves Kael's final identity.*

---

### Revised Character Brief [PROPOSAL]

**Name:** Kael

**Title:** Arena Champion

**What the title commemorates [PROPOSAL]:** The title "Arena Champion" is an honorific awarded — or informally recognized — in the Arena Realm for extraordinary civic contribution during a period of acute need. It does not mark a victory over opponents. It marks a commitment to the gathering itself: to keeping the space open, the fires lit, and the doors of the Great Gathering Hall unlocked when isolation made it easier to close them. In the Restoration Era, the title carries a specific and well-known meaning in the Arena Realm: *the one who kept the table set when no one was sure anyone would come.*

**Personality [PROPOSAL — building from Art Bible traits, recontextualized]:**
- Brave: not in a martial sense — brave in the sense of showing up for something uncertain. Kael chose to maintain the Great Gathering Hall during the worst of the post-Shattering isolation, when it was unclear whether anyone would return. That required a specific kind of courage — civic courage, the courage of unreciprocated care.
- Determined: he is not easily discouraged by absence, silence, or failed gatherings. He sets chairs for people who haven't arrived yet. He restores records of assemblies no one remembers attending.
- Adventurous: he is curious about the people who come through the Hall — their stories, their Houses, their complaints. He seeks out voices that haven't been heard in the Gathering space. He finds the non-obvious people and brings them to the table.

**Role in canon terms [PROPOSAL]:** Kael is the Keeper of the Great Gathering Hall in the Arena Realm. He is not a Guardian and not a Companion — he is a citizen who has become, by sustained effort over years, the living institutional memory of civic assembly in that Realm. He remembers how the Hall was used during the First Harmony, or at least fragments of what he was told about it. He maintains those practices because he believes assembly is itself a form of restoration.

---

### Revised One-Line Description [PROPOSAL]

**To replace:** *"Brave, determined and adventurous, Kael helps you defeat the Arena Realm and is the strength of the group."*

**Proposed replacement:** *"Brave, determined and genuinely curious about people, Kael has kept the Great Gathering Hall open through the long silence — and he believes the next great assembly is closer than anyone thinks."*

---

### Possible Backstory Directions [PROPOSAL — creator selects one, or takes another direction]

**Option 1 — The Inheritor.** Kael inherited the Keeper role from a parent or mentor who tended the Hall before him. He didn't choose it initially — he was raised into it. But somewhere along the way, it became his own commitment, not an obligation. His bravery is the quiet bravery of someone who understood what they were carrying and chose to carry it anyway. His adventurousness shows in how he has expanded the role: where the previous Keeper maintained what existed, Kael has sought out new communities, new voices, new reasons to gather.

**Option 2 — The Returnee.** Kael left the Arena Realm during his youth — drawn away by wanderlust, by other communities, by the kind of restlessness that doesn't settle easily. He came back to find the Hall in disrepair, the records scattered, and the tradition of gathering nearly forgotten. He stayed, and has been rebuilding it ever since. His adventurousness is literal in his past; his determination is the adult response to what he found when he came home.

**Option 3 — The Witness.** Kael has no inherited connection to the Hall — he arrived as a stranger during a period of deep isolation, found the building open and empty, and started maintaining it because no one else was. He has no formal claim to the Keeper role. The community recognized him by usage rather than by appointment. His title is therefore doubly meaningful: he was not anointed, he was witnessed. This backstory gives him the most interesting tension — he holds something he was never officially given, and the question of legitimacy is one he sits with quietly.

---

## Section 4 — His Role in the Restoration

In civic, community, and contribution terms — not power terms — Kael does the following in the Restoration Era:

**He maintains the space.** The Great Gathering Hall requires upkeep: physical maintenance, record-keeping, the scheduling and hosting of assemblies. Kael does this work practically and without fanfare. He is not waiting for the world to be restored before he opens the doors. He opens the doors now, in the current state of fragmentation, and trusts that gathering is itself a form of healing.

**He holds the record of who has gathered.** In a world where Memory is wounded and records have been lost, Kael keeps accounts of who has come to the Hall, what was discussed, what was agreed, and what was left unresolved. He is not an archivist in the Archive's sense — he is a civic secretary of the Assembly. Those records exist nowhere else. They are, in their way, a form of the Lantern Network's belonging function: memory not just of knowledge, but of people in relationship with each other.

**He actively recruits the absent voices.** The Arena Realm's civic identity — as a neutral meeting ground where all Houses could speak — depends on *all* Houses actually being present. Kael's specific, practical contribution to restoration is seeking out the voices that have stopped showing up, understanding why, and making the Hall feel safe and worth returning to. This is not passive hospitality. It is active, determined, adventurous work.

**He models contribution without title.** Kael's honorific is informal, or historically awarded — either way, his ongoing work is not performed for recognition. He works because he believes assembly matters. This makes him an exemplar of GemVerse's core value: contribution that is not transactional, not hero-framed, not competitive. He is someone worth knowing because he has chosen a civic commitment that will outlast him.

**He connects Guardians to the Arena Realm's purpose.** For players arriving in the Arena Realm, Kael is the character who helps them understand what the Realm actually is — not a venue, not a challenge zone, but a living tradition of civic gathering that has survived because one person kept faith with it. He gives the Realm its human face.

---

## Section 5 — What Must Not Change

Regardless of which backstory direction the creator chooses, the following elements are identified as distinctive and worth preserving in any reframe:

**Brave, determined, adventurous.** These three traits from the Art Bible are good. They are worth keeping. The reframe does not remove them — it moves them out of combat context and into civic context. Bravery as civic courage. Determination as sustained care. Adventurousness as genuine curiosity about people. These are not weaker versions of the traits — they are more interesting versions.

**The teal/green visual identity.** His transferred character art is visually distinct and canon. Whatever narrative is built around him should feel consistent with a person who presents as capable, determined, and warm — not martial, not armored, not threatening.

**His specificity to the Arena Realm.** Kael is not a generic "good person." He is specifically the Keeper of the Great Gathering Hall, specifically in the Arena Realm, specifically during the Restoration Era. His distinctiveness comes from his particularity. Do not genericize him.

**His connection to the civic tradition of assembly.** The Arena Realm's identity as a neutral meeting ground where all Houses could speak is one of the most interesting civic ideas in GemVerse. Kael should be the living embodiment of that idea — not a symbol of it, but a practitioner of it. Someone who has made his life in service of it.

**His humanity.** He is not a mystic, not a sage, not a wise elder dispensing wisdom. He is someone doing a particular job that he believes in, and he has opinions, preferences, frustrations, and genuine delight in the people who show up. He should feel like someone worth spending time with — curious, warm, occasionally wry.

**His non-savior quality.** Kael does not save the Arena Realm. He tends it. That distinction is everything. He is not the one who fixes things — he is the one who makes sure the space for fixing things together remains available.

---

## Section 6 — Creator Decision Points

The following decisions are required to lock Kael's final identity. Each is presented as a question with options where applicable.

---

**Decision 1: Which backstory direction for Kael?**

- A. The Inheritor — raised into the Keeper role, chose it as his own
- B. The Returnee — left, came back, has been rebuilding since
- C. The Witness — arrived as a stranger, stayed, holds an informal title
- D. Creator's own direction — none of the above

*Impact:* Determines his origin narrative, emotional relationship to the Hall, and the texture of his dialogue in the Arena Realm.

---

**Decision 2: What does "Arena Champion" formally mean in the world?**

- A. An honorific awarded informally by community recognition — no ceremony, no institution
- B. A formal title that was historically awarded by the Harmony Council or a civic body, now carried by Kael as the most recent recipient
- C. A title Kael holds because of a specific, memorable act — the story of which is known in the Arena Realm but not yet written

*Impact:* Determines whether the title implies an institutional history, a folk tradition, or a specific dramatic event.

---

**Decision 3: Is "Keeper of the Great Gathering Hall" Kael's official role, or is it informal?**

- A. Official role — there is a formal Keeper tradition with responsibilities, records, and succession
- B. Informal — Kael does the work but holds no official appointment; the community recognizes him by practice, not by title
- C. Somewhere between — the role has ancient formal roots that are now partially lost; Kael practices what he can piece together

*Impact:* Shapes how Guardians interact with him and whether there is an institutional backstory to the Hall itself.

---

**Decision 4: What is Kael's relationship to the Houses?**

- A. He actively maintains the Hall as neutral ground and belongs to no House — his civic neutrality is his identity
- B. He is affiliated with House Hearthlight (Community Pillar) but maintains the Hall as neutral territory — the affiliation is known but does not bias the space
- C. His House affiliation is unknown or private — part of his civic commitment is that he never says

*Impact:* Affects his dialogue, his relationships with House-affiliated Guardians, and the political texture of the Arena Realm.

---

**Decision 5: What is Kael's emotional relationship to the long silence?**

The post-Shattering period during which Kael maintained the Hall with little to no response from the community — what does he carry from that?

- A. He is at peace with it — it made him who he is, and he doesn't speak of it as hardship
- B. It left a mark — he is resilient but has a quality of quiet grief that players eventually learn about
- C. He rarely speaks of it but responds to Guardians who ask with genuine reflection — this can go either direction depending on the creator's preference for his emotional register

*Impact:* Shapes the depth of his character and what kind of emotional truth Guardians can access when they spend time with him.

---

**Decision 6: Does Kael have a "missing piece"?**

GemVerse Companions have a "missing piece" as part of their canon structure. Kael is an NPC, not a Companion — but NPCs in the Arena Realm should have inner lives that feel fully inhabited.

- A. Yes — give Kael a missing piece: something he has not yet been able to restore, a question he cannot answer, an assembly he has been unable to convene
- B. No — his arc is already defined by what he does, not what he lacks; leave his inner life deliberately quieter
- C. Defer — this is a character depth question; address when writing the Arena Realm narrative in full

---

## Review Checklist

Before this document proceeds to any downstream use, confirm the following:

- [ ] Creator has reviewed all flagged [PROPOSAL] items and confirmed or revised each
- [ ] Creator has selected one backstory direction (Decision 1) or provided an alternative
- [ ] Creator has confirmed the formal meaning of "Arena Champion" (Decision 2)
- [ ] Creator has confirmed whether "Keeper" is official or informal (Decision 3)
- [ ] Creator has confirmed Kael's House affiliation status (Decision 4)
- [ ] Creator has confirmed Kael's emotional register re: the long silence (Decision 5)
- [ ] Creator has decided whether Kael has a missing piece (Decision 6)
- [ ] Revised one-line description has been confirmed or revised
- [ ] Asset Registry updated: Kael character art status to reflect Conflict 3 Option A locked, awaiting remaining identity decisions
- [ ] Canon Map updated: Kael entry to reflect reframe direction once decisions above are confirmed

---

*This document does not lock, resolve, or approve Kael's identity. It presents the current canon state, the problem clearly, and the options available. The creator approves his final identity.*

*Next action: Creator reviews Decision Points 1–6 and returns answers. Computer will then draft the finalized Kael character brief and update the Canon Map and Asset Registry accordingly.*
