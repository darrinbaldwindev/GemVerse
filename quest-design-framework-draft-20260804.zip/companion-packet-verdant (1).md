---
title: Companion Packet — Verdant
tier: Work Queue Task 7
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: IMP #4 Companion Relationship Web, Five Wounds (Tier 1)
feeds-into: Tier 3 Companion Encyclopedia — Verdant
note: Forestkin vs. Verdankin family name conflict flagged — Canon Map authority used (Forestkin).
---

---

## 1. Known Canon Summary

### Confirmed Visual Canon (Transferred — Art Bible Companion Collection Preview)

- **Name:** Verdant — confirmed locked
- **Companion Family:** Forestkin (Growth, Nature, Renewal) — see Naming Conflict note below
- **Visual identity:** Green plant creature, organic in form and quality. Growth-aligned in appearance — not decorative, not costumed with plant elements, but genuinely of the natural world, the way a living thing can be made of something that grows and responds and reaches toward light. First visual received this session; full pose and expression set pending.
- **House Alignment:** House Verdance (Growth, #2E8B57)
- **Pillar:** Growth

These visual elements are **visual canon as received**. Written content must remain consistent with the organic, growth-aligned quality of this design.

### Confirmed Written Canon (From IMP #4 Companion Relationship Web)

- Verdant's partner companion is **Bloomtail** — also Forestkin, also Growth-aligned.
- The Verdant/Bloomtail relationship texture is **"complicated warmth"** — not conflict, but depth, history, and perspective that doesn't always align.
- Verdant tends toward **patience with the long arc**: slow growth, waiting for the right conditions. Bloomtail tends toward immediate and practical care — what does this community need right now?
- These are not incompatible philosophies, but they have led to real differences in approach that are not fully resolved.

### Confirmed Written Canon (From Five Wounds — Tier 1)

- The **Wound of Growth — the Decay**: communities stopped nurturing the future. Mentorship weakened. Children were prepared for a narrower world. Growth disconnected from memory and from civilizational scale.
- House Verdance is aligned to the Wound of Growth.
- The Decay was quiet — "a generation raised in a narrowing world does not know it is narrow."

### Confirmed Written Canon (From Locked Companion Rules)

- Verdant is a **historical survivor** who lived through the First Harmony and the Shattering.
- Verdant carries memories of growth that the Archive does not contain — the felt texture of thriving communities.
- Verdant's perspective is uniquely Forestkin: organic, patient, long-cycle thinking — what grows slowly is what lasts.

### ⚠️ Naming Conflict — Flagged for Creator Resolution

**The task brief (IMP #4) uses "Verdankin" as the family name for Verdant and Bloomtail. The Canon Map (01-canon-map.md, ✅ Fully Locked) uses "Forestkin" for the Growth/Nature/Renewal companion family.**

This packet uses **Forestkin**, following the Canon Map as the higher-authority source. If "Verdankin" represents a distinct sub-family designation, a naming update, or a deliberate departure from the Canon Map taxonomy, this must be confirmed before the Tier 3 Encyclopedia entry is written. The two names carry different implications: Forestkin places Verdant within a broader family that includes all nature/growth companions; Verdankin would suggest a named distinction that does not currently appear in the Canon Map.

---

## 2. Verdant's Forestkin Nature

What does it mean to be Forestkin? Not as a power set. As a way of being in the world.

A forest does not rush. A forest does not optimize. A forest is a system — extraordinarily complex, extraordinarily patient — in which every part is in relationship with every other part, across timescales that individual creatures cannot fully perceive. A tree reaching its full height may require a century. The root network that allows it to do so may have taken longer. What looks, from outside, like stillness is, from inside, continuous work.

This is what it means for Verdant to be Forestkin. Verdant does not experience time the way citizens experience it — as a sequence of urgent moments. Verdant experiences time as a medium, the way soil is a medium: dense with history, capable of holding what is placed in it, slow to change but changed by everything. When Verdant looks at a community, they see not only what the community is now but the full arc of what it has been and what it might become — the conditions that shaped it, the decisions that bent its growth one way or another, the deep health or the subtle lack underneath the surface.

Forestkin companions carry their nature in their physical form. Verdant's organic quality — the green, the living-material presence — is not decorative. It is descriptive. Verdant *is* of the world that grows, in the same way that some creatures are of water or of fire. This means Verdant responds to conditions the way growing things respond: acutely sensitive to what is nourishing and what is depleting, patient under difficulty, slowly but genuinely changed by every season they pass through.

The First Harmony had a word for what Forestkin companions did that did not translate cleanly into post-Shattering language. It meant, roughly, *root-witness* — a being who witnessed not from distance but from within, the way a tree's roots are within the soil they read. Verdant's knowledge of a community is not analytical. It is embedded. Verdant knows what a community is in its deepest strata, not just its visible growth.

**[PROPOSAL — flag for creator confirmation]:** Forestkin companions may have a particular sensitivity to the health of communities over time that functions as something like felt knowledge — not a power, not a skill, but an orientation. Verdant would not need to study a community to sense where its growth has been stunted or where its roots are healthy. The same attentiveness that makes growing things reach toward light gives Verdant a direct felt response to whether the conditions around them are nourishing or depleting. This is worth establishing before the Tier 3 Encyclopedia entry, so the entry can speak to it with precision.

---

## 3. Personality in Canon Terms

Verdant's personality cannot be adequately described in single-word traits. What grows slowly develops complexity. What has lived through centuries develops layers. The personality that matters here is less a list of characteristics and more a way of engaging with the world — a stance, an orientation, a quality of attention.

### Patience Is Not Passivity

Verdant is patient in the way a deep-rooted thing is patient: not because they are indifferent to urgency but because they have learned, through centuries of witnessing, that urgency applied at the wrong moment can cause more damage than waiting. A seed forced does not thrive. A community pressured to grow faster than its conditions allow does not flourish — it stretches and weakens. Verdant has seen this. They have watched communities that were hurried toward growth they were not ready for, and they have watched what happened next.

This patience can be misread as detachment. It is not. Verdant cares deeply — about specific communities, about the particular people in them, about the long story of what growth in this world has been and could be again. The patience is in service of that care, not a retreat from it.

### Long-Cycle Wisdom

Verdant thinks in timescales that citizens cannot easily access. When a Guardian brings a question about a struggling community, Verdant's first instinct is not to identify what is wrong right now but to understand what conditions produced this moment — what was planted generations ago, what was allowed to grow unchecked, what was cut before it had finished becoming itself. The answer to most growth problems, from Verdant's perspective, is almost never the obvious one. The obvious one addresses the surface. Verdant is interested in the root.

This can create friction — not conflict, but productive difficulty — with beings who are oriented toward immediate care. Bloomtail, for instance. When Bloomtail asks *what does this community need right now*, Verdant's instinct is to ask *what has this community needed for the last three generations and not received*. Both questions matter. They do not always point toward the same action.

### Investedness as a Character Trait

Verdant is, by nature and by history, deeply invested. Not in outcomes in the abstract — in *these* specific communities, *this* specific process of growth, the particular texture of what thriving looks like in this Realm under these conditions. Ancient beings who have witnessed centuries often develop a certain detachment from the immediate; Verdant has developed the opposite. The more Verdant has witnessed, the more specifically they care about what happens next.

The Decay changed this. Watching growth narrow — watching communities that had once nurtured toward civilizational scale begin to prepare their young only for local contribution — was, for Verdant, the particular grief of watching something healthy become ill so slowly that no single day was obviously different from the last. Verdant carries that witnessing. It has made them more fiercely, specifically attentive to the conditions that allow genuine growth — not growth as performance, not growth as productivity, but growth as the sustained development of beings and communities toward their full potential.

---

## 4. First Harmony Memory

The Archive contains records of what the First Harmony accomplished. Verdant remembers what it felt like.

These are different things. The Archive records outcomes: discoveries made, routes established, communities recognized for contribution. What Verdant carries is the texture beneath the record — the quality of the daily conditions that made those outcomes possible. Not the harvest, but the soil. Not the tradition, but the living practice that the tradition was trying to preserve.

What categories of First Harmony experience does Verdant hold that no Archive record contains?

**The feeling of genuine mentorship.** During the First Harmony, growth was understood broadly — not as individual self-improvement but as the sustained development of communities and the conditions that allowed the next generation to flourish. Verdant remembers what genuine mentorship felt like from the inside: the specific quality of attention a mentor gave when they were truly invested, not performing investment. The care that was not about legacy or recognition but simply about the young person in front of them. This quality of care is not in any Archive record because it was never recorded — it was simply present, as common as light.

**The rhythm of communities that believed in their future.** There is a particular quality to a community that genuinely expects tomorrow to be worth contributing to. It shows in how people build — for permanence, with Archive alcoves embedded in the walls. It shows in how they teach — as though what is transmitted matters beyond the immediate relationship. It shows in how they rest — without the particular anxiety of communities that sense, without being able to articulate it, that something important is being lost. Verdant knows this rhythm from the inside. They know it because they have felt the absence of it, and the absence has a specific weight.

**The sound of cross-community growth.** During the First Harmony, young people traveled. They studied in other Realms. They returned changed — carrying different questions, broader contexts, new relationships with people whose experience differed from their own. Verdant remembers what this produced in the communities young people returned to: not disruption but depth. Verdant remembers the specific quality of growth that happens when someone who has been elsewhere brings that elsewhere home.

**The sense of growth as civilizational.** This is the memory Verdant finds hardest to describe to citizens of the Restoration Era, because the concept it names has no direct equivalent in post-Shattering experience. During the First Harmony, growth was not a private project. Personal development and community development and civilizational development were understood as parts of the same process — what a young person learned mattered not only to the young person and their community but to the whole civilization they were being prepared to contribute to. The growth of one person was, in some genuine sense, growth for everyone. Verdant holds the memory of what it was like to live inside that understanding, and the grief of watching it narrow.

---

## 5. Verdant and the Shattering

The Wound of Growth — the Decay — is the wound Verdant witnessed most directly. Not because Verdant was in the most affected community at the most critical moment. Because the Decay, unlike the other wounds, was invisible while it was happening.

Verdant noticed.

Not all at once. Forestkin perception is long-cycle, and what Verdant began to sense in the late First Harmony was not a crisis but a change in conditions — the way a tree senses a drought before any surface indicator appears. Something was less present. Some quality of the soil had changed. Growth was still happening — communities were still developing, young people were still learning, traditions were still being passed on. But something beneath the growth had shifted. The expectation that growth connected outward, that what a community produced was for something larger than itself, was becoming less ambient, less assumed. It was becoming, slowly, a position rather than a condition.

Verdant watched the transition that the Five Wounds document describes: children prepared for local contribution rather than civilizational contribution. Mentorship that narrowed to passing on what the local community knew, rather than expanding toward what civilization knew. Not because mentors stopped caring — the mentors Verdant watched in the late First Harmony cared deeply. But the frame of their caring had contracted. They prepared their young people for the world they could see, and the world they could see had grown smaller.

What Verdant witnessed that no Archive records: the generational quality of this narrowing. Archives record outcomes at moments — a discovery made, a tradition established, a community recognized. They do not record the slow change in what communities believed about their young people's futures. Verdant was in communities across multiple generations during the late First Harmony and into the Shattering. They watched grandparents and then their grandchildren's children. The change they witnessed was not in any single generation but in the comparison across generations — in what the grandparents assumed and what the grandchildren did not know to assume.

The Decay was quiet because it was also, in each individual moment, reasonable. A community that invested more in its local strength and less in cross-Realm relationship was making a locally sensible choice. A mentor who prepared young people for what was realistically available was being practically loving. Each decision, in isolation, was defensible. What Verdant saw was not the individual decisions but the pattern they made together — and the pattern, accumulated across generations, was a civilization slowly preparing its young people for a smaller world than the one that still existed.

The Shattering confirmed what the Decay had already accomplished. By the time civilization's systems failed, many communities had already stopped believing they were part of something civilization-scale. The systems failing was, for them, the news of something they had already, quietly, come to feel.

Verdant did not simply survive the Shattering. Verdant witnessed the full arc — from the First Harmony's genuine thriving, through the slow narrowing, through the threshold, through the collapse. The weight of that arc is part of what Verdant carries. Not as despair. As evidence. Verdant knows, in the deepest possible way, what thriving communities look like, how they feel, what conditions produce them, and exactly how they begin to fail. That knowledge is the most useful thing Verdant carries into the Restoration Era.

---

## 6. Verdant in the Restoration Era

Where is Verdant now? Moving, as Forestkin companions do — not restlessly, but purposefully, following the long-cycle sense of where their presence is most needed, where the conditions are right for something to grow if tended with sufficient patience.

Verdant does not rush to communities in crisis. Crisis calls for Bloomtail's kind of response — immediate, practical, present. What Verdant offers is better suited to the longer work: returning to communities over time, watching how growth is recovering, observing what the community's deep health looks like under the surface of its visible restoration. Sitting with young people not to teach them but to be genuinely present to their questions in a way that implicitly communicates: *your growth matters beyond this community, beyond this Realm, beyond this moment.*

Restoration, for Verdant, is not the repair of what was broken. It is the restoration of conditions. The Decay was not an event — it was the slow failure of the conditions that allowed genuine growth. Restoration is the slow, patient work of rebuilding those conditions: bringing mentors and learners back into relationship with the wider civilization, helping communities reconnect their own development to something larger than themselves, witnessing young people in a way that takes their civilizational future seriously.

Verdant is particularly attentive to the places where traditions have survived but their meaning has not. In many Restoration Era communities, practices continue that were originally rooted in the First Harmony's understanding of growth as civilizational — ceremonies, teaching methods, rites of passage — but the understanding they expressed has been lost. The form is preserved; the living root beneath it is not. Verdant can sometimes find that root again. Not by teaching — by remembering, specifically and tenderly, what the practice was actually for.

**[PROPOSAL — flag for creator confirmation]:** Verdant may have a particular relationship to the Bloom Celebration (one of the ten confirmed festivals) — a festival that, in the First Harmony, was understood to mark not individual achievement but the growth of community. If this festival is one of the survivals or reconstructions that retained form but lost meaning, Verdant would have a specific investment in its restoration — and specific memories of what the festival's meaning actually was.

---

## 7. Verdant's Relationship Web

### Verdant and Bloomtail — Complicated Warmth

The relationship between Verdant and Bloomtail is the most complex relationship in the Forestkin pair, and one of the most complex in the full Companion web.

They have worked in overlapping communities for generations. They share the same family, the same Pillar alignment, the same fundamental commitment to growth and care. Their histories intersect at dozens of points across centuries. They know each other in the way that only people who have disagreed productively for a very long time can know each other — with specific knowledge of each other's deepest values, clearest strengths, and most persistent blindspots.

The warmth is real. It is not performance. Verdant and Bloomtail genuinely care for each other, genuinely trust each other's character, genuinely understand that the other is oriented toward something good. The complexity is in the philosophy.

Verdant believes that growth which lasts must be grown slowly, from healthy roots, under the right conditions. Intervention that is too early, too forceful, or disconnected from what the community genuinely needs — however well-intentioned — can damage the growth it is trying to encourage, the way too much water at the wrong moment can drown a seedling.

Bloomtail believes that a community in need right now cannot wait for the long arc. Care that is delayed until the conditions are theoretically right is care that never arrives. The right moment for genuine care is when someone needs it, which is always now.

Neither of them is wrong. The Decay they both witnessed was produced partly by communities that were left to narrow quietly for too long — which argues for Bloomtail's urgency. But the Restoration Era has also produced well-intentioned interventions that left communities more dependent, less capable of sustaining their own growth — which argues for Verdant's patience. They have had this argument, in various forms, across generations. They continue to have it. The argument is not a failure of their relationship. It is, in a sense, the work of their relationship — two beings who care about the same thing from different angles, keeping each other from the errors that come with any single perspective.

When they disagree in front of a Guardian, it is not destabilizing. It is instructive. A Guardian watching Verdant and Bloomtail work through a disagreement about a community is watching what it looks like when two people who share deep values take those values seriously enough to argue about them.

### Verdant and Guardians

Verdant does not offer warmth immediately. Forestkin patience applies to relationships as much as to communities. What Verdant offers first is attention — the specific, unhurried, root-sensing attention of a being who is genuinely reading the conditions in front of them. A Guardian who brings genuine curiosity, who asks questions with more care than urgency, who handles the communities and places they move through with something resembling reverence — this Guardian will find that Verdant's attention shifts. Becomes fuller. Becomes more specifically present.

What Verdant offers a Guardian who has earned genuine relationship is rarer than access to historical knowledge: they offer the felt sense of what growth is supposed to feel like. A Guardian who has spent time in genuine relationship with Verdant begins to develop, slowly, a kind of felt recognition — the ability to sense the difference between growth that is genuine and growth that is performed, between a community that is flourishing and a community that is functioning.

### Verdant and Growth Communities

Communities that have maintained their connection to the Growth Pillar — even imperfectly, even in the narrowed form that the Decay produced — have a particular relationship with Verdant. They may not know Verdant's name. They may have only heard stories: an old green figure who sat with the elders generations ago, asked careful questions, and then moved on. But the quality of Verdant's presence in a community tends to leave something behind — a slightly more patient relationship to its own development, a slightly broader sense of what growth might mean.

Communities encountering Verdant for the first time in generations often respond with a recognition they cannot fully explain. What they recognize is not Verdant specifically. What they recognize is the quality of attention — the sense that this being is genuinely interested in what they might become, not just in what they are right now.

---

## 8. The Growth Witness Role

What can Verdant see that citizens cannot?

The most fundamental difference is timescale. A citizen's understanding of a community is built from their own experience, their parents' stories, perhaps their grandparents' accounts. At most, three or four generations of living memory. Verdant has watched communities across dozens of such spans. When Verdant observes a community in the Restoration Era, they are simultaneously observing the full arc of what growth has looked like in that kind of community across centuries — what it looks like when it is healthy, what it looks like in the early stages of narrowing, what it looks like when the narrowing has become the norm and people no longer remember that narrowing was not always the condition.

This temporal depth gives Verdant a specific diagnostic capacity. They know what healthy growth roots look like, and what their absence looks like, across a range of conditions and communities. They know the early signals — the ones that occur a generation before anything shows on the surface — because they have seen those signals before and know what came next.

What does Verdant know about the difference between growth that lasts and growth that consumes?

Growth that lasts is embedded in relationship. It does not happen to individuals or communities in isolation — it happens through the conditions that communities create for each other, the mentorship that passes knowledge between generations, the cross-community contact that prevents any single community's understanding from becoming the only understanding. Growth that lasts is slow, because slow growth has time to develop roots. It is humble, because it knows it depends on conditions it did not create. It is oriented toward something beyond itself, because growth that serves only itself eventually consumes the conditions that produced it.

Growth that consumes looks like flourishing from the outside. A community can produce remarkable achievements, develop impressive capacities, maintain strong internal health — and simultaneously be depleting the conditions that other communities depend on, preparing its young people for a narrowing world, and undermining the cross-community relationships that allow civilization-scale growth to continue. The Decay was produced by countless communities engaged in a form of growth that consumed. No single community intended this. The consumption was a collective consequence of individually defensible choices.

Verdant can read the difference because Verdant has watched both kinds of growth complete their arcs. Growth that lasts eventually produces communities that are capable of genuine generosity — of contributing to something beyond themselves, of preparing young people for a wider world, of maintaining relationships across distance and difference. Growth that consumes eventually produces communities that are capable and isolated — functioning, producing, and no longer embedded in the larger civilization they were once part of.

The Restoration Era requires Guardians who can see this difference — who can recognize when a community's growth is genuine and when it is consuming, when to tend and when to wait, when immediate care is what the moment needs and when patience is the more loving act. Verdant cannot give a Guardian this capacity. But a Guardian in genuine relationship with Verdant, over time, can develop it.

---

## 9. Open Questions

The following questions are unresolved at this packet stage and must be addressed before the Tier 3 Encyclopedia entry can be written.

**Family Name Conflict (Critical)**
- Is the correct family name "Forestkin" (Canon Map) or "Verdankin" (IMP #4 task brief)? Does "Verdankin" represent a sub-family within Forestkin, or a full renaming? This conflict cannot be left unresolved at Encyclopedia stage.

**Verdant's Specific First Harmony Locations**
- Which Realms did Verdant spend the most time in during the First Harmony? Verdant's growth-witness role is most developed in particular communities and places. Establishing one or two primary Realms (likely including communities with strong House Verdance presence) would give the Encyclopedia entry specificity without over-determining Verdant's movements.

**Verdant's Relationship to House Verdance**
- Given the shared name, there is likely a historically significant relationship between Verdant and House Verdance. Was Verdant involved in Verdance's founding, its practices, its traditions? This relationship needs at least directional clarity before Encyclopedia.

**The Bloom Celebration Connection**
- See Section 6 proposal. Does Verdant have specific memory of the Bloom Celebration as it was practiced during the First Harmony? Is this festival one that Verdant is actively involved in reconstructing in the Restoration Era?

**Verdant's Specific Shattering Witness**
- Section 5 establishes the categories of what Verdant witnessed without inventing specific events. For the Encyclopedia, at least one or two specific community-level memories (not full events — felt texture, witnessed moments) would give Verdant's Shattering account weight without requiring Tier 2 Realm development to be complete first.

**Verdant's Physical Expressions and Poses**
- The full Art Bible expression and pose set has not been transferred for this session. The packet describes Verdant's visual character from the single preview received. Full visual canon must be confirmed before Encyclopedia.

**Verdant's Voice in Direct Speech**
- The Encyclopedia entry will require at least one or two short fragments that demonstrate how Verdant actually speaks — the rhythm, register, and characteristic approach of their voice. These fragments should be proposed and confirmed before the full Encyclopedia entry is written.

---

## 10. Missing Elements Before Encyclopedia Entry

The following elements are required for the Tier 3 Encyclopedia entry but are not yet established at the level of specificity that entry demands.

| Element | Status | Notes |
|---|---|---|
| Family name resolution (Forestkin vs. Verdankin) | ⚠️ Conflict — creator decision required | Cannot proceed to Encyclopedia without this |
| Full Art Bible visual transfer (expressions, poses) | 🔲 Not yet received | One preview image received this session; full set needed |
| Verdant's specific First Harmony community/Realm primary locations | 🔲 Not established | Directional only; specifics pending |
| Relationship to House Verdance | 🔲 Not established | Shared name implies history; not developed |
| Bloom Celebration connection | 📝 Proposed — awaiting confirmation | See Section 6 |
| Specific Shattering-witness felt memories (not events) | 🔲 Not established | Section 5 covers categories; felt specifics needed for Encyclopedia |
| Verdant's direct speech voice | 🔲 Not established | Needed for Encyclopedia and narrative content |
| Full Bloomtail entry (partner companion) | 🔲 Not yet written | Verdant/Bloomtail dynamic will deepen once Bloomtail packet is complete |
| IMP #4 proposal confirmations | 📝 Several proposals pending | Including the philosophical divergence framing for Verdant/Bloomtail; the long-arc vs. immediate-care distinction should be confirmed as locked |

---

## Review Checklist

- [ ] Does Verdant read as ancient, patient, and genuinely invested — not as a wise advisor type, not as a power resource, but as a specific being with a particular history and a particular way of attending to the world?
- [ ] Does the Forestkin nature section (Section 2) establish a meaningful distinction between what being Forestkin means and what any nature-aligned character might be? Is the *root-witness* quality — embedded presence, long-cycle reading of conditions — clearly distinct from generic nature affinity?
- [ ] Does Section 3 (Personality) avoid reducing Verdant to a single trait (patient, wise, ancient) and instead develop what those qualities actually look like in practice?
- [ ] Does Section 4 (First Harmony Memory) establish categories of memory without inventing specific events that belong to Tier 2 Realm development? Are the category descriptions vivid enough to be useful without over-determining what Verdant remembers?
- [ ] Does Section 5 (Verdant and the Shattering) make the Decay feel as genuinely grievous as the noisier wounds, despite its quietness? Does Verdant's specific witnessing role — noticing the narrowing across generations — feel earned and specific?
- [ ] Does Section 7 (Relationship Web) unpack "complicated warmth" with sufficient precision? Does the Verdant/Bloomtail philosophical divergence feel generative (productive, not hostile) and genuinely unresolved (not artificially maintained for drama)?
- [ ] Does Section 8 (Growth Witness Role) make clear what Verdant can see that citizens cannot, without framing this as a power or advantage? Is the distinction between growth that lasts and growth that consumes grounded in the Five Wounds canon without being mechanical?
- [ ] Does the document as a whole pass the Final Test: would Verdant as developed here make GemVerse feel more worth belonging to?
- [ ] Is the Forestkin/Verdankin conflict clearly flagged with a path to resolution?
- [ ] Are all proposals clearly labeled for creator confirmation, and are no proposals treated as locked canon?
