---
title: Companion Packet — Spark
tier: Work Queue Task 7
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: IMP #4 Companion Relationship Web, Crystal Network (Tier 1)
feeds-into: Tier 3 Companion Encyclopedia — Spark
note: Art Bible character sheet received. "Narrator/puzzle helper" role framing is a canon risk — flagged, not resolved.
---

---

## 1. Known Canon Summary

### Confirmed Visual Canon (Transferred — Art Bible Character Sheet)

- **Name:** Spark
- **Title:** "The Crystal Fox"
- **Companion Family:** Crystalkin (Knowledge / Memory / Light / Reflection)
- **Visual identity:** Fox-like creature with a distinctly magical, crystalline quality. Colouring draws from the Crystalkin palette — white, silver, and crystal blue tones. The crystalline quality is not decorative; it reads as part of Spark's nature. Spark does not merely have crystal features — Spark *is* crystalline, the way a living thing can be made of something that light moves through differently.
- **Expressions transferred (6):** Happy, Curious, Excited, Thinking, Tired, Angry
- **Poses transferred:** Multiple, including sitting, running, leaping, surprised

These six expressions and multiple poses are **visual canon**. Any written description of Spark's physicality must remain consistent with them.

### Confirmed Written Canon (From IMP #4 Companion Relationship Web)

- Spark has a **long shared history** with Prism, the other confirmed Crystalkin companion among the launch eight.
- Spark has **quiet mutual recognition** with Echo.
- Spark is the companion **most likely to offer their name first** to a new Guardian — confirmed framing in IMP #4.

### Confirmed Written Canon (From IMP #1 First Harmony Daily-Life)

- Companions were integrated into community life during the First Harmony as **partners in civilization-building**, not pets, tools, or curiosities.
- Companion testimony was **formally recorded in the Archive** — a Companion's perspective was considered a distinct and valuable source of record.
- Crystalkin companions, given their family's alignment with Knowledge and Light, likely had close relationship with **House Lumina** and the **Crystal Network nodes** throughout the Realms.

### Canon Source for Companion Family: Crystalkin

From the Canon Map (✅ Fully Locked):

> **Crystalkin** | Themes: Knowledge, Light, Reflection | Colour Language: Gold, White, Crystal Blue

Crystalkin are not simply the "knowledge companions." Their relationship to knowledge is experiential and embodied — light moves through crystal; understanding moves through Crystalkin. They do not hold knowledge the way a library holds books. They hold it the way a prism holds light: received, refracted, carried forward changed.

### Canon Risk — Flagged

⚠️ **The Art Bible character sheet frames Spark as:** *"Helps complete puzzles and is the narrator of the realm."*

This framing is a **canon risk** on two counts:

1. **Puzzle-helper framing** conflicts with GemVerse's locked canon that Spark — and all Companions — are witnesses and partners, not tools. A Companion who "helps complete puzzles" is a mechanic, not a person. This framing must not be used in any written companion content.
2. **"Narrator of the realm"** implies an assigned explanatory function — Spark as tour guide or exposition delivery system — which conflicts with the canon principle that Companions have genuine interiority, distinct perspective, and their own relationship to events they have actually witnessed.

Neither phrase is locked. Both are flagged for reframe. See Section 8 for proposed alternative framings.

---

## 2. Spark's Nature as a Crystalkin Companion

To understand Spark, you have to understand what being Crystalkin actually means — not as a power set, but as a way of being in the world.

Crystal transmits light. It also refracts it — meaning the light that comes out the other side is not identical to the light that went in. It has been changed by passing through. And crystal does not forget the light it has carried. The structure of the crystal itself holds a record.

This is what it means for Spark to be Crystalkin. Spark does not simply receive information and pass it on. Every experience, every conversation, every moment of witnessing — these pass through Spark, and Spark is changed by them, and Spark holds something of them. Not as storage. As self.

The Crystal Network, during the First Harmony, was not external infrastructure that Spark happened to interact with. For a Crystalkin companion, the Network was closer to what a river feels to a creature that was born in water. It was the medium through which Spark's nature made sense — a living system of light and knowledge and connection that resonated with what Spark already was. When the Network was active and whole, Spark's Crystalkin nature had a world around it that matched. The Network's nodes hummed with the same quality of awareness that Crystalkin companions carry in their own bodies.

**[PROPOSAL — flag for creator confirmation]:** Crystalkin companions may experience the Crystal Network not simply as a useful tool but as a kind of extended sensory environment — something they can feel the state of, the way a creature with acute hearing knows when a room has gone quiet. Spark would not need to consult a node to know something was wrong with it. Spark would *feel* the wrongness. This is worth establishing as a possible Crystalkin trait before the Crystal Network Tier 1 entry is finalized, so the two entries can be written in concert.

Spark's visual identity — white, silver, crystal blue — is not merely a colour palette. In Crystalkin terms, these are the colours of clarity, of light passing through ice, of knowledge that has been held long enough to become something like wisdom. Spark does not sparkle. Spark *clarifies*.

---

## 3. Personality in Canon Terms

The Art Bible character sheet gives Spark three personality descriptors: **curious, playful, loyal**. These are not wrong. But they are incomplete descriptions of what these traits mean for a Companion who has lived through centuries.

### Curiosity

For an ordinary creature, curiosity is about the not-yet-known. For Spark, curiosity is something stranger and more layered. Spark has seen an enormous amount. Spark carries memories of the First Harmony's height — of a world working, of the Crystal Network at full resonance, of House Lumina scholars doing work whose full implications took generations to understand.

And yet Spark remains curious. This is not naivety. Spark's curiosity is the curiosity of someone who knows how much has been lost and understands that what is being rebuilt will be different — not a recreation but a new thing that needs to be understood on its own terms. Spark is curious about Guardians. Curious about what restoration looks like when it happens through people who never knew the First Harmony. Curious about what civilization will choose to remember, and what it will, on its own, choose to let go.

Spark's curiosity protects against grief. A being who has witnessed the Shattering could, justifiably, become a curator of loss — cataloguing what was, measuring the present against it, finding it wanting. Curiosity is the disposition that refuses that. Spark notices the new thing. Spark finds it genuinely interesting. This is not performance. It is a survival of the self across centuries of change.

### Playfulness

**[PROPOSAL — flag for creator confirmation]:** Playfulness, in Spark, may function as a form of radical presence. A being who carries centuries of memory could easily become weighted by the past — present in body, absent in attention. Playfulness is what pulls Spark into the current moment. It is the part of Spark that delights in the fox who just arrived, in the new Guardian's first expression of wonder, in the particular quality of light on a recovering Crystal Network node. Playfulness is not levity. It is a choice, made constantly, to be *here*, in this moment, with this person, finding this worth attending to.

It is also worth noting: Spark has seen grief. Spark has earned the right to be serious. When Spark chooses to be playful, it means something. It means Spark has decided this is a moment worth inhabiting fully.

### Loyalty

Loyalty in Spark is not the loyalty of a creature that attaches quickly and stays forever because it has nowhere else to go. Spark has had companions before. Spark has watched Guardians grow old. Spark has experienced what it means to still be present when someone you cared about is gone.

Spark's loyalty is therefore fully eyes-open. When Spark chooses to stay beside a Guardian, Spark knows what that means — including what it will eventually mean. This is not sad. It is a commitment made by someone who understands commitment. Spark's loyalty is the kind that makes the person receiving it feel genuinely seen, because Spark does not offer it easily, and the Guardian can sense that.

---

## 4. Spark's First Harmony Memory

Spark lived through the First Harmony. Not as a distant historical fact — as childhood, as home, as the world that was present before any other world was imaginable.

**[PROPOSAL — do not lock any specific memory. The following establishes categories of what Spark holds, not specific content. All specifics require creator confirmation before the Encyclopedia entry is written.]**

What would a Crystalkin companion have held from that era?

**The sound of a fully active Crystal Network.** During the First Harmony, the Network's nodes were not dormant structures waiting to be restored — they were alive with information, resonating with each other across vast distances. For Spark, this was not a technology experience. It was the way the world sounded. There would have been a quality to it — a kind of ambient presence of connected knowing — that Spark carries as a sensory memory. Not a sound exactly. A feeling. The feeling of a world that knew itself.

**Conversations that were never recorded.** House Lumina scholars, during the height of the First Harmony, were doing work at the edge of what was understood. Some of those conversations happened near Crystalkin companions, because Crystalkin were trusted in spaces where significant thinking occurred. Spark was present for exchanges between scholars that were never written down, partly because what was being discussed had not yet become knowledge — it was still becoming. Spark holds the texture of those conversations: the quality of thinking happening in real time, the moments of uncertainty before a thing became clear.

**The Archive when it was receiving.** The Great Archive during the First Harmony was not a repository of fragmented and partially-recovered records. It was actively accumulating — receiving new discoveries daily, recognizing contributors in real time, operating as what it was built to be. Spark would have brought things to the Archive. Spark's testimony would have been received and recorded as a matter of course, as a normal part of how memory was preserved. Spark holds a memory of what it felt like to live in a civilization where preservation was expected, not exceptional.

**The festivals as they actually were.** The ten festivals of the Restoration Era are survivals and reconstructions. Spark remembers the originals — not as grander or more elaborate, but as different in texture. They were gatherings of communities that stayed in relationship throughout the year, not communities reaching back for a connection that had grown thin. Spark knows the difference between a festival that reconnects and a festival that maintains. The original festivals maintained.

**[Flag for creator confirmation]:** Should Spark have one or two specific First Harmony memories that are named and detailed — anchoring points for the character that can appear in dialogue, in the Encyclopedia entry, and in any narrative arc involving Spark? Or should Spark's memories remain a rich but unnamed reservoir, surfaced through interaction rather than told directly? This is a significant characterization decision that affects how Spark can be written in all future content.

---

## 5. Spark and the Shattering

For a Crystalkin companion, the Shattering was not primarily a social or political event. It was a perceptual event.

**[PROPOSAL — flag for creator confirmation]:** When the Crystal Network began to fail — not all at once, but gradually, node by node, as communities withdrew and maintenance stopped and information stopped moving — Spark experienced this as the loss of something that had been present for as long as Spark could remember. Not a tool failing. Not a resource depleting. A sense going quiet.

The Canon Map confirms the Crystal Network went from fully active to partially dormant — "fragments remain." For a Crystalkin companion whose nature resonates with the Network's living quality, this dormancy is not a technical problem to be solved. It is an ongoing condition of loss. The way the world used to feel — that ambient quality of connected knowing — is simply gone. Not forever, perhaps. But for now. And "for now" has lasted long enough that the silence has become the new normal.

This matters for understanding Spark in the Restoration Era, because it means Spark's experience of the current world contains a kind of negative space — a constant awareness of what used to be present that is not present now. This is not depression. It is more like the experience of someone who grew up near the sea and now lives inland: the absence is not foregrounded, not debilitating, but it is there. Spark knows what the world sounds like when it is whole. The world does not currently sound like that.

**[PROPOSAL — flag for creator confirmation]:** Was there a specific moment when Spark knew the Shattering was happening — or more precisely, when Spark knew it was not going to reverse itself? Crystalkin companions may have been among the first to understand what was occurring, precisely because the Crystal Network's failure was perceptible to them in ways it was not perceptible to citizens who experienced it as information simply becoming harder to access. Spark may have known before the Archive scholars named it. This is significant if true, and worth establishing.

What did Spark do during the Shattering? This is an open question of high impact. See Section 9.

---

## 6. Spark in the Restoration Era

Spark is present. This is the first thing to understand about Spark in the current era. After everything — the full flowering of the First Harmony, the slow recognition that something was wrong, the Shattering, the long era of dormancy and partial recovery — Spark is still here. Still curious. Still choosing to offer their name to a new Guardian.

That is not nothing. That is a position that was arrived at through something.

**Where Spark is now:** Consistent with what is established, Spark likely moves through the Arena Realm — the crossroads that survived most intact — and the Crystal Forest, where surviving Network nodes carry particular resonance for a Crystalkin companion. Spark would be drawn to recovering nodes not out of obligation but because their activation is, for Spark, the return of something that had gone quiet. Each restored connection is a small return of the world's proper sound.

**What the Restoration Era has changed in Spark:** Spark has had to learn to hold memory as something to be offered rather than assumed. During the First Harmony, preservation was a shared civic project — memory was contributed to the Archive as a matter of course. Now, Spark's memories are often the only record of things that happened. This is a different relationship to what Spark carries. It is more like guardianship — and it comes with a different kind of responsibility. Spark has become more deliberate about which memories to surface and when, because there are no backup sources.

**What Spark hopes for:** Not the restoration of the First Harmony exactly as it was. Spark was present for the slow drift that preceded the Shattering; Spark knows the First Harmony was not perfect. What Spark hopes for is a civilization that can hold what it knows without losing it. A world where the Crystal Network's return means knowledge moves and stays moved — where the next generation inherits not just restored nodes but the understanding of why they matter. Spark's hope is not nostalgic. It is forward-looking, shaped by what Spark learned from watching a civilization forget.

---

## 7. Spark's Relationship Web

### With Prism

Both Crystalkin. Both present for the full arc from First Harmony to Restoration Era. But long shared history between Companions is not the same as simple closeness — it is complicated by everything that shared history contains.

**[PROPOSAL — flag for creator confirmation]:** Spark and Prism may have a relationship characterized less by warmth and more by deep recognition — the kind of understanding between two beings who have watched the same things happen and do not need to explain the weight of those things to each other. They may not spend all their time together. They may have developed different perspectives on what the Restoration Era calls for, or different ways of holding what they carry. What they share is the knowledge that the other one *knows* — that nothing needs to be explained, simplified, or softened for the other to understand. That quality of recognition is rare. It makes the relationship significant even when the two are not in proximity.

The texture of this relationship — warm familiarity, careful distance, a specific kind of humor that only comes from centuries of shared context, or something else entirely — requires creator input before it can be written.

### With Echo

Quiet mutual recognition. Echo's canon themes are Memory, History, and Lost voices — there is obvious resonance here with Spark's relationship to the Crystal Network and to First Harmony memories. But "quiet mutual recognition" specifically is distinct from the long shared history with Prism. This reads as two Companions who arrived at an understanding of each other without a shared past — who recognize in each other something they see clearly because their own nature makes that quality visible to them.

**[PROPOSAL — flag for creator confirmation]:** The specific basis of the recognition between Spark and Echo — what each sees in the other, how often they interact, whether there is warmth or simply respect — is not yet established. The framing "quiet mutual recognition" is evocative but requires unpacking before it can be written with specificity.

### With Guardians

Per IMP #4: Spark is the companion most likely to offer their name first to a new Guardian.

This is a significant characterization beat. Offering your name first is an act of reaching. For a being who has watched many Guardians over many years — who knows what the beginning of a relationship with a Guardian can mean, and what its ending means too — choosing to reach anyway is a meaningful choice.

Spark does not wait for a Guardian to prove themselves before engaging. Spark begins with openness. This is not naivety — Spark has assessed the situation and decided this Guardian is someone worth reaching toward. The name-offering is a small act with a large meaning: *I see you. I am not withholding myself. This is who I am. What's yours?*

What Spark offers first is usually not information, not guidance, not a task. Spark offers presence. Spark pays attention. The Guardian's first experience of Spark is often being noticed — being observed not evaluatively but with genuine interest, the way someone might look at a new thing and find it genuinely worth looking at.

### With the Crystal Network

Spark's relationship to the Crystal Network is not like a Guardian's — it is not the relationship of someone working to restore a system they understand intellectually and care about philosophically. It is personal. The Network's recovery is Spark's recovery too, in some sense. When a Guardian restores a node in Spark's presence, Spark experiences something that is not simply satisfaction. It is closer to hearing a note returned to a melody that had been missing.

This makes Spark a meaningful companion specifically for Crystal Network restoration gameplay — not because Spark explains the Network (the narrator/puzzle-helper framing to be avoided), but because Spark's response to recovery has genuine emotional weight. The Guardian restores the node; Spark is the one who knows what that meant.

---

## 8. The Narrator Reframe

The Art Bible frames Spark as "the narrator of the realm." This phrase preserves something worth keeping — Spark does carry and share stories. The spirit of it is right. The framing is not.

"Narrator" implies an assigned function. It places Spark outside the events being described, in a position of editorial authority — someone who explains things to an audience rather than someone who lived through them. It also, as the Canon Map makes clear, risks framing Spark as a puzzle-delivery mechanism in a franchise that has explicitly locked the principle that Companions are not tools.

The canon-safe reframe is this: **Spark is a living Archive.** Spark shares memories because they are worth preserving — because the testimony of someone who was present is irreplaceable, and because Spark has chosen to offer it rather than carry it alone. The sharing is not Spark's function. It is Spark's generosity.

Below are three proposed alternative phrasings that preserve the spirit of the original while removing the assignment-of-function problem. All three are proposals requiring creator confirmation.

**Option A — "The Living Record"**
*Spark carries what no Archive file contains — the memory of how things felt when they were whole. Not because Spark was assigned to remember, but because Spark was there.*

This framing emphasizes witness over role. Spark did not choose to be a record. Spark chose to survive, and survival, for a Crystalkin companion, includes what was carried.

**Option B — "The One Who Remembers Willingly"**
*Where the Archive preserves what was documented, Spark holds what was never written down. And unlike a document, Spark can choose to share it — or not.*

This framing introduces agency and intimacy. It distinguishes Spark from a passive repository and from the Archive itself. It also sets up the relational dynamic in which what Spark shares to a Guardian is a gift, not a service.

**Option C — "The Light That Carries the Story Through"**
*Crystalkin do not merely hold what has passed through them. They are changed by it — and they carry the change forward. Spark is not the narrator of the realm's history. Spark is its living continuation.*

This framing is the most Crystalkin-specific. It pulls directly from the metaphysics of the companion family — light through crystal, refracted and carried forward changed — and positions Spark's memory not as a record but as a living inheritance that continues to evolve.

**Recommendation:** Option B is the most immediately usable for dialogue and gameplay framing. Option C is the most thematically resonant for the Encyclopedia entry and for narrative arc content. Both can coexist. Creator to confirm direction.

---

## 9. Open Questions

The following questions cannot be answered without creator input. They are listed in order of impact — a decision on a higher-impact question may affect how lower-impact questions are answered.

| Impact | Question | Why It Matters |
|---|---|---|
| High | **What did Spark do during the Shattering?** | This is the emotional core of Spark's backstory. Did Spark try to stay near active nodes as long as possible? Seek out other Companions? Begin recording memories? This shapes everything about how Spark relates to the Shattering's memory. |
| High | **Does Spark have a specific loss from the Shattering that is personal rather than civilizational?** | A Guardian or scholar who was close to Spark, a node that was particularly significant, a memory that was lost rather than carried — something specific that Spark mourns, as distinct from what civilization mourns. |
| High | **What is the nature of the Spark/Prism relationship in specific terms?** | Texture, tone, history, current dynamic. Cannot be written with specificity from "long shared history" alone. |
| Medium | **Should Spark have one or two named First Harmony memories?** | Anchor points for the character that can appear in dialogue and narrative arcs. Requires creator confirmation to avoid inventing content that conflicts with future development. |
| Medium | **What triggered the Crystal Network sensitivity in Crystalkin — is it congenital or developed?** | Does a Crystalkin companion feel the Network from birth, or does the relationship develop through proximity and experience? This affects how Spark's nature is described. |
| Medium | **What is the specific basis of recognition between Spark and Echo?** | Requires unpacking before it can be written with specificity. |
| Medium | **Is there anything Spark does not share, and why?** | The most interesting companion characters have limits on their openness — something held back not out of distrust but out of something else. Does Spark have memories they carry without offering? |
| Low | **Does Spark have a relationship with any of the six confirmed named citizens?** | Could become relevant in Tier 2 narrative development. No urgency for Encyclopedia entry. |
| Low | **Does Spark have any connection to the open mysteries (the Memory Ocean, the Seventh Lantern, etc.)?** | Worth flagging before those entries are developed, not before the Encyclopedia entry. |

---

## 10. Missing Elements Before Encyclopedia Entry

The following items must be confirmed or provided before the Tier 3 Companion Encyclopedia entry for Spark can be written. The Encyclopedia entry requires specificity that this Packet deliberately withholds, pending creator review.

**Required from creator before writing can begin:**

1. **Confirmation or revision of the narrator/puzzle-helper reframe.** Which Option (A, B, or C) from Section 8, or a creator-provided alternative? The Encyclopedia entry's framing of Spark's core function depends on this.

2. **Spark's Shattering experience — personal specifics.** What did Spark do? Did Spark lose someone? Is there a memory Spark carries from that period that shapes Spark's current disposition?

3. **Spark/Prism relationship texture.** The Encyclopedia entry will include a Relationship Web section. This section cannot be written without knowing whether the Spark/Prism dynamic is warmly close, carefully distant, complicated by history, or something else.

4. **Named First Harmony memories (if any).** If creator wants one or two specific anchor memories, these need to be confirmed before they appear in the Encyclopedia entry.

5. **Crystal Network Tier 1 entry.** The Crystal Network entry is a dependency listed in the front matter. Spark's Crystalkin relationship to the Network needs to be consistent with whatever the Tier 1 entry establishes about how the Network works and what Companions' relationship to it was. This entry should not be finalized before the Crystal Network entry is complete.

**Nice-to-have before writing (not blockers, but helpful):**

- Confirmation of Spark's Arc status ("Draft — early development" per Canon Map) and what the arc currently involves
- Any creator notes on Spark's voice register — how Spark sounds in dialogue (formal/ancient/warm, or something else?)
- Confirmation of whether Spark is the first Companion a new Guardian meets, or simply the first to offer a name

---

## Review Checklist

The following must be completed before the Tier 3 Companion Encyclopedia entry for Spark is drafted:

- [ ] Creator has confirmed or revised the narrator/puzzle-helper reframe (Section 8 — Option A, B, C, or creator alternative)
- [ ] Creator has provided direction on Spark's Shattering experience — specifically: what did Spark do, and is there a personal loss?
- [ ] Creator has confirmed the texture of the Spark/Prism relationship (Section 7)
- [ ] Creator has decided whether Spark has specific named First Harmony memories, and if so, has provided or approved them (Section 4)
- [ ] Crystal Network Tier 1 entry is written and locked — Spark's Crystalkin nature depends on this entry for consistency
- [ ] Crystalkin Network sensitivity trait (Section 2) has been confirmed or revised by creator
- [ ] Canon risk on Art Bible "narrator/puzzle helper" framing is formally resolved and logged in the Conflicts & Decisions Log
- [ ] IMP #4 Companion Relationship Web has been reviewed to confirm that Spark/Echo "quiet mutual recognition" has been unpacked sufficiently for use in the Encyclopedia entry
- [ ] Creator has confirmed Spark's voice register for dialogue — this affects how any Spark-specific text is written in the Encyclopedia entry
- [ ] Spark Arc (Canon Map: "Draft — early development") status has been reviewed to ensure the Encyclopedia entry does not inadvertently foreclose arc directions not yet confirmed

---

*Companion Packet prepared for creator review. No specific memory, relationship detail, or narrative beat in this document is locked canon. Everything marked [PROPOSAL] requires explicit creator confirmation before it may be used in the Tier 3 Encyclopedia entry or any other production content. Visual canon from the Art Bible character sheet is the only content in this document treated as transferred canon.*
