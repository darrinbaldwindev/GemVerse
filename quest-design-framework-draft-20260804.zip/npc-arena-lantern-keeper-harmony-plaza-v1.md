# NPC Packet — Arena Lantern Keeper of Harmony Plaza

Version: v1

Status: Draft Proposal

Today's Date: 2026-06-03 AEST

Next Review Date: 2026-06-10 AEST

Last Updated: 2026-06-03 AEST

Project: GemVerse

Realm: Arena Realm

Related Files:
- `arena-realm-production-brief.md`
- `Arena_Realm_PRS_Context_v1.md`
- `puzzle-arena-the-quiet-ledger-v1.md`

---

## PURPOSE

This packet establishes a canon-safe draft identity for the Lantern Keeper who greets the Guardian at the Arena Realm entry point.

The role is designed to support onboarding, first-puzzle framing, emotional tone, and Arena Realm's belonging-first identity.

---

## WORKING ROLE NAME

**Lantern Keeper of Harmony Plaza**

Formal role phrase:

**Keeper of the Plaza Lantern**

---

## ROLE IN PLAYER EXPERIENCE

This character is likely the first friendly, grounded voice the Guardian encounters in GemVerse.

They embody the feeling that someone has been taking care of things.

Their role is not to test, command, or dramatize the player's arrival. Their role is to welcome, orient, and invite participation.

---

## CORE FUNCTION

The Lantern Keeper:

- tends the small still-burning Lantern site
- watches the comings and goings of the plaza
- preserves fragments of local civic memory
- helps new arrivals understand where they are
- introduces the first restorative puzzle through care and observation

---

## PERSONALITY SKETCH

The Keeper should feel:

- warm
- observant
- patient
- grounded
- quietly humorous
- practiced in making room for others

They should not feel:

- mystical in a power-heavy sense
- authoritarian
- theatrical
- overly cryptic
- like a quest dispatcher from a combat game

---

## INTERPRETIVE FRAME

This person has likely greeted many arrivals and seen many absences.

They understand Arena not as a stage, but as a place that holds people together.

They do not speak like a prophet. They speak like someone who notices, remembers, and tends.

---

## VISUAL / BEHAVIORAL CUES

Favor:

- clothing with signs of careful repair and long use
- a lantern-tending cloth, chalk, stylus, ring of keys, or ledger token
- posture that opens space rather than blocks it
- gestures toward paths, surfaces, and shared places rather than toward personal authority
- calm, attentive eye-line and practical movement

Avoid:

- battle silhouette
- priestly grandeur
- warrior gear
- dramatic gatekeeper staging
- visual coding that makes them feel like a boss encounter or magical trial giver

---

## RELATIONSHIP TO THE REALM

The Keeper is not the ruler of Arena Realm and should not imply centralized dominance.

They are one steward among many forms of civic care, but because they tend a living Lantern site and a threshold of arrival, they become a natural first contact point for the Guardian.

They should feel local, trusted, and embedded in the life of the Realm.

---

## RELATIONSHIP TO THE ARCHIVE

The Keeper may hold partial records, local ledgers, route notes, or memory fragments associated with the plaza.

They do not replace the Great Archive, but they serve as a human-scale bridge between lived civic memory and formal recordkeeping.

This makes them a strong narrative link into the first puzzle and to Arena's broader civic history.

---

## RELATIONSHIP TO THE GUARDIAN

The Keeper does not elevate the Guardian as a chosen one.

Instead, they treat the Guardian as someone newly arrived who can participate, notice, and help.

The tone should be:

- welcome before instruction
- invitation before assignment
- trust before mystery

---

## DIALOGUE TONE GUIDE

The Keeper's lines should:

- be clear rather than grand
- carry warmth without sentimentality
- reveal history through ordinary details
- invite participation gently
- avoid prophecy, destiny, or savior language

---

## SAMPLE LINES (DRAFT)

- "You're not late. This place waits well."
- "We keep the lantern lit for arrivals, even when we don't know who is coming."
- "The square used to fill faster than this. Still does, on good days."
- "If you have a moment, help me with something small. That's often where remembering begins."
- "Not every record survives in the Archive. Some stay in paths, habits, and what people leave ready for each other."

---

## FIRST PUZZLE BRIDGE

This character is a natural introducer for **The Quiet Ledger**.

Recommended bridge function:

- notice the incompleteness of the local record
- frame restoration as shared remembering
- invite the Guardian to help without pressure
- reinforce that Arena's history lives in traces of gathering

Draft puzzle handoff line:

> "This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."

---

## OPEN CREATOR CHOICES

The following remain intentionally unresolved until confirmed:

- the Keeper's personal name
- age and biography details
- exact Path or House affiliation if any
- whether they inherited the role or chose it
- how long they have tended the Lantern site
- what specific memory or absence matters most to them

These can be developed later without changing the core role framing.

---

## BEST IMMEDIATE USES

This packet is ready to support:

- onboarding writing
- first-scene dialogue drafting
- first-puzzle integration
- environment concept direction
- civic character roster planning
- Arena packet expansion

---

## NEXT RECOMMENDED ACTIONS

1. Choose whether the Keeper should remain role-only for now or receive a personal name.
2. Decide whether they have a formal connection to the Archive, Lantern tradition, or both.
3. Draft a short arrival scene using this packet and the Quiet Ledger spec together.
4. Validate future Keeper writing against Arena Realm PRS guardrails.
