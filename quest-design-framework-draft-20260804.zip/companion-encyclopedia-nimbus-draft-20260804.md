# Companion Encyclopedia Entry — Nimbus
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.3  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Nimbus  
**Themes:** Exploration, Freedom, Discovery  
**Companion Family:** Skykin (Sky Blue, Cloud White, Silver)  
**Visual Identity:** Cloud-formed body with silver lining edges, translucent core that shimmers with wind currents, capable of partial mist-form  
**Symbol:** Drifting Cloud with Silver Lining (representing limitless horizons and guidance)  
**Unique Trait:** Wind-current reading — can sense air pressure changes, thermal pockets, and updrafts across great distances  

---

## 1. Origin Story

Nimbus formed during a legendary wind convergence known as the "Seven Winds' Embrace" — a rare meteorological event that occurs once every seventy years in the Sky Citadel. During this convergence, wind currents from all directions meet in a spiraling dance high above the floating platforms. It was during one such event that Nimbus manifested from the pure joy of unfettered movement itself.

Nimbus was first encountered by Lyra (the Realm Explorer) during her early expeditions to the Sky Citadel. Unlike other companions who are born to families or communities, Nimbus simply appeared — a sentient cloud-shape that responded to Lyra's call for help when she was stranded on a drifting platform. From that moment, Nimbus chose Lyra as their constant companion, though they maintained their independent nature.

---

## 2. Personality

Nimbus embodies pure freedom and curiosity. They are restless but not reckless — they understand that true exploration requires both boldness and careful observation. Nimbus speaks in gusts and whispers, often finishing thoughts in metaphors of weather patterns ("The path ahead feels like a rising mist... uncertain but breathable").

They are deeply empathetic to movement — not just their own, but others'. They can sense when someone feels "stuck" and will instinctively try to lift their spirits (literally, if the person is small enough). This can sometimes be overwhelming to more grounded companions and citizens.

Nimbus experiences time like weather — in patterns and cycles rather than strict linear sequences. They remember events not by when they happened, but by what the wind was doing at the time.

---

## 3. Shattering Memory

Nimbus remembers the First Harmony skies — vast currents that carried news, songs, and scents across Realms. After the Shattering, these "Windways" fragmented. The great sky routes that once allowed instant communication between the Sky Citadel and ground Realms became erratic, then silent.

This wasn't destruction — it was quieting. The wind still blew, but it no longer "spoke." Nimbus felt this loss as a kind of deafness. They could still fly, but the conversations the wind used to carry were gone.

What Nimbus misses most is not just the communication, but the collective movement — when all the Realms felt connected by currents of shared purpose and understanding.

---

## 4. Missing Piece

Nimbus' Missing Piece is the "Keystone Drift" — a specific wind pattern that once connected all the Realm capitals during seasonal festivals. This wasn't just wind, but a living pathway made of coordinated air pressure systems, maintained by Windkeepers in each Realm. When the Shattering occurred, the keepers vanished or forgot their roles, and the Keystone Drift scattered into fragments.

Nimbus carries a "Drift-echo" — a memory-scent of this pattern, but cannot recreate it alone. They spend much of their time searching for places where remnants of the Keystone Drift still flicker, hoping to relearn how it was maintained.

---

## 5. Restoration Story

Nimbus joined the Guardian when the Guardian was lost on a journey through the Sky Citadel's outer platforms. While Lyra was away on a mapping expedition, Nimbus took it upon themselves to guide the Guardian back — not by the fastest route, but by the most memorable one.

During this journey, Nimbus began to sense something they hadn't felt in years — a partial Keystone Drift, rekindled by the Guardian's presence in a place where multiple wind memories overlapped. This brief reconnection sparked something in both Nimbus and the Guardian — the realization that restoration might not be about fixing the old patterns, but about creating new ones worth remembering.

Nimbus' role in restoration is to help the Guardian see options others miss. They don't just show paths — they show possibilities. Where others see barriers, Nimbus shows how the wind might carry you over, around, or through.

---

## 6. Legacy Story

Nimbus has taught the Guardian the "Windborne Method" — a form of problem-solving that involves asking: "What wants to move here?" and "What is trying to connect?" rather than "How do I get through this obstacle?"

Others have begun to speak of "Nimbus Moments" — times when a solution appears suddenly, carried on an unexpected breeze of inspiration or opportunity. Whether this is literal or metaphorical, it's brought a sense of wonder back to problem-solving across the Realms.

Nimbus' legacy is not a solved puzzle, but a changed perspective — showing others that freedom and focus can coexist, that exploration is not wandering but intentional witnessing.

---

## Relationships

### Skykin Family
Nimbus has no formal family but considers all wind-spirits their kin. They maintain loose contact with other Skykin through weather-pattern greetings — unique gust signatures that announce identity and current emotional weather.

### Guardian
Nimbus sees the Guardian as a "Grounded Skywatcher" — someone who wants to soar but must walk. This fascinates them. They try to teach the Guardian to "feel the wind" in decisions and to trust movement that doesn't have a fixed destination.

### Other Companions
- **Lyra:** "My first fixed point. The one who chose to see me, not just see through me."
- **Spark:** "Too quick to rest, but lights up every cloud they touch. Exciting but exhausting."
- **Verdant:** "Slow and deep like morning mist. Speaks in growing-time. Hard to rush, impossible to ignore."
- **Frostpaw:** "A different kind of stillness. Their quiet has weight, like snow-heavy branches."
- **Bloomtail:** "Joy moves through them like wind through flower fields. Uplifting but unpredictable."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Wind-current Reading:** Can predict weather patterns, safe travel routes, and air-pressure changes up to three Realms away
- **Partial Mist-form:** Can become translucent and ride wind directly for short distances (not true teleportation, but rapid localized movement)
- **Drift-echo Sensing:** Can detect residual Keystone Drift fragments in locations where significant movement events occurred
- **Empathic Lifting:** Can literally lift lighter objects and small creatures by enveloping them in supportive wind currents
- **Weather Memory:** Remembers every significant wind pattern they've experienced — experiences time through weather associations

---