# Guardian Role — Proposals & Exploratory Concepts
**Version:** 1.0
**Status:** EXPLORATORY — Not Canon
**Source:** Conflict 10 Resolution (2026-08-04)
**Authority:** Creator confirmation — Status Mode session

---

## Purpose
This document contains **all** Guardian concepts that are proposals, exploratory ideas, or未定. None of these are canon. They are preserved here for future consideration and potential canonization through explicit Creator decisions.

---

## ⚠️ Canon Status Notice
**Nothing in this document is canon.** These are proposals only. For locked Guardian canon, see `guardian-role-canon.md`.

---

## Proposal Categories

### 1. Guardian Classes / Specializations
**Proposal:** Formal Guardian roles aligned with Seven Pillars / Five Wounds
- **Pathfinder Guardian** — specializes in Realm navigation, Lantern Network restoration (Astra / Discovery)
- **Chronicler Guardian** — specializes in Archive contribution, memory preservation (Borealis / Memory)
- **Steward Guardian** — specializes in Verdance cultivation, community growth (Verdance / Growth)
- **Harmonist Guardian** — specializes in Pillar balance, Harmony Alignment (Solstice / Harmony)
- **Lumina Guardian** — specializes in Crystal Network calibration, knowledge flow (Lumina / Knowledge)
- **Hearthlight Guardian** — specializes in festival traditions, civic belonging (Hearthlight / Belonging)
- **Legacy Guardian** — specializes in Legacy Seals, long-term preservation (Legacy / Cross-Wound)

**Questions:**
- Are these formal titles or fluid tendencies?
- Can a Guardian shift specialization?
- Is there a "generalist" Guardian path?
- How does specialization affect puzzle access or narrative?

---

### 2. Guardian Progression / Recognition System
**Proposal:** Visible progression of Guardian contribution
- **Archive Entry Tiers:** Each significant restoration adds a Chronicle entry (Bronze/Silver/Gold/Platinum tiers — metaphorical, not competitive)
- **Hall of Guardians Induction:** Physical commemoration in Legacy Realm after major cross-Realm restoration
- **Companion Testimonies:** Companions contribute memories of Guardian's work to Book of Guardians
- **Festival Recognition:** Communities celebrate Guardian contributions during festivals (non-competitive)
- **Lantern Network Beacon:** Restored Lanterns pulse in Guardian's honor (visual, not mechanical advantage)

**Questions:**
- How to avoid "achievement hunting" / gamification feel?
- Is recognition automatic or nominated?
- Can recognition be declined (humility as value)?
- How does this display in UI without power-escalation framing?

---

### 3. Guardian Arrival / First Contact
**Proposal:** How a new Guardian first enters GemVerse
- **Arrival Site:** Lantern Network threshold — a dormant Lantern reactivated by presence
- **First Companion:** Spark (as guide/witness, not tutor) or Aurora (as Archive guide)
- **First Act:** Simple restoration — relight a Lantern, calibrate a node, contribute a memory
- **No Tutorial Framing:** Arrival is narrative, not mechanical onboarding
- **Aurora's Role:** Guardian Guide / Story Teller — introduces world, not mechanics

**Questions:**
- Where exactly? (Arena Realm Harmony Plaza? Twilight Frontier threshold? Memory Ocean shore?)
- Is arrival the same for all players or personalized?
- How does this connect to "Guardian" as title — earned or recognized?
- What does the player *do* in first 5 minutes that feels like restoration?

---

### 4. Guardian Tools / Equipment
**Proposal:** Canon-safe tools carried by Guardians
- **Resonance Journal** — records puzzle solutions, Archive fragments, Companion memories (not inventory)
- **Lantern Key** — physical key to dormant Lanterns; glows near unlit thresholds (not "unlock" mechanic)
- **Harmony Tuning Fork** — used for Harmony Alignment puzzles; resonates with Pillar states
- **Archive Lens** (reframed from Crystal Pearl) — reads Fragment Assembly pieces
- **Companion Whistle** — calls nearby Companion for memory contribution (not "summon" mechanic)

**Questions:**
- Are tools physical items or abilities?
- Do tools persist across sessions or are they contextual?
- How do tools avoid "inventory management" feel?
- Can tools be shared/gifted to other Guardians?

---

### 5. Guardian-Companion Bonding Mechanics
**Proposal:** Deepening partnership without "bonding levels"
- **Shared Memory:** Guardian and Companion co-contribute a memory to Archive
- **Witnessed Restoration:** Companion present for major restoration; both recorded in Book of Guardians
- **Festival Co-Hosting:** Guardian and Companion co-lead a festival tradition
- **Cross-Realm Journey:** Guardian and Companion travel together to a Realm neither has restored
- **Legacy Seal Co-Opening:** Guardian and Companion together open a Legacy Seal

**Questions:**
- Is "bonding" tracked or purely narrative?
- Can a Guardian have multiple deep partnerships?
- How does this differ from Citizen Path partnerships (IMP-03)?
- What happens if a Companion "leaves" (narrative, not mechanical)?

---

### 6. Guardian Cross-Realm Authority / Recognition
**Proposal:** How Guardians are recognized across Realms
- **Lantern Network Attunement:** Restored Lanterns recognize Guardian's resonance signature
- **Archive Access Tier:** Book of Guardians entry grants deeper Archive section access (not "unlock")
- **Citizen Recognition:** Citizens in restored Realms greet Guardian by contribution ("You're the one who fixed the Crystal Forest node")
- **Companion Network:** Companions share Guardian's restoration stories across families
- **No Formal Authority:** Guardians have no command power; only trust earned through contribution

**Questions:**
- How is "recognition" displayed without UI badges/popups?
- Does recognition persist if Guardian stops playing?
- Can recognition be lost (neglect vs. active harm)?
- How does this scale to 9 Realms + future Realms?

---

### 7. Guardian Council / Governance Role
**Proposal:** Guardian collective structure (if any)
- **Council of Restorers:** Informal gathering of Guardians who've completed major cross-Realm restorations
- **Meets at:** Great Archive (Book of Guardians) or Hall of Guardians (Legacy Realm) or rotating Realm
- **Function:** Share restoration knowledge, coordinate multi-Realm efforts, advise Harmony Council
- **No Authority:** Council cannot direct other Guardians; only advise and witness
- **Membership:** By invitation from existing members + Archive Chronicler nomination

**Questions:**
- Does this exist at launch or emerge post-launch?
- Relationship to Harmony Council (Tier 1 canon)?
- Can non-Guardians attend (citizens, companions, Harmonists)?
- How to avoid "guild" / "faction" framing?

---

## Canonization Process
To move any proposal to canon:
1. Create new Conflict entry in `02-conflicts-log.md`
2. Present proposal with canon alignment rationale
3. Obtain explicit Creator confirmation
4. Move resolved section to `guardian-role-canon.md`
5. Update all downstream documents (Arena onboarding, Archive, Hall, narratives)

---

## Related Proposals (Cross-Reference)
- `arena-first-slice-prototype-assembly-brief-v1.md` — Guardian arrival experience
- `great-archive-systems-design-draft-20260804.md` — Book of Guardians implementation
- `imp-04-companion-relationship-web-draft-20260804.md` — Companion partnership matrix
- `harmony-index-system-design-draft-20260804.md` — Guardian contribution visibility

---

**Status: EXPLORATORY — Do not treat as canon. No production implementation without canonization.**