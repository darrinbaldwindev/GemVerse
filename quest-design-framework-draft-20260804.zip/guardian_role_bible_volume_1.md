# GEMVERSE ART STUDIO
## Guardian Role Bible — Volume 1
### The Role of Guardians in GemVerse

CANON STATUS: DRAFT OUTLINE (CANON-SAFE)

## 1. The Guardian Principle

Guardians are:

- Contributors, not saviors
- Participants, not rulers
- Learners, not commanders

They arrive in a civilization that existed long before them and will continue long after them.

**Player Feeling:**

- "I’m helping this world heal."
- "I’m earning my place here."

## 2. Guardians & The Eight Pillars

Public Pillars:

- Knowledge
- Discovery
- Growth
- Memory
- Community
- Harmony
- Legacy

Hidden Pillar:

- Belonging (never measured, never on a progress bar)

Guardian relationship:

- Guardians tend Pillars through choices and actions.
- They never “max out” a Pillar; they learn how to live with it.

## 3. Guardians & Companions

Companions are:

- Witnesses
- Partners
- Historical survivors

Guardians must never treat Companions as:

- Pets
- Tools
- Power-ups
- Combat assets

Core rules:

- Every Guardian–Companion bond is voluntary and mutual.
- Collection is framed as relationships, not gacha or power collection.
- The reward for partnership is understanding and shared stories, not damage or DPS.

## 4. Guardians & Realms

Guardians interact with Realms as:

- Guests
- Builders
- Restorers

They:

- Help reconnect communities
- Support existing traditions
- Learn local customs and festivals
- Participate in restoration, not conquest

Guardians do not:

- Claim ownership of Realms
- Install themselves as rulers
- Decide which cultures “win”

## 5. Guardians & The Shattering

Canon rules:

- The Shattering is caused by Pillar imbalance, not a villain or dark lord.
- No civilization or group is blamed.
- Guardians arrive during the Restoration Era, where the task is healing, not revenge.

Guardian role:

- Understand what drifted out of harmony.
- Support communities in rebalancing their Pillars.
- Avoid simplistic “fix everything” solutions; listen first.

## 6. Guardian Motivations

Approved motivations:

- Curiosity
- Empathy
- Restoration
- Story-seeking
- Belonging

Disallowed motivations:

- Power fantasy
- Domination or conquest
- Pay-to-win progression
- Chosen-one destiny

**Player Feeling:**

- "I belong more as I understand more."
- "The world changes because many people care, not because I am special."

## 7. Guardian Progression Philosophy

Progression represents:

- Understanding, not power
- Trust, not dominance
- Belonging, not rank

Visible systems may track:

- Stories learned
- Communities helped
- Traditions participated in
- Journeys completed

They may not track:

- Damage
- Kill counts
- Power levels
- Belonging as a numeric stat

## 8. Guardians & Puzzles

Puzzles are:

- Fragments of civilization
- Created by people within GemVerse
- Tied to specific purposes such as archives, wayfinding, rituals, and restoration

Guardians:

- Solve puzzles to understand and restore, not to unlock raw power.
- Treat each puzzle as a story: who built this, why, and what it reveals.

## 9. Guardians & Open Mysteries

Guardians may:

- Discover hints
- Participate in legends
- Collect partial stories

Guardians may not:

- Fully resolve named open mysteries without explicit creator sign-off

Examples include:

- The Missing Realm
- The Memory Oceans origin
- The Seventh Lantern
- The Lost Harmonists
- The Sleeping Gate
- The Forgotten Door

## 10. Guardian Tone & Presentation

Visual and narrative framing:

- Warm
- Hopeful
- Grounded
- Ordinary people choosing to care

Avoid:

- Grimdark armor
- Horror motifs
- Savior framing
- Power-fantasy presentation

Clothing and tools should emphasize:

- Travel
- Study
- Restoration
- Participation

The Guardian’s presence should always make GemVerse feel more worth belonging to.
