# GemVerse Canon Risk Report
**Report ID:** CRR-20260601
**Date:** 2026-06-01
**Task:** Visual Asset Transfer Intake (Task 10)
**Source material:** Four transferred images — Construct 3 Development Bible (Image 1), Art Bible v1.0 + UI Wireframes (Image 2), Art Bible v1.0 main (Image 3), Consolidated Art Bible / Summary Sheet (Image 4)
**Prepared by:** Computer (Task 2 — Canon Validation & Continuity Checker)
**Stop rule:** Computer does not resolve any canon conflict. All flagged items are returned to creator.

---

## RISK SUMMARY BY SEVERITY

### CRITICAL (1 item)
- Story Screen narrative text — "Crystal Heart" artifact + "darkness spread" antagonist framing

### HIGH (3 items)
- Kael visual framing — "defeat the Arena Realm / strength of the group"
- Power-ups & boosters (all named items) — power advantage framing
- "Challenge Your Mind. Save the Realms." tagline variant — savior/hero framing

### MEDIUM (6 items)
- Spark role framing — "helps complete puzzles / narrator of the realm"
- "Heart of the Core" realm — unknown; not in locked canon
- Resource bars (Crystal/Ember/Star) — unknown function; possible energy-gating
- Special gems (Bomb Gem, Lightning Gem, Rainbow Gem) — named destruction mechanics
- Scoring / combo system (2x, 3x, 4x+) — power escalation framing
- Kael Art Bible description — confirms combat framing in text canon

### LOW (4 items)
- Arena Realm description — "ancient strength" framing
- Ember Depths description — "primal strength" framing
- "Collection Guardian" achievement badge — possible gacha/collectible implication
- "One Puzzle. Countless Realms." tagline variant — franchise identity reduction
- Lumi, Ember, Frosty companion visuals — Conflict 6 canon status unresolved (confirmed visual presence, no launch status change)

---

## INDIVIDUAL CANON RISK NOTES

---

### RISK 01 — Story Screen Narrative Text

```
CANON RISK — Story Screen Narrative Text ("Crystal Heart" + "darkness spread")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Story Screen mockup (Images 2, 3, 4)
Rules violated: 2.1, 2.2, 2.3
Description: The Story Screen mockup contains narrative text that names a specific artifact
  ("Crystal Heart") as the cause of the Shattering and frames its shattering as the moment
  "darkness spread" — introducing both a named causative artifact and an antagonist/darkness
  framing that does not exist in locked canon.
Source A (new content): "Long ago, the Crystal Heart unified all realms. When it shattered,
  darkness spread. Together, we will restore the light."
Source B (locked canon): The Shattering was caused by Pillar imbalance — a slow drift, not
  a sudden event, not an artifact's destruction, and not caused by any evil force or darkness.
  No central antagonist exists. Rule 2.1: "No villain caused the Shattering." Rule 2.2:
  "Does this content avoid introducing a central antagonist or dark lord?" Rule 2.3: "Is the
  Shattering described as a consequence of drift not a sudden attack or catastrophe?"
Severity: CRITICAL
Recommended action: Stop and return to creator. Do not resolve. This is the single most
  significant canon conflict in the entire visual asset transfer. The Story Screen text must
  be rewritten before any version of this screen can be tagged Transferred or Approved.
  The phrase "Crystal Heart," all variants of "darkness spread," and all "restore the light"
  savior framing must be removed. This text may not be used in any build, prototype, or
  public-facing material.
```

---

### RISK 02 — Kael Visual Framing (Art Bible v1.0)

```
CANON RISK — Kael Character Description ("defeat the Arena Realm / strength of the group")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 main, Panel 2 (Image 3)
Rules violated: 1.3, 5.1, 5.4
Description: The Art Bible v1.0 describes Kael as helping the player "defeat the Arena Realm"
  and as "the strength of the group" — confirming combat framing and a power role that
  conflict with both no-combat canon and the locked Option A civic contribution resolution
  for Kael (Conflict 3).
Source A (new content): "Brave, determined and adventurous, Kael helps you defeat the Arena
  Realm and is the strength of the group."
Source B (locked canon): Rule 1.3: GemVerse avoids combat as a core mechanic or player
  motivation. Rule 5.1: Guardians are framed as contributors, not saviors or heroes.
  Rule 5.4: Content avoids chosen-one language or framing. Conflict 3 in the Conflicts Log
  flagged Kael's Arena Champion framing as unresolved; Perplexity session canon established
  Option A (civic contribution) as the resolution direction. The Art Bible text confirms
  this conflict is now present in the transferred visual canon.
Severity: HIGH
Recommended action: Stop and return to creator. Do not resolve. Kael's character art is
  Transferred but cannot be tagged Approved. The descriptor text must be reframed to reflect
  civic contribution identity (Option A) — e.g., Kael as a community organizer, civic
  champion, or contribution leader within the Arena Realm — before any art or copy
  referencing Kael's role can be finalized.
```

---

### RISK 03 — Power-ups & Boosters (All Named Items)

```
CANON RISK — Power-up / Booster Assets ("Harmony Blast," "Star Blast," "Colour Bomb," etc.)
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 main Panel 9 (Image 3);
  Consolidated Art Bible (Image 4)
Rules violated: 6.1, 1.4
Description: Named power-up and booster items are shown with visual blast/explosion effects,
  framing them as power advantages rather than puzzle tools — a standing canon risk that is
  now confirmed and expanded across two transferred documents.
Source A (new content): Image 3 names: Harmony Blast, Star Blast, Colour Bomb, Sparkle,
  Crystal Pearl. Image 4 names: Moonlight Blast, Vertical Blast, Arial Blast, Colour Bomb,
  Crystal Pearl. All shown with visual power effects suggesting external force applied to
  the puzzle board.
Source B (locked canon): Rule 1.4: GemVerse avoids power escalation as a reward system.
  Rule 6.1: Puzzles exist as fragments of civilization with a worldbuilding reason, not as
  arbitrary obstacles. The Puzzle Design Test asks: Why does it exist? Who created it? What
  purpose? What does it reveal? A "Colour Bomb" or "Harmony Blast" used as a purchased or
  earned board-clearing tool cannot pass this test and positions puzzle-solving as a power
  fantasy, not a restoration act.
Severity: HIGH
Recommended action: Stop and return to creator. Do not resolve. Creator must determine
  whether these items are reframeable as puzzle tools with worldbuilding identity (canon-safe)
  or whether they function as power advantages that must be redesigned or removed. No
  power-up or booster asset may be tagged Approved under the current framing.
```

---

### RISK 04 — "Challenge Your Mind. Save the Realms." Tagline Variant

```
CANON RISK — Tagline Variant ("Challenge Your Mind. Save the Realms.")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Consolidated Art Bible / Summary Sheet
  (Image 4)
Rules violated: 1.5, 5.1
Description: A new tagline variant shown in the Consolidated Art Bible uses "Save the Realms"
  language, framing the Guardian role as hero/savior — directly conflicting with locked canon
  that positions Guardians as contributors, not saviors.
Source A (new content): "Challenge Your Mind. Save the Realms."
Source B (locked canon): Rule 1.5: GemVerse avoids chosen-one or hero-saves-the-world
  narrative framing. Rule 5.1: Guardians are framed as contributors, not saviors or heroes.
  The approved and locked tagline is "Restore Realms. Build Your Legacy." — which correctly
  frames the Guardian action as contribution and legacy, not rescue.
Severity: HIGH
Recommended action: Stop and return to creator. Do not resolve. This tagline variant must
  not be used in any build, prototype, design file, or public-facing material. Creator
  should confirm whether this variant is formally retired. The approved tagline
  "Restore Realms. Build Your Legacy." remains the only permitted tagline.
```

---

### RISK 05 — Spark Role Framing ("Helps Complete Puzzles")

```
CANON RISK — Spark Role Descriptor ("helps complete puzzles and is the narrator of the realm")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 + UI Wireframes Panel 2
  (Image 2); Art Bible v1.0 main Panel 2 (Image 3)
Rules violated: 4.1, 4.2
Description: Spark is described in both Art Bible versions as a character who "helps complete
  puzzles" — reducing the companion's canonical identity from witness and partner to a
  puzzle mechanic or assistance tool.
Source A (new content): "Helps complete puzzles and is the narrator of the realm."
  (Repeated identically in both Image 2 and Image 3.)
Source B (locked canon): Rule 4.1: Companions are treated as witnesses, partners, and
  historical survivors — not pets, tools, or collectibles. Rule 4.2: Content avoids framing
  Companions as power-ups or combat assets. Spark's locked canon themes are Hope, Curiosity,
  and Beginnings. The companion's role is to witness, accompany, and share their own
  perspective — not to assist the player mechanically with puzzle completion.
Severity: MEDIUM
Recommended action: Stop and return to creator. Do not resolve. Spark's role descriptor
  must be reframed before the character sheet can be tagged Approved. Suggested framing
  direction: Spark as companion and witness who "shares the realm's stories" or "travels
  alongside the Guardian" — not as a puzzle-solving tool or narrator-mechanic.
```

---

### RISK 06 — "Heart of the Core" — Unknown Realm Name

```
CANON RISK — "Heart of the Core" (unrecognized realm environment)
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 main Panel 3 (Image 3)
Rules violated: 8.3 (visual canon must be consistent with locked canon; 8.4: no asset tagged
  Approved without explicit creator review)
Description: An eighth realm environment appears in the Art Bible labeled "Heart of the Core"
  with the description "The realm at the very heart of the world." This name does not match
  any of the nine confirmed realms in locked canon. Its identity, role, and relationship to
  existing realms cannot be determined from the transferred material alone.
Source A (new content): "Heart of the Core — The realm at the very heart of the world."
  Shown as the 8th environment panel in a set of realm art.
Source B (locked canon): Nine confirmed realms (locked in Canon Map): Arena Realm, Crystal
  Forest, Sky Citadel, Frozen Expanse, Ember Depths, Twilight Frontier, Celestial Nexus,
  Legacy Realm, Memory Ocean. "Heart of the Core" matches none of these. Possible
  interpretations — (a) a 9th Realm not previously documented; (b) a working title or
  alternate name for Memory Ocean; (c) a working title or alternate name for Legacy Realm;
  (d) a concept environment not intended as a canonical realm.
Severity: MEDIUM
Recommended action: Stop and return to creator. Do not resolve. Asset has been logged as
  Transferred with a FLAGGED status in the registry. Creator must confirm identity before
  this environment can be associated with any canonical realm or tagged Approved.
```

---

### RISK 07 — Resource Bars (Crystal/Ember/Star) — Possible Energy System

```
CANON RISK — Home Screen Resource Bars (Crystal / Ember / Star)
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 + UI Wireframes Panel 1
  and Panel 5 (Images 2 & 3)
Rules violated: Potential violation of Rule 1.6 (energy systems that block play)
Description: The Home Screen UI mockup displays visible resource bars labeled Crystal, Ember,
  and Star (or similar currency types). The function of these bars — whether they gate play
  access or represent collection progress — cannot be determined from the visual alone.
Source A (new content): Home Screen shows resource/currency bars with gem icons and numeric
  values visible in the UI header area.
Source B (locked canon): Rule 1.6: GemVerse avoids pay-to-win, exploitative monetization,
  or energy systems that block play. The confirmed monetization model permits cosmetics,
  visual themes, companion skins, housing, festivals, profile items, founder packs, and
  physical merchandise. It does not permit energy systems that gate gameplay.
Severity: MEDIUM (conditional — depends on function)
Recommended action: Stop and return to creator. Do not resolve. Creator must confirm
  whether these resource bars are: (a) collection resources or cosmetic currencies (canon-safe),
  or (b) energy/stamina systems that limit how often a player can engage (not canon-safe).
  Asset tagged Transferred pending clarification.
```

---

### RISK 08 — Special Gems (Bomb Gem, Lightning Gem, Rainbow Gem)

```
CANON RISK — Special Gem Types (Bomb Gem / Lightning Gem / Rainbow Gem)
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Construct 3 Development Bible Panel 4
  (Image 1)
Rules violated: 1.4, 6.1
Description: The Construct 3 Development Bible confirms three named "special gems" with
  implied destructive or transformative board effects — framing them as power mechanics
  rather than puzzle elements with worldbuilding purpose.
Source A (new content): "Special gems: Bomb Gem, Lightning Gem, Rainbow Gem." Listed in
  Puzzle Detection (Match 3 Board) panel of the Development Bible.
Source B (locked canon): Rule 1.4: GemVerse avoids power escalation as a reward system.
  Rule 6.1: Puzzles exist as fragments of civilization, not arbitrary obstacles. Bomb and
  Lightning naming implies external destructive force — the opposite of restoration.
Severity: MEDIUM
Recommended action: Stop and return to creator. Do not resolve. Creator to confirm whether
  these mechanics can be reframed as restoration tools with worldbuilding identity (e.g., a
  Crystal Resonance gem that realigns connected gems), or whether the Bomb/Lightning naming
  must be replaced. No special gem type may be tagged Approved with destruction-implied naming.
```

---

### RISK 09 — Scoring / Combo System (2x, 3x, 4x+ Multipliers)

```
CANON RISK — Combo Multiplier System (2x / 3x / 4x+)
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Construct 3 Development Bible Panel 5
  (Image 1)
Rules violated: 1.4
Description: The Development Bible confirms a scoring combo system with explicit power
  multipliers (2x, 3x, 4x+), framing puzzle play as a power escalation loop rather than
  a contribution or restoration act.
Source A (new content): "Combo system: 2x, 3x, 4x+ multiplier" confirmed in Scoring System
  panel of the Construct 3 Development Bible.
Source B (locked canon): Rule 1.4: GemVerse avoids power escalation as a reward system.
  The franchise philosophy states: "Power + Combat + Competition + Dominance = project
  weakens." Numerical power multipliers that escalate with consecutive play are a standard
  power-fantasy reward loop that conflicts with contribution-based progression.
Severity: MEDIUM
Recommended action: Stop and return to creator. Do not resolve. Creator to confirm whether
  the combo system can be reframed as a harmony/flow reward (e.g., "Harmony Flow" instead of
  "4x Multiplier") with language and design that reflects restoration momentum rather than
  power accumulation. Scoring mechanics tagged Transferred pending review.
```

---

### RISK 10 — Arena Realm Description ("Ancient Strength" Framing)

```
CANON RISK — Arena Realm Environment Description ("A lush realm of ancient strength")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 main Panel 3 (Image 3)
Rules violated: Soft conflict with Rule 1.3; inconsistent with locked Arena Realm civic theme
Description: The Art Bible describes the Arena Realm as "A lush realm of ancient strength" —
  using "strength" as the defining quality, which carries combat/power connotations
  inconsistent with the Arena Realm's locked civic/community theme.
Source A (new content): "Arena Realm — A lush realm of ancient strength."
Source B (locked canon): The Arena Realm's locked theme is Community (Canon Map). It "acts
  as crossroads and hub" and is the most connected realm. Under Kael Option A resolution,
  the Arena Realm's identity is civic contribution, not physical strength or combat.
Severity: LOW-MEDIUM
Recommended action: Return to creator for note. Not a blocking risk on its own, but
  consistent with the Kael/Arena Realm reframe requirement (Risk 02 above). The description
  should be revised to reflect community, connection, and civic vitality rather than strength.
```

---

### RISK 11 — Ember Depths Description ("Primal Strength" Framing)

```
CANON RISK — Ember Depths Environment Description ("A fiery realm of primal strength")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Art Bible v1.0 main Panel 3 (Image 3)
Rules violated: Soft conflict with Rule 1.4; inconsistent with locked Ember Depths theme
Description: The Art Bible describes Ember Depths as "A fiery realm of primal strength" —
  using "primal strength" as the defining quality, which conflicts with Ember Depths' locked
  theme of Resilience and Determination.
Source A (new content): "Ember Depths — A fiery realm of primal strength."
Source B (locked canon): Ember Depths' locked theme is Resilience (Canon Map). Resilience
  and Determination are distinctly different from "primal strength" — one is a community
  quality earned through endurance, the other implies raw physical power.
Severity: LOW-MEDIUM
Recommended action: Return to creator for note. Suggested reframe: "A fiery realm of
  endurance and determination" or similar, consistent with the Resilience theme.
```

---

### RISK 12 — "Collection Guardian" Achievement Badge

```
CANON RISK — "Collection Guardian" Achievement Badge
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Consolidated Art Bible (Image 4)
Rules violated: Potential soft conflict with Rule 4.4 (companion collection ≠ gacha)
Description: The achievement badge name "Collection Guardian" may imply that companions
  are collectible items to be accumulated, rather than relationships to be cultivated.
Source A (new content): Achievement badge named "Collection Guardian" among 8 badges in the
  Consolidated Art Bible.
Source B (locked canon): Rule 4.4: Companion collection must feel like relationship-building,
  not gacha or power collection. The word "Collection" in a badge title risks reinforcing
  a collect-them-all framing.
Severity: LOW
Recommended action: Return to creator for note. This is low risk — the badge may have
  benign intent. Creator to confirm whether the badge name can be revised (e.g., "Companion
  Keeper," "Bond Builder," "Companion Friend") to emphasize relationship over collection.
```

---

### RISK 13 — "One Puzzle. Countless Realms." Tagline Variant

```
CANON RISK — Tagline Variant ("One Puzzle. Countless Realms.")
Date: 2026-06-01
Document/task flagged: Visual Asset Transfer Intake — Consolidated Art Bible / Summary Sheet
  (Image 4)
Rules violated: Soft conflict with franchise identity (GemVerse is NOT a puzzle game with lore)
Description: A tagline variant positions "Puzzle" as the primary GemVerse identifier, which
  conflicts with the locked franchise statement that GemVerse is a civilization adventure
  that uses puzzles — not a puzzle game with lore.
Source A (new content): "One Puzzle. Countless Realms." — shown as tagline variant in
  Consolidated Art Bible.
Source B (locked canon): Canon Map (locked): "GemVerse is NOT a puzzle game with lore. It is
  a civilization adventure that uses puzzles." Approved tagline: "Restore Realms. Build
  Your Legacy." This variant foregrounds puzzle identity over civilization identity.
Severity: LOW
Recommended action: Return to creator for note. Not a blocking risk, but creator should
  confirm whether this variant is retired or reserved for specific marketing contexts where
  puzzle-first positioning is intentional (e.g., app store puzzle category metadata only).
```

---

## WHAT CAN PROCEED — Canon-Safe Assets (Transferred, No Blocking Risk)

The following assets were confirmed in the visual transfer and are canon-consistent. They are logged as Transferred. They may not be tagged Approved without explicit creator confirmation but carry no blocking canon risks.

| Asset | Reason It Can Proceed |
|---|---|
| Aurora character sheet (full) | Role "Guardian Guide. Story Teller." is canon-consistent. Expressions and colour palette confirmed. |
| Lyra character art (full body) | "Curious and adventurous, explores new Realms and discovers mysteries" — fully consistent with Realm Explorer / Pathfinder framing. |
| Crystal Forest environment | "A crystalline realm filled with living crystal and harmony" — directly aligns with Knowledge/Harmony theme. |
| Sky Citadel environment | "A sky realm of boundless discovery and adventure" — directly aligns with Discovery theme. |
| Frozen Expanse environment | "A realm of silence and deep memory" — excellent alignment with Memory theme. |
| Twilight Frontier environment | "Mysterious lands with untold stories and awakening quests" — consistent with Imagination/Mystery theme. |
| Celestial Nexus environment | "Where stars align and wisdom grows" — consistent with Wonder theme. |
| Realm Map (isometric overview) | Shows connected realms — aligns with restoration-era world structure. |
| GemVerse Logo (primary + secondary) | Cinzel Semibold confirmed. No canon risk. |
| App Icon variants (all 4) | No canon risk in visual motifs. None Approved — creator confirmation required for final selection. |
| "Restore Realms. Build Your Legacy." tagline | Already Approved. Confirmed present in transferred materials. |
| Cinzel Semibold + Satoshi / Cabinet Grotesk fonts | Both confirmed. No canon risk. |
| Brand style tags (Magical, Inspiring, Welcoming, Premium, Adventurous) | Fully consistent with franchise tone. |
| Colour palette (Crystal Blue, Emerald, Amethyst, Sunset, Pure White, Deep Indigo) | Confirmed in Art Bible. Relationship to Lantern Gold/Archive Blue requires creator mapping — no blocking risk. |
| Match-3 board mockup (prototype) | No canon risk in the visual structure. Text and framing issues handled separately. Retain as reference. |
| Daily Puzzle screen mockup | Stats shown (accuracy, streak, days) reflect contribution/practice — consistent with contribution-based progression. |
| Level Complete screen | Score and gems earned — no canon risk in the UI structure. |
| Profile screen | Guardian level, streak, companions — no canon risk. |
| Navigation tabs (Story, Quests, Companions, Realms, Academy, Museum) | Museum as Archive interface is consistent with locked Great Archive canon. |
| Achievement badges (First Steps, Puzzle Master, Streak Keeper, Realm Restorer, Academy Graduate, Daily Pal, Daily Dedicated) | Seven of eight badges are consistent with contribution/recognition framing. "Collection Guardian" flagged separately (LOW). |
| Construct 3 Development Bible | Technical platform, scene structure, puzzle types — no canon risk in platform/technical choices. |
| Icon Style Guide (6 styles) | Visual style references — no canon risk. |
| Visual effects style (Match, Crystal, Bonus Pop-up, Victory) | Style references — no canon risk. |
| Verdant companion art (first visual) | Green plant creature consistent with Growth/Renewal/Patience theme. Canon status pending full encyclopedia entry. |

---

## WHAT MUST WAIT — Assets That Cannot Be Tagged Approved Without Creator Input

| Asset | Blocker |
|---|---|
| Story Screen text | CRITICAL — must be fully rewritten. No version of current text may proceed. |
| Kael character art | HIGH — reframe of role descriptor required before Approved. Art is Transferred. |
| All power-up / booster items | HIGH — creator must determine puzzle tool vs. power advantage. |
| "Save the Realms" tagline variant | HIGH — must be formally retired. |
| Spark character sheet | MEDIUM — role descriptor must be reframed before Approved. |
| "Heart of the Core" environment | MEDIUM — creator must identify this realm before any association or approval. |
| Resource bars (Crystal/Ember/Star) | MEDIUM — function must be confirmed (collection vs. energy-gating). |
| Special gems (Bomb, Lightning, Rainbow) | MEDIUM — naming must be reviewed for power framing. |
| Combo multiplier system | MEDIUM — framing must be reviewed for power escalation. |
| Lumi, Ember, Frosty companion art | MEDIUM — Conflict 6 (launch status) unresolved. |
| Realm descriptions (Arena "strength", Ember Depths "primal strength") | LOW-MEDIUM — reframe recommended alongside Kael/Arena resolution. |
| "Collection Guardian" badge | LOW — badge rename recommended. |
| "One Puzzle. Countless Realms." tagline | LOW — creator to confirm retired or contextually permitted. |
| Gem type count discrepancy (6 vs 7) | LOW-MEDIUM — creator to confirm final gem set. |

---

*End of Canon Risk Report CRR-20260601. No conflicts have been resolved by Computer. All items returned to creator.*
