# Harmony Index System Design
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.2  
**Linked Files:** `01-canon-map.md`, `imp-01-first-harmony-daily-life.md`, `imp-03-citizen-life-layer.md`, `imp-04-companion-relationship-web.md`

---

## Overview

The Harmony Index is **not a metric system**. It is a **qualitative framework** for understanding and visualizing civilizational health — a way for citizens to feel the state of their communities, realms, and civilization without reducing belonging to numbers.

In the First Harmony, the Harmony Index was a living practice — communities regularly gathered to assess their collective wellbeing through dialogue, observation, and shared reflection. There were no dashboards, no leaderboards, no numerical scores. There was only the felt sense of harmony: Are we listening to each other? Are our systems serving everyone? Is our work contributing to what matters?

The Restoration Era adaptation maintains this philosophy while providing gentle structure for communities relearning how to practice harmony assessment.

---

## Core Philosophy

### Three Principles

1. **Felt Over Measured** — Harmony is experienced, not calculated. The Index provides frameworks for attention, not instruments for quantification.

2. **Participation Over Observation** — You understand harmony by participating in its assessment, not by reading reports about it.

3. **Restoration Over Perfection** — The goal is not a perfect score but the ongoing practice of noticing what needs tending and tending to it.

### What the Harmony Index Is NOT
- A numerical score (no 0-100, no stars, no tiers with numbers)
- A comparison tool (no realm rankings, no citizen leaderboards)
- A gatekeeping mechanism (no content locked behind harmony thresholds)
- A monetization lever (no harmony-boosting purchases)
- A progress bar (no "87% harmonious")

### What the Harmony Index IS
- A language for describing civilizational health
- A practice of collective attention
- A framework for identifying what needs care
- A celebration of what's working
- A guide for where to contribute next

---

## Three-Level Framework

The Harmony Index operates at three nested scales, each informing the others:

### Level 1: Personal Harmony (Individual Reflection)
**Scale:** Single citizen's experience  
**Practice:** Seasonal self-reflection guided by Path principles  
**Output:** Personal harmony map — a visual, non-numerical representation

**Path-Aligned Reflection Prompts:**
- **Scholar Path**: "What have I learned that serves others? What questions am I carrying?"
- **Pathfinder Path**: "Where have I traveled that created connection? What paths need tending?"
- **Steward Path**: "What have I maintained that supports community? What needs my care?"
- **Chronicler Path**: "What stories have I preserved? What voices need amplifying?"
- **Mentor Path**: "Who have I guided? What guidance do I need?"
- **Harmonist Path**: "Where have I brought balance? What tensions need attention?"

**Visual Representation:** A living diagram — not a chart. Elements might include:
- Connected circles (relationships)
- Growing vines (learning/development)
- Flowing rivers (contribution flow)
- Anchored stones (commitments kept)
- Open windows (perspectives welcomed)

### Level 2: Community Harmony (Local Assessment)
**Scale:** Neighborhood, district, or small Realm community  
**Practice:** Seasonal Community Harmony Circles — facilitated gatherings  
**Output:** Community harmony tapestry — collaborative visual artifact

**Assessment Dimensions (All Qualitative):**
- **Listening Quality**: How well do we hear each other?
- **Contribution Flow**: Does work reach where it's needed?
- **Conflict Transformation**: Do disagreements deepen understanding?
- **Inclusion Reality**: Who's missing from our circles?
- **Celebration Practice**: Do we honor each other's contributions?
- **Adaptation Capacity**: How do we respond to change?
- **Intergenerational Connection**: Are elders and youth in dialogue?
- **Companion Integration**: Do companions participate as partners?
- **Environmental Relationship**: How do we tend our place?
- **Cross-Realm Openness**: Are we connected beyond our borders?

**Process:**
1. **Preparation** (1 week): Citizens reflect individually using Path prompts
2. **Gathering** (2-3 hours): Facilitated dialogue using structured conversation guides
3. **Co-Creation** (1 week): Community creates harmony tapestry together
4. **Display** (ongoing): Tapestry displayed in community space, updated as things change
5. **Action** (continuous): Identified needs become community projects

**Facilitation:** Rotating citizen facilitators trained in Harmony Circle practice. Companions (especially Solen, Mira, Prism) often participate as supportive presences.

### Level 3: Civilizational Harmony (Realm & Cross-Realm)
**Scale:** Full Realm or multi-Realm assessment  
**Practice:** Annual Harmony Convergence — representatives from all communities  
**Output:** Civilizational harmony map — living document updated continuously

**Assessment Dimensions (Expanded):**
All Community dimensions, plus:
- **Restoration Momentum**: Are we healing the Five Wounds?
- **Knowledge Circulation**: Does wisdom flow where needed?
- **Resource Equity**: Are materials, skills, attention distributed fairly?
- **Aspirational Alignment**: Does daily work connect to civilizational vision?
- **Mystery Relationship**: Do we honor what we don't understand?
- **Future Orientation**: Are we good ancestors?
- **Companion-Citizen Partnership**: Are relationships deepening?
- **Festival Vitality**: Are our celebrations meaningful and inclusive?
- **Archive Integrity**: Is our memory serving the present?
- **Lantern Network Health**: Are connections maintained and growing?

**Process:**
1. **Realm Assemblies** (monthly): Each Realm conducts its own assessment
2. **Cross-Realm Dialogues** (quarterly): Border communities share insights
3. **Harmony Convergence** (annual): Representatives gather at Arena Realm
4. **Living Map Maintenance** (continuous): Dedicated citizens update the map
5. **Restoration Planning** (ongoing): Identified needs inform project priorities

---

## Visualization Design (No Numbers, No Metrics)

### Personal Harmony Map
**Format:** Interactive, evolving diagram  
**Elements:**
- **Center**: Core self (represented by Path symbol)
- **Connections**: Lines to people, projects, places, companions
- **Growth Indicators**: Organic forms (vines, roots, branches, rivers)
- **Tension Markers**: Gentle knots or bends showing where attention needed
- **Celebration Blooms**: Flowers appearing where contributions flourished
- **Seasonal Layers**: Translucent overlays showing change over time

**Interaction:**
- Tap any element → see story/context (not statistics)
- Add elements through reflection prompts
- Share selectively with mentors, friends, companions
- No export, no comparison, no aggregation

### Community Harmony Tapestry
**Format:** Physical/digital collaborative artwork  
**Creation:** Made together during Harmony Circles  
**Materials:** Fabric, thread, natural materials, digital equivalent  
**Elements:**
- **Warp threads**: Community's enduring values
- **Weft threads**: Current projects, relationships, challenges
- **Knots**: Tensions being worked on (visible, not hidden)
- **Embroidered symbols**: Celebrations, milestones, memories
- **Empty spaces**: Acknowledged gaps, missing voices
- **Border**: Community's relationship to other communities

**Display:** Prominent community location. Updated continuously. New citizens add their thread on arrival.

### Civilizational Harmony Map
**Format:** Large-scale living installation (Arena Realm Great Archive) + distributed digital reflection  
**Scope:** All Realms, updated by dedicated Harmony Keepers  
**Elements:**
- **Realm nodes**: Each Realm's tapestry essence
- **Connection threads**: Lantern Network routes, trade, knowledge exchange
- **Wound indicators**: Gentle representations of the Five Wounds' current state
- **Restoration blooms**: Where healing is visibly happening
- **Mystery horizons**: Representations of open questions
- **Aspiration stars**: Civilizational commitments visible on horizon
- **Companion pathways**: Routes companions travel between communities

**Access:** Any citizen can visit the physical map. Digital reflection allows remote viewing and contribution.

---

## Companion Integration

Each companion family contributes uniquely to Harmony Index practice:

### Crystalkin (Spark, Prism)
- **Spark**: Energizes Personal Harmony reflection — "What lit you up this season?"
- **Prism**: Facilitates multi-perspective seeing in Community Circles — "How does this look from there?"

### Forestkin (Verdant, Bloomtail)
- **Verdant**: Guides environmental relationship assessment — "How does the land feel about our presence?"
- **Bloomtail**: Supports inclusion reality checks — "Who's at the edge of our circle?"

### Skykin (Nimbus, Galewing)
- **Nimbus**: Brings cross-Realm perspective — "What winds are blowing from other Realms?"
- **Galewing**: Facilitates large-scale Convergence logistics — "How do we gather well?"

### Frostkin (Frostpaw, Echo)
- **Frostpaw**: Provides long-term memory context — "What did our ancestors notice here?"
- **Echo**: Preserves Harmony Circle stories — "What was said that must not be lost?"

---

## Path Progression Integration

Harmony Index replaces traditional progression systems:

### Instead of XP/Levels:
- **Path Deepening**: Seasonal reflection shows growing sophistication in practice
- **Contribution Breadth**: Harmony tapestry reveals expanding circles of impact
- **Mentorship Emergence**: Others naturally seek your guidance (visible in tapestry)
- **Cross-Path Fluency**: Ability to facilitate other Paths' reflection prompts

### Recognition (Non-Numerical):
- **Harmony Threads**: Added to community tapestry for sustained contribution
- **Tapestry Keeper**: Citizens who maintain the physical/digital tapestry
- **Circle Facilitator**: Trained to lead Harmony Circles (rotating, not permanent)
- **Convergence Representative**: Chosen by community to attend annual gathering
- **Harmony Keeper**: Dedicated citizens maintaining Civilizational Harmony Map

---

## Technical Implementation Notes

### Data Schema (Minimal, Qualitative)
```json
{
  "personalHarmonyMap": {
    "lastReflectionDate": "ISO date",
    "path": "scholar|pathfinder|steward|chronicler|mentor|harmonist",
    "elements": [
      { "type": "connection|growth|tension|celebration|season", "story": "text", "connections": ["elementIds"] }
    ],
    "sharedWith": ["citizenIds", "companionIds"]
  },
  "communityTapestry": {
    "communityId": "string",
    "lastCircleDate": "ISO date",
    "participants": ["citizenIds"],
    "threads": [
      { "type": "warp|weft|knot|embroidery|space|border", "story": "text", "contributors": ["citizenIds"] }
    ],
    "facilitator": "citizenId",
    "displayLocation": "physical|digital"
  },
  "civilizationalMap": {
    "lastConvergenceDate": "ISO date",
    "realmNodes": ["realmId"],
    "connectionThreads": [{ "from": "realmId", "to": "realmId", "type": "lantern|trade|knowledge|companion", "health": "thriving|tending|dormant|severed" }],
    "woundIndicators": [{ "wound": "knowledge|community|memory|growth|discovery", "state": "healing|stable|needs attention" }],
    "restorationBlooms": [{ "location": "realmId", "description": "text", "contributors": ["citizenIds"] }],
    "mysteryHorizons": [{ "realm": "realmId", "description": "text" }],
    "aspirationStars": [{ "commitment": "text", "originRealm": "realmId", "supporters": ["citizenIds"] }],
    "companionPathways": [{ "companion": "name", "route": ["realmIds"], "frequency": "regular|seasonal|rare" }]
  }
}
```

### No Analytics Tracking
- No "harmony score" calculations
- No engagement metrics tied to harmony
- No A/B testing of harmony features
- No data sold or shared externally
- Data exists only to support the practice, not to measure it

### Accessibility
- All reflection prompts available in text, audio, visual formats
- Harmony Circles designed for diverse participation styles (speaking, writing, drawing, silence)
- Tapestries can be physical, digital, or hybrid
- No time pressure, no performance expectation

---

## Festival Integration

Each festival includes a Harmony Index practice:
- **Festival of Beginnings** → Personal Harmony Map creation for newcomers
- **Lantern Gathering** → Community Tapestry thread for each connection celebrated
- **Harmony Week** → Community Harmony Circles (primary annual practice)
- **Mentor Celebration** → Mentor threads added to tapestries
- **Growth Festival** → Environmental relationship assessment
- **Discovery Festival** → Cross-Realm connection mapping
- **Memory Festival** → Ancestral thread integration
- **Resilience Festival** → Tension knot acknowledgment
- **Imagination Festival** → Aspiration star creation
- **Wonder Festival** → Civilizational Harmony Map visit/contribution

---

## Monetization Boundary (Explicit)

**The Harmony Index is entirely outside monetization.**
- No cosmetic purchases affect harmony visualization
- No "premium" reflection prompts
- No tapestry customization for purchase
- No Convergence access for sale
- No Harmony Keeper status for purchase

Cosmetics from festivals (scarves, charms, etc.) are earned through participation only.

---

## Restoration Connection

The Harmony Index directly serves the Five Wounds restoration:

| Wound | Harmony Index Role |
|-------|-------------------|
| **Knowledge — Fragmentation** | Community Circles integrate fragmented knowledge through dialogue |
| **Community — Division** | Tapestry makes division visible and reparable |
| **Memory — Forgetting** | Ancestral threads preserve what matters |
| **Growth — Decay** | Environmental assessment catches decay early |
| **Discovery — Isolation** | Cross-Realm mapping reveals and repairs isolation |

---

## Implementation Priority

### Phase 1 (MVP)
- Personal Harmony Map (all 6 Path reflection prompts)
- Community Harmony Circle guides (facilitator training + conversation guides)
- Community Tapestry creation tools (physical + digital)
- Festival integration for 4 launch festivals

### Phase 2 (Post-Launch)
- Civilizational Harmony Map (Arena Realm installation)
- Cross-Realm dialogue framework
- Annual Convergence structure
- Companion integration deepening

### Phase 3 (Long-term)
- Advanced facilitation training
- Inter-civilizational harmony exchange (if other civilizations discovered)
- Harmony Index as cultural export (sharing the practice)
- Academic/archival study of harmony practice evolution