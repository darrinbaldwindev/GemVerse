# Citizen Encyclopedia Entry — Taren
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.12  
**Linked Files:** `01-canon-map.md`, `imp-03-citizen-life-layer.md`, `imp-04-companion-relationship-web.md`

---

## Overview

**Name:** Taren  
**Themes:** Exploration, Adventure, Discovery  
**Path Alignment:** Pathfinder Path (Discovery Pillar)  
**Visual Identity:** [Pending - Character art not yet available]  
**Symbol:** Compass with Blooming Path (representing discovery that creates life)  
**Notable Traits:** Fearless curiosity, natural route-finding ability, deep respect for the journey

---

## 1. Background

Taren was born in the Sky Citadel to a family with generations of Pathfinder service. Their earliest memories involve the wind on high platforms, the smell of distant Realms carried on air currents, and the stories of explorers returning from journeys that expanded civilization's understanding of itself.

Unlike some Pathfinder families who emphasized mapping and documentation, Taren's family emphasized the *experience* of discovery - the moment when a new perspective suddenly makes everything look different, the realization that a path you've walked a hundred times can still reveal something you never noticed, the understanding that the most important discoveries are often about yourself.

Taren's formal training began early, learning to read wind patterns, identify safe routes, document findings in ways that would be useful to future travelers, and most importantly, how to travel with companions - both the companion creatures who choose to accompany explorers, and the human companions who join expeditions.

A defining moment came during Taren's first solo journey - a traditional rite of passage for young Pathfinders. Instead of taking the well-documented route to the Crystal Forest, Taren followed a barely-visible wind current that Nimbus had mentioned in passing. This led to the discovery of a previously unknown seasonal migration route used by Skykin companions - a discovery that benefited both the Pathfinder community and the companion families.

---

## 2. Role in Society

Taren serves as an **Exploration Methodology Specialist** in the Sky Citadel, working at the intersection of practical route-finding and the deeper questions of what discovery means for civilization. Their role involves:

- **Route Development**: Finding and documenting new pathways between Realms and within Realms
- **Exploration Training**: Teaching new Pathfinders not just technical skills but the philosophy of discovery
- **Cross-Realm Coordination**: Working with citizens in other Realms to ensure routes serve community needs
- **Companion Partnership**: Collaborating with Skykin and other exploration-aligned companions

Taren is particularly valued for their approach to discovery as a *relational* practice rather than a *conquest* practice. They don't "claim" routes or discoveries - they document them in ways that benefit the communities they connect, and they always consider the impact of increased accessibility on the places and people being "discovered."

They also serve as a bridge between the structured Pathfinder tradition and the more intuitive exploration methods of companions like Nimbus and Galewing. When Archive scholars want to understand a phenomenon in a distant Realm, Taren helps design an exploration approach that respects both the scientific need for documentation and the civilizational need for respectful engagement.

---

## 3. Relationships

### Companion Connections

Taren has developed particularly strong relationships with several companions:

- **Nimbus**: Primary exploration partner. Nimbus's wind-reading provides the data; Taren's route-finding provides the methodology. They communicate in a shorthand of wind-patterns and route-marks.
- **Galewing**: Collaborates on large-scale exploration projects. Galewing's path-singing creates the infrastructure; Taren provides the methodological framework.
- **Lyra**: Professional peer and frequent collaborator. Lyra's Realm Explorer perspective complements Taren's Pathfinder methodology.
- **Verdant**: Unexpected but fruitful connection. Verdant's growth-pattern understanding helps Taren identify where new routes might support environmental restoration.

### Citizen Relationships

- **Mentor**: A senior Pathfinder who taught Taren that the best routes serve the people who walk them
- **Peers**: Other Pathfinder Path practitioners who share methodological debates and collaborative projects
- **Apprentices**: Younger citizens learning the Pathfinder craft, both technical and philosophical
- **Cross-Realm Contacts**: Citizens in other Realms who host Pathfinder waystations and benefit from route connections

### Institutional Relationships

- **Pathfinder Guild Council**: Technical advisor on exploration methodology standards
- **Archive Discovery Documentation Division**: Primary liaison for recording new discoveries
- **Inter-Realm Route Coordination Committee**: Represents Pathfinder perspective in route planning

---

## 4. Personal Goal

Taren's current personal goal is to develop a **Sustainable Discovery Framework** - an approach to exploration that ensures new connections benefit all communities involved without disrupting the environments or cultures that make those communities unique.

This involves:
- Developing "impact assessment" methodologies for new routes that consider cultural and environmental factors
- Creating "community consent" protocols for exploration in or near inhabited areas
- Building "knowledge return" systems ensuring discoveries benefit the communities where they're made
- Establishing "explorer responsibility" training that emphasizes relationship over achievement

They're working on this with Pathfinder elders, community leaders from multiple Realms, and companions who understand the difference between discovering *for* a civilization and discovering *as part of* a civilization.

---

## 5. Contribution Story

Taren's most significant contribution came during a period when several long-dormant routes between the Sky Citadel and the Frozen Expanse were being considered for restoration. The technical challenges were significant - the high-altitude paths were treacherous, and the seasonal windows for safe travel were narrow.

The standard Pathfinder approach would have been to wait for optimal conditions, send the most experienced explorers, and document the route for future use. Taren proposed a different approach: **Community-Guided Restoration**.

Instead of sending elite explorers, Taren organized mixed teams of citizens from both Realms - scholars, artisans, elders, youth - to work on the route restoration together. The technical Pathfinder work was shared among all participants, with experienced explorers teaching as they went. The project became as much about rebuilding the relationship between the two Realms as about restoring the physical route.

The results were remarkable:
- The route was restored faster than technical projections suggested, because more hands were available for the physical work
- The citizens who participated developed personal connections across the Realms, creating a social foundation for ongoing exchange
- The restored route was designed with community needs in mind from the start, not as an afterthought
- The methodology has been adopted for other cross-Realm route restorations

This contribution demonstrated that discovery is most meaningful when it's a shared civilizational activity rather than an individual achievement.

---

## 6. Legacy Story

Taren's **Sustainable Discovery Framework** is being integrated into Pathfinder training across multiple Realms. The emphasis on community impact, relational exploration, and discovery as civilizational service rather than personal achievement represents a significant philosophical shift.

Archive scholars have documented Taren's approach as an important evolution in civilizational exploration methodology - one that addresses the imbalances that contributed to the Wound of Discovery by ensuring that new connections serve belonging rather than isolation.

Taren hopes their legacy will be a civilization where every new path creates not just a connection between places, but a connection between people. They see exploration not as finding what's "out there," but as discovering what's possible "between us."

---

## Citizen Abilities (Narrative, Not Mechanical)

- **Route Intuition**: Can identify promising paths where others see only obstacles
- **Exploration Philosophy**: Understands discovery as relational practice, not conquest
- **Community-Integrated Planning**: Designs exploration projects that serve community needs
- **Cross-Cultural Navigation**: Bridges different Realm approaches to exploration and discovery
- **Mentorship Facilitation**: Teaches both technical skills and the deeper purpose of exploration

---