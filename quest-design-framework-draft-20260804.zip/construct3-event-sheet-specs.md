# Construct 3 Event Sheet Specifications — Canon-Aligned
**Version:** 1.0
**Status:** Canon-Specification — Ready for Implementation
**Source:** puzzle-catalog.md Section 2 + Conflict 8 (Reframed Tools) + Conflict 11 (Threshold Model)
**Authority:** Creator confirmation — Status Mode session

---

## Purpose
Canonical technical specifications for all 8 puzzle type event sheets in Construct 3. Each spec defines:
- In-world origin & civilizational purpose (Puzzle Design Test)
- Core mechanic (not generic Match-3)
- Reframed tool integration (Conflict 8)
- Harmony Flow feedback (no power escalation)
- Archive reveal triggers

---

## Global Constants (All Event Sheets)

```javascript
// Global Constants — Canon Constraints
const CANON = {
  // Harmony Flow tiers (visual feedback ONLY — no score mult, no resource bonus)
  HARMONY_FLOW: {
    ATTUNED: { threshold: 2, glow: "soft", chime: "gentle", label: "Attuned Flow" },
    DEEP:    { threshold: 3, glow: "warm",  chime: "resonant", label: "Deep Attunement" },
    CONVERGENCE: { threshold: 4, glow: "harmonic", chime: "convergence", label: "Harmony Convergence" }
  },
  
  // Reframed Tools (reveal/illuminate/guide — NEVER destroy)
  TOOLS: {
    HARMONY_PULSE:   { type: "reveal", scope: "board-pattern",   puzzleTypes: ["Crystal Resonance"] },
    STAR_GUIDE:      { type: "highlight", scope: "route-sequence", puzzleTypes: ["Pathfinder's Mark"] },
    SPECTRUM_KEY:    { type: "identify", scope: "required-gems",  puzzleTypes: ["Verdance Cultivation"] },
    GLIMMER_HINT:    { type: "indicate", scope: "pattern-gap",    puzzleTypes: ["Community Pattern"] },
    ARCHIVE_LENS:    { type: "reveal", scope: "fragment-orient",  puzzleTypes: ["Fragment Assembly"] },
    TWILIGHT_VEIL:   { type: "preview", scope: "seal-structure",  puzzleTypes: ["Legacy Seal"] },
    COLUMN_INSIGHT:  { type: "reveal", scope: "column-pattern",   puzzleTypes: ["Crystal Resonance"] },
    WIND_SCAN:       { type: "overview", scope: "route-network",  puzzleTypes: ["Pathfinder's Mark"] }
  },
  
  // Special Gem Variants (puzzle-type specific, not destruction)
  SPECIAL_GEMS: {
    RESONANCE_GEM:    { puzzleType: "Crystal Resonance",    effect: "reveal-3x3-adjacent-fragments" },
    PATHFINDERS_BEACON: { puzzleType: "Pathfinder's Mark", effect: "reveal-connected-route-segment" },
    HARMONY_PRISM:    { puzzleType: "Harmony Alignment",    effect: "show-all-pillar-states" }
  },
  
  // Canon Constraints (HARD STOPS)
  STOP_RULES: {
    NO_DESTRUCTION:      true,
    NO_POWER_ESCALATION: true,
    NO_ENERGY_GATING:    true,
    NO_SHAME_ON_FAIL:    true,
    CIVILIZATIONAL_ORIGIN: true
  }
};
```

---

## Event Sheet 1 — Crystal Resonance (Primary Match-3 Variant)

### In-World Origin
Lumina scholars developed resonance alignment protocols during First Harmony. Crystal Network nodes embedded self-repair guides in their surface patterns. Guardians calibrate nodes by aligning gem sequences to the node's resonance pattern.

### Core Mechanic
Match-3 board with fixed resonance pattern target — not score-based. Guardian aligns gem sequences to match the node's displayed resonance pattern. Board reflects node configuration; success = node reconnects to network.

```javascript
// CrystalResonanceEventSheet
const CrystalResonance = {
  board: {
    size: { width: 8, height: 8 },
    gemTypes: ["Light", "Air", "Earth", "Water", "Fire", "Rainbow", "Dusk"],
    resonancePattern: "predefined-sequence-per-node",
    winCondition: "pattern-matched",
    loseCondition: "none"
  },
  
  tools: {
    HARMONY_PULSE:   { unlock: "node-calibration-2",  effect: "reveal-hidden-pattern-fragments" },
    COLUMN_INSIGHT:  { unlock: "node-calibration-4",  effect: "show-one-column-pattern" },
    RESONANCE_GEM:   { spawn: "on-pattern-partial-match", effect: "reveal-3x3-adjacent" }
  },
  
  harmonyFlow: {
    track: "consecutive-pattern-matches",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "node-fully-calibrated",
    fragmentType: "Knowledge Fragment",
    content: "Lumina research record / cross-Realm communication / node cultivation history"
  },
  
  puzzleDesignTest: {
    whyExist: "Crystal Network node calibration & maintenance",
    whoCreated: "Lumina scholars, First Harmony",
    originalPurpose: "Restore node alignment for knowledge distribution",
    reveals: "Civilization built repairable knowledge systems",
    restores: "Crystal Network connection + Archive fragment"
  }
};
```

---

## Event Sheet 2 — Pathfinder's Mark (Path/Route Puzzle)

### In-World Origin
Astra Pathfinders maintained waypoint systems across Eight Realms. Carved stones, marked trees, embedded symbols formed navigational keys. Decoding required understanding local geography in relation to broader network.

### Core Mechanic
Branching route reconstruction — Guardian traces/restores a Pathfinder's route through a corrupted/overgrown waypoint network.

```javascript
// PathfindersMarkEventSheet
const PathfindersMark = {
  map: {
    type: "branching-waypoint-network",
    nodes: "waypoint-stones",
    edges: "routes",
    corruption: "overgrown/damaged/missing-waypoints",
    winCondition: "route-fully-restored-to-original-intention",
    loseCondition: "none"
  },
  
  tools: {
    STAR_GUIDE:       { unlock: "route-reconstruction-2", effect: "highlight-valid-sequence" },
    WIND_SCAN:        { unlock: "route-reconstruction-4", effect: "overview-one-region" },
    PATHFINDERS_BEACON: { spawn: "on-route-segment-restored", effect: "reveal-connected-segment" }
  },
  
  harmonyFlow: {
    track: "waypoints-correctly-restored-in-sequence",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "route-fully-restored",
    fragmentType: "Expedition Record",
    content: "Pathfinder's log / discovery at destination / what they intended to contribute"
  },
  
  puzzleDesignTest: {
    whyExist: "Navigational infrastructure for cross-Realm Pathfinder travel",
    whoCreated: "Astra Pathfinders, First Harmony, maintained collectively",
    originalPurpose: "Guide travelers safely; distribute discovery across civilization",
    reveals: "Cross-Realm connection was civic obligation, not personal achievement",
    restores: "Route connection + Expedition Record"
  }
};
```

---

## Event Sheet 3 — Echo Sequence (Memory Sequence Puzzle)

### In-World Origin
Borealis Chroniclers developed Echo Sequence protocols for Companions to formally contribute memories to Archive without distortion.

### Core Mechanic
Observed sequence reproduction — Guardian watches a memory sequence then reproduces it accurately.

```javascript
// EchoSequenceEventSheet
const EchoSequence = {
  sequence: {
    types: ["visual-symbols", "narrative-beats", "companion-memory-fragments"],
    length: "5-12 steps",
    presentation: "paced, contemplative, no timer",
    reproduction: "guardian-inputs-sequence-in-order",
    winCondition: "sequence-accurately-reproduced",
    loseCondition: "none"
  },
  
  tools: {},
  
  harmonyFlow: {
    track: "sequence-steps-correctly-reproduced-consecutively",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "sequence-complete",
    fragmentType: "Companion Testimony",
    content: "First-person account / First Harmony scene / living history nowhere in written records"
  },
  
  puzzleDesignTest: {
    whyExist: "Companion memory contribution protocol for Archive",
    whoCreated: "Borealis Chroniclers + Companion communities, First Harmony",
    originalPurpose: "Allow Companions to contribute memories without distortion",
    reveals: "Civilization built formal systems for honoring testimony",
    restores: "Companion memory to Archive + living history fragment"
  }
};
```

---

## Event Sheet 4 — Community Pattern (Collective Pattern Puzzle)

### In-World Origin
Hearthlight festival traditions included collective pattern practices — structured contributions of color/sound/symbol requiring coordinated action.

### Core Mechanic
Collective pattern completion — Guardian contributes their piece to a larger community pattern.

```javascript
// CommunityPatternEventSheet
const CommunityPattern = {
  pattern: {
    type: "grid/symbol/color collective structure",
    totalContributions: "community-size-scaled",
    guardianContribution: "one-piece-per-engagement",
    existingPieces: "pre-filled-by-community-history",
    winCondition: "pattern-restored-to-intended-form",
    loseCondition: "none"
  },
  
  tools: {
    GLIMMER_HINT: { unlock: "pattern-completion-1", effect: "subtly-indicate-one-gap" }
  },
  
  harmonyFlow: {
    track: "community-patterns-contributed-to",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "pattern-fully-restored",
    fragmentType: "Festival Record",
    content: "Last performance account / participants / what community affirmed / when tradition went quiet"
  },
  
  puzzleDesignTest: {
    whyExist: "Festival/civic ritual record — collective pattern-making",
    whoCreated: "Hearthlight tradition, maintained collectively across generations",
    originalPurpose: "Demonstrate civic belonging through coordinated contribution",
    reveals: "Belonging as practice, not assumption",
    restores: "Festival Record + community tradition resumable"
  }
};
```

---

## Event Sheet 5 — Verdance Cultivation (Growth/Cultivation Puzzle)

### In-World Origin
Verdance Stewards maintained cultivation records — conditions for growth of environments, communities, mentorship lineages.

### Core Mechanic
Condition/sequence identification — Guardian identifies correct gem-type combinations, sequences, or conditions.

```javascript
// VerdanceCultivationEventSheet
const VerdanceCultivation = {
  site: {
    type: "depleted-cultivation-site",
    requiredConditions: "gem-type-sequences / element-combinations / timing",
    soilState: "depleted → restored (visual progression)",
    winCondition: "site-flourishing-all-conditions-met",
    loseCondition: "none"
  },
  
  tools: {
    SPECTRUM_KEY: { unlock: "cultivation-site-2", effect: "identify-required-gem-types-for-solution" }
  },
  
  harmonyFlow: {
    track: "conditions-correctly-identified-applied",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "site-restored",
    fragmentType: "Steward Field Record",
    content: "Community growth trajectory / mentorship lineage / unpracticed cultivation protocol"
  },
  
  puzzleDesignTest: {
    whyExist: "Verdance cultivation knowledge record embedded in Realm sites",
    whoCreated: "Verdance Stewards, First Harmony",
    originalPurpose: "Preserve cultivation knowledge for community self-sufficiency",
    reveals: "Civilization invested in growth conditions as deliberately as growth itself",
    restores: "Cultivation site + Steward record + renewed development conditions"
  }
};
```

---

## Event Sheet 6 — Fragment Assembly (Knowledge Assembly Puzzle)

### In-World Origin
Lumina scholars fragmented high-value records across multiple locations during Crystal Network failure — emergency preservation protocol.

### Core Mechanic
Fragment reconstruction — Guardian arranges/aligns/connects partial fragments into coherent whole.

```javascript
// FragmentAssemblyEventSheet
const FragmentAssembly = {
  fragments: {
    count: "3-6 per record",
    types: ["text", "symbol", "map-section", "diagram"],
    distribution: "across Realm sites / Archive nodes",
    assembly: "drag-align-connect",
    winCondition: "fragments-form-coherent-record",
    loseCondition: "none"
  },
  
  tools: {
    ARCHIVE_LENS: { unlock: "fragment-set-2", effect: "reveal-one-fragment-correct-orientation" }
  },
  
  harmonyFlow: {
    track: "fragments-correctly-assembled-in-session",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "record-fully-assembled",
    fragmentType: "Cross-Realm Discovery / Research Record / Historical Account",
    content: "Connects previously partial Archive entries / parallel research revelation"
  },
  
  puzzleDesignTest: {
    whyExist: "Emergency preservation — records fragmented to survive Network failure",
    whoCreated: "Lumina scholars, late First Harmony/early Shattering",
    originalPurpose: "Protect critical knowledge from single-point destruction",
    reveals: "Scholars anticipated loss and acted — civilizational faith",
    restores: "Complete Archive record + cross-entry connections"
  }
};
```

---

## Event Sheet 7 — Harmony Alignment (Balance Puzzle)

### In-World Origin
Solstice Harmonists maintained Pillar balance using Harmony Alignment — structured assessment/adjustment of Pillar relationships.

### Core Mechanic
Multi-element equilibrium adjustment — Guardian identifies imbalances across Pillar-representative values.

```javascript
// HarmonyAlignmentEventSheet
const HarmonyAlignment = {
  configuration: {
    pillars: 7,
    representation: "gem-type-distribution / element-ratios / visual-pillar-states",
    currentState: "drifted-from-equilibrium",
    targetState: "sustainable-relationship (not perfect equality)",
    adjustment: "guardian-modifies-distribution-ratios",
    winCondition: "all-pillars-in-sustainable-relationship",
    loseCondition: "none"
  },
  
  tools: {
    HARMONY_PRISM: { unlock: "alignment-3", effect: "show-all-pillar-states-simultaneously" }
  },
  
  harmonyFlow: {
    track: "pillars-brought-into-equilibrium",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "harmony-restored",
    fragmentType: "Harmonist Balance Record",
    content: "Pillar configuration at peak / restoration actions taken / systemic reference point"
  },
  
  puzzleDesignTest: {
    whyExist: "Pillar balance assessment tool for Solstice Harmonists",
    whoCreated: "Solstice tradition over many generations",
    originalPurpose: "Assess/restore equilibrium to prevent drift like pre-Shattering",
    reveals: "Civilization understood its complexity & built formal maintenance systems",
    restores: "Realm/Community Harmony + Harmonist record + systemic recovery conditions"
  }
};
```

---

## Event Sheet 8 — Legacy Seal (Composed Multi-Type Puzzle)

### In-World Origin
Legacy House developed Sealing — formal process protecting significant contributions against time/degradation.

### Core Mechanic
Multi-type composed challenge — Combines elements from other puzzle types.

```javascript
// LegacySealEventSheet
const LegacySeal = {
  composition: {
    stages: "2-4",
    stageTypes: "subset-of-other-puzzle-types",
    example: [
      "Crystal Resonance (node calibration)",
      "Fragment Assembly (seal inscription)",
      "Harmony Alignment (value demonstration)",
      "Echo Sequence (memory of legacy)"
    ],
    winCondition: "all-stages-complete-with-coherent-care",
    loseCondition: "none"
  },
  
  tools: {
    TWILIGHT_VEIL: { unlock: "seal-attempt-1", effect: "temporarily-show-seal-structure" }
  },
  
  harmonyFlow: {
    track: "stages-completed-with-attunement",
    thresholds: CANON.HARMONY_FLOW,
    feedbackOnly: true
  },
  
  archiveReveal: {
    trigger: "seal-opened",
    fragmentType: "Sealed Legacy Contribution (HIGHEST TIER)",
    content: "Complete Guardian testimony / community pledge / Companion history / Time Capsule"
  },
  
  puzzleDesignTest: {
    whyExist: "Legacy preservation protocol — protect most significant contributions",
    whoCreated: "Legacy House archivists + Chroniclers, late First Harmony",
    originalPurpose: "Ensure what was most worth preserving survives for future civilization",
    reveals: "Civilization trusted the future — deeply & deliberately",
    restores: "Sealed legacy + high-significance Archive record + named legacy recognition"
  }
};
```

---

## Implementation Checklist (Per Event Sheet)

| Check | Crystal Resonance | Pathfinder's Mark | Echo Sequence | Community Pattern | Verdance Cultivation | Fragment Assembly | Harmony Alignment | Legacy Seal |
|-------|-------------------|-------------------|---------------|-------------------|----------------------|-------------------|-------------------|-------------|
| Puzzle Design Test answers encoded | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| No destruction mechanics | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| No score multiplication | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| No resource bonuses | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| No energy gating | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| No shame on incomplete | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Civilizational origin in code comments | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Tools integrate as reveal/illuminate/guide | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Special gems as puzzle variants | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Harmony Flow = visual feedback only | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Archive reveal triggers defined | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| Companion presence integrated | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |

---

## Next Steps for Implementation Team
1. Create each event sheet in Construct 3 per above specs
2. Verify against checklist — all 12 checks per puzzle type
3. Playtest with canon lens — "Does this feel like restoration archaeology?"
4. Update puzzle-catalog.md Section 3 with implementation notes
5. Log any deviations in 02-conflicts-log.md as new conflicts

**Status: SPECIFICATION COMPLETE — Ready for Implementation**