# Kael Reframe Decision Brief

Version: v1

Status: Creator Review Required

Today's Date: 2026-06-03 AEST

Next Review Date: 2026-06-10 AEST

Last Updated: 2026-06-03 AEST

Project: GemVerse

Scope: Arena Realm / Kael / role framing

Related Files:
- `arena-realm-production-brief.md`
- `Arena_Realm_PRS_Context_v1.md`
- `canon-risk-report-20260601.md`
- `gemverse-session-continuity-log.md`

---

## PURPOSE

This brief exists to resolve the framing of Kael so future writing, art direction, UI copy, onboarding notes, and production materials remain aligned with GemVerse canon.

---

## DECISION REQUIRED

What is the final canon-safe framing for Kael's role and for the title **Arena Champion**?

---

## BACKGROUND

Current Arena canon establishes that Kael is present in the Restoration Era and that his title, **Arena Champion**, is a civic honorific rather than a martial one.

However, transferred visual-copy material introduced conflicting language describing Kael as helping the player "defeat the Arena Realm" and as "the strength of the group," creating a direct conflict with GemVerse's no-combat and no-savior framing.

This conflict is already treated as a blocked creator-only decision in current project continuity.

---

## LOCKED CONSTRAINTS

Any approved Kael framing must respect the following:

- Arena means assembly, not combat.
- Arena Realm is the civic heart of civilization.
- The Realm theme is Community.
- Kael may not be framed as a warrior, combat leader, or power archetype.
- The Guardian may not be framed as defeating the Realm.
- GemVerse does not use chosen-one, savior, or conquest framing.
- Kael's bravery, determination, and adventurousness must be expressed through civic contribution, stewardship, welcome, or restoration.

---

## OPTION A — CIVIC CHAMPION

### Core framing

Kael is the **Arena Champion of Contribution** — a person recognized for extraordinary, sustained civic service in Arena Realm.

### What this means

- He helps hold gatherings together.
- He supports festivals, arrivals, and shared civic life.
- He mentors others through action and presence.
- He is brave because he keeps showing up.
- He is determined because he sustains difficult work over time.
- He is adventurous because he remains open to people, possibility, and renewal.

### Advantages

- Strongest alignment with Arena's locked identity.
- Cleanest solution to the canon risk around combat framing.
- Preserves emotional warmth and first-realm belonging.
- Easy to explain in copy, narrative notes, and marketing-safe internal language.

### Risks

- Requires a pass over any older text that implies physical dominance or battle utility.
- Needs a concise approved descriptor to prevent future drift.

---

## OPTION B — CIVIC PATHFINDER

### Core framing

Kael is a **Champion of Gatherings and Wayfinding** — a civic guide whose title reflects his role in helping people orient, reconnect, and participate in Arena life.

### What this means

- He helps people find their place in the Realm.
- He keeps routes, records, and gathering traditions legible.
- He is associated with movement through living civic spaces, not with fighting through obstacles.
- His adventurousness becomes exploration in service of connection rather than conquest.

### Advantages

- Builds a strong link between Kael, onboarding, and Arena's gathering identity.
- Connects well with puzzle framing, routes, and the first-arrival experience.
- Offers a gentle bridge between civic care and active presence.

### Risks

- Slightly less immediate than Option A unless reinforced with visible examples.
- Could become too abstract if not grounded in practical civic acts.

---

## OUT-OF-BOUNDS FRAMING

The following must be explicitly rejected:

- Kael as someone who helps defeat the Arena Realm.
- Kael as the physical strength of the group in a battle sense.
- Kael as a warrior, fighter, or combat specialist.
- Kael as a heroic answer to Realm conflict through force.
- Any copy that implies Arena is a challenge zone to be overcome.

---

## RECOMMENDED DIRECTION

**Recommended:** Option A as the primary canon framing.

Option B can still inform specific aspects of Kael's behavior, such as helping others navigate spaces, traditions, and gatherings, but should not replace the core contribution-centered identity.

This preserves the strongest alignment with Arena Realm's civic role and resolves the highest-risk copy conflict with the least ambiguity.

---

## PROPOSED APPROVED DESCRIPTOR

Draft internal descriptor:

**Kael is the Arena's civic champion — brave, determined, and adventurous through contribution, welcome, and steadfast care for shared life.**

Alternative shorter form:

**Kael is the Arena Champion: a civic figure of contribution, welcome, and steady presence.**

---

## IMPLEMENTATION NOTES

If Option A is approved, apply the following cleanup rules:

- Replace all combat-coded Kael descriptions.
- Remove any wording about defeating the Arena Realm.
- Replace strength language with contribution, steadiness, presence, and care.
- Align visual briefs so posture and staging suggest welcome, confidence, and civic presence rather than battle readiness.
- Cross-check Kael references in UI copy, onboarding notes, environment notes, and marketing-adjacent internal drafts.

---

## CREATOR DECISION

Choose one:

- [ ] Approve Option A — Civic Champion
- [ ] Approve Option B — Civic Pathfinder
- [ ] Request Option C exploration
- [ ] Hold pending more context

---

## FOLLOW-UP ACTIONS AFTER DECISION

1. Update Kael references across Arena-related files.
2. Add final decision note to continuity log and relevant conflict/decision records.
3. Create a short Kael role packet aligned to the approved framing.
