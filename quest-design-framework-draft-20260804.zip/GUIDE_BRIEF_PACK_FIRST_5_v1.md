# Guide Brief Pack: First 5 Guides

## Purpose

This document provides structured briefs for the first five BabyPetSafety guides so drafting can begin with clear SEO, merchandising, and internal-link direction.

## Brief template logic

A good content brief should define the target query, article angle, required internal links, and conversion goal before drafting starts.[cite:200]

## Guide 1

### Title

How to baby-proof your living room when you also have a dog

### Intent

Practical mixed-household safety guidance.

### Main conversion path

- At Home collection
- Open-Plan Living Safety Kit

### Required product types

- baby gate
- play mat
- cabinet lock
- sofa protector

## Guide 2

### Title

Best ways to protect car seats when travelling with a baby and a dog

### Intent

Problem-solving guide for car protection and travel setup.

### Main conversion path

- On the Road collection
- First Baby and Dog Car Setup Bundle

### Required product types

- car seat protector
- dog car seat cover
- travel bowl
- organizer

## Guide 3

### Title

What to pack for outings with a baby and a pet

### Intent

Checklist-style guide with product support.

### Main conversion path

- Out and About collection
- Park Day Pack

### Required product types

- pram organizer
- outing bag
- travel bowl
- hooks or accessories

## Guide 4

### Title

How to set up a safer open-plan home for babies and pets

### Intent

Broader household safety setup guide.

### Main conversion path

- At Home collection
- Open-Plan Living Safety Kit

### Required product types

- gate
- extension
- play mat
- storage products

## Guide 5

### Title

Baby gate buying guide for homes with pets and young children

### Intent

Buying guide for a core hero product type.

### Main conversion path

- baby gate collection or relevant At Home collection
- supporting add-on bundle

### Required product types

- pressure-mounted gate
- extension kit
- wall protector

## Shared brief rules

For all five guides:

- define one clear intent per guide[ cite:200]
- include required internal links before drafting begins[ cite:200]
- connect the article to one primary collection and one primary bundle
- keep product references tied to product type and use case rather than one fragile SKU
