# Arena First Slice Implementation Checklist

Version: v1  
Status: Draft — Production Checklist  
Date: 2026-06-09 AEST  

Project: GemVerse  
Realm: Arena  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related file: `arena-first-experience-spec-v1.md`

---

## Purpose

This checklist breaks the Arena First Experience Spec into practical work by discipline so a small team or a future assistant can move from concept to prototype without reopening major framing questions.

It is designed for the first playable glimpse of GemVerse, not for a polished launch-ready slice.

---

## Design / Direction

- [ ] Confirm the slice uses Arena as a civic crossroads, not a battleground.
- [ ] Confirm the guiding character for this slice:
  - [ ] Aurora
  - [ ] Arena Lantern Keeper
- [ ] Confirm whether a companion appears in the slice.
- [ ] Confirm which puzzle type is used:
  - [ ] Community Pattern
  - [ ] Harmony Alignment
- [ ] Confirm that no boosters, blasts, bombs, combo multipliers, or energy systems appear anywhere in the flow.

---

## Narrative / Writing

Draft and approve final text for each beat:

- [ ] Arrival text framing Arena as a place of gatherings and crossings.
- [ ] Guide text explaining that the patterns are records, not decoration.
- [ ] Puzzle-introduction text explaining what the pattern marked in-world.
- [ ] Puzzle-success text describing quiet restoration rather than victory.
- [ ] Archive fragment text (1–2 sentences).
- [ ] Return-to-Arena text hinting there are more remembered patterns.

Copy QA:

- [ ] All lines align with `design-guardrail-gemverse-v1.md`.
- [ ] All lines align with `puzzle-support-vocabulary-guide-v1.md`.
- [ ] No hero/savior/combat wording remains.
- [ ] No language treats companions as tools.

---

## Art / UX

- [ ] Select or crop one Arena background that reads as a gathering square.
- [ ] Emphasize civic details such as banners, lanterns, stalls, benches, and notice-boards.
- [ ] Remove or de-emphasize anything that reads as combat, training, or tournament spectacle.
- [ ] Mock one small puzzle board UI for the slice.
- [ ] Remove any visible booster slots, power-up buttons, or destructive special-gem cues.
- [ ] Hide score multipliers and energy/lives UI in this slice.
- [ ] Design one subtle restoration animation or state change after puzzle completion.
- [ ] Design one simple Archive Fragment panel or card.

---

## Programming / Implementation

- [ ] Implement scene flow:
  - [ ] Arena arrival
  - [ ] Guide dialogue
  - [ ] Puzzle scene
  - [ ] Restoration moment
  - [ ] Archive fragment
  - [ ] Return to Arena
- [ ] Implement a very small deterministic puzzle board.
- [ ] Ensure puzzle interactions feel like aligning, restoring, or completing patterns.
- [ ] Disable any inherited booster or resource-bar systems for this slice.
- [ ] Disable visible combo multiplier logic in the prototype UI.
- [ ] Make text content easy to swap or revise without rebuilding the whole scene.
- [ ] Ensure there is no harsh fail state; use a gentle retry loop if needed.

---

## QA / Canon Safety

Before calling the slice GemVerse-safe, verify:

- [ ] Arena reads as civic/community space, not battleground.
- [ ] The puzzle passes the Puzzle Design Test.
- [ ] The slice contains no banned power-up / booster framing.
- [ ] No energy/stamina gating appears.
- [ ] Companions, if present, only witness/comment/remember.
- [ ] The restoration moment feels like reconnection, not conquest.
- [ ] The Archive fragment meaningfully ties the puzzle to civilization memory.

---

## Completion Standard

The slice is ready for internal review when:

- all narrative beats are present,
- the puzzle is playable end-to-end,
- the restoration and Archive reveal are visible,
- and no part of the flow contradicts GemVerse’s approved guardrails.

This is enough for a first “does this feel like GemVerse?” check, even if art and interaction polish are still rough.
