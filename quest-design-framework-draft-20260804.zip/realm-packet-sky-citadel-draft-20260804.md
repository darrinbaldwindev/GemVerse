# Realm Packet — Sky Citadel
**Draft Date:** 2026-08-04  
**Status:** Ready for Creator Review  
**Tier 2 Entry:** 2.1 (partial)  
**Linked Files:** `01-canon-map.md`, `06-five-wounds.md`, `imp-02-five-wounds-restoration-model.md`, `asset-registry.md`

---

## Overview

**Name:** Sky Citadel  
**Theme:** Discovery  
**Current State:** Partially isolated; routes unrecovered  
**Wound Alignment:** Wound of Discovery — Isolation  
**Visual Identity (from Art Bible):** "A sky realm of boundless discovery and adventure."  
**Symbol:** Ascending Spiral (representing upward journey and revelation)  
**Key Locations:** The Spiral Archives, The Wind Observatory, The Threshold Bridges, The Founders' Spire

---

## 1. Realm Essence

The Sky Citadel is a floating archipelago of interconnected stone platforms, suspended by unknown forces high above the ground Realms. In the First Harmony, it was a hub of exploration — a place where Pathfinders trained, theories were tested, and new routes between Realms were discovered and mapped. The Citadel's structures are built not for permanence but for adaptation — platforms can shift, bridges extend, and viewing chambers rotate to offer new perspectives.

The realm embodies Discovery not as conquest or claim-staking, but as revelation — the patient thrill of seeing something that was always there, waiting to be noticed.

---

## 2. Current State (Restoration Era)

The Sky Citadel now drifts in partial isolation. Some platforms remain connected and populated by a small, contemplative community of Pathfinders and their companions. Others hang unreachable, connected only by faint, unstable routes that appear and vanish with wind patterns.

The **Wind Observatory**, once the Citadel's central mapping hub, is partially functional. Its charts still show the "Known Paths" — routes that were open during the First Harmony — but the "Dreaming Paths" (theoretical routes to undiscovered Realms) have faded to near invisibility. The Observatory's grand telescope, the **Oculus of Horizons**, still works but its lens is cracked, limiting vision to short distances.

The **Spiral Archives** — a vast, cylindrical library that once held every Pathfinder log, route note, and speculative map — is in decay. Sections have collapsed. Others are sealed behind puzzle doors that require specific keys (Echo Sequences from Pathfinder Companions) to unlock.

---

## 3. Cultural Details

### Daily Life

Citizens of the Sky Citadel (the few who remain) follow a rhythm of "watching, waiting, and wondering." They are not idle — they maintain the Observatory, tend to wind-engine mechanisms, and attempt to stabilize failing routes — but their work is deeply contemplative. A common greeting is not "How are you?" but "What have you seen?"

Food is grown in sky-suspended gardens — mostly hardy grains, wind-ripened fruits, and root-vegetables that can handle the altitude. The Citadel's signature dish is **Spiral Bread** — a dense, spiraled loaf baked in stone ovens that are kept alight by wind-captive flames.

### Arts & Traditions

The Citadel's art form is **Skyweaving** — intricate patterns created by releasing colored sands and powders into wind currents. Master Skyweavers can create imagery that lasts for hours, telling stories in the clouds above. These are often ephemeral — intended to be witnessed and remembered, not preserved.

Festivals are tied to wind patterns. The **Ascension Festival** occurs every seven years when the **Seven Winds Converge** — a rare alignment that allows brief access to the unreachable platforms. The **Stillwind Vigil** is observed when the winds die completely — a quiet, contemplative period where no travel, no building, and no wind-based art is permitted.

### Notable Citizens

- **Zephyr-7** — A Pathfinder who maintains the Observatory and has mapped the last stable routes. Speaks only in conditional statements ("If we wait, then perhaps...", "Should the mist clear, we might see...").
- **Nimbe** — A young Skyweaver-in-training whose patterns seem to predict wind shifts. Believes they are descended from the First Pathfinders.
- **Aethon the Curator** (non-human)** — A wind-elemental presence who has lived in the Spiral Archives for centuries. Knows every book, scroll, and fragment by heart. Dislikes being disturbed.

---

## 4. Discovery Themes

The Sky Citadel is aligned with the **Wound of Discovery — Isolation**. This is not just physical separation, but the loss of curiosity's community — when wondering alone becomes wandering without purpose.

### What the Sky Citadel Reveals About the Wound:

- **Discovery Requires Shared Wonder** — A single Pathfinder cannot map a route that no one else will walk. The joy of discovery is incomplete without the possibility of sharing it.
- **Isolation Breeds Theory Without Practice** — The Citadel's thinkers have become increasingly abstract. They propose new routes on maps, but few attempt to walk them.
- **Restoration is Not Return** — The goal is not to "reclaim" the old routes, but to rediscover the spirit of exploration — where wonder, care, and shared purpose guide movement through the world.

---

## 5. Puzzle Integration Points

### Pathfinder's Mark Puzzles

These are the most natural puzzles for the Sky Citadel. They may involve:

- **Route Reconstruction** — Rebuilding a broken path from scattered marker fragments (Fragment Assembly)
- **Wind Pattern Logic** — Reading seasonal wind clues to determine which bridges will be stable (Harmony Alignment)
- **Telescope Calibration** — Using gem patterns to clear the cracked Oculus lens for distant vision (Crystal Resonance)

### Archive Discovery Puzzles

The Spiral Archives contain Echo Sequences, Memory Fragments, and Contributor Testimonies from the First Harmony. Puzzles here might include:

- **Skyweaver Pattern Memory** — Replicating a wind-born image to unlock a sealed chamber (Echo Sequence)
- **Pathfinder Log Reconstruction** — Assembling scattered expedition notes into coherent maps (Fragment Assembly)

---

## 6. Restoration Goals

The Sky Citadel's restoration is not about reconnecting every platform or reviving every route. It is about restoring the **spirit of shared discovery**. This means:

1. **Opening the Threshold Bridges** — Not all of them, just enough to allow small teams to move between platforms with intention.
2. **Reactivating the Dreaming Paths Portal** — A sealed chamber that contains theoretical routes to lost or unknown Realms. Activation requires a Harmony of Discovery — a puzzle that aligns the perspectives of multiple Companions.
3. **Hosting the First Post-Shattering Pathfinder Convocation** — A gathering of Pathfinders and Restoration-era explorers to re-establish the tradition of shared learning.

---

## 7. Mystery Hooks (Open, Not Resolved)

- **The Missing Platform** — A section of the Citadel shown in ancient maps that no longer exists. Was it destroyed? Did it drift away? What was its purpose?
- **The Walker of Silent Winds** — A figure referenced in Pathfinder logs who could move between platforms without bridges — but only during Stillwind Vigils. What became of them?
- **The Archive's Last Curator** — Aethon is not the last — there was one who vanished centuries ago, taking with them a key fragment that allowed access to the deepest Spiral Vaults.

---

## 8. Companion Connections

- **Lyra** (Realm Explorer) — Naturally aligned; her presence strengthens wind-watching abilities.
- **Nimbus** (Skykin Family) — Deeply at home here; can perceive wind patterns others miss. Joyful but restless. Needs grounding.
- **Spark** — Fascinated by the wind-engine mechanisms; sees them as puzzles to be solved. Can overstimulate local systems.
- **Verdant** — Finds the wind chaotic; has trouble perceiving the Citadel's "growth pulse." However, appreciates the wind's role in spreading seeds and stories.

---

## Files Updated / Referenced

- `asset-registry.md` — Sky Citadel environment art Tag updated to reflect this draft
- `imp-02-five-wounds-restoration-model.md` — Section on Discovery Wound + Realm integration
- `puzzle-catalog.md` — Pathfinder's Mark and Archive puzzle types contextualized for Sky Citadel
- `tier-roadmap-tracker.md` — Sky Citadel Realm Packet status: Draft Complete