# Launch Board v1 Consolidated Product Spec

Status: Draft  
Product: Launch Board  
Audience: Solo founders running one active launch  
Mode: Async-first, no phone calls

## Product definition

Launch Board v1 is a focused web app for solo founders who are actively running a launch and need one place to keep the launch clear, current, and moving. The product is intentionally narrow: one active launch, one opinionated workflow, and one lightweight board that helps a founder avoid rebuilding context from memory every time they sit down to work.

The core product promise is:

- Keep one current launch visible.
- Keep current priorities explicit.
- Keep tasks, ideas, decisions, and notes in one place.
- Support a weekly review habit without requiring calls, demos, or high-touch onboarding.

## Product goals

### Goals

- Help a solo founder get to a usable launch board quickly.
- Give the user immediate clarity on current phase, current focus, and next actions.
- Make the board useful in the first session without a call.
- Support a lightweight weekly maintenance ritual.
- Make the upgrade path understandable and fully async.

### Non-goals

- Collaboration, invites, roles, or team permissions.
- Timeline, calendar, gantt, or roadmap views.
- Rich reporting or analytics dashboards inside the product.
- CRM, campaign execution, or email marketing workflows.
- Complex billing and plan packaging in v1.
- Heavy setup forms or enterprise-style admin configuration.

## Canonical language

Use these terms consistently across product, docs, copy, and analytics:

- Launch board
- Current launch
- Launch status
- Current focus
- Next 3 actions
- Board
- Direction
- Build
- Launch
- Aftermath
- Archive
- Founder plan

Avoid these terms unless the product is intentionally renamed later:

- Workspace
- Hub
- Dashboard (as the product noun)
- Roadmap
- Control center
- War room
- Pipeline

## Primary user

The primary user is a solo founder actively shipping and launching a SaaS product. They do not want high-touch onboarding, do not want phone calls, and need a calm product that helps them see what matters now.

## Core user job

"Help me keep my launch context in one place so I can sit down, see what matters now, and move the launch forward without reconstructing everything from memory."

## v1 scope

Launch Board v1 supports:

- One account per user.
- One active current launch in v1.
- One board per current launch.
- A phase-based workflow made of:
  - Launch status
  - Current focus
  - Next 3 actions
  - A board with four columns
- Cards with four types:
  - Task
  - Idea
  - Decision
  - Note
- Archive for moved-off active work.
- Async feedback through in-app help and email.
- A simple founder-plan upgrade path.

## Information architecture

### Global navigation

- Current launch
- Archive
- Settings

### Main current-launch page sections

1. Page header
2. Onboarding checklist or completion panel
3. Launch status
4. Next 3 actions
5. Board
6. Tiny Need help affordance

### Board columns

- Direction
- Build
- Launch
- Aftermath

Optional first-use helper subtext:

- Direction — What you’re deciding
- Build — What you need to finish
- Launch — What matters during launch
- Aftermath — What you learned after launch

## Screen inventory

### 1. Sign-up

Purpose:
- Create account and enter the product.

### 2. Launch creation

Purpose:
- Create the current launch board with minimal setup.

Fields:
- Launch name
- Current phase
- Describe your current focus (optional at creation if needed)

CTA:
- Create board

### 3. Current launch main screen

Contains:
- Header
- Checklist or completion panel
- Launch status
- Next 3 actions
- Board
- Need help

### 4. Archive

Contains:
- Archived cards
- Search cards
- Optional filter by type
- Empty state and no-results state

### 5. Settings

Sections:
- Profile
- Notifications
- Launch defaults
- Card types
- Help

### 6. Pricing / upgrade

Contains:
- Headline
- One founder plan card
- Included features
- Reassurance block
- FAQ
- Upgrade CTA

### 7. Upgrade confirmation

Contains:
- Success headline
- Short reassurance body
- Open your board CTA

### 8. Help

Contains:
- Async support explanation
- Send feedback action

## First-run experience

The first-run experience should be product-led and async-only.

### First-run hierarchy

1. Page title and launch name
2. Checklist
3. Launch status
4. Next 3 actions
5. Board
6. Need help

### Checklist title and subtitle

Title:
- Set up your launch board

Subtitle:
- Complete these 4 steps to get your board ready.

### Checklist items

- Set your launch phase
- Describe your current focus
- Add your next 3 actions
- Add at least 3 cards

### Checklist behavior

Checklist items auto-complete based on real product state.

Completion rules:

- Set your launch phase → complete when phase is saved and not empty.
- Describe your current focus → complete when trimmed text is at least 20 characters.
- Add your next 3 actions → complete when all 3 action fields are non-empty.
- Add at least 3 cards → complete when the board has 3 or more cards total.

Checklist UX rules:

- Show progress as X of 4 done.
- Tick items automatically when requirements are met.
- Do not use manual checkboxes.
- Completed items can soften visually but remain visible until all items are done.
- When all 4 items are complete, replace the checklist with a completion panel.

### Completion panel

Headline:
- Your board is set up.

Body:
- Update your focus and next 3 actions each week to keep this launch moving.

Primary CTA:
- Open board

Secondary link:
- Need help?

## Main screen copy system

### Header

Recommended:

- Title: Current launch
- Launch name: [Launch name]
- Optional subtitle: Keep your launch clear, current, and moving.

### Launch status section

Purpose:
- Give the user immediate orientation.

Fields:
- Launch phase
- Describe your current focus

Helper copy:
- Launch phase: Choose where this launch is right now.
- Current focus: What are you trying to move this week?

Validation:
- Choose a launch phase.
- Describe your current focus.
- Use at least 20 characters.
- Add a bit more detail so this is useful later.

Primary CTA:
- Save status

Success message:
- Launch status updated.

Empty state:
- Headline: Your launch status is empty.
- Body: Set your phase and describe your current focus to make this board useful at a glance.
- CTA: Set launch status

Success-state copy:
- Headline: Your launch status is up to date.
- Body: Review it whenever priorities shift so the board still reflects what matters now.

### Next 3 actions section

Purpose:
- Give the user a concrete near-term plan.

Fields:
- Action 1
- Action 2
- Action 3

Helper copy:
- Action 1: A concrete step you can take next.
- Action 2: Add the second action that matters now.
- Action 3: Add the third action to keep momentum.

Validation:
- Add an action here.
- Add all 3 actions to complete this step.
- Optional future stronger rule: Make this action more specific.

Primary CTA:
- Save next 3 actions

Success message:
- Next 3 actions updated.

Empty state:
- Headline: No next actions yet.
- Body: Add the next 3 actions that would move this launch forward this week.
- CTA: Add next 3 actions

Success-state copy:
- Headline: Your next actions are set.
- Body: Update them when priorities change or once one is done.

### Board section

Purpose:
- Hold the evolving launch work: tasks, ideas, decisions, and notes.

Board rules:
- Highest-priority cards appear at the top of each column.
- Reordering is manual.
- Reordering can happen through drag-and-drop and a non-drag fallback path.
- The board is not sorted by recency by default.

Columns:
- Direction
- Build
- Launch
- Aftermath

Column empty states:

Direction:
- Headline: Nothing here yet.
- Body: Add ideas, decisions, and bets shaping this launch.
- CTA: Add first card

Build:
- Headline: Nothing here yet.
- Body: Add the tasks and decisions needed before launch.
- CTA: Add first card

Launch:
- Headline: Nothing here yet.
- Body: Add the tasks, checks, and notes for launch week.
- CTA: Add first card

Aftermath:
- Headline: Nothing here yet.
- Body: Add results, lessons, and follow-ups after the launch.
- CTA: Add first card

Column populated-state copy:

Direction:
- Headline: Your direction is taking shape.
- Body: Keep adding ideas and decisions as the launch gets clearer.

Build:
- Headline: Your build work is captured.
- Body: Keep this area current so nothing important slips before launch.

Launch:
- Headline: Your launch window is mapped.
- Body: Use this area to stay focused during launch week.

Aftermath:
- Headline: Your aftermath notes are started.
- Body: Capture results and lessons while they are still fresh.

Board-level empty state:
- Headline: Your board is empty.
- Body: Add your first card to start capturing tasks, ideas, decisions, or notes.
- CTA: Add first card

### Need help affordance

Placement:
- Small muted link under the checklist or completion panel.

Collapsed text:
- Need help?

Expanded prompt:
- What feels confusing or unclear?

Helper text:
- Reply in 1–2 sentences. I read every message.

CTA:
- Send feedback

Success message:
- Thanks — I’ve got it.

Rules:
- Inline expansion, not a modal.
- Keep it available during onboarding and after completion.
- No calls.
- Async-only support language throughout.

## Placeholder policy

Placeholders are examples only, not replacements for labels.

Recommended placeholders:

- Current focus: e.g. Clarify positioning and finish onboarding copy
- Action 1: e.g. Rewrite hero section
- Action 2: e.g. Add onboarding checklist
- Action 3: e.g. Draft launch email
- Card title: e.g. Pricing page copy
- Card detail: Add context, a decision, or the next step

Rules:
- Visible labels must always remain visible.
- Do not put critical rules only in placeholders.
- Use helper text for requirements.

## Card system

### Card types

- Task
- Idea
- Decision
- Note

### Card fields

- Title
- Type
- Optional detail
- Column
- Optional completed state for Task only
- Created at
- Updated at
- Archived state

### Card anatomy

Display order:
1. Title
2. Small type label
3. Optional detail preview

### Card create flow

Default behavior:
- Add card opens an inline composer at the top of the current column.
- Save adds the card immediately to the board in place.
- The user stays in context after save.

Optional defaults by column:
- Direction → Idea
- Build → Task
- Launch → Task
- Aftermath → Note

### Card detail drawer

Fields and actions:
- Title
- Type
- Details
- Column
- Mark as done (Task only)
- Save changes
- Archive card
- Delete card

Helper text:
- Details: Add context that helps you act, decide, or remember later.
- Column: Choose where this belongs in the launch.

### Card menu labels

- Edit card
- Move card
- Mark as done
- Archive card
- Delete card

Hide Mark as done on non-Task cards.

### Card color strategy

- Neutral card surfaces.
- Small muted type labels only.
- Do not color entire cards by type.

Suggested type-label mapping:
- Task: neutral or teal
- Idea: gold
- Decision: purple
- Note: muted gray-blue

## Archive

Purpose:
- Store historical cards without cluttering the active board.

Archive page copy:
- Title: Archive
- Subtitle: Past cards and completed work from this launch.

Archive empty state:
- Headline: Nothing archived yet.
- Body: Archived cards will appear here when you move them off the main board.
- CTA: Back to board

Archive no-results state:
- Headline: No archived cards matched your search.
- Body: Try a different word or clear the search.

Archive rules:
- Archived cards leave the active board.
- Archive is searchable.
- Archive is separate from delete.
- No auto-archiving in v1.

## Search and filtering

Toolbar labels:
- Search cards
- Filter by type
- Sort by priority
- Add card

Optional later:
- Show completed

Search states:
- No cards matched your search.
- Try a different word or clear the search.

Filter-empty state:
- No cards match this filter.
- Change the filter or add a new card.

## Settings

Settings sections:
- Profile
- Notifications
- Launch defaults
- Card types
- Help

Notification settings:
- Weekly reminder email
  - A weekly prompt to review your phase, focus, actions, and cards.
- Product updates
  - Occasional emails about meaningful changes to the product.
- Feedback replies
  - Replies to messages you send from inside the app.

If a setting is off, explain the effect:
- Weekly reminder email is off. Turn it on to get a prompt each week to update your board.
- Product updates are off. Turn them on to hear about meaningful product changes.

## Pricing and upgrade

### Upgrade page structure

1. Headline
2. One-sentence value statement
3. Founder plan card
4. What’s included
5. Early-user reassurance block
6. FAQ
7. Final CTA

### Headline and value statement

- Keep your launch board
- A simple plan for solo founders running real launches

### Founder plan card

- Plan name: Founder plan
- Subhead: For solo founders actively running launches
- Included:
  - One current launch board
  - Full board workflow
  - Weekly reminder emails
  - Archive access
  - Ongoing product improvements
- CTA: Upgrade to founder plan

### Reassurance block

- You joined while the product was still taking shape.
- Early users get a simpler founder plan and clear notice before any changes.

### FAQ

Questions:
- Why am I being asked to upgrade now?
- What happens to my existing board?
- Will my founder plan price change soon?
- Can I cancel later?
- Do I lose archived cards if I cancel?
- Is support still async only?

Suggested answers:
- The product is moving out of early access, and paid plans help support ongoing development.
- Your existing board stays as it is. Upgrading simply keeps access active.
- You’ll have clear notice before any future pricing changes.
- Yes. You can cancel without a call.
- Your archive remains accessible while your plan is active.
- Yes. Support stays async through email and in-app feedback.

### Upgrade confirmation

Headline:
- You’re on the founder plan.

Body:
- Your board stays active, and your founder access is now in place.

Primary CTA:
- Open your board

Secondary text:
- Your support and product updates will still stay async.

## Weekly reminder ritual

This is the core retention habit after setup.

Short in-product prompt:
- Update your focus and next 3 actions for this week.

Weekly email:

Subject:
- Update your launch board for this week

Body:
- A quick prompt to keep your board useful this week:
- Review your launch phase
- Update your current focus
- Rewrite your next 3 actions
- Add, move, or archive any cards that changed
- Open your board: [link]

## State inventory

Each core screen should explicitly support the following states where relevant:

- Loading
- Empty
- Populated
- Success
- Error
- Search no-results
- Filter-empty

### Loading states

Use skeletons for major app surfaces:
- Checklist rows
- Status panel text bars
- Next 3 actions lines
- Board columns with card placeholders

Use spinners only for tiny inline actions like sending feedback.

### Save states

- Saving…
- Saved
- Return to normal label

Use toast only for larger actions, not every field save.

### Toast vocabulary

Use short factual toasts:
- Launch status updated
- Next 3 actions updated
- Card added
- Card updated
- Card deleted
- Card moved
- Feedback sent
- Your board is set up

### Error states

Examples:
- We couldn’t load your board. Try again.
- We couldn’t save that change. Try again.
- Feedback couldn’t be sent. Try again in a moment.

Primary CTAs:
- Retry
- Try again

## Confirmation and recovery rules

### Confirmation hierarchy

- Save/update → no modal, inline or toast confirmation
- Archive → light confirmation or toast with Undo
- Delete → explicit confirmation
- Upgrade → dedicated page, not modal
- Cancel subscription later → explicit confirmation

### Delete confirmation

Title:
- Delete this card?

Body:
- This will permanently remove the card from your board.

Primary CTA:
- Delete card

Secondary CTA:
- Cancel

### Archive confirmation

Title:
- Archive this card?

Body:
- This removes the card from your main board and keeps it in Archive.

Primary CTA:
- Archive card

Secondary CTA:
- Cancel

### Undo-supported actions

Recommended Undo support:
- Card deleted
- Card archived
- Card moved across columns (optional if easy)

## Layout and interaction rules

### Density and spacing

Use moderate web-app density.

Recommended spacing rhythm:
- 8px between label and helper text
- 12px between related items inside a card
- 16px between controls inside a panel
- 24px between stacked dashboard sections
- 32px between major page zones

### Mobile behavior

Do not show four narrow columns at once on mobile.

Recommended mobile approach:
- Status and Next 3 actions remain stacked.
- Board becomes tabs or segmented control:
  - Direction
  - Build
  - Launch
  - Aftermath
- One column visible at a time.
- Default to the most relevant column based on current phase if useful.

### Drag-and-drop

Required affordances:
- Visible drag handle
- Grab cursor on desktop
- Lift shadow while dragging
- Clear drop target highlight
- Non-drag fallback via menu or button path

## Accessibility and command rules

### Accessibility

- Labels must remain visible.
- Placeholder text must not replace labels.
- All icon-only actions need accessible labels.
- Focus management must work for dialogs and drawers.
- Form errors must not rely on color alone.
- Touch targets should be at least 44x44 on mobile.
- Reduced-motion-safe behavior should be respected.

### Suggested accessible labels

- Open card menu
- Move card
- Close panel
- Send feedback
- Search cards
- Add card

### Keyboard support (later if implemented)

Suggested shortcuts:
- N → Add card
- / → Search cards
- Esc → Close dialog or drawer

## App-level empty states

### No current launch

- Headline: No current launch yet.
- Body: Create a launch board for the work you’re doing now.
- CTA: Create board

### Board empty

- Headline: Your board is empty.
- Body: Add your first card to start capturing tasks, ideas, decisions, or notes.
- CTA: Add first card

## Data model (v1 simplified)

### User

- id
- email
- auth provider id or password hash
- plan_type
- plan_variant
- subscription_start_date
- subscription_end_date
- weekly_reminder_enabled
- product_updates_enabled
- feedback_reply_enabled
- created_at
- updated_at

### Launch

- id
- user_id
- name
- current_phase
- current_focus
- action_1
- action_2
- action_3
- created_at
- updated_at

### Card

- id
- launch_id
- title
- card_type
- detail
- column_name
- is_completed (task only)
- archived_at (nullable)
- created_at
- updated_at
- sort_order

### Feedback message

- id
- user_id
- launch_id (nullable)
- message
- source
- created_at

## Explicit v1 rules

- One account = one user.
- One active current launch in v1.
- No collaborators.
- No hard due dates required in v1.
- No timeline or calendar views.
- No complex plan packaging.
- No calls in onboarding, support, or upgrade.

## Analytics and tracking plan

### Naming convention

Use:
- snake_case
- concise object_action or completed-event naming
- one consistent tense across the implementation

Recommended events:
- account_created
- board_created
- onboarding_started
- checklist_completed
- phase_updated
- focus_updated
- actions_updated
- first_card_added
- card_added
- card_moved
- card_archived
- board_returned
- pricing_viewed
- founder_plan_viewed
- founder_plan_started
- founder_plan_completed

### Recommended event properties

- phase
- card_type
- column_name
- source
- plan
- checklist_step
- board_age_days

Do not send raw free-text current focus or card detail content as event properties.

### Product metrics

Activation:
- checklist_completed

Retained early use:
- board_returned within 7 days
- plus one of:
  - focus_updated
  - actions_updated
  - card_added

Upgrade funnel:
- pricing_viewed → founder_plan_started → founder_plan_completed

## Launch readiness checklist for implementation

Before building or shipping, ensure the project includes:

- The canonical language list in product copy.
- The four-item onboarding checklist and completion rules.
- The main screen hierarchy.
- Empty, success, loading, and error states for all core screens.
- Archive behavior and copy.
- Search and filter labels.
- Inline feedback affordance.
- Founder plan page and confirmation copy.
- Weekly reminder email copy.
- Event taxonomy and activation tracking.
- Mobile one-column board behavior.
- Drag fallback for non-pointer users.
- Accessible labels for icon-only controls.

## Migration note from earlier spec

This consolidated spec intentionally replaces the earlier multi-plan, many-project, seeded-task launch planner model in `prs_v1_spec.txt` with a narrower Launch Board v1 model focused on one active launch, one board, async onboarding, and a simpler founder-plan upgrade path. If implementation work has already started from the older spec, this file should be treated as the new product source of truth for v1 direction.
