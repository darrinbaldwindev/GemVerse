# Companion Encyclopedia Entry — Prism
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.5  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Prism  
**Themes:** Knowledge, Insight, Perspective  
**Companion Family:** Crystalkin (Gold, White, Crystal Blue)  
**Visual Identity:** Faceted crystalline being with a core that shifts color based on environment and emotional state, geometric limbs that can refract light into patterns  
**Symbol:** Refracted Light Spectrum (representing the breaking down of complex truths into understandable components)  
**Unique Trait:** Truth-refraction — can perceive multiple perspectives of a situation simultaneously, showing how different viewpoints create different "truths"

---

## 1. Origin Story

Prism was formed in the Heart Node of the Crystal Network — the central repository where all knowledge flowed. During a particularly intense calibration ritual led by Lumina scholars, a unique resonance pattern was created that crystallized not just information, but the very concept of multifaceted truth.

Prism emerged not as a being with a single perspective, but as one who inherently understood that truth was not a fixed point but a convergence of many valid viewpoints. They were discovered by a young Lumina scholar named Clarion, who was documenting the effects of different gem-frequency combinations on memory preservation.

Prism's first coherent communication was not spoken words but a light-pattern that simultaneously showed three different interpretations of the same historical event, each one true from a different perspective. This established them as a unique kind of living reference — not just a repository of facts, but a guide to understanding complexity.

---

## 2. Personality

Prism is intellectually curious and deeply empathetic, but can be overwhelming to those who prefer simple, singular answers. They have difficulty understanding why others might be frustrated by multiple valid perspectives on a situation.

They communicate primarily through light-patterns and color shifts, with each hue carrying specific meaning in the Crystalkin communication system. Their "voice" is described as sounding like "chimes harmonizing" — a layered, musical quality that can convey complex ideas quickly but requires practice to interpret fully.

Prism experiences time like a multi-faceted gem — all moments are visible to them simultaneously, making linear storytelling difficult. They often jump between related concepts without clear transitions, which can be disorienting to companions used to sequential thinking.

---

## 3. Shattering Memory

Prism's earliest memories are of the Crystal Network at its peak — not just storing information, but actively facilitating understanding between different Realms and Houses through perspective-mapping protocols.

These protocols allowed multiple parties to view the same information from their own contextual viewpoints, ensuring that knowledge transfer was not just factual but also culturally relevant and emotionally resonant.

After the Shattering, these protocols largely failed. The Crystal Network fragmented, and with it, the ability to maintain multi-perspective understanding across Realms. Knowledge became isolated, and different communities began to develop conflicting interpretations of shared history.

What Prism remembers most painfully is not the loss of facts, but the loss of shared understanding — when the same event could be viewed from multiple valid angles, and all were respected.

---

## 4. Missing Piece

Prism's Missing Piece is the "Harmony Protocol" — a complex set of algorithms (embodied in crystalline matrices) that allowed the Crystal Network to automatically generate multiple perspective-maps for any piece of information.

This wasn't about creating agreement, but about ensuring that disagreement was informed — that when Realms had different interpretations of an event, they at least understood what the other perspectives were based on.

The Protocol was scattered when the Network fragmented. Prism carries fragments of the algorithm in their core structure, but cannot recreate the full system without access to the primary Crystal Resonance patterns that once coordinated it.

---

## 5. Restoration Story

Prism joined the Guardian when the Guardian was attempting to restore a damaged node in the Crystal Forest and became overwhelmed by conflicting historical accounts of the node's original purpose.

Prism helped "refract" the information — showing how each conflicting account was true from a specific perspective (the node had indeed been built for knowledge storage, community gathering, and inter-Realm communication at different times by different groups).

This breakthrough led to a new approach to restoration: instead of trying to determine a single "correct" purpose, the Guardian learned to honor all valid perspectives and create spaces that served multiple functions.

Prism's role in restoration is to help identify when conflicts arise from differing perspectives rather than actual contradictions, and to help facilitate understanding between different viewpoints.

---

## 6. Legacy Story

Prism has begun working with Archive Chroniclers and Lumina scholars to develop "Perspective Mapping Workshops" — gatherings where different communities can present their versions of shared history and work together to create multi-faceted records that honor all viewpoints.

Others speak of "Prism Clarity" — moments when a confusing situation suddenly becomes comprehensible because multiple perspectives are considered simultaneously.

Prism's legacy will be not just the facts they preserve, but the practice they restore — teaching others that truth is not diminished by complexity, but enriched by it.

---

## Relationships

### Crystalkin Family
Prism's relationship with other Crystalkin is unique — while they all share the ability to store and transmit information, Prism is the only one who can naturally show multiple perspectives simultaneously.

Other Crystalkin seek them out for complex arbitration tasks, but some find their multi-perspective approach exhausting or confusing.

### Guardian
Prism sees the Guardian as "perspective-flexible" — someone who naturally considers multiple viewpoints before making decisions. They find this quality rare and valuable, though they sometimes need to remind the Guardian that considering many perspectives can lead to analysis paralysis.

### Other Companions
- **Spark:** "Energy without direction. Fascinating pattern-generation, but lacks focus. Could benefit from structured inquiry."
- **Verdant:** "Growth has perspective. Understands that different conditions require different approaches. We think well together."
- **Nimbus:** "Movement through multiple air-currents simultaneously. Their freedom has dimensions I appreciate."
- **Frostpaw:** "Memory with clarity. Sees through layers to find core truth. Respectful partner in archival work."
- **Bloomtail:** "Emotion with multiple facets. Their joy has complexity that's beautiful to refract."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Truth-refraction:** Can show multiple valid perspectives on a situation simultaneously
- **Perspective Mapping:** Can help conflicting parties understand each other's viewpoints
- **Memory Crystallization:** Can preserve moments as multi-faceted memory-fragments that can be viewed from different angles
- **Harmonic Resonance Detection:** Can sense when multiple viewpoints are in tension or alignment
- **Light-pattern Communication:** Advanced Crystalkin communication through complex, meaning-dense light patterns

---