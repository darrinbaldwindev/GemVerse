# Arena Realm Production Brief

**Project:** GemVerse  
**Document Type:** Production-ready realm brief  
**Status:** Working brief derived from current Space canon  
**Source Basis:** `realm-packet-arena-realm.md`, `gemverse-session-continuity-log.md`

---

## Purpose

This document distills the current Arena Realm packet into a short, practical brief for writers, designers, artists, and narrative planners. It is intended to preserve canon-safe framing while reducing the amount of packet material a production team needs to parse before working on Arena Realm content.

This brief does **not** replace the full Realm Packet. The packet remains the deeper source for nuance, dependencies, and open questions. This document exists to make day-to-day execution safer and faster.

---

## Core Identity

The Arena Realm is the civic heart of civilization.

Its name means **assembly, convergence, and shared presence**. It does **not** mean combat, contest, dominance, or spectacle. Any framing that makes the Arena Realm feel like a battleground, tournament zone, or victory challenge is out of bounds.

The Arena Realm's locked theme is **Community**. It is the great gathering place of the world, the crossroads where people from different Realms, Paths, Houses, and traditions encounter one another. During both the First Harmony and the Restoration Era, it functions as the most connected Realm and the natural entry point into GemVerse.

---

## Player-Facing Function

The Arena Realm is the **canonical first Realm** a Guardian encounters.

The first experience of GemVerse should communicate:
- warmth before grandeur
- welcome before mystery
- care before scale
- contribution before destiny

A Guardian does not arrive as a chosen one, hero, conqueror, or rescuer. They arrive as a person entering a place that has been waiting, holding together, and making room for others.

The emotional first impression should be: **someone has been taking care of things**.

---

## Locked Canon Facts

The following points are safe to use directly in production work.

- Arena means assembly, not combat.
- The Realm theme is Community.
- The Arena Realm is the most connected Realm and serves as the crossroads of civilization.
- It is the first Realm a Guardian enters.
- The civic gathering hall still stands in the Restoration Era.
- Some Crystal Network nodes in the Realm are dormant.
- The Realm is quieter than in the First Harmony, but still more active than most other Realms.
- Guardians arrive at a small still-burning Lantern site.
- A Keeper greets them.
- The Archive has an incomplete record waiting.
- The first puzzle is framed by the question: **"What was here before?"**
- Kael is present in the Realm during the Restoration Era.
- Kael's title, **Arena Champion**, is a civic honorific, not a martial one.
- Kael is brave, determined, and adventurous through civic contribution, not combat.

---

## Required Emotional Tone

Arena Realm should feel:
- warm
- welcoming
- restorative
- civic
- lived-in
- quietly hopeful

It should not feel:
- militarized
- gladiatorial
- triumphalist
- grim
- decayed beyond care
- built around challenge or domination

The Realm earns its scale through meaning, not intimidation. The player should notice hospitality, continuity, and presence before they notice monumental architecture.

---

## Visual Direction

Use the transferred visual direction as a base: **lush, organic, grown rather than aggressively built**.

The Arena Realm is not a stone arena, combat bowl, or coliseum. It should feel like architecture and landscape matured together over time through stewardship and care.

Visual cues to favor:
- welcoming pathways
- layered civic gathering spaces
- greenery integrated with built structures
- lantern light as continuity and care
- open thresholds and visible routes of movement
- signs that the Realm was made for people to arrive, gather, and remain

Visual cues to avoid:
- weapon silhouettes
- banners or staging associated with combat victory
- harsh fortress geometry
- throne-room dominance framing
- anything that implies the Realm exists to be defeated, conquered, or cleared

---

## Entry Experience

The Arena Realm entry sequence should be intimate before it becomes expansive.

Recommended order of feeling and perception:
1. A small still-burning Lantern site.
2. A Keeper who greets the Guardian.
3. Evidence of care: clear paths, maintained spaces, signs of use.
4. The incomplete Archive record.
5. The opening question: **"What was here before?"**
6. Only then, the larger scale of the Realm and its civic past.

This sequencing matters. Arena Realm should introduce GemVerse through belonging, not spectacle.

---

## Kael Guidance

Kael is a civic figure, not an action figure.

Use these framing principles:
- Kael represents commitment, steadiness, and showing up.
- Arena Champion means extraordinary contribution to community life.
- His bravery is civic bravery.
- His determination is sustained care.
- His adventurousness is openness to people, possibility, and restoration.

Never frame Kael as:
- someone who helps defeat the Realm
- a combat leader
- the physical strength of the group in a battle sense
- a warrior archetype
- the answer to Realm conflict through force

If Kael appears in copy, key art direction, UI text, quest text, or design notes, the language should reinforce contribution, maintenance, welcome, and civic presence.

---

## Hub Zones

The following hub zones are canonical and safe to reference:
- Harmony Plaza
- Great Archive
- House Districts
- Companion Grove
- Festival Grounds
- Guardian Hall
- Marketplace
- Lantern Tower

These are locked as zone names and functions at the high level. Internal layouts, exact adjacencies, and detailed operations remain open unless separately confirmed.

---

## Production Rules

When making Arena Realm content, use these rules as hard guardrails:

- Do not use combat language.
- Do not imply the Realm must be defeated.
- Do not frame the Guardian as a savior.
- Do not turn Kael into a warrior.
- Do not make the Realm feel empty in a hopeless way.
- Do not describe Arena using "strength" if that wording tilts toward dominance or battle.
- Do not build the first arrival around spectacle before warmth.
- Do not make the civic gathering hall feel like a throne room or boss arena.

Preferred language families:
- gathering
- welcome
- arrival
- convergence
- contribution
- stewardship
- continuity
- belonging
- civic care
- shared life

---

## Working Interpretive Frame

The strongest current interpretive frame is:

**The Arena Realm is where civilization remembers itself by gathering.**

That sentence is a useful north star for concept art, narrative beats, environment writing, quest framing, onboarding design, and community-facing copy.

If a production choice makes Arena feel more like a battleground than a crossroads, or more like a power center than a place of shared presence, it is likely off-canon.

---

## Open Items Still Requiring Creator Confirmation

The following items should be treated as unresolved until explicitly confirmed:

- Whether the Arena Realm's primary Wound is **Wound of Belonging — the Division**.
- The exact basis for Kael earning the Arena Champion title.
- Whether the Great Gathering Hall was ever temporarily closed during the drift period.
- The identity and name of the Keeper at the Guardian entry point.
- The exact incomplete Archive record that triggers the first puzzle.
- Which named citizens are primarily associated with the Arena Realm.
- The fate or visible traces of the Harmony Council.
- Specific festival traditions tied to the Festival Grounds.

These questions should shape future packets and Tier 2 writing, but should not be guessed into final canon.

---

## Best Immediate Uses

This brief is ready to support:
- narrative onboarding work
- environment concept direction
- copy cleanup for Arena Realm descriptions
- Kael reframe checks
- hub design alignment
- review of UI or marketing lines that mention Arena Realm

For deeper historical, civic, and dependency logic, return to the full Arena Realm packet.
