# GemVerse Realm Packet Template

Use this template to create a canon-aligned packet for any Realm in GemVerse. The template is built to match the current locked canon: each Realm has a confirmed theme and current state, while cultural details, district structure, traditions, and most internal layouts remain to be authored.[file:109] Arena Realm already establishes the model of a canonical hub with named zones such as Harmony Plaza, Great Archive, Festival Grounds, Guardian Hall, Marketplace, and Lantern Tower.[file:109]

## Packet Metadata

- Realm name:
- Canon version:
- Packet version:
- Author:
- Date updated:
- Canon status: Locked / Draft / Needs review
- Associated House(s):
- Associated Path(s):
- Related companions:
- Related mysteries:

## Canon Snapshot

Record only what is currently locked in canon at the top of the packet so later creative work does not override it. Every Realm should begin with its confirmed theme and current state, because those are already fixed at canon level.[file:109]

| Field | Entry |
|---|---|
| Realm name |  |
| Core theme |  |
| Current state |  |
| Restoration role in civilization |  |
| Emotional tone |  |
| Pillar alignment |  |
| Companion family alignment |  |
| MVP status |  |

## One-Paragraph Realm Description

Write a single paragraph that explains what the Realm feels like, what contribution it makes to civilization, and why it is worth belonging to. The paragraph should follow GemVerse tone rules: hopeful, warm, curious, and restorative, while avoiding grimdark, conquest framing, or chosen-one logic.[file:109]

## Narrative Purpose

Use this section to define what the Realm contributes to the wider world and why players visit it.

- Civilization function:
- Why this Realm matters after the Shattering:
- What wound or imbalance it helps heal:
- Guardian relationship to the Realm:
- What the Realm teaches about contribution:

## Visual Identity

This section locks the visual language before concept art expands too far. Realm visuals should communicate possibility, contribution, connection, meaning, and legacy rather than fear, aggression, scarcity, or domination.[file:109]

- Primary visual idea:
- Secondary visual idea:
- Architecture language:
- Landscape language:
- Material language:
- Lighting language:
- Color palette:
- Motion/weather cues:
- Signs of restoration:
- Signs of incompleteness:
- Visual motifs to avoid:

## Civic Structure

All Realms need civic logic, not just scenery. Arena already proves that Realm spaces should be framed as lived civilization spaces with named zones and practical community functions.[file:109]

| Civic element | Purpose | Locked / Draft | Notes |
|---|---|---|---|
| Primary gathering space |  |  |  |
| Knowledge or record space |  |  |  |
| Travel or route space |  |  |  |
| Companion-integrated space |  |  |  |
| Ritual or celebration space |  |  |  |
| Craft or work space |  |  |  |
| Quiet reflection space |  |  |  |
| Landmark or skyline feature |  |  |  |

## Districts and Locations

List the Realm's most important places. If the Realm does not yet have formal districts, define provisional zones first and mark them as draft.

| Location | Type | Function | Canon status | Key image reference |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

## Key Art Placement

Use this section to lock how artwork maps to canon documents and production work. This prevents images from becoming disconnected mood boards.

| Asset role | Image / visual reference | Where cited in docs | Notes |
|---|---|---|---|
| Primary civic illustration |  | Realm packet |  |
| Secondary environment illustration |  | Visual bible / PRS |  |
| System integration illustration |  | Systems doc |  |
| Onboarding illustration |  | Onboarding flow |  |
| Marketing support illustration |  | Brand / pitch / website |  |

## Culture

The canon map explicitly states that food, music, architecture, traditions, holidays, folk heroes, district structure, and local culture are still missing for all eight Realms, so this section is where most future worldbuilding will expand.[file:109]

- Daily life summary:
- Hospitality style:
- Food traditions:
- Music / soundscape:
- Clothing / adornment:
- Work and craft traditions:
- Celebrations and observances:
- Proverbs or sayings:
- Folk hero or remembered citizen:
- Intergenerational practices:

## Companion Integration

Companion families are canon-locked by theme and color language, so each Realm packet should state how companions belong in everyday civic life rather than treating them as collectibles alone.[file:109]

| Companion family | Role in this Realm | Everyday presence | Symbolic meaning | Visual notes |
|---|---|---|---|---|
|  |  |  |  |  |

## Guardian Experience

The Guardian is a contributor, not a savior, and the packet should show how the player participates in restoration through meaningful tasks, relationships, and discoveries.[file:109]

- Entry fantasy:
- First arrival feeling:
- Primary onboarding activity:
- First meaningful contribution:
- Mid-term restoration loop:
- Long-term legacy opportunity:
- Non-combat challenge types present here:
- Social or civic recognition opportunities:

## Systems Hooks

Use this section to connect the Realm to broader game systems.

| System | How it appears here | Canon status | Notes |
|---|---|---|---|
| Crystal Network |  |  |  |
| Lantern Network |  |  |  |
| Great Archive |  |  |  |
| Houses |  |  |  |
| Paths |  |  |  |
| Harmony Index |  |  |  |
| Festivals |  |  |  |
| Legacy systems |  |  |  |
| Puzzle types |  |  |  |

## Mysteries and Restraints

GemVerse keeps several world mysteries intentionally unresolved, including the Memory Ocean, the Missing Realm, the Lost Harmonists, the Seventh Lantern, the Sleeping Gate, and the Forgotten Door, so Realm packets should seed mystery without over-explaining it.[file:109]

- Realm-specific mystery:
- Open questions players should feel:
- What must remain undefined:
- What should only appear in fragments:
- What not to resolve in this packet:

## Tone Guardrails

Use this checklist before approving any Realm expansion.

- Does this strengthen wonder, belonging, community, memory, or legacy?[file:109]
- Does this avoid conquest, domination, fear escalation, or grimdark framing?[file:109]
- Does the Realm feel lived-in rather than merely scenic?[file:109]
- Are companions integrated into society rather than added decoratively?[file:109]
- Does the Guardian contribute rather than rescue everyone?[file:109]
- Is the Realm worth belonging to?[file:109]

## Production Handoff

This final section converts the packet into something usable by design, narrative, and art teams.

| Team | Required output | Status | Notes |
|---|---|---|---|
| Narrative | Realm overview paragraph, civic purpose, mystery framing |  |  |
| Worldbuilding | Culture, traditions, districts, local logic |  |  |
| Concept art | Primary civic illustration, secondary landmarks, materials |  |  |
| Design | Onboarding loop, systems hooks, navigation logic |  |  |
| Audio | Ambient identity, music direction, sound motifs |  |  |
| Production | Versioning, approvals, dependencies |  |  |

## Suggested Use Order

1. Fill **Canon Snapshot** first so the packet starts from locked truth rather than invention.[file:109]
2. Write the **One-Paragraph Realm Description** and **Narrative Purpose** before expanding culture, because those sections establish meaning and boundaries.[file:109]
3. Lock **Visual Identity** and **Civic Structure** before commissioning more art, so every new image maps to a real place and function.[file:109]
4. Expand **Culture**, **Guardian Experience**, and **Systems Hooks** only after the Realm's civic logic is clear.[file:109]
5. Finish by tagging at least one image into **Key Art Placement** so art, canon, and production stay synchronized.[file:109]
