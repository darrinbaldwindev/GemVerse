# Arena First Slice Prototype Assembly Brief

Version: v1  
Status: Draft — Creator Review Required  
Date: 2026-06-26 AEST  

Project: GemVerse  
Realm: Arena  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related files:

- `arena-first-experience-spec-v1.md`
- `arena-first-slice-dialogue-content-pack-v1.md`
- `arena-first-slice-ui-screen-map-v1.md`
- `implementation-checklist-arena-first-slice-v1.md`
- `arena-slice-qa-script-v1.md`
- `arena-realm-production-brief.md`
- `puzzle-arena-the-quiet-ledger-v1.md`
- `npc-arena-lantern-keeper-harmony-plaza-v1.md`

---

## Purpose

This brief defines the minimum viable assembly plan for building the Arena first slice as a rough playable prototype.

It is not a full production plan. Its purpose is to help a builder or future assistant assemble the first end-to-end GemVerse prototype without reopening already-set framing decisions.

---

## Assembly Goal

Build one short playable sequence that proves the following:

- Arena feels like a civic crossroads, not a battleground.
- The first puzzle feels like restoring a meaningful remnant of civilization.
- The Lantern Keeper provides welcome and orientation without acting like a quest-dispatcher.
- Success feels like restoration and memory returning, not like a power victory.
- One Archive fragment gives the interaction meaning beyond the board itself.

If all five are true in a rough build, the slice is doing its job.

---

## Prototype Scope Lock

The build should include only the following:

- One Arena arrival scene
- One Lantern Keeper interaction
- One puzzle intro overlay
- One small deterministic puzzle
- One success/restoration state
- One Archive fragment card
- One return-to-Arena closing screen

Do not expand scope during assembly.

Specifically out of scope:

- Additional levels
- Inventory systems
- Resource bars or energy systems
- Booster systems
- Kael implementation
- Quest log structures
- Broader realm navigation
- Shop, reward, or progression economies

---

## Minimum Asset List

A rough prototype can be assembled with the following asset set.

### Environment

- 1 Arena square background image or mock scene
- 1 restored Arena variant, or one toggled visual layer showing restoration after puzzle success

### Character

- 1 Lantern Keeper portrait, bust, silhouette, or in-scene figure
- Optional: 1 small companion presence icon or portrait

### Puzzle

- 1 puzzle board layout (4x4 or 5x5)
- 1 tile set or fragment set appropriate to the selected mechanic
- 1 solved board state

### UI

- 1 dialogue panel style
- 1 overlay/prompt panel style
- 1 Archive fragment card/modal style
- 1 primary button style
- 1 secondary button style if needed

### Audio (optional but useful)

- 1 ambient Arena loop
- 1 soft success cue
- 1 soft UI click set

If audio is unavailable, the slice can still function visually.

---

## Required Text Hooks

Use the content pack as source of truth for prototype text.

Minimum text blocks required:

- Arrival narration
- Keeper opening line
- Keeper orientation line
- Puzzle handoff line
- Puzzle mechanic-specific intro line
- 1 hint line
- Success/restoration line
- Keeper follow-up line
- Archive fragment text
- Return-to-Arena closing line

If implementation is time-limited, use the default script section from the dialogue/content pack.

---

## Recommended Implementation Order

Build in this sequence.

### Step 1 — Static flow shell

Implement all seven screens or states with placeholder art and final text before puzzle logic is added.

Goal:

- the whole slice can be clicked through from start to finish.

### Step 2 — Puzzle interaction

Replace the placeholder puzzle state with one simple playable mechanic.

Goal:

- the player can complete one small puzzle and trigger the success state.

### Step 3 — Restoration feedback

Add the smallest possible environmental change after puzzle success.

Examples:

- lantern glow strengthens
- banner brightens
- board pattern lights softly
- ambient scene warms slightly

Goal:

- success visibly changes the world, even in a minimal way.

### Step 4 — Archive fragment reveal

Attach the Archive panel to the success flow.

Goal:

- the player understands that the puzzle restored meaning, not only arrangement.

### Step 5 — Final tone cleanup

Run one pass to remove anything that feels like conventional puzzle-game UI or quest language.

Goal:

- the slice feels recognizably GemVerse rather than genre-default placeholder design.

---

## Assembly Dependencies by Role

### Writer / narrative support

Needed before build lock:

- final selected lines from the dialogue/content pack
- final Archive fragment choice
- final button copy

### Artist / UX support

Needed before visual lock:

- Arena background selection
- Keeper visual treatment
- board visual style
- restored-state cue
- panel style for dialogue and Archive fragment

### Builder / implementer

Needed before prototype review:

- scene flow wiring
- puzzle logic
- state transition triggers
- text placement
- success state trigger

One person can do all roles in rough form if needed.

---

## Hard Constraints During Assembly

These are non-negotiable for this slice.

- No boosters, bombs, blasts, power-ups, or combo multipliers.
- No energy, stamina, or life gating.
- No victory banner, stars, medal screen, or score celebration.
- No hero, savior, conquest, or battle wording.
- No companion-helper mechanics framed as tools.
- No pressure into a next level at the end of the slice.

If any of these appear, the prototype is drifting off-tone.

---

## Fastest Viable Build Version

If time is short, the fastest viable version is:

- static Arena background
- static Keeper portrait
- one 4x4 puzzle board
- one text box reused across the whole slice
- one Archive card
- one visible restoration effect on success

That is enough to test tone, flow, and meaning.

Do not wait for polished art before building this version.

---

## Definition of Playable for This Slice

Treat the slice as playable when a tester can:

1. arrive in Arena,
2. read the Keeper interaction,
3. start and complete the puzzle,
4. witness a restoration response,
5. read an Archive fragment,
6. return to the Arena closing screen,
7. and describe the experience as restorative rather than combative.

If a tester cannot do all seven, the slice is not yet ready for tone review.

---

## Review Gate After Assembly

Once assembled, review the slice using the QA script.

The build is ready for the next internal step only if:

- Arena clearly reads as civic space,
- the puzzle clearly reads as a world-remnant,
- the success state feels like restoration,
- and no major red-flag checks are triggered.

If it still feels like a generic level-clear loop, revise the copy and UI before adding more content.

---

## Immediate Next Deliverable After This Build

After the prototype exists, the next best document is a short **revision log template** for recording what testers felt, what broke tone, and what should change before expanding the slice.

That would keep the project from drifting once the first real build feedback arrives.
