# Festival Specification — Bloom Equinox
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.02  
**Linked Files:** `01-canon-map.md`, `realm-packet-crystal-forest-draft-20260804.md`, `imp-03-citizen-life-layer-draft-20260804.md`, `puzzle-catalog.md`

---

## Overview

**Name:** Bloom Equinox  
**Theme:** Growth, Renewal, Collective Cultivation  
**Duration:** 5 days (crosses the spring equinox)  
**Realm Focus:** Crystal Forest (primary), all Realms with growing systems  
**Visual Identity:** Cascading blooms, verdant growth patterns, collaborative gardening, seasonal transition motifs  
**Symbol:** Spiral of unfolding leaves (representing growth that builds on itself)  
**Key Activities:** Community garden projects, seed sharing ceremonies, growth pattern observation, collaborative tending

---

## 1. Festival Essence

The Bloom Equinox celebrates the fundamental civilizational commitment to growth — not just the growth of plants, but the growth of understanding, community, and possibility. It is a festival of patient cultivation, recognizing that the most valuable things take time to develop.

In the First Harmony, the Bloom Equinox was when the civilization aligned its growth practices with the natural cycles — when new garden projects were begun, when seeds were shared between Realms, when growth pattern specialists from all communities gathered to exchange knowledge about cultivation techniques that worked.

The festival embodies Growth not as forced acceleration, but as **patient, collaborative nurturing** — the understanding that tending conditions is more important than demanding results.

---

## 2. Restoration Era Adaptation

In the Restoration Era, the Bloom Equinox has become even more vital as a reminder that growth continues even in challenging conditions. Communities that might struggle with other aspects of restoration often excel at growing things, and the festival serves as a bridge between what can be grown and what can be restored.

### Current Practice:
- **Community Garden Renewal**: Starting new garden projects or revitalizing existing ones
- **Seed Library Expansion**: Citizens contributing seeds and cuttings to shared community stores
- **Growth Pattern Observation**: Structured citizen science activities tracking seasonal changes
- **Collaborative Tending Projects**: Multi-community efforts to care for shared growing spaces
- **Knowledge Exchange Sessions**: Gardeners sharing techniques for challenging growing conditions

### Companion Participation:
- **Verdant**: Primary festival leader; teaches growth patterns, facilitates collaborative gardening
- **Bloomtail**: Supports community garden projects, ensures inclusive participation
- **Spark**: Energizes growing projects, helps overcome seasonal discouragement
- **Echo**: Preserves traditional growing techniques and records seasonal changes

---

## 3. Festival Activities

### Community Garden Projects
Collaborative growing initiatives involving multiple citizens:
- **New Garden Installation**: Citizens working together to prepare soil, plant seeds, establish care routines
- **Garden Revitalization**: Restoring neglected growing spaces with community effort
- **Cross-Realm Plant Exchange**: Arranging exchanges of plants that thrive in different conditions
- **Seasonal Transition Planting**: Coordinated planting that takes advantage of seasonal timing

### Seed Sharing Ceremonies
Structured exchanges of growing materials between communities:
- **Community Seed Libraries**: Citizens contributing seeds and cuttings to shared collections
- **Cross-Realm Seed Exchange**: Formal systems for sharing plants between different Realms
- **Heirloom Preservation**: Identifying and protecting traditional plant varieties
- **Adaptive Variety Development**: Collaborative breeding projects for plants suited to current conditions

### Growth Pattern Observation
Citizen science activities focused on understanding cultivation:
- **Seasonal Tracking Projects**: Citizens recording changes in their local growing conditions
- **Cross-Community Data Sharing**: Pooling observations from different environments
- **Growth Challenge Documentation**: Recording how plants respond to different stressors
- **Collaborative Research Planning**: Identifying questions that multiple communities want to explore

### Collaborative Tending Projects
Multi-community growing initiatives:
- **Shared Greenhouse Management**: Communities coordinating care of large-scale growing facilities
- **Rotating Garden Care**: Citizens from different neighborhoods taking turns tending shared spaces
- **Seasonal Transition Support**: Helping communities adjust growing practices to changing conditions
- **Problem-Solving Networks**: Citizens with different expertise helping each other with growing challenges

---

## 4. Companion Involvement

### Verdant — Growth Pattern Teacher
- **Pattern Guidance**: Teaching citizens to read the signs of healthy plant development
- **Collaborative Garden Design**: Helping communities design growing spaces that serve multiple needs
- **Stress Response Education**: Showing how to understand and support plants under challenge
- **Seasonal Transition Support**: Helping communities adjust practices to changing conditions

### Bloomtail — Community Garden Facilitator
- **Inclusive Participation**: Ensuring all community members can contribute to growing projects
- **Care Coordination**: Organizing schedules and responsibilities for collaborative tending
- **Growth Visualization**: Creating visual representations of community growing achievements
- **Community Bonding**: Using gardening projects to strengthen neighborhood relationships

### Spark — Growing Enthusiasm Catalyst
- **Project Energizer**: Maintaining momentum in long-term growing projects
- **Seasonal Morale Support**: Helping communities stay positive during challenging growing periods
- **Creative Solution Inspiration**: Suggesting innovative approaches to growing problems
- **Celebration Organizer**: Planning moments of recognition for growing achievements

### Echo — Traditional Knowledge Keeper
- **Historical Technique Preservation**: Recording traditional growing methods from elder citizens
- **Seasonal Change Documentation**: Maintaining records of how growing conditions have shifted
- **Knowledge Synthesis**: Helping communities learn from successful growing practices elsewhere
- **Memory Sharing**: Facilitating communication between experienced and new gardeners

---

## 5. Puzzle Integration

### Verdance Cultivation Puzzles
Growing-focused puzzles that mirror festival activities:
- **Garden Layout Design**: Puzzles that balance different plant needs in shared growing spaces
- **Seasonal Transition Planning**: Logic puzzles that optimize planting schedules for changing conditions
- **Resource Distribution Optimization**: Balancing water, nutrients, and care responsibilities among citizens
- **Problem-Solving Networks**: Puzzles that connect citizens with different growing expertise

### Harmony Alignment Puzzles
Puzzles that reflect the festival's collaborative nature:
- **Community Garden Coordination**: Multi-player puzzles that require synchronized actions from different participants
- **Cross-Community Resource Sharing**: Puzzles that optimize the distribution of growing materials between communities
- **Knowledge Exchange Facilitation**: Puzzles that help citizens find the right expertise for their growing challenges
- **Collective Decision Making**: Puzzles that require consensus-building for community growing projects

### Fragment Assembly Puzzles
Puzzles that preserve growing knowledge:
- **Traditional Technique Reconstruction**: Reassembling fragmented records of historical growing methods
- **Seasonal Timing Records**: Combining observations from different communities to understand optimal timing
- **Adaptive Variety Development**: Puzzles that reveal how traditional varieties can be modified for current conditions
- **Cross-Realm Growing Guide Synthesis**: Creating comprehensive guides from techniques used in different Realms

---

## 6. Visual & Audio Atmosphere

### Visual Elements
- **Cascading Bloom Effects**: Visual representations of plants growing and blooming in coordinated sequences
- **Growth Pattern Displays**: Interactive visualizations showing how plants develop over time
- **Community Garden Maps**: Shared displays showing the locations and progress of collaborative growing projects
- **Seasonal Transition Indicators**: Visual markers showing how growing conditions change through the festival
- **Collaborative Tending Timelines**: Visual schedules showing when different community members contribute to shared gardens

### Audio Elements
- **Garden Ambience Soundscapes**: Blended recordings of growing spaces from different communities
- **Seasonal Soundscape Evolution**: Audio that shifts to reflect the progression from early spring to full bloom
- **Collaborative Music Making**: Citizens contributing musical elements that blend into evolving compositions
- **Growth Sound Documentation**: Recording the subtle sounds of plants growing and changing
- **Community Garden Communication**: Audio environments that represent the coordination needed for shared projects

---

## 7. Accessibility & Inclusion

### Physical Accessibility
- **Multiple Garden Access Points**: Ensuring all growing spaces are accessible to citizens with mobility challenges
- **Adaptive Gardening Tools**: Providing equipment that allows citizens with different physical abilities to participate
- **Seated Gardening Options**: Areas designed for citizens who need to work from chairs or other support
- **Sensory Garden Sections**: Growing spaces designed to engage multiple senses for citizens with different sensory needs

### Cognitive Accessibility
- **Clear Growth Stage Indicators**: Visual markers that show what stage plants are in and what care they need
- **Simple Care Instructions**: Basic guidance that allows all citizens to contribute meaningfully
- **Flexible Participation Options**: Multiple ways to engage with growing projects from simple tasks to complex planning
- **Support Systems**: Companion and citizen helpers available for citizens who need additional assistance

### Social Accessibility
- **Inclusive Community Design**: Growing projects structured to welcome citizens who might otherwise feel excluded
- **Cultural Sensitivity**: Respect for different community traditions around growing and seasonal celebration
- **Communication Support**: Systems that help citizens with different communication needs participate fully
- **Barrier Reduction**: Active systems to identify and remove obstacles to participation

---

## 8. Festival Rewards (Cosmetic Only)

### Growing Achievements
- **Bloom Pattern Designs**: Visual representations of successful growing patterns achieved during the festival
- **Community Garden Maps**: Cosmetic items showing the layouts of collaborative growing projects
- **Seasonal Transition Markers**: Visual indicators of successful adaptation to changing growing conditions

### Personal Commemoratives
- **Gardener's Recognition Ribbons**: Visual indicators of citizen contribution to festival growing projects
- **Collaborative Care Badges**: Recognition of participation in shared tending responsibilities
- **Knowledge Sharing Medals**: Commemoratives for citizens who contributed traditional growing techniques

### Companion Recognition
- **Growth Teacher Crowns**: Visual indicators when companions have successfully taught growing techniques
- **Community Garden Facilitator Displays**: Companion cosmetics that reflect their role in collaborative projects
- **Seasonal Adaptation Symbols**: Visual recognition of companions who helped communities adjust to seasonal changes

---

## Files Updated / Referenced

- `tier-roadmap-tracker.md` — Festival Encyclopedia status: 2/10 complete
- `asset-registry.md` — Bloom Equinox festival art tags pending
- `puzzle-catalog.md` — Verdance Cultivation puzzle references updated