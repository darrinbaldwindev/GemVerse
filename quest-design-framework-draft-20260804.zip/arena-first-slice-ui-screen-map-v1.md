# Arena First Slice UI Screen Map

Version: v1  
Status: Draft — Creator Review Required  
Date: 2026-06-26 AEST  

Project: GemVerse  
Realm: Arena  
Owner: Creator  
Prepared by: Perplexity (assistant)  

Related files:

- `arena-first-experience-spec-v1.md`
- `arena-first-slice-dialogue-content-pack-v1.md`
- `implementation-checklist-arena-first-slice-v1.md`
- `arena-slice-qa-script-v1.md`
- `arena-realm-production-brief.md`

---

## Purpose

This file maps the Arena first slice into a simple, screen-by-screen prototype flow so a builder can implement the first playable GemVerse experience without inventing UI structure from scratch.

It is intended for a rough but coherent prototype, not a final polished UI specification.

---

## Flow Summary

Recommended screen order:

1. Arrival screen  
2. Lantern Keeper dialogue screen  
3. Puzzle introduction overlay  
4. Puzzle screen  
5. Restoration response screen  
6. Archive fragment panel  
7. Return-to-Arena screen

This flow should feel intimate, readable, and lightly guided.

---

## Global UI Rules for This Slice

Apply these rules across every screen in the slice.

- No boosters, bombs, blasts, combo multipliers, or energy bars.
- No combat, victory, challenge, or hero framing in labels.
- Buttons should feel calm and invitational.
- The screen should privilege atmosphere, text clarity, and one action at a time.
- If score exists under the hood, do not foreground it in the UI.
- Companion presence, if used, should be small and optional, never dominant.

---

## Screen 1 — Arrival Screen

### Purpose

Establish Arena as a civic gathering place and give the player a calm first impression.

### Visual contents

- Arena background art or mockup
- One still-burning lantern as focal point
- Soft environmental details such as paths, banners, benches, notice-boards, greenery
- Optional subtle ambient motion (lantern glow, drifting light, small cloth movement)

### Text block

Use one arrival line from the dialogue pack.

Recommended default:

"The first thing you notice is not grandeur, but care. A lantern still burns. The paths are still tended. Someone has been keeping this place ready for arrivals."

### UI elements

- Main text box or narration panel
- One primary button: `Look around`

### Avoid

- Busy top HUD
- Currency bars
- Play/battle/challenge CTA language
- Any feeling of a lobby for a conventional puzzle game

### Transition out

Pressing `Look around` moves to Screen 2.

---

## Screen 2 — Lantern Keeper Dialogue Screen

### Purpose

Introduce a grounded human presence and frame Arena through care and civic memory.

### Visual contents

- Same Arena environment, slightly reframed or zoomed
- Lantern Keeper portrait, bust, or in-scene figure
- Optional small companion presence in corner if desired

### Text block

Recommended sequence:

1. "We keep the lantern lit for arrivals, even when we don't know who is coming."
2. "We used to keep careful records here. Not only in ledgers, but in paths, lantern marks, worn stone, and the way people made room for one another."

### UI elements

- Dialogue panel
- Speaker name: `Lantern Keeper`
- Primary button: `Show me`
- Optional subtle secondary text indicator: `Tap to continue`

### Avoid

- Quest-style exclamation icons
- RPG command menus
- Overly mystical or grand presentation

### Transition out

Pressing `Show me` opens Screen 3.

---

## Screen 3 — Puzzle Introduction Overlay

### Purpose

Frame the first puzzle as an act of remembering, not a level challenge.

### Visual contents

- Arena background dimmed or blurred slightly
- Overlay card or panel describing the puzzle context
- Optional small diagram / fragment motif

### Text block

Recommended sequence:

1. "If you have a moment, help me with something small. That's often where remembering begins."
2. "This place carried more gatherings than one ledger could hold. Some records slipped away. Help me remember what once filled this square."
3. "This pattern marked the opening of Harmony Week. Restore it, and the square may remember how it felt when every path led here."

### UI elements

- Overlay title, optional: `A Quiet Ledger`
- Primary button: `Begin restoring`
- Secondary button if needed: `Back`

### Avoid

- "Level 1"
- "Mission"
- "Challenge"
- "Difficulty"

### Transition out

Pressing `Begin restoring` opens Screen 4.

---

## Screen 4 — Puzzle Screen

### Purpose

Deliver the first interactive restoration moment.

### Visual contents

- Small puzzle board (4x4 or 5x5)
- Minimal board frame integrated into Arena style
- Quiet environmental backdrop or faded plaza texture
- Optional small Keeper or companion icon, if needed for line delivery

### UI elements

Required:

- Puzzle board
- One small text area for hints or reminder lines
- Primary action button if the mechanic needs confirmation, otherwise direct manipulation only
- Exit/back control only if consistent with prototype scope

Allowed labels:

- `Try again`
- `Return to the square`

Not allowed:

- `Power up`
- `Boost`
- `Clear board`
- `Use bomb`
- `Victory`
- `Next level`

### Hint behavior

If the player hesitates or retries, use one line at a time from the dialogue pack, such as:

- "Not every trace points to the same kind of gathering. Look for what people left ready for one another."
- "The square remembers more than ceremony. Some marks belong to ordinary meetings."

### Avoid

- Harsh fail screens
- Big points popups
- Combo multipliers
- Energy or lives countdowns
- Highly saturated destruction VFX

### Transition out

Successful completion opens Screen 5.

---

## Screen 5 — Restoration Response Screen

### Purpose

Let success land as recognition and reconnection.

### Visual contents

- Same Arena scene or puzzle scene transitioning back toward the plaza
- Small environmental change: lit banner, glow in the restored pattern, warmer lantern response
- Optional soft sound cue implied in implementation notes

### Text block

Recommended default:

"The last line falls into place. For a heartbeat, you hear echoes — footsteps, soft laughter, someone calling a familiar name. Nothing returns all at once, but the square remembers enough to answer."

Keeper follow-up:

"A small thing restored is still a real return."

### UI elements

- Primary button: `Read fragment`

### Avoid

- Giant success banner
- Confetti or triumph VFX
- Performance stars or medals

### Transition out

Pressing `Read fragment` opens Screen 6.

---

## Screen 6 — Archive Fragment Panel

### Purpose

Make the meaning of the puzzle explicit through a small, human-scale record.

### Visual contents

- Archive card or modal
- Optional icon or simple crest motif
- Background remains Arena, dimmed gently

### Text block

Recommended default:

**Archive Fragment**  
"Harmony Week Ledger, Year 173 of the First Harmony. Names of each community that sent someone, written in the same patient hand."

### UI elements

- Title: `Archive Fragment`
- Primary button: `Continue`

### Avoid

- Long lore dump
- Dense encyclopedia page
- Overexplaining the world too early

### Transition out

Pressing `Continue` opens Screen 7.

---

## Screen 7 — Return-to-Arena Screen

### Purpose

Return the player to the plaza with a sense that one small part of the world has answered.

### Visual contents

- Arena background in restored state
- One visible change from the start of the slice: lit lantern response, glowing pattern, subtle environmental warmth
- Keeper remains present or visible nearby

### Text block

Recommended default:

"This is only one pattern. There are others, tucked into corners, carved under dust. Each one remembers a different way people stood together."

### UI elements

- Primary button: `End for now`
- Optional secondary button later in development: `Explore later`

### Avoid

- Immediate pressure into another level
- Reward shop presentation
- Progress gate language

### Transition out

This screen ends the slice.

---

## Minimal State Diagram

```text
Arrival
  -> Look around
Lantern Keeper dialogue
  -> Show me
Puzzle introduction
  -> Begin restoring
Puzzle screen
  -> success
Restoration response
  -> Read fragment
Archive Fragment
  -> Continue
Return to Arena
  -> End for now
```

---

## Builder Notes

For a rough prototype, the whole slice can be built with:

- 1 Arena background
- 1 Lantern Keeper portrait or simple figure presence
- 1 puzzle board state
- 1 restored board/environment state
- 1 Archive panel style
- 7 short text states

This is enough to test whether the slice feels like GemVerse before investing in broader systems.

---

## QA Checks for This Screen Map

Before implementation is treated as ready:

- Every screen has only one clear primary action.
- No screen introduces generic puzzle-game framing.
- Arena always reads as civic and welcoming.
- The puzzle reads as restoration, not destruction.
- The emotional sequence remains: welcome -> noticing -> restoring -> remembering.

If any screen feels like a mobile puzzle lobby or level-clear flow, revise before continuing.
