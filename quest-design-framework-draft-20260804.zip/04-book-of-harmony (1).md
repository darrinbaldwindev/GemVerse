# Book of Harmony
**GemVerse Master Bible — Tier 1 Entry**
**Status:** Canon-Safe Expansion | Built on confirmed locked canon + draft foundations
**Canon Source:** Transfer Volumes 1, 3, 6; Perplexity session confirmed canon

---

## Purpose

This document is the full Master Bible entry for the Book of Harmony — the foundational wisdom text of the First Harmony and the philosophical bedrock of GemVerse civilization. It establishes the Book's origins, structure, voice, principles, surviving fragments, and commentary tradition. All other Tier 1 entries reference this document. It should be written and approved before any other Tier 1 work proceeds.

---

## What the Book of Harmony Is

The Book of Harmony is the collected wisdom of civilization — not a sacred scripture, a legal code, or a prophecy, but something older and more humble than any of those things.

Archive scholars most often describe it as:

> *"The memory of how civilization learned to live together."*

It is a living record in one sense: it accumulated across generations, welcoming new observations alongside ancient ones, preserving contradictions rather than resolving them. In another sense, it is fixed: the original text stands unchanged, as it was compiled during the First Harmony. What has grown around it — centuries of commentary, reflection, interpretation, and response — is not the Book itself. It is the civilization that the Book made possible, talking back.

When the Shattering came, portions of the Book were lost. The Archive continues the work of reconstruction. Guardians who recover fragments of the Book are contributing to one of the most significant acts of memory restoration available to them.

---

## Origins

### Authorship

> **⚠️ OPEN CANON — Author not yet finalized. Three proposals below. User must confirm before this section is locked.**

**Proposal A — The Harmony Council**
The Book was compiled by the seven founding members of the Harmony Council — one representative from each House — during the height of the First Harmony. Each contributed the wisdom of their Pillar. The result is a text with seven distinct voices braided into one, designed to be read not as a single argument but as a sustained conversation about balance.

**Proposal B — The Original Harmonists**
Before the Houses were formalized, a generation of wandering philosophers called the Harmonists traveled between nascent communities, observing what made civilizations flourish and what made them fail. They compiled their observations over a lifetime of travel. The Book is their testament — rougher, more personal, and closer to lived experience than any institutional document.

**Proposal C — A founding author with later additions**
A single person — whose name the Archive does not agree upon — wrote the foundational text. Subsequent generations added volumes. The original author's voice anchors Volumes I through III; Volumes IV through VII were added across centuries by scholars, Lantern Keepers, and ordinary citizens who recognized something true worth recording. Volume VIII was never authored by anyone — it assembled itself from the voices of people who had no title, only something worth saying.

*Recommended direction for user consideration: Proposal B or C gives the Book a more emotionally resonant origin than a council document. A collective of wandering observers or a single humble author creates the sense that the Book was earned through experience, not decreed through authority.*

### When It Was Compiled

During the First Harmony — in the era when civilization was at its most connected and the Seven Pillars were in healthy relationship. The Book was not written in crisis. It was written during belonging, which is part of why it speaks about belonging so well, and why its loss during the Shattering cut so deeply.

### The Fixed Text and the Commentary Tradition

The original seven volumes are considered fixed. They are preserved exactly as compiled, including passages that seem to contradict each other, questions that were never answered, and observations that later generations found uncomfortable or incomplete. The Book does not pretend civilization has always known the right answer. It preserves the learning process itself.

What grew around the fixed text is the **Commentary Tradition** — an unbroken practice, maintained by Archive Scholars and those on the Chronicler Path, of writing responses, interpretations, and reflections on individual passages. Commentary is never inserted into the original text. It exists alongside it, clearly labeled by era and author. A Guardian reading any passage of the Book can scroll outward to find centuries of responses — arguments, agreements, poems, personal stories, corrections, and unanswerable questions that other readers left behind.

The Commentary Tradition is one of the Great Archive's most active ongoing projects.

### Volume VIII — On Belonging

Volume VIII is different from all the others.

It has no single author. It was never formally compiled. It accumulated — slowly, over generations — as citizens who had felt deeply connected to civilization, or deeply separated from it, wrote down what belonging meant to them and gave those words to the Archive. Lantern Keepers collected them. Chroniclers gathered them. Some arrived as scraps of parchment. Some came as oral testimony recorded by Archive scribes.

Volume VIII is the hidden volume because civilization did not realize it was writing one. It only became recognizable as a volume when someone at the Archive looked at the accumulation and understood that these were not random fragments — they were the same conversation, conducted by thousands of people across hundreds of years who had never met.

Volume VIII is the proof that Belonging is the Eighth Pillar — not because a scholar declared it so, but because ordinary people kept returning to it, unprompted, across generations.

---

## Structure

The Book of Harmony is organized into eight volumes, each with its own character and purpose. Within each volume, entries are grouped into section types rather than numbered chapters, because the Book was not designed to be read cover-to-cover — it was designed to be lived with, returned to, and discovered one passage at a time.

### The Eight Volumes

**Volume I — On Knowledge**
The first volume. Observations about how civilization learns — what knowledge is for, how it is preserved, what happens when it is hoarded, and what wisdom is that knowledge alone cannot provide. The most formally structured volume. Scholars on the Scholar Path often begin here.

**Volume II — On Discovery**
A more restless, searching volume than the first. Reflections on exploration, on what is found, on what it means to venture beyond what is known. Includes some of the Book's most celebrated passages about wonder. Pathfinders often carry a copy.

**Volume III — On Growth**
The warmest volume. Concerned with how things — communities, skills, people, traditions — develop over time. A significant portion is devoted to mentorship, to the relationship between those who have learned and those who are learning.

**Volume IV — On Memory**
The most fragmented volume, even before the Shattering damaged it. Memory was always the Pillar most aware of its own vulnerability. Volume IV contains more questions than answers. Chroniclers maintain a running effort to reconstruct missing passages.

**Volume V — On Community**
A practical volume. Less philosophical than some, more concerned with the actual texture of how people live together. Includes accounts of communities that thrived and communities that fell apart. Some passages read almost like case studies; others like letters home.

**Volume VI — On Harmony**
The most difficult volume to read because it is about balance between things that pull against each other. It does not pretend Harmony is easy or natural. It documents the effort required to maintain it — and the speed with which it can unravel when that effort stops.

**Volume VII — On Legacy**
The closing volume of the original text. Concerned with what endures — what a civilization owes to the generations that will come after it, and what those generations will inherit or lose depending on the choices made now. The final passage of Volume VII ends mid-sentence; scholars debate whether this was intentional or a loss from the Shattering.

**Volume VIII — On Belonging**
See above. The hidden volume. Never formally written. Accumulated across generations. The Archive maintains it as a living collection — new entries continue to be added by citizens and Guardians today.

### Section Types (within each volume)

| Section Type | Description |
|---|---|
| Reflections | Meditative observations — short, quotable, often one to three sentences. The most widely remembered passages come from here. |
| Observations | Longer, more analytical entries. Often compare or contrast different communities, eras, or approaches. |
| Parables | Stories — short enough to tell in one sitting, long enough to stay with you. Some are clearly fictional; some are claimed to be true. The Book does not always distinguish them. |
| Historical Accounts | Records of specific events, decisions, or developments from the First Harmony. More factual in tone, though Archive scholars note that "factual" in an oral tradition requires care. |
| Guardian Contributions | Entries attributed to named Guardians who contributed observations from their restoration work. Added to the living text across the Restoration Era. |
| Pillar Teachings | Direct elaborations of each Pillar — what it means in practice, how it interacts with others, what its failure looks like. |
| Questions Without Answers | A section in every volume. These are questions the original compilers could not answer, asked aloud so that future readers would not feel alone in not knowing. |
| Companion Testimonies | Accounts attributed to Companions — their memories, their observations about civilization before and after the Shattering. Some of the most emotionally affecting entries in the Book. |

---

## The Twelve Principles

These are the most widely quoted distillations of the Book's philosophy. They are not commandments — the Book is explicit that it does not command. They are observations that enough readers across enough generations agreed were simply true.

1. Balance requires effort. It does not maintain itself.
2. Knowledge without wisdom creates imbalance.
3. Discovery without responsibility creates imbalance.
4. Growth without memory creates imbalance.
5. Memory without growth creates stagnation.
6. Harmony is the effort of maintaining relationship between things that would otherwise drift.
7. Belonging cannot be commanded. It can only be cultivated.
8. Civilization survives when memory survives.
9. No individual holds the whole truth. Wisdom emerges collectively.
10. Community is not proximity. It is participation.
11. Legacy is not fame. It is contribution remembered by those who come after.
12. The purpose of restoration is not to return to what was. It is to remember what was worth keeping.

> *Canon note: These twelve are expanded from the ten confirmed in the Transfer Volume 1 draft. Principles 10 and 12 are canon-safe expansions — they are direct expressions of established GemVerse philosophy. **Flag for user review before locking.***

---

## Known Surviving Fragments

These are passages from the Book that survived the Shattering in recoverable form. They are not invented — they are built from the four thematic draft fragments confirmed in the transfer, plus canon-safe expansions written in the same voice.

**All fragments are labeled by volume of origin where known. Fragments marked [Volume Unknown] are confirmed to exist but have lost their source location.**

---

> *"To remember alone is preservation.*
> *To remember together is civilization."*
— Volume IV, On Memory

---

> *"Every lantern lights a path.*
> *Together they illuminate a world."*
— [Volume Unknown — attributed to the Lantern Keepers' oral tradition; exact origin disputed]

---

> *"What is discovered belongs first to wonder,*
> *then to understanding,*
> *then to those who come after."*
— Volume II, On Discovery

---

> *"The future is not inherited.*
> *It is entrusted."*
— Volume VII, On Legacy

---

> *"A civilization that forgets how to ask questions*
> *has forgotten how to learn."*
— Volume I, On Knowledge, Questions Without Answers section

---

> *"Balance is not a destination.*
> *It is a practice.*
> *Every day without it is a day it must be rebuilt."*
— Volume VI, On Harmony

---

> *"Growth that forgets where it began*
> *does not know where it is going."*
— Volume III, On Growth

---

> *"The loneliest thing a person can believe*
> *is that their contribution does not matter.*
> *The Archive exists to prove them wrong."*
— Volume V, On Community

---

**Fragments from Volume VIII — On Belonging (citizen voices)**

> *"I did not know I belonged until I left.*
> *I did not know what I had built*
> *until I saw what others were trying to rebuild."*
— Volume VIII, citizen contribution, era unknown

---

> *"No one told me I was part of something.*
> *I just kept showing up,*
> *and one day I looked around*
> *and saw that something had grown around me."*
— Volume VIII, citizen contribution, era unknown

---

> *"My name is not in any record.*
> *But I taught three people who taught ten people*
> *who built something that still stands.*
> *That is enough.*
> *That is more than enough."*
— Volume VIII, citizen contribution, Restoration Era

---

> *Canon note: The four confirmed draft fragments are included above unchanged. The remaining fragments are canon-safe expansions written in the same established voice. **Flag for user review before locking.***

---

## The Book After the Shattering

When the Shattering came, the Book of Harmony did not survive intact.

Some volumes were preserved in the Great Archive, protected by Memory Crystals before the Crystal Network failed. Volume I and Volume V are the most complete. Volume IV — On Memory — suffered the cruelest irony: it is the most damaged volume. Large portions survive only in referenced quotations from other sources, where scholars cite passages that no longer exist in any known copy.

Volume VII's final passage ends mid-sentence. Scholars have debated for generations whether the original text was always incomplete — whether the author stopped deliberately, asking future readers to finish the thought — or whether the ending was lost. The Archive catalogs this question in its Archive of Unanswered Questions. It has not been answered.

Volume VIII continues to grow. New entries arrive from citizens and Guardians. It is the only volume that is actively, openly expanding. In some sense, the Shattering could not damage Volume VIII — because Volume VIII was never finished to begin with.

---

## The Book and the Seven Pillars

Each volume of the Book aligns with one of the seven public Pillars. This is not a coincidence — it reflects the understanding that civilization requires all seven to be held in balance simultaneously. Reading only the volume of your own House Pillar is considered a beginner's approach. Scholars note that every volume is, in some sense, about all seven Pillars — it just approaches them from one angle first.

| Volume | Pillar | House Alignment |
|---|---|---|
| Volume I | Knowledge | Lumina |
| Volume II | Discovery | Astra |
| Volume III | Growth | Verdance |
| Volume IV | Memory | Borealis |
| Volume V | Community | Hearthlight |
| Volume VI | Harmony | Solstice |
| Volume VII | Legacy | Legacy |
| Volume VIII | Belonging | — (no House; all citizens) |

House Solstice (Harmony) holds the view that Volume VI is the most important volume because it describes how all other Pillars relate to each other. Most other Houses politely disagree. This disagreement is itself considered an example of what Volume VI is about.

---

## The Book in the Restoration Era

Guardians who spend time in the Great Archive will encounter the Book of Harmony in fragmented form — some volumes nearly complete, others reduced to a handful of surviving passages with large gaps. The Archive labels every gap clearly rather than filling it with approximations.

A significant portion of Guardian archival work involves recovering additional fragments of the Book from across the Realms — found in the ruins of libraries, encoded in Crystal Network nodes, preserved in Companion memories, embedded in Lantern traditions. Each recovered passage is added to the Archive's edition of the Book, with a note on where and how it was found and by whom.

The Chronicler Path regards Book recovery as among the highest forms of contribution available to a Guardian.

---

## Relationship to Other Systems

- **Great Archive:** The Archive is the primary preserver and distributor of the Book. Every Archive site across the Realms maintains the most complete version of the Book that could be recovered for its region.
- **Crystal Network:** The most complete copies of the Book before the Shattering were distributed through Crystal Network nodes. Recovery of Crystal nodes sometimes recovers Book passages.
- **Lantern Network:** The Lantern Keepers maintained oral versions of key passages — particularly from Volume V (Community) and Volume VIII fragments. Some passages survive only because Keepers memorized them.
- **Commentary Tradition:** Maintained by Archive Scholars and Chronicler Path Guardians. Centuries of response text surround the original. Commentary is never inserted into the Book itself — it exists in a separate, labeled layer.
- **Puzzles:** Some puzzles in the Archive Realm are organized around recovering, decoding, or contextualizing Book of Harmony fragments. These are Archive Puzzles.
- **Harmony Index:** The Book is considered foundational context for understanding what the Harmony Index is measuring and why. Guardians who have read more of the Book are said to perceive the Harmony Index differently — not as a meter, but as a mirror.

---

## Canon Notes

**Pillars touched:** All eight (each volume addresses one; Volume VIII addresses the hidden eighth)
**Houses touched:** All seven (each aligned to a volume)
**Paths most relevant:** Chronicler (recovery and commentary), Scholar (study and interpretation), Harmonist (Volume VI)
**Systems touched:** Great Archive, Crystal Network, Lantern Network, Commentary Tradition, Archive Puzzles, Harmony Index
**Open mysteries not resolved:** The Seventh Lantern (referenced in oral Lantern tradition alongside Book passages — not clarified), Volume VII's missing ending (left open deliberately)
**Conflicts resolved in this document:** Conflict 1 (living document vs. fixed text — resolved as fixed original + commentary tradition)
**Open items flagged:** Author identity (3 proposals), Principles 10 and 12 (expansions), Fragments beyond the confirmed four (expansions) — all require user review before locking

---

## Review Checklist

- [ ] Does this entry reinforce belonging, restoration, memory, and legacy as the heart of GemVerse civilization?
- [ ] Does anything here contradict the confirmed canon that the Book's original text is fixed?
- [ ] Does anything drift toward a religious, prophetic, or legalistic framing that the confirmed canon explicitly excludes?
- [ ] Does Volume VIII feel like a natural emergence of citizen voices rather than a designed product?
- [ ] Do the fragments feel earned and world-appropriate — not modern, not generic, not purple?
- [ ] Does the relationship between the Book and the Great Archive / Crystal Network / Lantern Network make sense as connected civilization infrastructure?
- [ ] Is the author identity question clearly flagged as unresolved, with proposals that do not inadvertently close other canon?
- [ ] Do the canon-safe expansions (Principles 10 & 12, additional fragments) pass the Final Test: do they make GemVerse feel more worth belonging to?
