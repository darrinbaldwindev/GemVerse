# GemVerse — Arena First Slice Launch Readiness Checklist

**Purpose:** Final verification before releasing the Arena Realm first slice (playable prototype). Run each item in order. Do not release until every item is ✅.

---

## Phase 0: Pre-Launch Gate (Must Pass Before Internal Playtest)

| # | Check | Owner | Status | Evidence |
|---|-------|-------|--------|----------|
| 0.1 | All 8 creator-only decisions resolved (Dark Gem, Companion launch list, Power-ups, Taglines, Heart of Core, Forestkin/Verdankin, Guardian Bible, First Harmony) | Creator | ⬜ | `DECISION_LOG.md` all `Locked` |
| 0.2 | Arena Realm PRS Context v1.0+ approved | Creator | ⬜ | `Arena_Realm_PRS_Context_v1.md` |
| 0.3 | Arena Production Brief v1.0+ approved | Creator | ⬜ | `arena-realm-production-brief.md` |
| 0.4 | Kael reframe Option A (Champion of Contribution) integrated in all packets | Dev | ⬜ | `decision-kael-arena-champion-v1.md`, companion packets |
| 0.5 | Dark Gem renamed to Dusk/Twilight across all systems | Dev | ⬜ | `puzzle-catalog.md`, `asset-registry.md`, Construct 3 |
| 0.6 | First Harmony duration/Threshold model locked | Creator | ⬜ | `05-first-harmony.md` |
| 0.7 | Book of Harmony authorship/Principles 10&12 locked | Creator | ⬜ | `04-book-of-harmony.md` |
| 0.8 | Power-ups/boosters/combo systems fate decided | Creator | ⬜ | `DECISION_LOG.md` (DEF-003) |
| 0.9 | Companion launch list (Lumi/Ember/Frosty) decided | Creator | ⬜ | `DECISION_LOG.md` (DEF-006) |
| 0.10 | Forestkin vs Verdankin naming decided | Creator | ⬜ | `DECISION_LOG.md` (DEF-007) |
| 0.11 | Guardian Role Bible Vol 1 canon split confirmed | Creator | ⬜ | `guardian_role_bible_volume_1.md` |
| 0.12 | Tagline variants decided | Creator | ⬜ | `DECISION_LOG.md` (DEF-004) |
| 0.13 | Heart of the Core naming decided | Creator | ⬜ | `DECISION_LOG.md` (DEF-005) |
| 0.14 | Construct 3 project opens and builds without errors | Dev | ⬜ | C3 project file |
| 0.15 | All 8 puzzle types implemented in Construct 3 event sheets | Dev | ⬜ | Event sheet audit |
| 0.16 | Match-3 primary board + cascade system functional | Dev | ⬜ | Gameplay test |
| 0.17 | Scene structure: MainMenu, GamePlay, Story, RealmCF, RealmFE, RealmAR | Dev | ⬜ | Scene list |
| 0.18 | Asset registry v2.0+ current; all FLAGGED items resolved | Dev | ⬜ | `asset-registry.md` |
| 0.19 | Canon risk report (2026-06-01) cleared for Arena assets | Dev | ⬜ | `canon-risk-report-20260601.md` |
| 0.20 | Visual framing notes for Arena/Kael integrated | Dev | ⬜ | `gemverse-visual-framing-notes-arena-kael-v1.md` |

---

## Phase 1: Canon & Narrative Verification

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 1.1 | No villain/chosen-one/power-fantasy/grimdark language in Arena text | ⬜ | Text audit |
| 1.2 | Arena framed as "assembly/community" not "combat/battle" | ⬜ | Text audit |
| 1.3 | Kael described as civic contributor, not warrior | ⬜ | Dialogue audit |
| 1.4 | Spark described as witness/companion, not mechanic | ⬜ | Dialogue audit |
| 1.4 | Puzzles described as archaeological/civilizational fragments | ⬜ | Text audit |
| 1.5 | No energy/stamina gating language | ⬜ | UI text audit |
| 1.6 | No gacha/companion collection language | ⬜ | UI text audit |
| 1.7 | Primary tagline only: "Restore Realms. Build Your Legacy." | ⬜ | UI audit |
| 1.8 | Resource bars = collection/cosmetic only | ⬜ | UI audit |
| 1.9 | Dusk/Twilight gem used (no "Dark Gem" references) | ⬜ | Asset audit |
| 1.10 | All Proper Nouns match `01-canon-map.md` spelling | ⬜ | Consistency audit |
| 1.11 | Five Wounds names match `06-five-wounds.md` exactly | ⬜ | Consistency audit |
| 1.12 | Crystal Network / Lantern Network references accurate | ⬜ | Lore audit |
| 1.13 | First Harmony / Restoration Era references accurate | ⬜ | Lore audit |

---

## Phase 2: Gameplay & Mechanics Testing

| # | Test Case | Device | Status | Notes |
|---|-----------|--------|--------|-------|
| 2.1 | MainMenu → GamePlay → Story flow works | Mobile (iOS/Android) | ⬜ | Video |
| 2.2 | Arena Realm entry: Guardian arrives at Lantern Plaza | Mobile | ⬜ | Video |
| 2.3 | Kael greeting dialogue plays (civic framing) | Mobile | ⬜ | Video |
| 2.4 | First puzzle: "Quiet Ledger" triggers correctly | Mobile | ⬜ | Video |
| 2.5 | Puzzle type: Crystal Resonance functional | Mobile | ⬜ | Video |
| 2.6 | Puzzle type: Pathfinder's Mark functional | Mobile | ⬜ | Video |
| 2.7 | Puzzle type: Echo Sequence functional | Mobile | ⬜ | Video |
| 2.8 | Puzzle type: Lantern Calibration functional | Mobile | ⬜ | Video |
| 2.9 | Puzzle type: Archive Resonance functional | Mobile | ⬜ | Video |
| 2.10 | Puzzle type: Harmonic Convergence functional | Mobile | ⬜ | Video |
| 2.11 | Puzzle type: Memory Weave functional | Mobile | ⬜ | Video |
| 2.12 | Puzzle type: Threshold Crossing functional | Mobile | ⬜ | Video |
| 2.13 | Companion Spark appears as witness (not mechanic) | Mobile | ⬜ | Video |
| 2.14 | Resource bars show collection only (no depletion) | Mobile | ⬜ | Video |
| 2.15 | No "Game Over" / "Fail" screens — only "Try Again" | Mobile | ⬜ | Video |
| 2.16 | Progress saved locally (no cloud dependency) | Mobile | ⬜ | Save/load test |
| 2.17 | Session length: 15-30 min for first slice | Mobile | ⬜ | Timer test |
| 2.18 | Performance: 60 FPS on target devices (iOS 14+ / Android 10+) | Mobile | ⬜ | Profiler |
| 2.19 | Memory: < 300 MB on target devices | Mobile | ⬜ | Profiler |
| 2.20 | Battery: < 5% drain per 15 min session | Mobile | ⬜ | Battery test |

---

## Phase 3: Visual & Audio Quality

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 3.1 | All Arena assets use approved visual framing notes | ⬜ | Asset audit |
| 3.2 | Kael model: civic attire, no weapons/armor | ⬜ | Model review |
| 3.3 | Spark model: witness posture, soft lighting | ⬜ | Model review |
| 3.4 | Lantern Plaza: warm, welcoming, lived-in | ⬜ | Environment review |
| 3.5 | Archive corner: quiet, scholarly, inviting | ⬜ | Environment review |
| 3.6 | Festival Grounds: communal, hopeful | ⬜ | Environment review |
| 3.7 | Gem visuals: 7 types (including Dusk/Twilight), distinct | ⬜ | Gem review |
| 3.8 | No "Bomb Gem", "Lightning Gem", "Blast" visual language | ⬜ | Asset audit |
| 3.9 | UI text: warm, patient, curious tone | ⬜ | Text audit |
| 3.10 | Audio: ambient soundscape (no combat SFX) | ⬜ | Audio review |
| 3.11 | Music: restorative, civic themes | ⬜ | Audio review |
| 3.12 | Accessibility: colorblind-safe gem colors | ⬜ | Color audit |
| 3.13 | Accessibility: text size scalable, high contrast mode | ⬜ | Accessibility test |
| 3.14 | Accessibility: haptic feedback optional | ⬜ | Settings test |

---

## Phase 4: Technical & Build Verification

| # | Check | Status | Notes |
|---|-------|--------|-------|
| 4.1 | Construct 3 export: iOS (Xcode project) builds | ⬜ | Build log |
| 4.2 | Construct 3 export: Android (AAB) builds | ⬜ | Build log |
| 4.3 | No deprecated Construct 3 features used | ⬜ | Feature audit |
| 4.4 | All event sheets organized, documented | ⬜ | Code review |
| 4.5 | Global variables named per convention | ⬜ | Variable audit |
| 4.6 | No hardcoded values — all in data tables | ⬜ | Data audit |
| 4.7 | Save system: JSON export/import works | ⬜ | Save test |
| 4.8 | Analytics events fire (privacy-compliant): puzzle_start, puzzle_complete, realm_enter | ⬜ | Analytics test |
| 4.9 | No third-party SDKs without approval | ⬜ | Dependency audit |
| 4.10 | App size: < 500 MB (iOS), < 400 MB (Android) | ⬜ | Build artifact |
| 4.11 | Launch time: < 3s cold start | ⬜ | Performance test |
| 4.12 | Crash-free rate target: 99.9% in playtest | ⬜ | Crashlytics |

---

## Phase 5: Operational Readiness

| # | Item | Owner | Status |
|---|------|-------|--------|
| 5.1 | Playtest build distribution (TestFlight / Play Console Internal) | Dev | ⬜ |
| 5.2 | Playtester recruitment: 10-15 target demographic | Owner | ⬜ |
| 5.3 | Feedback form: canon tone, puzzle clarity, enjoyment | Dev | ⬜ |
| 5.4 | Bug reporting channel (GitHub Issues / Discord) | Dev | ⬜ |
| 5.5 | Known issues document (pre-playtest) | Dev | ⬜ |
| 5.6 | Iteration plan: 2-week sprints post-playtest | Owner | ⬜ |
| 5.7 | Next slice scope defined (Sky Citadel / Frozen Expanse) | Owner | ⬜ |
| 5.8 | Companion Encyclopedia content ready for integration | Content | ⬜ |
| 5.9 | Realm packet templates validated for next realms | Content | ⬜ |
| 5.10 | Legal: privacy policy, terms, COPPA/GDPR for mobile | Legal | ⬜ |

---

## Phase 6: Playtest (7-Day Internal)

| Day | Activity | Owner | Success Criteria |
|-----|----------|-------|------------------|
| Day 1 | Distribute TestFlight/Internal build to playtesters | Dev | All testers have build |
| Day 2 | Collect Day 1 feedback (forms + optional calls) | Owner | ≥ 80% completion rate |
| Day 3 | Triage bugs: P0 (crash/canon break), P1 (mechanic), P2 (polish) | Dev | 0 P0, ≤ 3 P1 |
| Day 4 | Fix P0/P1; deploy updated build | Dev | Updated build live |
| Day 5 | Monitor playtest analytics (completion, retention, puzzle times) | Dev | ≥ 60% complete first slice |
| Day 6 | Collect qualitative feedback (tone, confusion, delight) | Owner | NPS ≥ 7 |
| Day 7 | **Go/No-Go decision** for external alpha | Owner | All Phase 0-5 ✅ |

---

## Phase 7: External Alpha Release

| # | Action | Owner | Deadline |
|---|--------|-------|----------|
| 7.1 | Final build uploaded to TestFlight / Play Console Alpha | Dev | Release Day |
| 7.2 | Alpha tester onboarding (NDA, feedback guide) | Owner | Release Day |
| 7.3 | Monitor daily (crashes, progression, feedback) | All | Release Day + 14 days |
| 7.4 | Weekly feedback synthesis → next slice planning | Owner | Weekly |

---

## Phase 8: Post-Alpha (Days 1–60)

| Week | Focus | Key Metrics |
|------|-------|-------------|
| 1-2 | Stabilize | Crash rate, completion rate, puzzle skip rate |
| 3-4 | Canon validation | Tone feedback, lore comprehension, character warmth |
| 5-6 | Mechanics | Puzzle difficulty curve, resource feel, companion presence |
| 7-8 | Systematize | Feedback → decision → implementation loop established |

---

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Creator / Worldbuilder | | | |
| Lead Developer (Construct 3) | | | |
| Narrative Designer | | | |
| Visual Director | | | |
| QA Lead | | | |
| Producer | | | |

---

## Rollback Triggers (Auto-Stop Release)

| Trigger | Action |
|---------|--------|
| Canon violation detected (combat, villain, chosen-one language) | Immediate build pull; text audit |
| Crash rate > 1% in playtest | Pause distribution; fix crash |
| Puzzle completion rate < 40% on first puzzle | Difficulty adjustment; redeploy |
| Negative tone feedback > 30% (combat/frustration) | Narrative review; pause |
| Construct 3 export fails for iOS/Android | Block release; engine debug |

---

## File References

| Checklist | Source Document |
|-----------|-----------------|
| Canon Authority | `01-canon-map.md`, `03-tier1-readiness.md` |
| Arena Context | `Arena_Realm_PRS_Context_v1.md`, `arena-realm-production-brief.md` |
| Conflicts | `02-conflicts-log.md`, `decision-kael-arena-champion-v1.md` |
| Assets | `asset-registry.md`, `canon-risk-report-20260601.md` |
| Visual Framing | `gemverse-visual-framing-notes-arena-kael-v1.md` |
| Puzzles | `puzzle-catalog.md`, `puzzle-arena-the-quiet-ledger-v1.md` |
| Companions | `companion-packet-*.md`, `companion-encyclopedia-*.md` |
| Implementation | `implementation-checklist-arena-first-slice-v1.md` |
| Continuity | `SESSION-LOG.md`, `DECISION_LOG.md`, `RISK_REGISTER.md`, `NEXT_PRIORITIES.md` |
| Handover | `GemVerse_AI_Handover.md`, `GemVerse_AI_Handover_Document.md` |

---

**Final Gate:** No item in Phase 0–5 may remain ⬜ at external alpha release. All Phase 0–5 items must be ✅ with evidence attached.

*End of Launch Readiness Checklist.*