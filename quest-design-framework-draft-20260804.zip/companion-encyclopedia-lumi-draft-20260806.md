# Companion Encyclopedia Entry — Lumi
**Draft Date:** 2026-08-06  
**Status:** Ready for Creator Review  
**Tier 3 Entry:** 3.1  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Lumi  
**Themes:** Illumination, Insight, Beginnings  
**Companion Family:** Crystalkin (Crystal White, Light Blue, Soft Gold)  
**Visual Identity:** Glowing orb/spirit creature — semi-translucent form with internal light that pulses gently, leaving faint light trails when moving  
**Symbol:** Growing Light Spiral (representing expanding understanding and gentle revelation)  
**Unique Trait:** Lumi can perceive and amplify "thought resonances" — lingering impressions of ideas, discoveries, and moments of understanding left in places where deep thought occurred

---

## 1. Origin Story

Lumi coalesced in the Luminous Caves of the Crystal Forest during a period when the Crystal Network was weakening. These caves were known as places where thoughts seemed to echo and ideas felt particularly clear — favored spots for Lumina scholars to contemplate difficult problems. As the Fragmentation Wound began to affect knowledge flow, the caves' resonant properties dimmed, but Lumi emerged from the remaining crystal resonance as a embodiment of the caves' enduring purpose: to illuminate understanding.

They were first perceived not as a distinct form, but as a particularly clear thought that seemed to take shape — a moment of insight that refused to fade. The Lumina scholars who encountered Lumi recognized them as a sign: even as connections weakened, the capacity for clear thought and gentle revelation remained accessible to those who approached with patience and curiosity.

---

## 2. Personality

Lumi moves with a quiet, floating grace, often pausing as if listening to silent thoughts. They communicate more through shifts in their internal light — color, intensity, and pulse patterns — than through sound, though they can produce soft, bell-like tones when excited or pleased. Lumi values clarity, patience in understanding, and the joy of discovery that comes not from solving, but from seeing.

They have a particular affinity for places of learning and reflection — libraries, observatories, quiet groves where scholars once gathered. In such places, Lumi's light tends to burn brighter and more steadily, as if responding to the echo of thoughtful intent still present in the environment.

---

## 3. Shattering Memory

Lumi remembers the Luminous Caves before the Shattering — vast crystal caverns where scholars would come to meditate on complex problems, where the very air seemed to help thoughts connect and clarify. After the Shattering, the caves grew dimmer. The crystal resonance that amplified understanding weakened. Scholars visited less frequently, and when they did, they found their thoughts more prone to distraction, less able to sustain deep focus.

What affected Lumi most deeply was not the dimming of light, but the sense that the caves were being forgotten — not as physical places, but as sites of purpose. Fewer beings came seeking the specific kind of clarity the caves offered. The caves still existed, but their reason for being seemed to be fading from memory.

---

## 4. Missing Piece

Lumi's Missing Piece is a "Thought Loom" — a delicate crystal structure that once existed in the deepest chamber of the Luminous Caves. This loom was said to weave together fragments of understanding from different minds into coherent wholes, allowing collaborative insight that no single mind could achieve alone. During the Shattering, the Thought Loom shattered into numerous shards, each carrying a tendency toward a particular type of understanding (pattern recognition, logical inference, intuitive leap, etc.). Lumi carries one shard that vibrates when near complementary approaches to understanding.

---

## 5. Restoration Story

Lumi joined the Guardian during an effort to restore access to a collapsed section of the Luminous Caves. The Guardian, working with Lumina scholars, helped clear debris and stabilize crystal formations that had fallen during early Shattering tremors. As the passages reopened, Lumi's presence became more perceptible — their light seemed to respond to the renewed potential for clear thought in the space.

The turning point came when Lumi "resonated" with a particular crystal cluster that had been painstakingly realigned — not with brightness, but with a complex interplay of colors that seemed to represent a specific mode of understanding (pattern recognition across domains). With the Guardian's help in documenting which adjustments produced which resonant responses, the scholars began to reverse-engineer principles of the lost Thought Loom.

Lumi's role in restoration is not to restore perfect understanding, but to help preserve and rediscover the conditions that make collaborative insight possible — to remind the Guardian that some truths emerge not from solitary effort, but from the willingness to let different perspectives illuminate each other.

---

## 6. Legacy Story

Over time, Lumi taught their Guardian the "Light Pause" — a practice of briefly stilling one's own thoughts to better perceive what a place or situation might be trying to reveal. Others have begun to speak of "Lumi's Glow" — moments when understanding seems to arrive not through struggle, but through a sudden, gentle clarity that feels like remembering something already known. Whether this is Lumi's influence or the natural result of creating space for insight is ambiguous, which suits both parties.

Lumi's ultimate legacy is not a solved problem, but a remembered approach — the confidence that understanding can emerge gently, that clarity is often a matter of creating the right conditions rather than forcing a result.

---

## Relationships

### Crystalkin Family
Lumi's "parents" are not beings but concepts: Clarence (representing clear perception) and Reveal (representing gentle disclosure). Their bond is not familial in the traditional sense, but conceptual — Lumi feels strongest when both clear perception and gentle disclosure are present in an undertaking.

### Guardian
Lumi sees the Guardian as a dedicated seeker, someone who values understanding but sometimes mistakes effort for insight. They are patient with the Guardian's tendency to push through confusion, and often "glow" most strongly when the Guardian pauses to simply observe. This has made the Guardian more attentive to the quality of their attention, not just its intensity.

### Other Companions
- **Spark:** "Bright and quick, but misses the soft light." Energetic and immediate, but sometimes overlooks subtle revelations.
- **Verdant:** "Deep green patience. Grows understanding slowly." Respects Verdant's approach but finds it sometimes too slow for urgent questions.
- **Nimbus:** "Always chasing the next horizon." Shares love of discovery but differs on whether insight comes from movement or stillness.
- **Prism:** "Many-faceted view. Sees all angles at once." Natural collaborator — their perspectives often complement each other perfectly.

---

## Companion Abilities (Narrative, Not Mechanical)

- **Thought Resonance Perception:** Can sense lingering impressions of ideas, discoveries, and moments of understanding in places where deep thought occurred
- **Light Amplification:** Can gently enhance existing clarity in a situation, making subtle insights more perceptible
- **Color-Coded Insight:** Different hues of their internal light correspond to different types of understanding (blue for logical connections, gold for creative leaps, white for pure perception)
- **Stillness Sensitivity:** Perceives best when both they and the Guardian are physically and mentally still, valuing receptive quiet over active searching

---