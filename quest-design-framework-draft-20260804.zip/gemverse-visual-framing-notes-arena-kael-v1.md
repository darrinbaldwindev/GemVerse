# GemVerse Visual Framing Notes — Arena Realm & Kael (v1)
**Version:** 1.0  
**Date:** 2026-08-04  
**Purpose:** Provide safe, canon-consistent visual direction for Arena Realm environments and Kael character depictions post-Conflict 3 resolution.  
**Authority:** Creator confirmation — Status Mode session (Option A selected: "Champion of Contribution")

---

## Kael — Champion of Contribution

### Identity
Kael is a **civic figure**, a beloved **community contributor**, and the **Arena Realm's most celebrated organizer**. His title "Arena Champion" refers to his achievements in **festival coordination, community leadership, and restoration projects** — not combat.

### Visual Anchors (Safe to Show)
- **Pose:** Confident but approachable — arms open in welcome, hands gesturing toward a project or group, standing with citizens rather than above them
- **Expression:** Warm smile, eyes crinkled with genuine joy, posture open and engaged
- **Attire:** Practical civic wear — durable cloth, sash or tabard in Arena Realm colors (likely Hearthlight warm tones: amber, copper, soft gold), tool belt with non-weapon items (ledger, stylus, measuring cord, small repair kit)
- **Setting:** Among citizens — directing a festival setup, mediating a group discussion, inspecting a restoration site
- **Color Language:** Hearthlight amber/copper (community/resilience), Archive blue (memory/wisdom), soft white/silver (hope/clarity)

### What *Not* to Show (Combat Framing)
- **Armor:** No plate mail, chainmail, or hard-shell combat attire. Civic wear only.
- **Weapons:** No swords, spears, shields, or fighting stances. Tools of restoration/community-building only.
- **Action Poses:** No striking, blocking, defending, or combat-ready stances.
- **Expression:** No grimacing, clenched jaws, battle focus, or dominance posturing.
- **Titles/Narrative:** Never "defeat", "enemy", "power", "beat", "win", "might", "strength" as physical force.

### Framing Language (Safe Narrative Copy)
**✅ Preferred:**  
- "Arena Champion of Civic Achievement"  
- "Kael, the heart of Harmony Plaza"  
- "Organizer of the Great Convergence Festival"  
- "Restored three Lantern routes to the Arena Hub"  
- "Founded the Companion Mentorship Program"  
- "Beloved for his tireless work bringing citizens together"  

**⛔ Avoid:**  
- "Arena Champion of Battle"  
- "Kael, the strength of the group"  
- "Defeated the Arena Realm's challenges"  
- "Won the title through combat"  
- "Strength / power / might made him Champion"  

---

## Arena Realm — Civic Hub

### Identity
The Arena Realm is the **crossroads of GemVerse**, the **heart of community life**, and the **place where citizens gather to share, restore, and celebrate**. It is not a combat zone.

### Visual Anchors (Safe to Show)
- **Architecture:** Open plazas, amphitheaters, gathering halls, lantern posts, archive annexes, companion groves
- **Activity:** Citizens working together, festivals in progress, restorative projects underway, storytelling circles, shared meals
- **Zones (locked canon):** Harmony Plaza, Great Archive, House Districts, Companion Grove, Festival Grounds, Guardian Hall, Marketplace, Lantern Tower
- **Color Language:** Hearthlight warm tones dominate (amber, copper, gold), Archive blue accents (memory/clarity), soft white/silver (hope/light)
- **Lighting:** Warm, golden hour glow — inviting, safe, social. Lanterns glowing as connection points.

### What *Not* to Show (Combat Framing)
- **Battle damage:** No scars, broken walls, scorch marks, defensive fortifications
- **Combat zones:** No fighting pits, gladiator arenas, weapon racks, armor displays
- **Dark/dramatic lighting:** Avoid chiaroscuro, high contrast, threatening shadows
- **Conflict imagery:** No arguments, duels, competitions framed as "winner/loser"
- **Titles/Narrative:** Never refer to "challenges to defeat", "enemies to overcome", "battles to win"

### Framing Language (Safe Narrative Copy)
**✅ Preferred:**  
- "The beating heart of GemVerse community"  
- "Where citizens gather to restore, share, and celebrate"  
- "Harmony Plaza: the place where ideas meet and friendships form"  
- "Festival Grounds: where traditions come alive"  
- "Great Archive Annex: knowledge shared is wisdom doubled"  
- "Marketplace: the exchange of goods, stories, and generosity"  

**⛔ Avoid:**  
- "The battlefield where you prove your worth"  
- "Enemies lurk in every corner"  
- "Defeat the Arena's trials"  
- "Only the strong survive here"  
- "Win glory in the colosseum"  

---

## Conflict 3 Resolution Summary

**Status:** RESOLVED — Option A Applied (2026-08-04)  
**Canon Entry:** `02-conflicts-log.md` updated  
**Asset Registry Update:** Flag #2 (Kael Art Bible) now ready for reframe review  
**Application:** All future Kael and Arena Realm art/copy must pass this framing test.  
- **If it shows community → ✅ Safe**  
- **If it shows combat → ⛔ Conflict**

---

## Review Checklist for Artists/Writers

- [ ] Kael's expression is warm and engaged, never grim or combat-focused  
- [ ] Kael's attire is practical civic wear, not armor or combat gear  
- [ ] Kael's poses show contribution, leadership, or community interaction  
- [ ] Arena Realm environments show civic life, not battle or conflict  
- [ ] Lighting/color palettes are warm and inviting, not dramatic/threatening  
- [ ] Narrative copy uses "contribution", "restoration", "community", "celebration"  
- [ ] No combat terms: "defeat", "enemy", "power", "strength", "battle", "win"

---

*Document created to align all visual and narrative depictions with Conflict 3 resolution. Treat this as the governing document for Arena Realm and Kael until further revision.*