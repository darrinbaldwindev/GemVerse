# The First Harmony
**GemVerse Master Bible — Tier 1 Entry**
**Status:** Canon-Safe Expansion | Built on confirmed locked canon + draft foundations
**Canon Source:** Transfer Volumes 1, 2, 6; Book of Harmony (now locked); Perplexity session confirmed canon
**Depends on:** Book of Harmony entry (must be complete first)

---

## Purpose

This document is the full Master Bible entry for the First Harmony — the greatest age of civilization before the Shattering. It establishes the era's character, governance, daily life, institutions, Companion integration, and the slow drift that ended it. It is the foundation on which the Five Wounds, Crystal Network, Lantern Network, and Restoration Era entries all depend.

---

## What the First Harmony Was

The First Harmony was not a golden age of perfection.

That distinction matters. Civilizations that remember a perfect past cannot restore it — they can only mourn it. The First Harmony was something rarer and more useful to remember: it was a time when civilization was genuinely trying, and mostly succeeding. Its Pillars were in balance. Its people felt connected. Its memory was preserved. Its future was considered.

It was not a time without disagreement, without hardship, without failure. The Book of Harmony was written during this era precisely because its authors recognized how fragile balance was — and how much effort it required to maintain. They wrote it as a reminder, not a monument.

The First Harmony ended not because it was destroyed from outside, but because it slowly forgot what it had learned.

---

## Duration

> **⚠️ OPEN CANON — Duration not yet confirmed. Proposal below. Flag for user review.**

**Proposed canon:** The First Harmony lasted approximately three to four centuries — long enough that the generation alive at its height had no living memory of a time before it, and long enough that its ending felt impossible to those who experienced it. It was not ancient history to those who lived through the Shattering; it was childhood. That proximity is part of what makes the Wound of Memory so acute.

*This framing serves the emotional tone: the Shattering feels like a loss within living memory, not a mythological collapse. It gives the Restoration Era urgency — there are still traces everywhere, still structures standing, still Companions who remember.*

---

## The Shape of Civilization

### The Realms in the First Harmony

All eight Realms were active, connected, and contributing to civilization. No Realm was isolated. No Realm was considered lesser. Each was understood to hold a piece of civilization's whole truth — a principle that the Realm Mystery System would later codify.

Travel between Realms was common. Knowledge moved. Stories moved. Companions moved. People moved to places where they felt their contribution was most needed. Communities grew, changed, and maintained relationships across vast distances through the Crystal Network and the Lantern routes.

The Arena Realm served as the primary meeting ground — the place where delegates, travelers, scholars, and ordinary citizens from every Realm converged. It was already the crossroads of the world before the Shattering made it the last intact hub.

### Governance

The civilization of the First Harmony was not governed by a single authority. It operated through a distributed system of interlocking institutions, each responsible for its domain, coordinated through the Harmony Council.

**The Harmony Council** sat at the center — not as rulers, but as stewards of balance. Its seven members held their positions not through power or wealth but through demonstrated commitment to all seven Pillars simultaneously. A Council member who advocated too strongly for their own House's Pillar at the expense of others was considered to be failing their role. The Council's function was not to govern daily life but to identify when the Pillars were drifting out of balance and to respond before the drift became irreversible.

> *Canon note: The Harmony Council's full membership, individual decisions, and fate during the Shattering are Tier 2 development. This entry establishes their function during the First Harmony without closing those questions.*

**The Houses** each administered their domain across all Realms. House Lumina maintained knowledge infrastructure. House Verdance oversaw growth and renewal projects. House Borealis managed the Archive's predecessor institutions. Each House worked within its Pillar and was expected to actively cooperate with the others — cooperation across Houses was considered a civic obligation, not a courtesy.

**The Paths** were not formal institutions during the First Harmony — they were recognized ways of contributing. A person who spent their life recording history was understood to be a Chronicler, whether or not they held a title. The Paths formalized after the Shattering, partly because formal recognition of contribution became more necessary when contribution was harder to sustain.

**The Archive** was already the center of civilization memory. During the First Harmony, it was not rebuilding — it was accumulating. New discoveries arrived daily. The Hall of Legends recognized contributors in real time. The Archive of Unanswered Questions was smaller then, because civilization had the capacity to answer more of its questions. It grew largest after the Shattering.

---

## Daily Life

### What a Citizen's Day Looked Like

The texture of daily life during the First Harmony varied enormously by Realm, by community, and by the person's chosen contribution. What was consistent across the civilization was less about specific practices and more about a shared orientation:

**Contribution was expected and celebrated.** Every citizen was understood to have something to offer — a skill, a memory, a question, a capacity for care. The culture did not require that contribution be grand. A person who maintained a Lantern route, taught a child to read, or copied Archive documents faithfully was considered to be doing civilization's work. Recognition was given at every scale.

**Learning was continuous.** The distinction between student and teacher was understood to be temporary and shifting. A Master Chronicler might be a student of navigation. A celebrated Pathfinder might seek instruction in memory preservation. The University of Harmony — already active during this era — embodied the belief that no single discipline held complete truth.

**Memory was civic work.** Preserving records, maintaining oral traditions, contributing to the Archive — these were not specialist activities reserved for scholars. Ordinary citizens brought memories, stories, and discoveries to their local Archive sites as a matter of course. The phrase that would later appear in the Book of Harmony — *"to remember together is civilization"* — described something people were already living.

**Festivals connected.** The ten festivals observed during the Restoration Era are all survivals or reconstructions of First Harmony traditions. In their original form, festivals were the primary mechanism by which communities that lived far apart maintained relationship. Attending a festival in another Realm was considered a meaningful act of citizenship — it meant choosing to know people you did not have to know.

**Companionship was woven in.** Companions were not pets, not tools, not curiosities. They participated in society alongside citizens — attending festivals, contributing observations to the Archive, traveling Lantern routes, maintaining connections between communities. A Companion's perspective was understood to be different from a citizen's perspective and therefore valuable in ways a citizen alone could not provide.

### What Children Learned

Education during the First Harmony introduced all seven Pillars before specialization. Children were taught to identify their own inclinations — which Pillar called to them most naturally — and to understand why the other six were equally necessary. The worst outcome an educator could produce was a child who believed their Pillar was the only important one.

Companions often participated in education. A Frostkin Companion's memory of an ancient event was considered a primary source. An Emberkin Companion's account of resilience under pressure carried weight no written text could replicate.

### What People Built

The First Harmony produced architecture, music, and cultural tradition specific to each Realm — these are Tier 2 development areas and are not invented here. What can be established now is the civilizational philosophy behind what was built:

Things were built to last. Things were built to be understood. Things were built to be added to. Architecture in the First Harmony almost always included an Archive alcove — a small space where the history of the building, its builders, and its purpose was recorded. Lantern housing was incorporated into civic buildings as a matter of course. Crystal Network nodes were embedded in major structures because connectivity was considered a feature of good construction, not an optional upgrade.

---

## The Seven Pillars in Daily Life

During the First Harmony, the Pillars were not abstract concepts. They were observable rhythms in daily life.

**Knowledge** showed up as accessible learning — libraries open to all, scholars who answered questions freely, knowledge shared across Realms through the Crystal Network rather than hoarded within them.

**Discovery** showed up as celebration of the new — a returned explorer was welcomed back; a new technique was shared, not patented; a previously unknown place was added to maps that belonged to everyone.

**Growth** showed up as the expectation of change — communities were expected to develop, individuals expected to deepen their skills and understanding, relationships expected to evolve. Stagnation was treated as a warning sign, not a comfort.

**Memory** showed up as active preservation — the Archive was not a passive repository but an active civic project. Every community maintained its own records. Every significant event was witnessed and recorded. The loss of a record was considered a civic grief.

**Community** showed up as genuine interdependence — communities were not self-sufficient by design. They traded skills, shared resources, sent their young people to learn in other Realms, and maintained relationships with distant communities through Lantern routes and festival traditions.

**Harmony** showed up as ongoing negotiation — disagreements between Houses, between Realms, between individuals were expected and considered healthy. The Harmony Council existed not to prevent disagreement but to ensure it remained productive rather than fracturing.

**Belonging** showed up as an ambient condition — something most citizens felt without being able to articulate it. They were part of something larger. Their contributions mattered. Their stories would be preserved. Their children would inherit something worth inheriting. Belonging was never named as a Pillar during the First Harmony because it did not need to be named. It was simply present.

---

## How Companions Participated

Companions during the First Harmony were understood as partners in civilization-building, not attachments to individual people. A Companion might travel with one Guardian for years and then, when that Guardian's work was complete, enter the Archive's care as a living repository of what they had witnessed together.

Companions attended Harmony Council meetings as observers — their perspective on Pillar balance, shaped by their particular family's nature and their own experience, was considered a valuable addition to deliberation. A Crystalkin Companion's analytical observation of a Knowledge imbalance carried different weight than a Hearthlight Scholar's argument, and both were considered.

The Companion Grove that exists in the Arena Realm during the Restoration Era is a survival — or a reconstruction — of a much larger network of Companion gathering places that existed throughout the First Harmony. These were places where Companions could convene without human presence, maintain their own traditions, and process their own relationship to the civilization they were part of.

---

## The Slow Drift

The First Harmony did not end dramatically. It ended the way most deep losses end — gradually, then all at once.

### What Changed First

**Communities became more specialized.** As each Realm developed its core strength, it began to invest more heavily in that strength and less in maintaining relationships with Realms whose strengths were different. A community of scholars needed scholars. They trained more scholars. They built more for scholars. The other Pillars were still present — still respected in principle — but the daily practice of maintaining them weakened.

**Knowledge disconnected from wisdom.** The Crystal Network made the distribution of knowledge faster and broader than ever before. But distribution is not understanding. Information moved; comprehension lagged behind. Scholars accumulated data faster than they could interpret it. Discovery outpaced reflection.

**Discovery disconnected from responsibility.** Pathfinders reached further, found more, mapped wider. The expansion was celebrated. The question of what expansion meant for the communities already living at the frontier was asked less often. The Realms that felt this most acutely began to pull back from the common network, slowly, without announcement.

**Growth disconnected from memory.** Communities that were growing quickly found less time for the practices of memory preservation. The Archive received fewer contributions from thriving communities — ironically, from those who had the most to contribute. Memory became the work of dedicated specialists rather than a civic norm.

**The Harmony Council's warnings were heard but not felt.** The Council identified the drift. They said so clearly. The Book of Harmony was already completed — its passages about imbalance were well known. But knowing something and feeling its urgency are different. Civilization had been in balance for so long that the drift felt theoretical. It didn't feel like an emergency. It felt like a phase.

### What Changed Last

**Belonging became invisible.** When communities stopped maintaining their cross-Realm relationships, when festivals became local rather than shared, when Companions were seen less in public spaces — belonging began to erode without anyone naming what was happening. People felt less connected. They attributed it to personal circumstances. They did not recognize it as civilizational.

**The Harmony Council lost the capacity to convene.** Not through conflict. Through drift. Representatives came less often. Correspondence slowed. The mechanisms of coordination that had seemed permanent turned out to require constant maintenance — and maintenance requires attention, and attention had moved elsewhere.

The Shattering was not a moment. It was the name given to the point at which the drift became undeniable.

---

## The Shattering's Threshold

> *Canon note: This section establishes the proximate cause of the Shattering as a structural answer, not a villain. It is a canon-safe expansion — no villain is introduced. Flag for user review.*

There was no single event. Scholars in the Restoration Era have identified what they call the **Threshold** — the moment when the Pillars had drifted so far from balance that the self-correcting mechanisms of civilization could no longer compensate. The Crystal Network, designed to distribute knowledge across a connected civilization, began to route information through fewer and fewer active nodes as communities withdrew. The Lantern routes, dependent on Keepers who were maintained by communities that increasingly had other priorities, went dark in sections. The Archive, receiving less input, had less to offer — which made communities less likely to contribute, which made the Archive less valuable, which made communities less likely to contribute.

The systems that had held civilization together were each dependent on the health of the others. When enough of them weakened simultaneously, they could not support each other. They collapsed together.

This is what the Five Wounds represent: not the injuries from a single blow, but the simultaneous failure of five interlocking systems that had always depended on each other to function.

---

## What Survived

Not everything was lost. The Shattering was catastrophic — but civilization had built things to last, and some of them did.

- The Great Archive's core holdings survived, protected by Memory Crystals sealed before the Crystal Network failed. Not everything — far from everything — but enough.
- The Houses survived as institutions, their structures and identities intact even when their members were scattered.
- Some Lanterns kept burning, maintained by Keepers who refused to leave their routes. Some Lantern traditions survived as folk practices in communities that no longer knew why they lit lanterns in winter but did it anyway.
- Some Crystal Network nodes survived — dormant, not destroyed. Their records intact, waiting.
- Companions survived. Every Companion alive during the Shattering carries a memory of what was lost. They are the most direct remaining witnesses.
- The Book of Harmony survived, partially. Enough of it survived to remember what civilization had known about itself.

And hope survived. Not as a policy or a system — as a disposition. The same disposition that had built something worth belonging to once was still present in the people who remained. It had nowhere to go yet. It waited for Guardians.

---

## Canon Notes

**Pillars touched:** All eight (each active during this era; Belonging present but unnamed)
**Houses touched:** All seven (all operational during First Harmony)
**Paths touched:** All six (present as informal practices; formalized after the Shattering)
**Systems touched:** Harmony Council, Great Archive, Crystal Network, Lantern Network, University of Harmony, Book of Harmony, Companion Grove, festivals, Memory Crystals
**Establishes foundation for:** Five Wounds (which are the Shattering's consequences), Crystal Network entry (which was whole during this era), Lantern Network entry (which was whole during this era), Restoration Era entry (which is defined by contrast to this one)
**Open items flagged:** Duration of the First Harmony (proposed as 3–4 centuries — awaiting user confirmation), Shattering proximate cause framing (structural "Threshold" model — awaiting user review)
**Deliberately left for Tier 2:** Realm-specific architecture, food, music, traditions — scaffolded here as philosophical direction but not invented in detail
**Deliberately left for Tier 2:** Harmony Council full membership and fate

---

## Review Checklist

- [ ] Does this entry portray the First Harmony as balanced-but-not-perfect, avoiding both utopian idealization and grimdark revisionism?
- [ ] Does the Shattering remain villain-free? Does the "Threshold" model explain the collapse through structural failure, not a single cause or bad actor?
- [ ] Does the slow drift feel inevitable in retrospect without feeling like anyone was uniquely at fault?
- [ ] Does Belonging appear naturally as an ambient condition — present but unnamed — consistent with it being the hidden Eighth Pillar?
- [ ] Does the description of Companion participation feel like genuine civic partnership, not decoration or pet-keeping?
- [ ] Does daily life feel warm, lived-in, and worth belonging to — without inventing specific cultural detail that belongs in Tier 2 Realm development?
- [ ] Are the Harmony Council's function and fate left appropriately open for Tier 2 without creating contradictions?
- [ ] Does the "What Survived" section set up the Restoration Era with hope rather than grief as the primary tone?
