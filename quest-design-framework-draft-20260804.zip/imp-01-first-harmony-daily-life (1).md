---
title: IMP #1 — First Harmony Daily-Life Framework
tier: IMP
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: First Harmony (Tier 1)
feeds-into: Tier 2 Realm Cultures, Tier 3 Companion Encyclopedia, IMP #3 Citizen Life Layer
---

# IMP #1 — First Harmony Daily-Life Framework

**Purpose:** This packet provides the lived-civilization layer beneath the structural First Harmony canon. It translates philosophy and governance into texture: what mornings smelled like, what a child's first year of learning felt like, what it meant to carry a memory to the Archive and have it accepted. Nothing invented here overrides the Tier 1 entry. Where questions remain open, they are flagged as proposals for creator confirmation.

---

## Part One: A Day in the Life

### Vignette 1 — An Ordinary Morning in the Arena Realm

Mira was a Lantern Keeper, and her day began before the light did.

She rose to check the oil in the four lanterns at the crossroads post where the southern route into the city met the path from the Crystal Forest. This was not a dramatic responsibility. It was not dangerous. Two of the lanterns had been burning continuously for thirty years, and in all that time the oil had run short exactly once, on a night she still thought about with mild embarrassment. She checked them anyway, every morning, because the point of a Lantern Keeper was not to respond to emergencies. The point was to prevent them.

By the time the market district was opening — stalls folding out their covers, Archive scholars already walking toward the library wing with their morning cups — she had completed her route and was writing in her log. The log was not for her. It was for the Archive, which collected route records from Keepers across the Realm network. Patterns in the logs helped communities understand which routes were most traveled, which needed better shelter markers, which had changed because of seasonal flooding or a new settlement. It was civic work dressed as ordinary habit, and she understood it as both.

Her neighbor, a young man named Solen who was two years into the Harmonist Path, stopped by her gate on his way to the House of Solstice for a morning session. He asked if she'd heard that a Skykin Companion named Galewing had arrived in the city the day before with accounts of cloud formations over the Celestial Nexus that matched no recorded pattern. The Archive was already preparing a session to hear the testimony.

She said she had not heard. She made a note to attend.

At midday, Mira would bring her weekly log to the local Archive station — a modest building beside the Harmony Plaza, staffed by two Chronicler Path citizens who accepted and catalogued contributions from across the district. She was not a scholar. She would never write a monograph. But her thirty years of route records formed a continuous thread in the city's memory of itself, and she knew it.

In the evening, she taught a young girl who had recently begun asking about the Lantern Keeper Path what a route looked like in winter, when the frost crept into the oil and required a different mixture. She did not tell the girl whether she should become a Keeper. She showed her the lanterns and let the girl decide what she felt.

---

### Vignette 2 — A Morning in the Frozen Expanse

The thing visitors always noticed first was the silence.

Not emptiness — the community of Verath-on-the-Ice was dense, close-built, and warm in the way that places surrounded by cold have to be. But the civic culture of the Frozen Expanse had developed around the particular quality of memory that silence makes possible. You could not hear the past if you were making noise.

Rowan had been a community elder for eleven years, and his morning practice was always the same: he sat in the Memory Hall at the center of the settlement and received. Anyone who had a memory to contribute — a recollection of their grandmother's account of the early First Harmony, a dream that had the quality of inherited memory, a story heard once and not yet recorded — could come during the first hour of the day and speak it aloud. He recorded in crystal-scribe notation. When the Hall's Memory Crystal had accumulated enough material, a Chronicler would carry it to the nearest Crystal Network node, and the memory would enter the larger record.

This was not considered remarkable. This was Tuesday.

The children of Verath were taught to preserve memory before they were taught to read. Not because reading was less important — the settlement's library was one of the finest in the Frozen Expanse — but because the elders understood that the instinct to preserve came first, and literacy served it. A child who knew why memory mattered could learn to read quickly. A child who could read but saw no reason to write anything down had missed the more important lesson.

A Frostkin Companion named Frostpaw lived semi-permanently at the Memory Hall. She was old enough that no one in the settlement could say with certainty when she had arrived, and she did not clarify. Her presence at morning sessions was customary: she added observations, corrected misremembered details gently, and occasionally contributed her own memories of events she had witnessed before anyone in the room had been born. Her testimony was recorded in the same log as everyone else's. No distinction was made. Memory was memory.

By afternoon the children would be in school, the Chroniclers would be organizing the morning's intake, and Rowan would be walking the outer paths of the settlement to check in with the families who hadn't come to the Hall in a while. Not to prompt or pressure — the Frozen Expanse had no tradition of mandatory contribution. Just to be present, so that those who had something to give would feel they had somewhere to bring it.

---

### Vignette 3 — A Companion's Morning

[Companion perspectives are from Frostpaw of the Frostkin family, sitting in the Memory Hall during a morning session at Verath-on-the-Ice.]

She had attended seven hundred and forty-three of these mornings, give or take. She had stopped keeping an exact count because the number had become less interesting than the accumulation itself.

What she found remarkable — and she had discussed this at a Companion gathering in the Arena Realm three years prior — was how consistent the quality of what people brought to the Hall was across generations. It was not that the same memories came back. It was that the same *impulse* came back: the need to ensure that something experienced would not be lost with the body that experienced it. Humans understood their own impermanence in a way that shaped everything they built.

She did not share this observation during the morning session. It was not the right kind of contribution for today's intake. What she shared was a detail from a memory she carried of a winter trade fair held in this same location two hundred years ago — specifically, the name of a Lantern Keeper who had maintained the route from the southeastern forest and who had never appeared in any written record despite being, by Frostpaw's direct observation, one of the more quietly remarkable people she had encountered in her long association with this settlement.

The elder recorded the name carefully. He thanked her.

She went back to listening.

---

## Part Two: Education and Learning

The First Harmony did not separate education into a place and an age. Learning happened in Houses, in markets, in Memory Halls, on Lantern routes, in Archive stations, and — most often — in the ordinary company of people who knew more than you about something you wanted to understand.

**What children learned first:** Before any path-specific training, every child was introduced to all seven Pillars — not as philosophy, but as observation. An educator might point to a Lantern Keeper and name what they were doing as Memory and Community at once. A returned explorer was brought to schools to share what had been found, making Discovery visible. The worst outcome an educator could produce, the First Harmony canon records explicitly, was "a child who believed their Pillar was the only important one."

**How the Paths were introduced:** Young people did not choose a Path in the way later generations would formalize after the Shattering. During the First Harmony, the Paths were recognized descriptions — a person who spent their life recording history was understood to be a Chronicler whether or not they held a title. For children, educators watched for inclinations and named what they saw: *you ask a lot of questions that will outlast any answer — that's the Scholar in you* or *you keep checking on the people who are struggling — that's the Mentor.* Assignment came later, through mentorship and affinity, not through testing or selection.

**Formal and informal learning:** The boundary was deliberately porous. A child apprenticed to a Lantern Keeper learned route-maintenance, weather reading, oral tradition, community care, and the physical practice of Memory — none of which appeared in any House curriculum as a named subject. The University of Harmony served as the integrating institution: scholars there held that no single discipline held complete truth, and the curriculum was organized accordingly. [PROPOSAL — the University of Harmony's active role during the First Harmony is confirmed in Tier 1 canon. Its specific curriculum structure, campus layout, and relationship to House education are not yet developed and require Tier 2 treatment. This packet assumes the institution existed and was functional without specifying details.]

**Companions in education:** A Frostkin Companion's memory of an ancient event was considered a primary source. Companions participated in schools not as teachers in any formal sense — they were not assigned, they were not employed — but as witnesses whose presence made the past accessible in a way that written records alone could not. A Companion who had attended the founding of a community could speak about it. That was different from reading about it.

---

## Part Three: Work and Contribution

### How Citizens Understood Their Work

The civic culture of the First Harmony held one idea about work that distinguished it most clearly from what came after: contribution was not what you did for money. It was what you did for civilization.

This did not mean citizens did not receive material support — communities maintained shared resources, Houses supported practitioners within their domain, and the Archive provided for the Chroniclers and Scholars whose work it relied upon. But the framing was not transactional. A community that had a thriving baker understood the baker to be contributing to Community and Growth, not simply selling bread. The baker's recipe, if exceptional, would be recorded in the local Archive's cultural record, not as commerce but as civilization.

The phrase *civic work* covered a wider range of activities than most modern frameworks allow. A person who spent their mornings receiving memories at a community Hall and their afternoons teaching young children to record what they heard was doing two kinds of civic work simultaneously and would have been surprised to hear either described as less than the other.

### How Contribution Was Recognized

Recognition was given at every scale. The Hall of Legends in the Great Archive recognized extraordinary contributions — major discoveries, significant acts of memory preservation, decades of Mentorship that shaped entire generations. But the local Archive stations recognized ordinary contributions just as formally: a Keeper's route records, a community elder's years of morning sessions, an educator's student histories. These local records were not lesser than the Hall of Legends. They were the foundation the Hall was built on.

Recognition was understood as memory, not reward. When a contribution was recorded in the Archive, it meant that the person who made it would not be forgotten. This was the primary currency of the First Harmony: not power, not rank, not wealth, but the certainty that what you had done would outlast you and be known.

### When Contribution Looked Different

The civilization held a practical consensus on this: every person had something to offer, and the work of the community was to find it, not to demand a specific form.

A person whose illness or circumstance prevented traditional kinds of work might hold community memory — the elderly neighbor who had watched the district change over sixty years was a living Archive. A person with a gift for being present in moments of grief served Community in ways no formal title could capture. A child still learning was understood to be contributing by learning: the act of becoming someone who would contribute was itself valued.

This orientation was not perfect. The First Harmony canon is careful to note it was balanced, not perfect. There were communities where the consensus broke down, where people who could not contribute in recognizable ways felt invisible. These were the places that produced the early warning signs of the Wound of Belonging — and they were often the places the Harmony Council was most concerned about in the later years.

---

## Part Four: Community and Gathering

### What Gathering Looked Like

Communities in the First Harmony did not wait for formal occasions to gather. Lantern crossroads sites served as natural meeting points — travelers moving between Realms stopped, exchanged news and stories, shared what they'd seen. Local Archive stations were social spaces as much as civic ones. The morning memory sessions of the Frozen Expanse were as much a place to see your neighbors as to contribute a record.

But the ten festivals were the primary mechanism by which communities that lived far apart maintained relationship. Attending a festival in another Realm was considered a meaningful act of citizenship — not tourism, not entertainment (though it was both), but the deliberate choice to know people you did not have to know. Festival of Beginnings marked new community undertakings. Lantern Gathering brought the Keeper network together in shared acknowledgment of the routes that connected the world. Remembrance Night crossed community boundaries more than any other festival — people traveled significant distances to hold memory together.

[PROPOSAL — the specific festival traditions, rituals, and ceremonies for each of the ten confirmed festivals are flagged Missing in the canon map and are Tier 2 development. This packet names the festivals as existing and important without inventing specific customs.]

### Lantern Sites as Community Hubs

The Lantern sites were not merely way-stations. They were maintained by Keepers who understood their role to include community care alongside physical upkeep. A Lantern site on a major route was likely to have a small gathering space, a weather-shelter where travelers could rest, and — in many communities — a board where messages could be left for people expected to pass through. Lantern Keepers carried news and stories along with them as they traveled their routes, serving as the low-technology analog to the Crystal Network: slower, more personal, more likely to include the emotional texture of information alongside its content.

### Cross-Realm Connection

Communities across the Eight Realms stayed connected through overlapping systems: the Crystal Network distributed information; the Lantern routes moved people and stories; the festivals brought distant communities into direct contact; and the Houses maintained cross-Realm administrative relationships that kept their respective domains coherent across geography. No single community was expected to be self-sufficient — the interdependence was structural. Communities sent their young people to learn in other Realms. Scholars traveled to contribute findings to Archive nodes far from home. Companions moved freely, carrying direct living memory across Realm boundaries.

The Arena Realm served as the primary convergence point — the place where delegates, travelers, scholars, and ordinary citizens from every Realm could find each other. Its role as the crossroads of the world was not imposed. It emerged from use.

---

## Part Five: Companion Roles in Daily Life

### Partners, Not Attachments

Companions during the First Harmony were understood as partners in civilization-building. This meant they participated in all of what civilization was: its gatherings, its records, its governance deliberations, its education, its quiet daily rhythms.

They were not assigned to individual citizens in the way that later frameworks might imagine. A Companion might travel with one Guardian or citizen for years, or might remain semi-permanently in a community like Frostpaw at the Verath Memory Hall. The relationship was determined by the Companion's own sense of where their perspective was most needed — and that perspective was genuinely valued because it was genuinely different.

### Formal Recognition

Companions were not formally employed or titled in most communities. But their contributions were formally recorded. A Frostkin Companion's testimony in a morning session appeared in the same Archive log as a human elder's. A Crystalkin Companion's analytical observation presented to the Harmony Council was transcribed alongside human argument. A Skykin Companion who brought new natural observations from distant exploration had those observations treated as primary source material.

[PROPOSAL — whether Companions held formal advisory positions with the Harmony Council is not yet resolved in canon. This packet proposes they attended as recognized observers whose testimony carried civic weight. Creator confirmation required before this is treated as locked.]

### The Companion Grove Network

The Companion Grove that exists in the Arena Realm during the Restoration Era is understood to be a survival or reconstruction of a much larger network of Companion gathering places throughout the First Harmony. These spaces allowed Companions to convene, maintain their own traditions, and process their relationship to the civilization they participated in. The existence of these spaces reflects an important principle: Companions were not simply embedded in human civilization — they maintained their own perspective on it. That independence was part of what made their contribution valuable.

### Effect on Daily Community Life

Communities that had Companions as long-term participants developed particular characteristics. Memory was more reliably deep: a Companion who had been present for decades added a living layer to the Archive that no written record could replicate. Discovery was more readily trusted: a Companion who had traveled widely brought geographic and cultural knowledge that crossed Realm boundaries in ways a human traveler could not, given time and life-span. And Belonging was more visceral: the presence of a Companion who had chosen to remain with a community — not because they had to, but because they found the community worth staying with — told the community something about its own worth.

---

## Part Six: Memory and Legacy as Civic Practice

### What Memory Preservation Actually Looked Like

The phrase "memory preservation was considered civic work" can sound grand. In daily practice it was more like Mira's Lantern log and Rowan's morning sessions: small, consistent, unglamorous, and essential.

Local Archive stations were present in every significant community — not the Great Archive's Hall of Legends, but working stations where Chronicler Path citizens accepted contributions from their neighbors. These contributions ranged from the significant (an explorer's findings, a decade of route records) to the seemingly minor (a community elder's memory of what the district looked like before a particular building went up, a child's account of a new game being played in the school yard, a Companion's recollection of a person who had died without any written record). All were accepted. All were catalogued.

The Archive did not distinguish between important memory and unimportant memory because the civilization understood that the significance of a record was often invisible at the time of contribution. A minor detail recorded today might be the only surviving evidence of something that mattered enormously to someone trying to understand the past a century from now.

### Crystal Network Node Maintenance

Crystal Network nodes at the local level were maintained by citizens who had taken on the Chronicler Path or who were affiliated with House Borealis, usually with support from a local House Lumina scholar for technical aspects. [PROPOSAL — the specific technical requirements and ceremonies around node maintenance are not yet established in canon and require Tier 2 development. This packet assumes nodes required active, recurring human and Companion attention to remain functional.]

The nodes did not maintain themselves. They required regular care — which meant that when communities stopped attending to them, the nodes began to drift offline. This is precisely what happened in the late First Harmony, and it is why the Crystal Network's deterioration was both a cause and a symptom of civilizational drift.

### How Ordinary Citizens Contributed to the Archive

The Archive was not a building citizens visited for special occasions. It was a system they participated in continuously. Citizens contributed through:

- **Lantern Keeper logs** — daily and weekly route records brought to local stations
- **Morning memory sessions** — in communities with Memory Halls, direct oral testimony
- **Event witnesses** — citizens who attended significant local events were encouraged to submit records, not as formal obligation but as civic habit
- **Companion testimonies** — formally transcribed by Chroniclers from Companion accounts
- **Recovery contributions** — when travelers found artifacts, fragments, or records in the field, bringing them to the nearest Archive node was understood as the natural next step

The phrase from the Book of Harmony — *to remember together is civilization* — was not philosophy to these citizens. It was a description of what they were already doing.

### Individual Legacy and Civilization Memory

The relationship between personal legacy and collective memory was not competitive. A person's individual record — their route logs, their morning testimonies, their Archive contributions, their Companion associations — became a thread in the larger fabric. The Hall of Legends honored the most visible contributions, but ordinary citizens understood that their own record would survive in the local Archive and, through the Crystal Network, in the Great Archive's holdings.

This is what made the loss of the Crystal Network during the Shattering feel like a personal grief as well as a civilizational one. People had contributed their lives to the record. When the record fragmented, the contributions were not simply lost to the civilization — they were lost to the families and communities who needed them to know who they had come from.

---

## Part Seven: Early Signs of Drift

### How Specialization Crept In

It did not happen through a decision. No community announced that it was prioritizing its own Pillar above the others. The drift happened the way most drift happens: through reasonable choices, made repeatedly, without the benefit of seeing what they added up to.

A community of scholars needed scholars. They trained more scholars. They built more for scholars — more library wings, more Crystal Network capacity, more Archive space. The Lantern Keeper who maintained the route into town was still respected, but there was less community time to attend morning sessions because mornings had filled up with other things. The Companion who used to bring observations from the frontier hadn't come by in a while. No one was sure why.

The Harmony Council identified these patterns and said so clearly. The Book of Harmony had been written to describe exactly this kind of drift. The problem was that knowing about drift and feeling its urgency are different things, and civilization had been balanced for so long that the drift felt theoretical. It didn't feel like an emergency. It felt like a phase.

### What Complacency Felt Like in a Balanced Civilization

This is one of the most instructive aspects of the First Harmony for the Restoration Era to understand: the drift was enabled by success. Communities that were thriving found the practices of memory preservation less urgent — they had so much happening that they couldn't attend to the documentation of it all. Discovery that was expanding fast had less time for the reflection that made discovery responsible. Growth that was visibly producing beautiful things generated confidence that overcorrected into assumption.

The Harmony Council's warnings were heard but not felt. This is not a story about villains ignoring good advice. It is a story about the fundamental human difficulty of feeling urgency about something that has not yet become a crisis.

### When Daily Life Began to Feel Different

The change was first perceptible in the small social textures of daily life, not in grand events.

Festival attendance from other Realms thinned. The Lantern Gathering that had once drawn Keepers from six Realms began to draw from three. Cross-Realm mentorship declined — families sent their children to study in their own Realm's best institutions rather than in another Realm's, which made sense as a practical choice and was also the beginning of the end of the knowledge that came from genuine encounter with difference.

Companions appeared less often in public civic spaces. It was not that they were excluded — no policy changed. It was that the social culture that had made their presence natural began to shift. Communities that were becoming more specialized began to feel, without articulating it, that a Companion's generalist perspective was less immediately useful than a specialist's focused expertise. The Companion was still welcomed. But the welcome began to feel different.

And belonging began to erode in the way only an ambient condition can erode: without announcement, without crisis, as a slowly accumulating absence that each person attributed to their own circumstances before recognizing it as something larger.

The Harmony Council called it drift. The ordinary citizen called it nothing yet, because they had no name for what was happening. Only later — in the archive records of communities that survived the Shattering, in the Companion testimonies collected during the Restoration Era — did it become possible to read the signs backward and understand what had been beginning.

---

## Review Checklist

### Items Awaiting Creator Confirmation

- [ ] **University of Harmony curriculum structure** — This packet treats the University as active during the First Harmony (confirmed in Tier 1 canon) but does not invent curriculum specifics. Tier 2 development of the University requires creator confirmation of its internal organization.

- [ ] **Companions as Harmony Council observers** — This packet proposes that Companions attended Harmony Council sessions as recognized observers with civic weight. This is consistent with Tier 1 canon but not explicitly specified. Requires creator confirmation before locking.

- [ ] **Crystal Network node maintenance requirements** — This packet proposes that nodes required active, regular care from Chronicler Path citizens and House Borealis affiliates. Technical specifics are not invented. Requires Tier 2 development and creator confirmation.

- [ ] **Festival-specific customs and traditions** — All ten festival names and purposes are locked canon. This packet treats them as significant without inventing specific rituals. Full tradition development is flagged Missing in the canon map and belongs to Tier 2 Realm Culture work.

- [ ] **Vignette character names** — Mira, Rowan, Solen, and Frostpaw are used as illustrative examples in the vignettes. Mira and Rowan are invented for this packet and are not canon characters. Frostpaw is used as a Companion name from the launch Companions list (confirmed as existing; full entry not yet written). Creator should confirm whether named characters in IMPs require approval or should be treated as illustrative-only.

- [ ] **Local Archive station structure** — This packet describes local Archive stations as working contribution points in every significant community. The specific format, staffing, and ceremony of these stations is not yet established in canon. Requires Tier 2 development.

### Downstream Dependencies This Packet Enables

- **Tier 2 Realm Cultures** — Each Realm's culture is a variation on this shared daily-life foundation. The Frozen Expanse vignette models how a Memory-aligned Realm adapted the shared practices. This packet provides the baseline from which all eight Realm cultures can diverge.

- **Tier 3 Companion Encyclopedia** — The Companion roles described in Part Five give Companion entries a social and civic context: where they lived, what they contributed, how their testimony was recorded, what the Companion Grove network provided them. Entries for Frostpaw, Galewing, and others can now be written against this backdrop.

- **IMP #3 Citizen Life Layer** — This packet establishes the broad strokes. IMP #3 can deepen individual citizen archetypes (the Keeper, the elder, the young Harmonist, the Archive scholar) with more specific narrative texture.

- **Five Wounds entries** — Part Seven (Early Signs of Drift) provides the daily-life layer of how each Wound began to manifest before the Shattering made it visible. The Wound of Belonging, the Wound of Memory, and the Wound of Discovery are all seeded here in terms ordinary citizens would have recognized without naming.

- **Festival System development** — Part Four establishes that festivals functioned as primary cross-community relationship maintenance, giving the Festival System entry a civic purpose beyond celebration.

- **Book of Harmony commentary tradition** — The daily practices described throughout this packet (morning sessions, Archive contributions, Keeper logs) explain where the citizen voices in Volume VIII came from. These were not special people writing formal entries — they were Miras and Rowans, writing what they knew.

---

*End of IMP #1 — First Harmony Daily-Life Framework*
*Word count: approximately 3,400 words*
*Status: Draft — Awaiting Creator Review*
