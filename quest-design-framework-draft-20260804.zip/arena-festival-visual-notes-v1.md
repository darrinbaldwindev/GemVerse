# Arena Festival Visual Notes v1

**Project:** GemVerse  
**Mode:** GemVerse Art Studio  
**Scope:** Festival Grounds framing, festival-adjacent environment visuals, seasonal gathering cues, non-lore-locking concept direction  
**Status:** Production-safe working notes derived from current Space canon

---

## Purpose

This document provides visual guidance for the Arena Realm's Festival Grounds and festival-adjacent scenes without inventing or locking specific festival lore that still requires creator confirmation.

It is intended to help art, UI, environment, and presentation work depict the Festival Grounds in a canon-safe way now, while leaving tradition-level specifics open for later decision files or Tier 2 documents.

---

## Canon-safe foundation

The Festival Grounds are a locked canonical hub zone in the Arena Realm.

In the Restoration Era, they are still used, but they are not full. They hold the memory of larger gatherings that once drew people from many Realms, and traces of earlier setups remain in ways that suggest continuity rather than abandonment.

The Arena Realm itself is the civic heart of civilization, the crossroads of the world, and the place where civilization remembers itself by gathering. Festival imagery must reinforce this identity.

---

## Core festival principle

**Festival visuals in Arena should feel like maintained possibility.**

The Grounds should not read as empty because life has vanished.
They should read as ready because the community never stopped making room.

This distinction matters.

---

## Emotional read

Festival visuals should communicate:
- welcome
- held memory
- readiness
- continuity
- civic joy
- shared life
- smaller present / larger remembered

Festival visuals should not communicate:
- decadence
- conquest celebration
- winner spectacle
- tournament atmosphere
- collapse and desolation
- nostalgia so heavy it erases hope

---

## Visual ingredients to favor

Use cues that suggest a place still prepared for gathering:

- lantern lines, hooks, poles, and anchor points still in use
- fabric traces, canopy rigging, or hanging structures that imply recurring setup
- circular or flowing gathering layouts rather than stage-versus-crowd dominance
- benches, low platforms, shared tables, open pavilion logic, and routes for mingling
- floral or organic adornment that feels renewed season by season
- signs that some decorations are refreshed while others are old but cared for
- stored festival infrastructure visible at the edges: folded frames, stacked seating, weathered posts, maintained storage alcoves

The Grounds should suggest a community that scales events up and down without losing the practice itself.

---

## Visual ingredients to avoid

Avoid any cues that pull Arena festivals toward spectacle-first or combat-coded interpretations:

- victory dais staging
- grand champion banners
- central podium logic built around winners and losers
- coliseum crowd reads
- firework language that feels militarized or explosive rather than celebratory
- parade-ground symmetry tied to dominance or display power
- giant empty stages that imply performance hierarchy instead of civic participation
- severe ruin imagery that says the Grounds are no longer usable

---

## Restoration Era read

The key Arena Festival Grounds image is not “the festival has ended forever.”

It is: **the festival still happens, but at a smaller scale than it once did**.

That means visuals should balance three truths at once:
- this place once held far more people
- it still holds people now
- the practice of gathering survived the thinning

Use physical remnants carefully. Old anchor points, weathered frames, and partially permanent setup structures should feel poignant, not tragic.

---

## Spatial guidance

### Layout feeling

The Festival Grounds should feel permeable and civic.
People should be able to enter from multiple directions.
Movement should feel social, not funnelled toward a single spectacle axis.

### Scale handling

The space can be visibly larger than current attendance requires, but never so large that the current community feels insignificant.
Use clusters, zones, and overlapping gathering pockets to preserve intimacy inside larger festival geography.

### Lighting

Favor warm distributed light over dramatic spotlight logic.
Lanterns, hanging light lines, and soft ambient glows help the space feel communal and inhabited.

---

## Seasonal and event-agnostic direction

Because specific festival traditions are still open decisions, use event-agnostic design language that can flex later:

- renewal
- remembrance
- welcome
- shared table
- returning paths
- lantern-light gathering
- companion presence at the edges and in the flow of the event
- civic preparation as part of beauty

This allows seasonal concepts, key art, and mood boards to proceed without falsely canonizing named festivals, rituals, or House-specific customs.

---

## Companion integration

Companions should feel naturally present in Festival Grounds imagery, not placed there as mascots or collectibles.

Good Companion festival behavior includes:
- moving between gathering groups
- observing from thresholds, railings, lantern posts, or grove edges
- participating in atmosphere rather than commanding attention
- subtly signaling that the Grounds belong to more than humans alone

The Companion Grove and Festival Grounds should feel spiritually adjacent even when visually distinct.

---

## Kael and citizen placement

If Kael appears in festival visuals, place him in preparation, stewardship, greeting, or quiet participation.

Good Kael festival reads:
- checking setup details
- helping open a space
- speaking with arrivals
- carrying or arranging civic-use items
- standing within the shared event, not above it

Citizens should read as participants and contributors, not spectators awaiting a show.

---

## Safe copy starters

These lines are safe starting points for decks, review notes, and temporary labels:

- Festival Grounds — A place still prepared for gathering.
- The memory of larger celebrations remains, but the practice never ended.
- A civic festival space shaped by welcome, continuity, and return.
- Smaller than before, still alive now.
- A Realm that kept the space ready, even through the long thinning.

---

## Review checklist

Before approving any Arena Festival Grounds asset, ask:

- Does this feel like shared civic life rather than spectacle entertainment?
- Does the space look usable now, not merely historical?
- Do the traces of the past support hope rather than loss-only reading?
- Would a viewer mistake this for a tournament venue or victory plaza?
- Are people invited into the scene, or only positioned before a stage?
- Does the scene preserve intimacy even when implying larger past scale?
- If Kael is present, does he read as steward rather than central performer?

If the image trends toward tournament, parade spectacle, or empty ruin, return it for reframe.

---

## Best immediate uses

This document is ready to support:
- Festival Grounds concept art
- seasonal Arena key art
- event hub mockups
- onboarding-adjacent world presentations
- environment deck cleanup
- mood board review before specific festival lore is locked

For deeper Arena alignment, pair this file with the Arena production brief, Arena visual framing notes, and Arena onboarding/environment notes.
