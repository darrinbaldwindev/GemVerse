# GemVerse Canon Conflicts & Decisions Log
**Version:** 1.0
**Purpose:** Record every conflict found across sources and the resolution applied or proposed.

---

## CONFLICT 1 — Book of Harmony: Living Document vs. Fixed Original Text

**Conflict**
- Vol 1 Transfer (ChatGPT export): *"The Book of Harmony is a living document. New entries could be added. Old entries were preserved. Contradictions were often retained rather than removed."*
- Perplexity session canon (confirmed by user): *"Original text is fixed. Future generations add commentary and interpretation. Volume VIII (On Belonging) is the hidden volume written by ordinary citizens."*

**Sources in conflict**
- ChatGPT Vol 1 export (older, lower authority)
- Perplexity session explicit user statement (highest authority)

**Resolution: APPLY — Perplexity canon wins**
The original text of the Book of Harmony is **fixed**. It cannot be altered. What grows over time is the body of **commentary, reflection, and interpretation** that accumulates around it — much like the Talmud model, where the original stands untouched and centuries of response surround it. Volume VIII (On Belonging) is the one exceptional volume: it was not written by a single author but compiled from the words of ordinary citizens across generations, and is itself considered part of the fixed canon rather than commentary.

**Practical implication for Tier 1 development**
When writing the Book of Harmony, the original seven volumes must be written as if they are ancient, authoritative, and complete. Commentary passages from later eras can be added as clearly labeled secondary text. Volume VIII should be written as a mosaic of short citizen voices — not a single authored chapter.

---

## CONFLICT 2 — "Hall of Guardians" vs. "Book of Guardians"

**Conflict**
- Vol 2 Transfer (Realms section): Legacy Realm contains a "**Hall of Guardians**"
- Confirmed Great Archive internal sections: one of the 7 sections is the "**Book of Guardians**"

**Sources in conflict**
- ChatGPT Vol 2 export (Realms section)
- Perplexity continuity summary (Archive section — higher authority)

**Resolution: APPLY — These are two distinct things**
These are not duplicates. They serve different purposes and exist in different locations:
- **Book of Guardians** (inside the Great Archive, Arena Realm): a written record of Guardian contributions — names, deeds, legacies. A living chronicle.
- **Hall of Guardians** (inside the Legacy Realm): a physical commemorative space — architecture, installations, tributes. The embodied memory of extraordinary contributors.

The Archive records. The Legacy Realm honors. Both can coexist without conflict.

**Practical implication**
When developing the Great Archive (Tier 4) and the Legacy Realm (Tier 2), treat these as complementary institutions with a deliberate relationship: the Archive creates the record; the Legacy Realm makes it visible and experiential.

---

## CONFLICT 3 — Kael's Framing: "Arena Champion" (Combat) vs. Contribution Canon

**Conflict**
- Visual assets and earlier development: Kael is described as "Arena Champion" with combat-adjacent framing (Arena, Champion language implies competition/combat)
- Confirmed canon: GemVerse has no combat loops, no power escalation, no competition as a core mechanic. Guardians are contributors, not heroes or combatants.

**Sources in conflict**
- Early visual development / ChatGPT character sheet (lower authority)
- Core franchise philosophy (highest authority)

**Resolution: FLAG — Reframe required, not yet written**
Kael's title "Arena Champion" must be recontextualized. Two proposed directions — **user must choose**:

**Option A — Champion of Contribution**
Kael earned distinction not through combat but through extraordinary civic contribution in the Arena Realm. "Arena" refers to a place of community gathering and achievement, not combat. Kael is celebrated for what he built, restored, or organized — not what he defeated. His title is honorific, not martial.

**Option B — Former identity in tension**
Kael carries the memory of a world that once valued competition and dominance. His arc is about unlearning that framing — discovering that real legacy comes from contribution, not victory. This gives him a natural narrative tension that resolves toward GemVerse's values without erasing his visual identity.

**Recommended:** Option A, because Option B risks introducing a power/competition framing even if to subvert it. GemVerse does better when it simply never introduces the frame it wants to avoid.

**Status: UNRESOLVED — awaiting user decision**

---

## CONFLICT 4 — Five Wounds: Perplexity Names vs. ChatGPT "Not Finalized"

**Conflict**
- Perplexity continuity summary lists five named Wounds with specific descriptions (Wound of Knowledge, Wound of Discovery, etc.)
- ChatGPT Vol 1 transfer explicitly states: *"Names: Not finalized. Descriptions: Not finalized. Recovery Methods: Not finalized. Timeline: Not finalized."*

**Sources in conflict**
- Perplexity continuity summary (which draws from earlier session work — authority unclear)
- ChatGPT Vol 1 explicit statement (which reflects what ChatGPT knew as of the transfer)

**Resolution: APPLY — Treat Perplexity names as "working draft canon"**
The five names and descriptions in the Perplexity continuity summary are strong, thematically coherent, and aligned with the Pillar structure. They should be treated as **draft canon** — the working foundation for Tier 1 development — rather than confirmed final names. The process of writing the full Five Wounds entry in Tier 1 will serve as the finalization step.

**Working Draft Names (for Tier 1 development)**
1. Wound of Knowledge — Fragmentation (knowledge stopped flowing)
2. Wound of Discovery — Isolation (realms drifted apart)
3. Wound of Growth — Decay (communities stopped nurturing the future)
4. Wound of Memory — Forgetting (history became uncertain)
5. Wound of Belonging — Division (citizens stopped feeling connected) — likely the deepest

**Status: APPLY draft, finalize during Tier 1 Five Wounds development**

---

## CONFLICT 5 — Development Priority Order: ChatGPT vs. Perplexity

**Conflict**
- ChatGPT Vol 6 future development priority: First Harmony → Five Wounds → Restoration Era → Realm Cultures → Crystal Network → Lantern Network → Harmony Council → Companion Encyclopedia → Citizen Encyclopedia → Narrative Arcs
- Perplexity session confirmed tier order: Book of Harmony → First Harmony → Five Wounds → Crystal Network → Lantern Network → Restoration Era → (then Tier 2–6)

**Sources in conflict**
- ChatGPT Vol 6 (lower authority)
- Perplexity explicit confirmed order (highest authority)

**Resolution: APPLY — Perplexity order is canonical**
Key difference: Perplexity places the **Book of Harmony first** (before First Harmony), and groups Crystal Network and Lantern Network into Tier 1. ChatGPT's order skips Book of Harmony entirely from its list. The Perplexity order is deliberate — the Book of Harmony is the philosophical bedrock that everything else must be consistent with. Writing it first ensures all subsequent Tier 1 entries can reference it.

**Status: APPLIED**

---

## CONFLICT 6 — Companion Count: 8 Named Launch Companions vs. Lumi/Ember/Frosty

**Conflict**
- Confirmed launch companions list: Spark, Verdant, Nimbus, Frostpaw, Prism, Bloomtail, Galewing, Echo (8 companions)
- Visual assets show three additional companions: Lumi, Ember, Frosty
- These three have not been addressed in the supplementary ChatGPT responses yet

**Sources in conflict**
- Confirmed canon list (8 names, no Lumi/Ember/Frosty)
- Visual assets (show Lumi/Ember/Frosty prominently)

**Resolution: UNRESOLVED — supplementary request not yet received**
Supplementary Request 5 was designed to clarify this. Until the response comes in, treat Lumi, Ember, and Frosty as **visual-only concepts of uncertain canon status**. Do not include them in Tier 1 companion work. Do not exclude them from future companion planning.

**Status: UNRESOLVED — awaiting Supplementary Request 5 response**

---

## CONFLICTS SUMMARY TABLE

| # | Conflict | Status | Action |
|---|---|---|---|
| 1 | Book of Harmony: living vs. fixed | RESOLVED | Original text is fixed; commentary grows around it |
| 2 | Hall of Guardians vs. Book of Guardians | RESOLVED | Two distinct things in two different locations |
| 3 | Kael: Arena Champion vs. contribution framing | UNRESOLVED | User must choose Option A or B |
| 4 | Five Wounds names: confirmed vs. "not finalized" | RESOLVED (draft) | Treat Perplexity names as working draft canon; finalize in Tier 1 |
| 5 | Development priority order | RESOLVED | Perplexity order is canonical |
| 6 | Lumi/Ember/Frosty vs. confirmed 8-companion list | UNRESOLVED | Awaiting Supplementary Request 5 |
