PRS Console v0.1 backend scaffold

Run:
1. cd backend
2. python -m venv .venv
3. .venv\\Scripts\\activate
4. pip install -r requirements.txt
5. uvicorn app.main:app --reload --port 8000

Key endpoints:
- GET /api/ping
- GET /api/projects
- GET /api/projects/{project_id}
- GET /api/projects/{project_id}/decisions
- GET /api/portfolio/summary
- GET /api/health/overview
