# Realm Packet — Legacy Realm
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 2 Entry:** 2.1  
**Linked Files:** `01-canon-map.md`, `06-five-wounds.md`, `02-conflicts-log.md`, `puzzle-catalog.md`, `asset-registry.md`

---

## Overview

**Name:** Legacy Realm  
**Theme:** Preservation  
**Current State:** Partially hidden; the civilization's long-term memory and aspirational archive  
**Wound Alignment:** Wound of Memory — Forgetting (manifests as preservation without context)  
**Visual Identity (from Art Bible):** Not directly described; confirmed in locked canon as a distinct Realm  
**Symbol:** Seed Vault with Growing Tree (representing preservation that enables future growth)  
**Key Locations:** The Hall of Guardians, The Time Capsule Vaults, The Founders' Grove, The Continuity Archives, The Promise Gardens, The Threshold of Tomorrow

---

## 1. Realm Essence

The Legacy Realm is the civilization's deliberate answer to the question: "What do we owe the future?" It is a realm designed not for the present, but for what comes after — a place where the most significant contributions, the deepest wisdom, and the clearest aspirations are preserved against the possibility of loss.

In the First Harmony, the Legacy Realm was understood as the **civilizational seed vault** — not just for biological seeds, but for ideas, values, commitments, and the distilled essence of what the civilization had learned. It was where the Legacy House operated, where the most significant Time Capsules were sealed, where the Hall of Guardians honored those whose contributions shaped the civilization's trajectory.

The realm embodies Preservation not as static storage, but as **intentional continuity** — the practice of choosing what matters most and ensuring it survives to inform futures we cannot imagine.

---

## 2. Current State (Restoration Era)

The Legacy Realm exists in a unique state — it is the most physically preserved of all Realms (by design, it was built to endure), but it is also the most disconnected from living civilization. Its preservation systems function, but the communities that would give its contents meaning are largely absent.

### Preserved Systems:
- **Hall of Guardians**: The physical commemorative space remains intact, its installations and tributes undamaged
- **Time Capsule Vaults**: The sealed capsules from the First Harmony and earlier eras remain secure
- **Founders' Grove**: The planted grove where each significant contributor planted a tree continues to grow
- **Continuity Archives**: The records of civilizational commitments, aspirations, and distilled wisdom are intact

### Disconnected Systems:
- **Active Curation**: No living community regularly evaluates, contextualizes, or adds to the preserved materials
- **Promise Gardens**: The gardens where citizens planted living symbols of their civilizational commitments are maintained automatically but not visited
- **Threshold of Tomorrow**: The ceremonial space for making new civilizational commitments is unused
- **Cross-Realm Transmission**: The systems for sharing Legacy Realm insights with other Realms are dormant

---

## 3. Cultural Details

### Daily Life

The few citizens who remain in the Legacy Realm (mostly Legacy House members and Archive specialists) follow a rhythm of "tending, witnessing, and waiting." Their work is the quiet maintenance of things meant to outlast them.

A common greeting is "What are you preserving for?" — referring both to the specific materials one is maintaining and to the larger civilizational purpose. The answer is expected to connect immediate work to long-term meaning.

Meals are simple and often shared in the Promise Gardens, surrounded by the living symbols of past commitments. Eating among the growing commitments is a daily reminder of the connection between present action and future consequence.

Children (very few) are taught that their lives are part of a continuity they did not choose but can choose to honor. "Legacy literacy" — understanding how to read the preserved records and how to make commitments worth preserving — is the core of their education.

### Arts & Traditions

The realm's art form is **Commitment Craft** — creating objects, spaces, or practices that embody a specific civilizational commitment and are designed to communicate that commitment across time. This includes:
- **Time Capsule Design**: Creating containers and contents that will be meaningful to unknown future recipients
- **Promise Garden Cultivation**: Tending living symbols that grow in specific patterns representing civilizational commitments
- **Guardian Tribute Creation**: Designing the installations in the Hall of Guardians that honor significant contributors
- **Continuity Weaving**: Textiles that encode civilizational wisdom in patterns designed to be readable across millennia

Festivals are tied to **Commitment Cycles**. The **Festival of Sealed Promises** marks the annual sealing of new Time Capsules. The **Guardian Recognition Day** honors new additions to the Hall of Guardians. The **Threshold Ceremony** invites citizens to make new civilizational commitments at the Threshold of Tomorrow.

### Notable Citizens

- **The Vault Keepers** — Specialists who maintain the Time Capsule Vaults' environmental controls and security
- **The Hall Curators** — Those who design and maintain the Hall of Guardians' installations
- **The Grove Tenders** — Caretakers of the Founders' Grove and its growing legacy
- **The Threshold Guardians** — Citizens who maintain the Threshold of Tomorrow and facilitate commitment ceremonies

---

## 4. Preservation Themes

The Legacy Realm is aligned with the **Wound of Memory — Forgetting**, manifesting as **preservation without context** — the danger of preserving the forms of civilization's achievements while losing the understanding of why they mattered.

### What the Legacy Realm Reveals About the Wound:

- **Preservation Requires Living Context** — A Time Capsule perfectly preserved but never opened, never understood, never connected to living questions, is not truly preserved — it's just stored.
- **Forgetting Is Not Just Loss** — The Forgetting Wound includes the erosion of the *relationship* between preserved materials and the communities they were meant to serve.
- **Restoration Is Recontextualization** — Healing the Memory Wound means restoring the living conversation between what was preserved and what is needed now.

---

## 5. Puzzle Integration Points

### Legacy Seal Puzzles

These are the signature puzzles of the Legacy Realm:

- **Time Capsule Decoding** — Interpreting the contents of sealed capsules to understand what previous generations valued and why
- **Commitment Verification** — Checking which civilizational commitments were fulfilled, which abandoned, which remain relevant
- **Aspirational Synthesis** — Combining insights from multiple Time Capsules to reconstruct the civilization's evolving self-understanding

### Fragment Assembly Puzzles (Continuity Reconstruction)

The Continuity Archives contain records that only make sense when assembled across time:

- **Commitment Genealogy** — Tracing how a civilizational commitment evolved across generations
- **Wisdom Distillation** — Reconstructing the process by which the civilization identified its most essential insights
- **Threshold Reconstruction** — Rebuilding the record of what citizens promised at the Threshold of Tomorrow

### Community Pattern Puzzles (Collective Commitment)

The realm's tradition of collective commitment-making:

- **Promise Garden Alignment** — Understanding how individual commitments were meant to support each other
- **Founders' Grove Mapping** — Reading the pattern of planted trees as a civilizational family tree
- **Hall of Guardians Resonance** — Understanding how different Guardians' contributions complemented each other

---

## 6. Restoration Goals

The Legacy Realm's restoration focuses on **reanimating preservation as a living conversation** — not just maintaining the physical preservation systems, but restoring the relationship between what was preserved and the civilization that needs it:

1. **Reactivating Curation Communities** — Re-establishing communities of citizens who actively engage with preserved materials
2. **Restoring Cross-Realm Transmission** — Creating pathways for Legacy Realm insights to inform current restoration work
3. **Reopening the Threshold of Tomorrow** — Inviting the current civilization to make its own commitments to the future
4. **Integrating Preservation into Daily Practice** — Ensuring that all restoration work includes consideration of what should be preserved for the future

---

## 7. Mystery Hooks (Open, Not Resolved)

- **The Unopened Capsule** — A Time Capsule sealed by the civilization's founding generation, with explicit instructions not to open it until "the civilization has forgotten why it exists." Has that time come? Who decides?
- **The Missing Guardian** — The Hall of Guardians has a space prepared for a Guardian whose name and contributions were deliberately erased from all other records but preserved here. Who were they, and why?
- **The Threshold's Other Side** — The Threshold of Tomorrow is described in some records as a doorway, not just a ceremonial space. What lies beyond it, and under what conditions does it open?

---

## 8. Companion Connections

- **Echo** — Primary Legacy Realm companion; preserves the voices and stories that give preserved materials their meaning
- **Frostpaw** — Maintains the deep memory of what the civilization chose to preserve and why
- **Prism** — Provides multi-perspective analysis of preserved commitments and their evolution
- **Verdant** — Understands the Founders' Grove as a living preservation system
- **Bloomtail** — Helps communities understand collective commitment as a form of community care
- **Solen** — Analyzes the systemic balance of what was preserved vs. what was lost
- **Nimbus** — Facilitates the rare journeys to this most remote Realm
- **Spark** — Represents the hope that preserved commitments will one day bloom again

---

## 9. Hall of Guardians vs. Book of Guardians Clarification

Per Conflict 2 resolution in `02-conflicts-log.md`:

> **Book of Guardians** (inside the Great Archive, Arena Realm): a written record of Guardian contributions — names, deeds, legacies. A living chronicle.
> 
> **Hall of Guardians** (inside the Legacy Realm): a physical commemorative space — architecture, installations, tributes. The embodied memory of extraordinary contributors.
> 
> The Archive records. The Legacy Realm honors. Both can coexist without conflict.

The Legacy Realm's Hall of Guardians is the *physical, experiential complement* to the Archive's written Book of Guardians. Where the Book records, the Hall embodies.

---

## Files Updated / Referenced

- `asset-registry.md` — Legacy Realm environment art tag updated
- `02-conflicts-log.md` — Conflict 2 resolution reference
- `puzzle-catalog.md` — Legacy Seal puzzle type contextualization
- `tier-roadmap-tracker.md` — Legacy Realm Packet status: Draft Complete