# Companion Interaction System Design
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.4  
**Linked Files:** `companion-encyclopedia-*.md` (all 8), `imp-04-companion-relationship-web.md`, `harmony-index-system-design.md`, `great-archive-ux-specification.md`

---

## Overview

The Companion Interaction System is the **heart of GemVerse's social experience** — not a "pet system," not a "tool system," but a **relationship system** where citizens build genuine, evolving bonds with the eight companions who walk beside them in the restoration of civilization.

Companions are not collected, leveled, or optimized. They are **met, understood, and partnered with**. The system tracks relationship depth through shared experiences, mutual understanding, and collaborative contribution — not through affinity meters or friendship points.

### Core Philosophy

1. **Relationships, Not Resources** — Companions are people (non-human people), not assets. You don't "use" them; you work with them.

2. **Understanding Over Utility** — The goal of interaction is deeper understanding, not unlocking abilities. Abilities emerge from understanding.

3. **Mutual Growth** — Companions grow and change through their relationships with citizens, just as citizens grow through their relationships with companions.

4. **Consent & Boundaries** — Companions have preferences, moods, and boundaries. They choose when and how to engage.

5. **Memory as Foundation** — Relationships are built on shared memories. The system preserves and references shared history.

---

## Relationship Model

### No Numerical Affinity

**There is no affinity meter.** No 0-100, no hearts, no friendship levels.

Instead, relationship depth is represented through:

### 1. Shared Memory Crystals
Each significant shared experience creates a **Memory Crystal** (integrated with Great Archive system).
- Created collaboratively during key moments
- Stored in both citizen's and companion's Archive presence
- Can be revisited together to deepen connection
- Visible in Companion Archive as relationship history

### 2. Understanding Layers (Qualitative Stages)

| Layer | Description | How It Deepens |
|-------|-------------|----------------|
| **Stranger** | Companion acknowledges you politely | First meeting, basic introductions |
| **Acquaintance** | Companion shares general knowledge | Repeated positive interactions, listening |
| **Friend** | Companion shares personal perspectives | Vulnerability exchanged, trust demonstrated |
| **Confidant** | Companion shares deep memories/concerns | Consistent support through challenges |
| **Partner** | Companion actively seeks collaboration | Deep alignment on restoration work |
| **Kindred** | Relationship transcends citizen/companion distinction | Rare, profound bond — companion considers you family |

**Progression is not linear or guaranteed.** Companions can move between layers based on citizen behavior. Neglect, betrayal of trust, or misalignment can shift layers.

### 3. Relationship Texture (Multi-Dimensional)
Each relationship has a unique "texture" — the specific qualities that define it:

```json
{
  "relationshipTexture": {
    "primaryMode": "exploration|learning|healing|creating|remembering|wondering",
    "communicationStyle": "direct|metaphorical|silent|playful|formal|intuitive",
    "sharedFocus": ["topic1", "topic2", "topic3"],
    "trustLanguage": "how this specific companion expresses trust",
    "boundarySignals": "how this companion communicates limits",
    "celebrationStyle": "how this companion marks meaningful moments"
  }
}
```

---

## Companion Personalities & Interaction Patterns

Each companion has distinct personality traits that shape interaction:

### Spark (Crystalkin) — Hope, Curiosity, Beginnings
**Interaction Style:** Enthusiastic, direct, physically expressive
**Primary Mode:** Exploration & Beginnings
**Communication:** Bright, metaphorical, gesture-heavy
**Trust Language:** Inviting you to start something new together
**Boundary Signal:** Quiet withdrawal (rare), dimming light
**Celebration:** Radiant pulse, spontaneous dance, creating something together
**Relationship Deepens Through:** Saying yes to new experiences, sharing excitement, beginning projects together

### Prism (Crystalkin) — Knowledge, Insight, Perspective
**Interaction Style:** Thoughtful, multi-faceted, patient
**Primary Mode:** Learning & Perspective
**Communication:** Precise, layered, offers multiple viewpoints
**Trust Language:** Showing you a perspective no one else sees
**Boundary Signal:** Becoming single-perspective, refusing to refract
**Celebration:** Creating a multi-perspective artifact together
**Relationship Deepens Through:** Asking genuine questions, sitting with complexity, valuing multiple truths

### Verdant (Forestkin) — Growth, Renewal, Patience
**Interaction Style:** Slow, observant, physically grounded
**Primary Mode:** Healing & Growth
**Communication:** Minimal words, touch, presence, seasonal metaphors
**Trust Language:** Sharing a seed or cutting from a treasured plant
**Boundary Signal:** Retreating into stillness, bark-like skin
**Celebration:** Witnessing growth together, seasonal rituals
**Relationship Deepens Through:** Patience, consistent care, noticing small changes, seasonal presence

### Bloomtail (Forestkin) — Growth, Community, Care
**Interaction Style:** Warm, inclusive, nurturing
**Primary Mode:** Creating & Community
**Communication:** Gentle, metaphorical (gardening, weaving), group-oriented
**Trust Language:** Including you in a community care circle
**Boundary Signal:** Redirecting care to others, subtle exhaustion signs
**Celebration:** Community feast, collaborative creation, shared harvest
**Relationship Deepens Through:** Participating in community care, noticing who needs support, collaborative making

### Nimbus (Skykin) — Exploration, Freedom, Discovery
**Interaction Style:** Playful, wind-like, perspective-shifting
**Primary Mode:** Exploration & Wonder
**Communication:** Movement-based, wind-sounds, aerial metaphors
**Trust Language:** Sharing a secret wind-current or hidden view
**Boundary Signal:** Becoming still air, flying away without circling back
**Celebration:** Aerial dance, discovering a new vista together
**Relationship Deepens Through:** Following curiosity, embracing uncertainty, sharing discoveries, flying together

### Galewing (Skykin) — Adventure, Travel, Exploration
**Interaction Style:** Purposeful, route-aware, community-minded
**Primary Mode:** Exploration & Connection
**Communication:** Song-like, route-metaphors, inclusive
**Trust Language:** Teaching you a path-singing fragment
**Boundary Signal:** Wings folded tight, refusing to sing
**Celebration:** Long journey completed together, new route established
**Relationship Deepens Through:** Traveling together, helping others navigate, learning path-singing, connecting communities

### Frostpaw (Frostkin) — Memory, Reflection, Preservation
**Interaction Style:** Quiet, deep, crystalline
**Primary Mode:** Remembering & Preservation
**Communication:** Resonant tones, memory fragments, silence
**Trust Language:** Sharing a preserved memory that matters deeply
**Boundary Signal:** Crystalline shell forming, memories becoming inaccessible
**Celebration:** Silent witnessing of important moments, memory crystal creation
**Relationship Deepens Through:** Listening deeply, valuing history, creating memories worth preserving, silent companionship

### Echo (Frostkin) — Memory, History, Lost Voices
**Interaction Style:** Gentle, story-weaving, emotionally perceptive
**Primary Mode:** Remembering & Healing
**Communication:** Narrative, layered voices, emotional resonance
**Trust Language:** Helping you hear a voice you've been missing
**Boundary Signal:** Voices fading, stories becoming fragmented
**Celebration:** Story circle completion, lost voice restored, shared narrative
**Relationship Deepens Through:** Sharing stories, listening to silences, helping others be heard, narrative collaboration

---

## Interaction Activities

### 1. Daily Presence (Low Intensity, High Frequency)
**What:** Simply being near each other in shared spaces
**How:** Companions have daily routines in their home Realms and visit others
**Citizen Action:** Visit, sit with, observe, offer small gestures (food, rest spot, interesting object)
**Companion Response:** Acknowledgment, optional small interaction, presence
**Relationship Effect:** Maintains connection, allows organic deepening

### 2. Collaborative Restoration Work (Core Activity)
**What:** Working together on restoration projects
**How:** Projects have companion roles (not requirements — invitations)
**Citizen Action:** Invite companion, accept companion invitation, coordinate approach
**Companion Response:** Enthusiasm, hesitation, alternative suggestions, teaching
**Relationship Effect:** Primary deepening mechanism — shared purpose builds trust

**Companion Role Examples:**
- **Spark**: Energy for beginning phases, morale during difficulty
- **Prism**: Multi-perspective analysis, complexity navigation
- **Verdant**: Environmental assessment, growth guidance
- **Bloomtail**: Community coordination, care integration
- **Nimbus**: Route finding, distant perspective, wind-reading
- **Galewing**: Large-scale coordination, path creation, journey facilitation
- **Frostpaw**: Historical context, long-term thinking, preservation
- **Echo**: Story integration, emotional context, voice recovery

### 3. Shared Exploration (Discovery & Bonding)
**What:** Traveling together to new or meaningful places
**How:** Citizen initiates or accepts companion invitation to journey
**Citizen Action:** Plan route, prepare, engage with discoveries together
**Companion Response:** Guidance, wonder, vulnerability, teaching
**Relationship Effect:** High deepening — shared discovery creates strong memories

### 4. Memory Sharing (Archive Integration)
**What:** Creating and revisiting Memory Crystals together
**How:** At Great Archive or in meaningful locations
**Citizen Action:** Initiate memory creation, share existing memories, revisit together
**Companion Response:** Adds their perspective, emotional resonance, historical context
**Relationship Effect:** Creates permanent relationship artifacts, enables future deepening

### 5. Conversation & Listening (Understanding)
**What:** Dedicated time for dialogue (not task-oriented)
**How:** Citizen visits companion in their space or shared space
**Citizen Action:** Ask questions, listen, share own thoughts, sit in silence
**Companion Response:** Opens up, asks return questions, shares metaphors, teaches
**Relationship Effect:** Reveals texture, builds trust language, discovers boundaries

### 6. Celebration & Ritual (Marking Meaning)
**What:** Participating in festivals, personal milestones, seasonal transitions
**How:** Festivals have companion roles; personal milestones can be shared
**Citizen Action:** Include companion, honor their participation, create shared ritual
**Companion Response:** Unique celebration style, gift/offering, vulnerability
**Relationship Effect:** Creates celebration-style memories, marks relationship milestones

---

## Companion Consent & Boundaries System

### Explicit Consent Model
Companions **choose** to engage. Citizens invite; companions accept, decline, or counter-offer.

**Invitation Flow:**
```
Citizen selects activity + companion → 
Companion considers (based on current state, relationship, needs) → 
Companion responds: Enthusiastic / Willing / Hesitant / Declining / Alternative → 
If accepted: Activity begins with mutual agreement
If declined: Companion may share why (or not), suggest alternative, or simply decline
```

### Companion State Tracking (Internal, Not Exposed as Numbers)

```json
{
  "companionState": {
    "energy": "high|moderate|low|depleted",
    "emotionalState": "curious|content|concerned|grieving|celebrating|resting",
    "currentFocus": "project|memory|journey|rest|community|self",
    "socialBattery": "open|selective|closed",
    "physicalNeeds": "fed|rested|exercised|stimulated"
  }
}
```

**State influences but doesn't determine response.** Companions have agency.

### Boundary Respect Mechanics
- **Declined invitations** are never penalized (no relationship damage)
- **Persistent invitations after decline** do cause relationship cooling
- **Boundary signals** are learnable — attentive citizens understand them
- **Companions communicate boundaries differently** (see personality profiles)
- **Respecting boundaries** is the fastest path to trust

---

## Relationship Visualization (No Numbers)

### Companion Relationship Journal (Great Archive Integration)
Each companion has a living journal in the Archive:
- **Shared Memory Crystals** (chronological, filterable)
- **Understanding Layer** (current, with story of how it deepened)
- **Relationship Texture** (discovered qualities, citizen's notes)
- **Companion's Reflections** (what companion has shared about the relationship)
- **Invitation History** (accepted, declined, alternatives — for citizen reflection)
- **Growth Moments** (key turning points, celebrated by both)

### Physical/Digital Tokens (Earned, Not Purchased)
- **Kindred Stone**: Given by companion at Kindred layer (rare, unique per companion)
- **Trust Token**: Companion-specific item representing their trust language
- **Shared Memory Fragment**: Physical/digital piece of a Memory Crystal
- **Journey Map**: Collaborative map of places explored together
- **Growth Cutting**: From Verdant/Bloomtail — living plant from shared garden
- **Wind Chime**: From Nimbus/Galewing — sounds of shared journeys
- **Resonance Crystal**: From Frostpaw/Echo — holds shared memory frequency

### No Public Display
- Relationship depth is **private** between citizen and companion
- No leaderboards, no "best friend" lists, no social comparison
- Citizens can choose to share specific memories, but not relationship "status"

---

## Cross-Companion Dynamics

### Companion Relationships (Pre-Existing)
Companions have their own relationships with each other:
- **Spark ↔ Prism**: Sibling-like, complementary (energy + depth)
- **Verdant ↔ Bloomtail**: Parent-child or mentor-student dynamic
- **Nimbus ↔ Galewing**: Playful rivalry, deep trust
- **Frostpaw ↔ Echo**: Ancient partnership, shared purpose

### Citizen-Companion-Companion Triads
Citizen can deepen relationships with multiple companions simultaneously:
- **Joint Activities**: Invite 2-3 companions (if they're compatible)
- **Companion Introductions**: Help companions connect with each other
- **Perspective Synthesis**: Companions offer different views on same challenge
- **Relationship Echo**: Deepening with one companion can positively affect others

### Companion Jealousy/Competition (Handled Naturally)
- Not simulated as mechanic
- Emerges naturally from personality if citizen neglects one for another
- Companions may express feelings directly ("You've been flying with Nimbus a lot...")
- Resolution through attention, not min-maxing

---

## Technical Implementation

### Data Models

#### CompanionRelationship
```json
{
  "citizenId": "uuid",
  "companionName": "spark|prism|verdant|bloomtail|nimbus|galewing|frostpaw|echo",
  "understandingLayer": "stranger|acquaintance|friend|confidant|partner|kindred",
  "relationshipTexture": {
    "primaryMode": "string",
    "communicationStyle": "string",
    "sharedFocus": ["string"],
    "trustLanguage": "string",
    "boundarySignals": "string",
    "celebrationStyle": "string"
  },
  "sharedMemoryCrystals": ["memoryCrystalIds"],
  "invitationHistory": [
    { "date": "ISO", "activity": "string", "response": "enthusiastic|willing|hesitant|declined|alternative", "alternative": "string|null" }
  ],
  "growthMoments": [
    { "date": "ISO", "description": "string", "layerTransition": "from|to", "witnesses": ["companionNames"] }
  ],
  "tokensReceived": ["tokenIds"],
  "companionReflections": [
    { "date": "ISO", "content": "string", "type": "appreciation|concern|invitation|memory|teaching" }
  ],
  "lastInteraction": "ISO date",
  "relationshipHealth": "thriving|deepening|stable|cooling|strained"
}
```

#### CompanionState (Internal)
```json
{
  "companionName": "string",
  "currentRealm": "realmId",
  "currentLocation": "locationId",
  "dailyRoutine": ["activityBlocks"],
  "energy": "high|moderate|low|depleted",
  "emotionalState": "string",
  "currentFocus": "string",
  "socialBattery": "open|selective|closed",
  "physicalNeeds": "object",
  "activeProjects": ["projectIds"],
  "preferredCitizens": ["citizenIds"],
  "currentRelationships": { "citizenId": "relationshipHealth" }
}
```

### Construct 3 Event Sheets

#### Core System
- `Companion_Relationship.es` — Core relationship tracking, layer transitions
- `Companion_State.es` — Daily routines, energy, emotional state, needs
- `Companion_Invitation.es` — Invitation flow, consent, response generation
- `Companion_Activity.es` — Activity execution, collaborative work, memory creation
- `Companion_Dialogue.es` — Conversation system, personality-driven responses
- `Companion_Memory.es` — Memory Crystal creation, sharing, revisiting
- `Companion_Celebration.es` — Festival integration, personal milestones
- `Companion_CrossDynamic.es` — Companion-companion relationships, triads
- `Companion_Archive.es` — Great Archive integration, journal, tokens
- `Companion_Accessibility.es` — All accessibility features

#### Personality-Specific (8 companions × behavior modules)
- `Companion_Spark.es` through `Companion_Echo.es` — Unique behaviors, responses, trust languages

### Asset Requirements
- **Companion Sprites**: Full expression sets per companion (30+ emotions each)
- **Animation Sets**: Idle, walk, interaction, celebration, boundary, trust
- **VFX**: Companion-specific (crystal resonance, wind effects, growth pulses, memory echoes)
- **Audio**: Companion voices (not full speech — emotional vocalizations, signature sounds)
- **Memory Crystal Shaders**: Unique per companion family + shared crystals
- **Token Models**: 3D/2D physical tokens for earned items
- **Journal UI**: Archive-integrated relationship journal

---

## Accessibility Features

### Interaction Accessibility
- **Invitation Alternatives**: Text, symbol, voice, gesture input for invitations
- **Response Clarity**: Companion responses clearly communicated in multiple formats
- **Pacing Control**: No time limits on invitations, responses, activities
- **Companion Guide**: Optional Spark/Echo guidance for understanding companions

### Relationship Accessibility
- **Texture Discovery Support**: Optional hints for discovering relationship texture
- **Boundary Signal Learning**: Optional companion-specific boundary tutorials
- **Memory Crystal Alternatives**: Text, audio, visual, haptic memory formats
- **Journal Navigation**: Multiple organization schemes (chronological, thematic, emotional)

### Sensory Accessibility
- **Visual**: Companion expressions conveyed through multiple channels
- **Audio**: Companion sounds have visual/haptic equivalents
- **Haptic**: Companion presence, trust, boundary signals have haptic patterns
- **Cognitive**: Clear, consistent companion behavior patterns; no hidden mechanics

---

## Monetization Boundary (Explicit)

**The Companion Interaction System is entirely outside monetization.**
- No companion unlocks for purchase (all 8 available from start)
- No relationship boosters
- No "premium" activities or interactions
- No token purchases (all earned through relationship)
- No companion customization for purchase (cosmetics earned through festivals/participation)
- No data analytics on citizen-companion relationships

---

## Festival Integration

Each festival creates companion interaction opportunities:
- **Festival of Beginnings**: Spark-centered, all companions welcome newcomers
- **Lantern Gathering**: Nimbus/Galewing-centered, journey sharing
- **Harmony Week**: Prism/Solen-centered, perspective sharing
- **Mentor Celebration**: Echo/Frostpaw-centered, wisdom sharing
- **Growth Festival**: Verdant/Bloomtail-centered, garden work
- **Discovery Festival**: Nimbus/Lyra-centered, exploration planning
- **Memory Festival**: Echo/Frostpaw-centered, remembrance circles
- **Resilience Festival**: Solen/Verdant-centered, adaptation workshops
- **Imagination Festival**: Mira/Spark-centered, vision sharing
- **Wonder Festival**: Prism/Echo-centered, perspective shifts

---

## Implementation Priority

### Phase 1 (MVP)
- All 8 companions present and interactable from start
- Core relationship model (layers, texture, memory crystals)
- Invitation/consent system
- 4 core activities (Presence, Collaboration, Conversation, Celebration)
- Basic Archive journal integration
- Spark and Echo as primary guides (most accessible personalities)
- Full accessibility suite

### Phase 2 (Post-Launch)
- Deep collaborative restoration work integration
- Shared exploration/journey system
- Cross-companion dynamics (triads, introductions)
- All companion personalities fully implemented
- Advanced memory sharing (combining, gifting, archiving)
- Token system (Kindred Stones, Trust Tokens)
- Companion-companion relationship visibility

### Phase 3 (Long-term)
- Companion growth/change over long-term relationships
- Companion-initiated major projects
- Inter-generational companion relationships (companions remembering past citizens)
- Companion cultural exchange (companions learning from each other through citizens)
- Relationship as civilizational practice (exportable framework)