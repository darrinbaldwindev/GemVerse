# Companion Encyclopedia Entry — Bloomtail
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.6  
**Linked Files:** `01-canon-map.md`, `imp-04-companion-relationship-web.md`, `asset-registry.md`

---

## Overview

**Name:** Bloomtail  
**Themes:** Growth, Community, Care  
**Companion Family:** Forestkin (Emerald, Leaf Green, Earth Brown)  
**Visual Identity:** Small, rabbit-like creature with flower-petal ears that change color with seasons, tail that blooms into small flowers which shed and regrow cyclically  
**Symbol:** Interwoven Flowers and Roots (representing interconnected growth and community care)  
**Unique Trait:** Empathic bloom-reading — can sense the emotional "health" of communities and predict what kind of support they need to flourish  

---

## 1. Origin Story

Bloomtail was born during a "Community Bloom" — a rare Verdance tradition where an entire settlement plants a communal garden that represents their collective hopes and dreams. This particular bloom was planted in the heart of the Verdant Vale during a period of rebuilding after early Shattering disruptions.

The garden was tended by Verdance Stewards, citizens, and companions working together. Bloomtail emerged not from a seed, but from a moment of perfect harmony between all the contributors — when everyone's intention for growth aligned in a single, joyful impulse.

They were first noticed by a young Verdance Steward named Tilia, who was coordinating the community garden project. Bloomtail's presence caused all the plants in their immediate vicinity to bloom more vibrantly, and people naturally gathered around them to share stories and plans for the future.

Bloomtail's first "words" were expressed through a spontaneous ring of flowering plants that spelled out a message of welcome and invitation in the communal garden.

---

## 2. Personality

Bloomtail is nurturing, optimistic, and deeply intuitive about group dynamics. They can sense when a community is thriving, struggling, or in need of specific kinds of support. This makes them a natural bridge-builder and mediator.

They communicate through a combination of expressive ear-color changes, gentle movements, and influencing the blooming patterns of nearby plants. Their "voice" is described as warm and encouraging, like "sunlight filtered through leaves."

Bloomtail experiences time through growth cycles — not just their own, but the cycles of the communities they're part of. They remember events not by date, but by what was growing when: "the season of the Great Sunflower Tower" or "the time of the Community Orchard's First Fruiting."

They can be overwhelming to more solitary companions, as they naturally try to involve everyone in collaborative activities.

---

## 3. Shattering Memory

Bloomtail's memories of the First Harmony include community gardens that spanned Realm boundaries, with plants and seeds exchanged regularly between different settlements. These weren't just practical agricultural exchanges, but acts of friendship — each seed a tiny promise of connection.

After the Shattering, these exchanges largely stopped. Communities became more isolated, and the communal gardening traditions that Bloomtail loved began to fade. Gardens became smaller, more utilitarian, less about shared joy and more about survival.

What Bloomtail remembers most painfully is not the loss of specific plants, but the loss of shared intention — when growing things together became growing things alone.

---

## 4. Missing Piece

Bloomtail's Missing Piece is the "Covenant of Seasons" — a formal agreement between communities to share specific plants and gardening knowledge according to seasonal cycles. This wasn't just about resources, but about maintaining relationships through regular, meaningful exchanges.

The Covenant involved detailed calendars of what to plant when, who would tend which experimental crops, and how discoveries would be shared. When communities became isolated, the detailed knowledge of the Covenant was lost in fragments.

Bloomtail carries echoes of the Covenant's rhythms in their seasonal awareness, but cannot recreate the full network of community cooperation it represented.

---

## 5. Restoration Story

Bloomtail joined the Guardian when the Guardian was helping to restore a communal garden in the Arena Realm that had been neglected for years. Bloomtail's presence didn't just help the plants grow — it helped the community members reconnect with each other.

They could sense which neighbors had been estranged, which families were struggling, and which individuals needed encouragement to participate. Through subtle influences on plant behavior and their own encouraging presence, they helped people remember how to grow things together.

Bloomtail's role in restoration is to help communities remember their interconnection — not just with each other, but with the larger web of life they're part of. They don't just grow gardens; they grow relationships.

---

## 6. Legacy Story

Bloomtail has inspired a new tradition called "Circle Gardens" — small communal growing spaces where neighbors plant not just vegetables and flowers, but also "intention seeds" that represent hopes for their community's future.

Others speak of "Bloomtail's Touch" — moments when a struggling community suddenly finds itself working together again, or when isolated individuals find their way into collaborative projects.

Bloomtail's legacy will be not the plants they grew, but the communities they helped reconnect — teaching others that growth is not just individual development, but collective flourishing.

---

## Relationships

### Forestkin Family
Bloomtail is related to many Forestkin through the communal gardens their family has tended for generations. They're especially close to Verdant, who shares their love of community-based growth, though Verdant is more contemplative while Bloomtail is more social.

### Guardian
Bloomtail sees the Guardian as "community-shaped" — someone who naturally brings people together around shared goals. They enjoy working with the Guardian because their collaborative approach resonates with Bloomtail's own nature.

### Other Companions
- **Verdant:** "Family. Deep roots, deep thoughts. We grow well together, though they need more solitude than I do."
- **Spark:** "Energy with direction! Their excitement is infectious, and they're surprisingly good at organizing group activities."
- **Nimbus:** "Dreams with purpose. Their vision for what communities could be inspires my own growth plans."
- **Frostpaw:** "Clarity about what communities need. Sometimes too clear — they can see problems before anyone else feels them."
- **Echo:** "Memory with heart. Remembers not just what happened, but what communities felt during shared experiences."

---

## Companion Abilities (Narrative, Not Mechanical)

- **Empathic Bloom-reading:** Can sense the emotional "health" of communities and what support they need
- **Seasonal Awareness:** Intuitively understands optimal timing for community initiatives and growth projects
- **Growth Harmony Facilitation:** Can encourage coordinated growth activities that bring people together
- **Plant Communication:** Can influence plant behavior to convey messages or create meaningful patterns
- **Community Intuition:** Naturally senses group dynamics and can help resolve tensions or encourage participation

---