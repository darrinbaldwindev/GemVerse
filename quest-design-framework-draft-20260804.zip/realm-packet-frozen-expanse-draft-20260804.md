# Realm Packet — Frozen Expanse
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 2 Entry:** 2.1 (partial)  
**Linked Files:** `01-canon-map.md`, `06-five-wounds.md`, `imp-02-five-wounds-restoration-model.md`, `asset-registry.md`

---

## Overview

**Name:** Frozen Expanse  
**Theme:** Memory  
**Current State:** Many memories inaccessible; Realm partially preserved in ice  
**Wound Alignment:** Wound of Memory — Forgetting  
**Visual Identity (from Art Bible):** "A realm of silence and deep memory."  
**Symbol:** Ice Crystal with Embedded Silhouette (representing preserved moments and hidden truths)  
**Key Locations:** The Memorial Glades, The Echoing Archive, The Threshold of First Snows, The Thawing Heart

---

## 1. Realm Essence

The Frozen Expanse is a vast, crystalline landscape of ice formations, glacier valleys, and perpetually snow-covered plateaus. In the First Harmony, it was not a cold wasteland but a realm of preservation — where the most precious memories were stored in ice-cathedrals and glacier-vaults by Borealis Chroniclers and Frostkin companions.

The realm embodies Memory not as mere recollection, but as **preservation with presence** — the idea that remembering is not just thinking about the past, but keeping it alive in meaningful ways.

---

## 2. Current State (Restoration Era)

The Frozen Expanse exists in a state of "selective stillness." Some areas are fully frozen — their memories locked away but intact. Others are slowly thawing, causing selective memories to resurface in fragments, often out of context.

The **Memorial Glades** — vast fields of ice-tomb markers for significant events and individuals — are mostly intact but无人tended. The **Echoing Archive**, once the central repository for Companion memories (managed by Borealis Chroniclers), is partially melted. Its lower levels are flooded, making retrieval dangerous.

The **Threshold of First Snows** — the realm's entry point — remains intact, but the traditional welcome ceremonies are forgotten. Visitors are greeted by silent Frostkin who remember their role but not its meaning.

---

## 3. Cultural Details

### Daily Life

Citizens of the Frozen Expanse (the few who remain) follow a rhythm of "remembering, preserving, and waiting for return." They are not idle — they maintain the Memorial Glades, tend to the Echoing Archive's outer chambers, and care for Frostkin companions — but their work is deeply contemplative.

A common greeting is "What do you hold?" — referring not to possessions, but to memories. The response is often not words but a gesture: touching a specific piece of jewelry, tasting a particular food, or humming a fragment of a song.

### Arts & Traditions

The realm's art form is **Memory-sculpting** — intricate ice-carvings that tell stories not through images but through texture and temperature. A skilled Memory-sculptor can create a piece that, when touched, evokes specific sensations associated with a memory — the warmth of a hearth, the sound of a loved one's footsteps, the taste of a childhood meal.

Festivals are tied to seasonal preservation cycles. The **Festival of First Frost** celebrates the moment each year when the realm's preservation magic is strongest. The **Remembrance Night** (midwinter) involves a communal ceremony where everyone shares one memory they wish to carry forward into the new season.

### Notable Citizens

- **Glacia the Keeper** — A Borealis Chronicler who has maintained the Memorial Glades for over a century. Speaks primarily through written notes and symbolic gestures. Her own memory is fading, making her work both more urgent and more poignant.
- **Whisper-of-Snow** (Frostkin)** — A companion who can "read" memories embedded in ice formations. Willing to help visitors, but communication is slow and often unclear.
- **The Archive Curator** (non-human)** — An ancient ice-elemental presence known as **Nix** who has lived in the Echoing Archive since its creation. Protective of memories but sometimes confused about which ones are important.

---

## 4. Memory Themes

The Frozen Expanse is aligned with the **Wound of Memory — Forgetting**. This is not just the loss of facts or events, but the fading of the emotional connections that made memories meaningful.

### What the Frozen Expanse Reveals About the Wound:

- **Memory Requires Context** — A preserved fact without its emotional or relational context becomes a museum piece, not a living part of identity.
- **Forgetting is Not Always Loss** — Sometimes, letting go of painful or irrelevant memories is necessary for growth. The Wound of Memory is as much about **clutter** as it is about absence.
- **Restoration is Not Return** — The goal is not to regain the exact memories of the First Harmony, but to develop healthy relationships with remembering and forgetting.

---

## 5. Puzzle Integration Points

### Memory Puzzles (Echo Sequence)

These are the most natural puzzles for the Frozen Expanse. They may involve:

- **Memory Sequence Reconstruction** — Rebuilding a fragmented memory from scattered sensory impressions (sight, sound, taste, touch)
- **Temperature Logic** — Reading temperature clues to determine which ice formations hold which memories
- **Sensory Pattern Matching** — Matching a memory-fragment based on sensory cues (a specific scent, sound, or feeling)

### Memory Preservation Puzzles (Fragment Assembly)

The Echoing Archive contains numerous fragmented memories that need assembly:

- **Memory Fragment Assembly** — Combining scattered pieces of a single memory to restore its coherence
- **Context Reconstruction** — Finding the emotional or relational context that gives a memory meaning

---

## 6. Restoration Goals

The Frozen Expanse's restoration is not about recovering every lost memory, but about helping its citizens develop a **healthy relationship with remembering**. This means:

1. **Reactivating the Memorial Glades** — Not preserving everything, but curating what is most meaningful to pass forward.
2. **Restoring the Echoing Archive's Function** — Making it not just a storehouse but a **living memory environment** where memories can be experienced, understood, and shared.
3. **Hosting the First Post-Shattering Memory Convocation** — A gathering where citizens and companions share new memories, acknowledging that restoration includes making new meaningful moments.

---

## 7. Mystery Hooks (Open, Not Resolved)

- **The Vanishing Chronicler** — A senior Borealis Chronicler who disappeared during a memory-retrieval expedition. Their last journal entry was "The memories are not what we thought they were."
- **The Living Memory** — A memory fragment discovered in the Archive that seems to respond to visitors — changing based on who experiences it. Is it a preserved personality, or something else?
- **The Thawing Heart** — A central location in the realm that is slowly melting, revealing something that was buried long ago. What will emerge, and should it?

---

## 8. Companion Connections

- **Frostpaw** (Frostkin Family) — Deeply connected to this realm's preservation systems, but struggling with their own memory fragments
- **Echo** (Memory-themed Companion) — Naturally aligned; can perceive memory layers others miss
- **Verdant** — Finds the realm's stillness peaceful but worries about its lack of growth
- **Spark** — Fascinated by the sensory aspects of memory; finds the Echoing Archive "overwhelming but incredible"
- **Nimbus** — Feels the memories in the wind currents but finds them "dense like snow" — hard to navigate

---

## Files Updated / Referenced

- `asset-registry.md` — Frozen Expanse environment art Tag updated to reflect this draft
- `imp-02-five-wounds-restoration-model.md` — Section on Memory Wound + Realm integration
- `puzzle-catalog.md` — Echo Sequence and Fragment Assembly puzzle types contextualized for Frozen Expanse
- `tier-roadmap-tracker.md` — Frozen Expanse Realm Packet status: Draft Complete