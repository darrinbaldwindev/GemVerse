# Arena Hub-Zone Visual Notes Pack v1

**Project:** GemVerse  
**Mode:** GemVerse Art Studio  
**Scope:** High-level visual interpretation of Arena Realm hub zones for concept, environment, UI, and onboarding support  
**Status:** Production-safe working notes derived from current Space canon

---

## Purpose

This pack translates the Arena Realm's locked hub-zone list into practical high-level visual direction without inventing internal layouts, exact adjacencies, or detailed operating logic that still remain open.

It is intended to help teams keep every major Arena hub zone aligned with the Realm's core identity: a civic crossroads built around gathering, welcome, continuity, and shared life.

---

## Realm-wide hub rule

Every Arena hub zone should feel like part of a world where people are expected to arrive.

Even when a zone is quieter than it once was, it should still feel maintained, permeable, and socially legible.

No hub zone should drift into combat-space logic, intimidation architecture, or spectacle-first staging.

---

## Harmony Plaza

### Primary read
Harmony Plaza is the social center of public gathering life.
It should feel like the most naturally shared space in the Realm.

### Visual character
- Open, breathable, and easy to cross from multiple directions.
- Built for mingling, pausing, listening, meeting, and informal assembly.
- A place where pathways, benches, low structures, and greenery support everyday civic interaction.

### Favor
- Layered public seating.
- Soft thresholds instead of hard gates.
- Flexible civic-use surfaces.
- Lanterns and planted elements that humanize scale.
- Signs of regular use rather than ceremonial perfection.

### Avoid
- Victory-plaza framing.
- Grand militarized symmetry.
- Empty ceremonial voids.
- Monumentality without social function.

---

## Great Archive

### Primary read
The Great Archive is a living record presence inside the Arena Realm, not a distant monument.
It should feel consequential, but reachable.

### Visual character
- Record-rich, memory-bearing, and quietly active.
- Less austere than a fortress of knowledge; more like a place where memory is still being held in trust.
- Capable of containing uncertainty, incompleteness, and discovery without feeling broken.

### Favor
- Alcoves, shelves, tablets, records, or storage forms integrated into civic architecture.
- Light that suggests attention and preservation.
- Thresholds that invite careful entry rather than forbid approach.
- A visual link to the first puzzle's incomplete record.

### Avoid
- Over-sealed sacred-vault reads.
- Cold academic detachment.
- Threat-coded mystery framing.
- Tutorial-room simplicity that reduces the Archive to a game mechanic.

---

## House Districts

### Primary read
The House Districts are the civic backbone of Arena life.
They should suggest plural presence within a shared Realm, not factional separation or territorial competition.

### Visual character
- Distinctive enough to imply different traditions.
- Cohesive enough to still belong to one shared civic whole.
- More neighborly than political.

### Favor
- Variations in material expression, ornament, color accents, and local civic habits.
- Shared routes and connective tissue between districts.
- Signs that district identity coexists with Realm identity.

### Avoid
- Fortress enclaves.
- Border logic.
- Rival-house staging.
- Anything that makes the Districts feel like competing camps.

---

## Companion Grove

### Primary read
The Companion Grove is a relational, witness-rich zone where non-human life and memory have visible presence.
It should feel quieter than the Plaza, but not disconnected from Arena's civic identity.

### Visual character
- Gentle, observant, and alive.
- A place where the Realm breathes differently.
- More listening space than performance space.

### Favor
- Organic forms, sheltered pockets, layered plant life, and soft pathways.
- Perches, edges, resting places, and subtle signs of repeated Companion presence.
- A mood of quiet exchange rather than spectacle.

### Avoid
- Pet-park framing.
- Cute-only treatment that strips depth or witness.
- Overdesigned habitat logic that makes Companions feel managed rather than present.

---

## Festival Grounds

### Primary read
The Festival Grounds are a place still prepared for gathering.
They should feel capable of joy without requiring full historical scale to feel meaningful.

### Visual character
- Flexible, open, and seasonally adaptable.
- Marked by memory, but not stuck in nostalgia.
- Ready rather than abandoned.

### Favor
- Reusable setup points, hanging-light logic, communal layouts, and maintained open space.
- Signs of scalable celebration.
- Soft festive cues that work even at smaller attendance.

### Avoid
- Tournament venue logic.
- Winner-stage emphasis.
- Empty spectacle architecture.
- Decayed-event-ground sadness as the dominant mood.

---

## Guardian Hall

### Primary read
Guardian Hall should feel like a place of orientation, contribution, and preparation, not heroic elevation.

### Visual character
- Welcoming, functional, and grounded.
- A place where Guardians are received into responsibility, not glorified as saviors.
- Aligned with belonging and contribution over destiny.

### Favor
- Human scale within larger civic context.
- Clear wayfinding and calm spatial logic.
- Work surfaces, records, maps, and preparation cues.
- Architecture that says “you can begin here.”

### Avoid
- Hall of champions framing.
- Hero memorial aesthetics.
- Chosen-one symbolism.
- Statues or layouts that imply worship, victory, or elite separation.

---

## Marketplace

### Primary read
The Marketplace is the crossroads made everyday.
It should show that Arena's civilizational role continues through ordinary exchange as much as major gatherings.

### Visual character
- Active, local, and connected.
- Lived-in without becoming chaotic.
- A place where movement, trade, and conversation naturally overlap.

### Favor
- Mixed goods, varied stalls, layered pathways, and civic-use edges.
- Signs of cross-Realm memory even when present-day trade is more local.
- Social warmth and recurring familiarity.

### Avoid
- Bazaar-as-spectacle excess.
- Aggressive commercialism.
- Crowding that erases the Realm's calm welcome.
- Purely decorative market dressing with no social readability.

---

## Lantern Tower

### Primary read
Lantern Tower is vertical guidance, not vertical dominance.
It should feel like a visible promise of continuity and orientation.

### Visual character
- Steady, watchful in the gentle sense, and connective.
- More beacon than monument.
- A place associated with guidance, signal, and long memory.

### Favor
- Warm light visible across distance.
- Clear silhouette that communicates finding one's way.
- Architectural restraint that supports trust rather than awe alone.

### Avoid
- Surveillance-tower framing.
- Power-spire dominance.
- Defensive tower reads.
- Harsh, cold light logic.

---

## Cross-zone consistency

To keep the Arena Realm feeling unified, all hub zones should share:

- organic integration between built and natural elements
- visible maintenance and care
- permeability and social legibility
- warmth before grandeur
- traces of fuller past use without hopeless emptiness
- civic welcome as the default emotional read

---

## Quick review checklist

Before approving a hub-zone concept, ask:

- Does this zone feel socially understandable at a glance?
- Does it belong to the same Realm as the Lantern Site and Gathering Hall?
- Is the mood civic, welcoming, and lived-in rather than combative or theatrical?
- Does this zone support the idea that civilization remembers itself by gathering?
- Would a player read this as a place to enter and belong, or as a place to conquer or perform in?

If the second reading is stronger, the asset needs reframe.

---

## Best immediate uses

This pack is ready to support:
- hub concept art briefs
- environment blockout review
- UI map zone labels and thumbnails
- onboarding path planning
- Arena mood-board cleanup
- internal art-direction alignment across multiple vendors or assistants

For broader Arena direction, pair this file with the Arena Realm production brief, the Arena visual framing notes, the onboarding/environment notes, and the festival notes.
