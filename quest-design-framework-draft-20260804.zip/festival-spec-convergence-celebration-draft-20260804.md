# Festival Specification — Convergence Celebration
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 4 Entry:** 4.01  
**Linked Files:** `01-canon-map.md`, `realm-packet-arena-realm-draft-20260804.md`, `imp-03-citizen-life-layer-draft-20260804.md`, `puzzle-catalog.md`

---

## Overview

**Name:** Convergence Celebration  
**Theme:** Collective Restoration Achievement  
**Duration:** 3 days (long weekend)  
**Realm Focus:** Arena Realm (primary), all accessible Realms (participatory)  
**Visual Identity:** Streams of light converging from all directions, collaborative art installations, shared project displays  
**Symbol:** Interwoven light streams forming a central glow (representing collective effort creating shared results)  
**Key Activities:** Community restoration showcase, collaborative art creation, collective storytelling, shared feast preparation

---

## 1. Festival Essence

The Convergence Celebration is the Restoration Era's premier festival of collective achievement — a time when the civilization pauses to recognize not individual accomplishments, but the collaborative work that makes restoration possible.

In the First Harmony, the Convergence Celebration marked the completion of major cross-Realm projects — the restoration of a significant Crystal Network route, the reactivation of a major Lantern Network site, the completion of a multi-generational Archive project. These were not competitive achievements but collaborative ones, requiring the coordinated effort of communities across multiple Realms.

The festival embodies Belonging not as passive inclusion, but as **active contribution to shared work**. Its focus is on what we accomplished together, not what any individual achieved alone.

---

## 2. Restoration Era Adaptation

In the Restoration Era, the Convergence Celebration has taken on new meaning. With cross-Realm coordination more challenging, the festival now focuses on celebrating the small, daily acts of collaboration that maintain community even when grand projects are not possible.

### Current Practice:
- **Local Community Showcases**: Each community displays their collaborative projects from the past year
- **Restoration Milestone Recognition**: Celebrating even small restoration achievements as community victories
- **Cross-Community Storytelling**: Citizens from different neighborhoods sharing their restoration experiences
- **Collaborative Art Projects**: Creating shared installations that represent community values
- **Shared Feast Preparation**: Multi-community meals that require coordinated effort to prepare

### Companion Participation:
- **Bloomtail**: Facilitates collaborative art projects, ensures all community voices are included
- **Spark**: Energizes community participation, helps overcome social barriers to collaboration
- **Echo**: Preserves the stories of collaborative efforts for future communities
- **Galewing**: Coordinates cross-community communication and shared project planning

---

## 3. Festival Activities

### Community Restoration Showcase
Each community prepares a display of their collaborative restoration work:
- **Project Documentation**: Visual presentations of community efforts (restored routes, Archive contributions, environmental improvements)
- **Before/After Displays**: Showing the transformation achieved through collective effort
- **Contribution Wall**: Citizen testimonials about their role in community projects
- **Future Vision Boards**: Collaborative drawings of what the community hopes to achieve next

### Collaborative Art Creation
Large-scale art projects that require multiple contributors:
- **Community Murals**: Sections contributed by different neighborhoods, forming a unified whole
- **Story Quilts**: Textile projects where each square tells part of a community story
- **Living Installations**: Garden designs that require coordinated tending by multiple citizens
- **Sound Sculptures**: Musical compositions built from contributions by different community members

### Collective Storytelling
Structured sharing of community restoration experiences:
- **Story Circles**: Small groups sharing personal restoration stories
- **Community Narrators**: Citizens trained to weave individual stories into collective narratives
- **Timeline Construction**: Creating visual timelines of community restoration efforts
- **Wisdom Harvesting**: Identifying lessons learned from collaborative challenges

### Shared Feast Preparation
Meals prepared through coordinated community effort:
- **Ingredient Gathering**: Citizens contributing different elements (garden harvests, traded goods, preserved stores)
- **Preparation Stations**: Different cooking tasks managed by different community groups
- **Recipe Creation**: Collaborative development of new dishes that represent community fusion
- **Feast Coordination**: Ensuring all dietary needs and preferences are accommodated

---

## 4. Companion Involvement

### Bloomtail — Collaborative Art Facilitator
- **Inclusive Design**: Ensures collaborative art projects include all community voices
- **Growth Visualization**: Creates living installations that show community growth over time
- **Pattern Recognition**: Helps citizens see connections between individual contributions and collective results
- **Harmony Maintenance**: Keeps collaborative projects balanced and positive

### Spark — Community Energizer
- **Participation Catalyst**: Encourages citizens who might otherwise stay on the sidelines
- **Enthusiasm Coordinator**: Maintains energy levels throughout multi-day collaborative projects
- **Barrier Breaker**: Helps overcome social divisions that might prevent collaboration
- **Celebration Planner**: Organizes moments of recognition throughout collaborative efforts

### Echo — Collective Memory Keeper
- **Story Recording**: Captures community storytelling sessions for future reference
- **Pattern Preservation**: Documents collaborative processes that worked well
- **Historical Context**: Provides background on similar community efforts from the past
- **Memory Sharing**: Helps distant communities learn from each other's collaborative experiences

### Galewing — Cross-Community Coordinator
- **Communication Facilitation**: Ensures different community groups can share information effectively
- **Route Planning**: Organizes physical movement between different collaborative project sites
- **Resource Sharing**: Coordinates the exchange of materials between communities
- **Scheduling Harmony**: Keeps different community timelines aligned for cross-community projects

---

## 5. Puzzle Integration

### Community Pattern Puzzles
Collaborative puzzles that require multiple contributors:
- **Mural Assembly**: Large puzzles that form community murals when completed together
- **Story Sequence Alignment**: Puzzles that require arranging narrative fragments in consensus order
- **Feast Planning Coordination**: Logic puzzles that balance dietary needs, ingredient availability, and preparation time
- **Project Timeline Synchronization**: Puzzles that require coordinating multiple community efforts

### Archive Connection Puzzles
Puzzles that celebrate collaborative historical efforts:
- **Past Celebration Reconstruction**: Reassembling records of First Harmony Convergence Celebrations
- **Community Hero Integration**: Connecting historical collaborative achievements with current community efforts
- **Wisdom Fragment Synthesis**: Combining lessons from multiple communities' restoration experiences
- **Shared Heritage Recognition**: Puzzles that reveal commonalities between different communities' values

### Lantern Network Puzzles
Puzzles that facilitate cross-community connection:
- **Celebration Route Planning**: Designing Lantern-guided routes between different community celebration sites
- **Shared Light Configuration**: Coordinating Lantern Network activation to create festival-wide lighting effects
- **Cross-Community Invitation Design**: Puzzles that create appealing invitation systems for distant communities
- **Memory Wall Synchronization**: Ensuring community stories are shared across the Lantern Network

---

## 6. Visual & Audio Atmosphere

### Visual Elements
- **Convergence Streams**: Light effects that appear to flow from all community locations toward central celebration spaces
- **Collaborative Art Displays**: Large installations created through citizen contribution
- **Community Story Walls**: Interactive displays showing citizen restoration stories
- **Shared Feast Tables**: Large communal dining areas with collaborative seating arrangements
- **Restoration Progress Maps**: Visual displays showing community restoration achievements

### Audio Elements
- **Community Soundscapes**: Ambient audio created from recordings of different community locations
- **Collaborative Music Making**: Citizens contributing to evolving musical compositions
- **Storytelling Sessions**: Structured audio environments for community narrative sharing
- **Celebration Anthems**: Songs created through community collaboration during the festival
- **Harmony Tones**: Audio that adjusts based on community collaborative puzzle solving

---

## 7. Accessibility & Inclusion

### Physical Accessibility
- **Multiple Access Routes**: Ensuring all festival locations are accessible to citizens with mobility challenges
- **Flexible Seating**: Various seating options for different physical needs
- **Assistive Technology Integration**: Systems that help citizens with different abilities participate fully
- **Quiet Spaces**: Areas for citizens who need respite from festival energy

### Social Accessibility
- **Participation Flexibility**: Multiple ways to contribute, from large collaborative projects to quiet individual efforts
- **Communication Support**: Systems for citizens with different communication needs
- **Cultural Sensitivity**: Respect for different community traditions within the larger festival framework
- **Inclusion Facilitation**: Active systems to ensure no citizen feels excluded

### Cognitive Accessibility
- **Clear Process Guidance**: Simple, visual instructions for collaborative activities
- **Multiple Engagement Options**: Different complexity levels for festival activities
- **Pacing Considerations**: Activities structured to accommodate different energy levels
- **Support Systems**: Companion and citizen facilitators available for complex collaborative tasks

---

## 8. Festival Rewards (Cosmetic Only)

### Community Display Items
- **Collaborative Art Pieces**: Digital recreations of community-created festival art
- **Celebration Banners**: Visual representations of community restoration achievements
- **Story Quilt Patterns**: Cosmetic items inspired by community storytelling

### Personal Commemoratives
- **Participation Ribbons**: Visual indicators of citizen contribution to festival activities
- **Community Connection Medals**: Recognition of cross-community collaborative efforts
- **Restoration Milestone Markers**: Cosmetics that celebrate specific community achievements

### Companion Recognition
- **Collaboration Crowns**: Visual indicators when companions have facilitated successful collaborative projects
- **Community Hero Displays**: Companion cosmetics that reflect their role in community festivals
- **Story Keeper Symbols**: Visual recognition of companions who preserved community narratives

---

## Files Updated / Referenced

- `tier-roadmap-tracker.md` — Festival Encyclopedia status: 1/10 complete
- `asset-registry.md` — Convergence Celebration festival art tags pending
- `puzzle-catalog.md` — Community Pattern puzzle references updated