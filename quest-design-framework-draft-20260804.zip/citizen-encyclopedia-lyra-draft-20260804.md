# Citizen Encyclopedia Entry — Lyra
**Draft Date:** 2026-08-04  
**Status:** DRAFT COMPLETE - Ready for Creator Review  
**Tier 3 Entry:** 3.14  
**Linked Files:** `01-canon-map.md`, `imp-03-citizen-life-layer.md`, `imp-04-companion-relationship-web.md`, `realm-packet-sky-citadel-draft-20260804.md`

---

## Overview

**Name:** Lyra  
**Themes:** Exploration, Discovery, Mapping  
**Path Alignment:** Pathfinder Path (Discovery Pillar)  
**Visual Identity:** [Pending - Character art not yet available]  
**Symbol:** Telescope with Unfolding Map (representing discovery that expands understanding)  
**Notable Traits:** Visionary explorer, meticulous documentarian, natural connector of distant places

---

## 1. Background

Lyra was born in the Sky Citadel during a rare celestial alignment that the Astra House scholars still debate the significance of. Their parents were both Pathfinders - one a route mapper, the other a discovery chronicler - and Lyra grew up in a home where maps covered the walls and expedition stories were bedtime entertainment.

From an early age, Lyra showed an unusual approach to exploration. Where other young Pathfinders focused on the technical skills of navigation and documentation, Lyra was drawn to the *meaning* of discovery. They asked questions like: "Why does finding this new path matter to the people who will walk it?" and "How does this discovery change what we understand about ourselves?"

This philosophical approach sometimes frustrated their more practically-minded instructors. But a senior Pathfinder recognized that Lyra's questioning wasn't resistance - it was a different kind of rigor. They mentored Lyra in developing an exploration methodology that integrated technical excellence with civilizational purpose: routes that serve communities, documentation that preserves meaning, discoveries that expand belonging.

Lyra's defining early achievement came when they were part of an expedition to map a newly accessible region of the Sky Citadel. While others focused on the technical mapping, Lyra documented the *stories* of the wind currents - how they had guided travelers for generations, what the local Skykin companions remembered about them, what the archive fragments suggested about their historical significance. This approach revealed that the "new" region was actually an ancient pathway system that had been deliberately maintained by previous generations.

---

## 2. Role in Society

Lyra serves as a **Realm Explorer and Discovery Chronicler** for the Sky Citadel, working at the intersection of active exploration and the preservation of exploration's civilizational meaning. Their role involves:

- **Exploration Design**: Planning expeditions that serve both discovery and community needs
- **Discovery Documentation**: Recording findings in ways that preserve their significance for future generations
- **Cross-Realm Connection**: Ensuring that new routes and discoveries strengthen relationships between Realms
- **Pathfinder Mentorship**: Teaching the next generation to explore with purpose, not just skill

Lyra is particularly valued for their ability to bridge the technical and meaningful dimensions of exploration. When a new route is discovered, Lyra doesn't just map it - they document who it connects, what it enables, what communities it serves, and what stories it carries.

They also serve as a bridge between the Sky Citadel's exploration community and the broader civilizational project. When Archive scholars want to understand what's being discovered in remote regions, Lyra provides context that transforms raw data into civilizational knowledge. When community leaders in other Realms want to understand what new connections might mean for them, Lyra helps translate exploration findings into practical possibilities.

---

## 3. Relationships

### Companion Connections

Lyra has developed particularly strong relationships with several companions:

- **Nimbus**: Primary exploration partner and close friend. They've worked together since Lyra's early expeditions. Nimbus provides the wind-reading; Lyra provides the methodological framework and civilizational context.
- **Galewing**: Collaborates on large-scale exploration coordination. Galewing's path-singing creates the infrastructure; Lyra designs the expeditions that use it meaningfully.
- **Taren**: Professional peer and philosophical partner. They often debate the ethics and purpose of exploration, pushing each other toward deeper understanding.
- **Echo**: Works with Echo to preserve the oral histories and companion memories that give exploration routes their depth and meaning.

### Citizen Relationships

- **Mentor**: The senior Pathfinder who taught Lyra to ask "why" alongside "how"
- **Peers**: Other Pathfinder Path practitioners, including Taren, who share methodological and philosophical discussions
- **Expedition Teams**: Citizens from multiple Realms who participate in Lyra's collaborative exploration projects
- **Archive Scholars**: Researchers who rely on Lyra's contextual documentation for their work

### Institutional Relationships

- **Astra House Council**: Advisor on exploration priorities and methodologies
- **Archive Discovery Documentation Division**: Primary contributor of contextual discovery records
- **Inter-Realm Exploration Coordination Committee**: Represents the Sky Citadel's exploration perspective
- **Pathfinder Guild Training Council**: Curriculum developer for purpose-driven exploration training

---

## 4. Personal Goal

Lyra's current personal goal is to develop a **Meaningful Discovery Framework** - an approach to exploration that ensures every new finding serves civilizational connection rather than just expanding the map.

This involves:
- Developing "significance assessment" criteria for new discoveries that consider civilizational impact
- Creating "community partnership" models for exploration in or near inhabited areas
- Building "discovery narrative" standards that preserve the human meaning alongside technical data
- Establishing "exploration ethics" that prioritize relationship over achievement

They're working on this with Pathfinder elders, Archive scholars, community leaders from multiple Realms, and companions who embody different aspects of the exploration spirit.

---

## 5. Contribution Story

Lyra's most significant contribution came during a period when the Sky Citadel was considering a major expansion of its exploration program - sending multiple simultaneous expeditions to map previously inaccessible regions.

The traditional approach would have been to optimize for coverage: send the most skilled explorers to the most distant regions, map as much territory as possible, document findings for the Archive. Lyra proposed a radically different approach: **Community-Embedded Exploration**.

Instead of sending elite teams to distant regions, Lyra organized expeditions that embedded citizens from the destination Realms as full partners from the beginning. Each expedition included:
- **Local Knowledge Holders**: Citizens who knew the region's stories, seasonal patterns, community needs
- **Technical Explorers**: Pathfinders providing navigation and documentation skills
- **Companion Partners**: Skykin, Nimbus, Galewing providing their unique capabilities
- **Archive Liaisons**: Scholars ensuring discoveries were documented with full civilizational context

The results transformed the exploration program:
- Expeditions discovered not just geography, but the *civilizational significance* of what they found
- Communities in destination regions became active participants rather than passive subjects
- Discovered routes were immediately useful because they were designed with community needs in mind
- The exploration program became a civilizational connection project rather than a mapping project

This contribution demonstrated that exploration's greatest value isn't the territory it covers, but the connections it creates and the understanding it deepens.

---

## 6. Legacy Story

Lyra's **Meaningful Discovery Framework** is reshaping how the Sky Citadel and other Realms approach exploration. The shift from "mapping territory" to "deepening connection" represents a profound philosophical realignment.

Archive scholars have documented Lyra's approach as a crucial evolution in civilizational exploration - one that directly addresses the Wound of Discovery by ensuring that new knowledge serves belonging rather than isolation.

Lyra hopes their legacy will be a civilization where every expedition asks not "what is there?" but "who will this connect, and how will it help them belong to each other?" They see exploration not as pushing boundaries outward, but as weaving connections inward - discovering not new places, but new ways of being connected.

---

## Citizen Abilities (Narrative, Not Mechanical)

- **Exploration Philosophy**: Understands discovery as civilizational service, not personal achievement
- **Significance Assessment**: Can identify the civilizational meaning of new findings
- **Community-Embedded Methodology**: Designs exploration that serves and involves local communities
- **Narrative Documentation**: Preserves the human story alongside technical data
- **Mentorship Integration**: Teaches both technical skills and the deeper purpose of exploration

---