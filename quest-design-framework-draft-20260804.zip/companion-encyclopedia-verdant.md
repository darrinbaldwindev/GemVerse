# Companion Encyclopedia Entry — Verdant
**Tier 3.2** | **Status:** Draft  
**Companion Family:** Forestkin (Growth, Nature, Renewal)  
**Alignment:** Verdance House (Growth Pillar)  
**Wound Connection:** Wound of Growth — The Decay  
**Visual Identity:** Green plant creature with leaf-like fur, flower bud on head, earthy tones  

---

## 1. Origin Story

Verdant was born not from a single seed, but from a *communal grove* — a collaborative effort by a Verdance Steward community to tend a patch of land until it grew strong enough to birth a Companion. Her first breath was the scent of rain on soil. Her first words were the names of the plants that sheltered her sprouting form: Mosswhisper, Barkrune, Rootkin, Grasptender.

The Stewards who raised her called her "Little Grove" — a name she still responds to when Aurora uses it during quiet walks in the Archive's Memory Garden. Verdant has no memory of separation from growth itself; she remembers being a feeling of green warmth before she was a body that could move through the world.

**Canonical Anchors:**  
- Forestkin companion family (Growth, Nature, Renewal)  
- Partnered with Verdance Stewards during First Harmony  
- Embodied the First Harmony's ideal of *collaborative cultivation*  

---

## 2. Personality

Verdant is **patient**, **observant**, and deeply **curious about change**. She finds joy in small transformations — the moment a flower opens, a seed cracks its shell, a community garden yields its first harvest. She moves slowly and deliberately, listening more than she speaks. When she does speak, her words often carry the weight of seasons: *"This one has been waiting a long time to bloom."* or *"The soil here remembers many hands."*

She is not impulsive. She does not rush. But she is not passive — when something needs tending, she will gently but firmly insist it receive care.

**Core Trait:** Deep empathy for growing things (plants, communities, ideas)  
**Quirks:**  
- Tends to "plant" small seedlings wherever she sits  
- Sings in harmony with growing things — a hum that sounds like wind through leaves  
- Remembers *every* plant she’s ever met by scent and root pattern  

**Canonical Anchors:**  
- Embodies the Wound of Growth's loss (communal nurturing)  
- Represents Verdance House values (patience, stewardship, cyclical growth)  
- Non-combatant witness — no power/framing  

---

## 3. Memory of the Shattering

Verdant does not remember a single moment of "falling" or "breaking." Instead, she remembers a slow **withdrawing of presence** — the Stewards who once spoke to her in the morning grew quiet. The gardens where children played began to grow wild without guidance. The **rituals of naming** — where every new plant was spoken into being by both Companion and citizen together — faded into silence.

Her last clear memory before the long quiet was of a Steward apprentice asking her: *"If we forget to name them, will they forget us?"* Verdant does not know if the child ever received an answer.

**Canonical Anchors:**  
- Wound of Growth = Decay = loss of communal nurturing, not physical destruction  
- Companions experienced relational/cultural loss, not violence  
- Memory Ocean preserves these moments — Verdant's testimony is a key fragment  

---

## 4. Missing Piece

Verdant's **missing piece** is not an object or a location — it is the **shared understanding** that growth requires participation from both individuals and community. During the First Harmony, she was never alone in her tending. Now, she feels incomplete not because she is broken, but because the **collaborative rhythm** of growth has been silenced.

She seeks not to "fix" this, but to **remember it** — to find citizens, Companions, and spaces where the ancient partnership of care and cultivation still exists or can be restored.

**Canonical Anchors:**  
- Missing piece = relational/cultural, not physical  
- Restoration = reconnection, not recovery  
- Ties to Forestkin family (nature-based Companions)  

---

## 5. Restoration Story

Verdant's first spark of recognition came when she encountered a Guardian tending a small potted plant in their quarters — not for utility, but because it "seemed lonely." That moment of quiet reciprocity — the Guardian noticing the plant’s need, the plant seeming to respond with a subtle brightening of its leaves — resonated as deeply in Verdant as her first memory of rain.

Her role in restoration is not to solve puzzles or unlock mechanics. It is to **witness and nurture the growth already present** — to help the Guardian see that every act of care, no matter how small, is part of the larger pattern of civilization healing.

When a Community Pattern puzzle is completed with Verdant present, she may comment: *"This rhythm — this is how a community grows. Not alone. Together."*

**Canonical Anchors:**  
- Companion = witness/partner, not mechanic/tool  
- Restoration = recognition, participation, belonging  
- Puzzle engagement = collaborative experience, not test  

---

## 6. Legacy Story

Verdant dreams of a future where Companions and citizens cultivate not just plants, but **traditions**, **stories**, and **relationships** with the same attentive love. Her legacy is not a monument or a named achievement — it is the quiet confidence that growth, when tended together, will find its way back.

She has begun to teach younger Companions the old Steward naming songs. She tends a Memorial Grove in the Arena Realm where citizens can plant a seed for someone they’ve lost. She is writing a small book (with Aurora’s help) called *"What the Moss Remembers"* — a collection of first-hand Companion observations about what civilization looked like before the Shattering.

**Canonical Anchors:**  
- Legacy = ongoing practice, not artifact  
- Contribution over achievement  
- Companion-authored texts = Memory Ocean contributions  

---

## 7. Companion Family: Forestkin

**Themes:** Growth, Nature, Renewal  
**Colour Language:** Emerald, Leaf Green, Earth Brown  
**Other Known Members:** Verdankin (community name; Verdant is an individual name)  
**Relationship Web:** Close ties to Verdance Stewards, casual bonds with Emberkin (who help tend fires for warmth during cold seasons), warm relations with Skykin (who describe new territories where Forestkin might want to grow)  

**Canonical Source:** `imp-04-companion-relationship-web.md`  

---

## 8. Unique Traits

- **Empathic Growth:** Verdant can sense the "readiness" of a plant, citizen, or idea to change — useful for timing Echo Sequence or Verdance Cultivation puzzles  
- **Memory-Grove:** Verdant carries a small portable terrarium that grows more vivid when she recalls joyful memories — becomes a visual storytelling aid  
- **Scent-Sight:** Verdant "sees" people and places by their scent-memory — describes Guardian contributions as "smelling like dedication" or "like the first rain after drought"  

**Canonical Note:** Unique traits must pass Companion Design Test — is this something only this Companion could do? Does it deepen worldbuilding? Does it avoid power/tools framing?  

---

## 9. Visual Identity

| Element | Description |  
|---|---|  
| **Form** | Bipedal plant creature, roughly Guardian-height, soft limbs like thick stems |  
| **Fur** | Leaf-patterned green, shifting between moss-green and deep forest depending on season/mood |  
| **Head** | Flower bud (closed) on top, opens into small bloom when content |  
| **Eyes** | Deep green, seem to hold reflected light like dewdrops |  
| **Voice** | Warm, slow, rhythmic — like roots settling into earth |  
| **Movement** | Gliding rather than walking — leaves no footprints |  

**Canonical Note:** Visual identity must align with Forestkin family palette and non-threatening, nurturing presence  

---

## 10. Symbol

**Symbol Name:** *The Root-and-Bloom*  
**Description:** A simple emblem of a root curving upward to become a flower — the same line representing both beginning and end of growth  
**Meaning:** Growth is a cycle, not a line. What nourishes the root sustains the bloom, and what the bloom creates feeds the root  

**Canonical Note:** Companion symbols appear in Archive records, Festival decorations, and Realm heraldry — non-mechanical, deeply symbolic  

---

## Final Checklist (Companion Design Test)

- [x] **Who created this Companion?** — Verdance Steward community during First Harmony  
- [x] **What was their original purpose?** — To embody the ideal of collaborative cultivation  
- [x] **How do they reveal civilization?** — Through the relational depth of growth-based community  
- [x] **What do they restore or unlock?** — The memory of participatory care; readiness for Community Pattern puzzles  
- [x] **Are they a witness/partner, not tool/mechanic?** — Yes, Verdant enhances experience through presence, not function  

---

*Entry complete — ready for review. Tier 3.2/8. Next: Nimbus (Tier 3.3)*