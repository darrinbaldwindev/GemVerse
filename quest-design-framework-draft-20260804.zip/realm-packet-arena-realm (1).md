---
title: Realm Packet — Arena Realm
tier: Work Queue Task 6
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: Restoration Era (Tier 1), Kael Conflict 3 Resolution (locked Option A)
feeds-into: Tier 2 Realm Cultures, Tier 2 Realm Histories, Tier 3 Citizen Encyclopedia
---

# Realm Packet — Arena Realm

---

## 1. Known Canon Summary

The following is confirmed locked canon for the Arena Realm. Nothing below is proposal. These items may be written from directly in Tier 2 and Tier 3 documents without additional creator confirmation.

**Identity**
- The Arena Realm's name refers to its function as the civic centre of civilization — the great gathering place of the world. "Arena" means assembly, convergence, shared presence. It has never meant combat, contest, or dominance. This framing is non-negotiable and must be maintained in all future writing.
- The Arena Realm's theme is **Community** (confirmed in Canon Map).
- It is the most connected of the eight Realms and serves as the crossroads and hub of civilization — both during the First Harmony and into the Restoration Era.
- It is the **canonical first Realm** a Guardian encounters. It is the entry point.

**Kael — Locked (Conflict 3, Option A)**
- Kael's title is **Arena Champion** — a civic honorific awarded for extraordinary contribution to the Arena Realm's community, not for martial achievement of any kind.
- Kael is brave, determined, and adventurous — qualities expressed in civic engagement, not combat.
- The Art Bible description of Kael as someone who "helps you defeat the Arena Realm" is a **canon risk** and must not be used. Kael does not fight. There is no Arena to defeat.

**Physical State — Restoration Era**
- The Arena Realm civic gathering hall still stands.
- Some Crystal Network nodes within the Arena Realm are dormant.
- The Realm is quieter than it was during the First Harmony, but still active — more so than most other Realms.
- Kael is present in the Realm during the Restoration Era.

**Guardian Entry Point**
- Guardians arrive at a small, still-burning Lantern site.
- A Keeper greets them.
- The Archive has a record waiting — but it is incomplete.
- The first puzzle is always: *"What was here before?"*
- This is not a chosen-one moment. The Guardian is not special for being here. They are here, and that is enough.

**Confirmed Hub Zones (8 canonical, all locked)**
Harmony Plaza, Great Archive, House Districts, Companion Grove, Festival Grounds, Guardian Hall, Marketplace, Lantern Tower. Internal layouts and operational details are not yet established.

**Visual Art (transferred)**
- Arena Realm environment concept art has been transferred — described as lush and organic in feel.
- The isometric realm map includes the Arena Realm.
- Kael's full body character art has been transferred (reframing pending, art itself is stable).

---

## 2. Realm Identity

The Arena Realm is built around a single, irreducible idea: **that gathering together is itself an act of civilization**. Not gathering to decide something, or to celebrate something, or to solve something — though it does all of these — but gathering as a statement. We are still here. We still choose each other.

Its relationship to the Seven Pillars places it most naturally in the domain of **Community**, the Pillar that governs genuine interdependence. But the Arena Realm is not aligned to Community alone. Its function during the First Harmony was to be the place where all seven Pillars came into contact — where scholars met explorers, where Chroniclers shared records with Mentors, where the Harmony Council convened, where ordinary citizens from the Crystal Forest or the Frozen Expanse arrived to find that civilization was larger than their corner of it.

In this way, the Arena Realm belongs to all seven Pillars and fully inhabits only one: it is the Realm most shaped by **Belonging** — the hidden Eighth Pillar that has no House, no visible metric, and no single contribution that heals it. The Arena Realm is where Belonging was most legible during the First Harmony. A citizen who had never left their home Realm and arrived at the Arena for the first time experienced something they could not fully name: the recognition that the world was large, and they were part of it, and that mattered.

[PROPOSAL — awaiting creator confirmation: The Arena Realm's primary Wound is the **Wound of Belonging — the Division**. A Realm built around gathering is most deeply wounded when people stop gathering. The civic hall still stands; the Festival Grounds are not ruined. But the fullness of what the Arena Realm once held — every Realm represented, every Path present, the whole civilizational body choosing to be in one place — that is what was lost. The physical infrastructure survived the Shattering more intact than most Realms. The social infrastructure is what thinned. Flag for creator confirmation before use in Tier 2.]

The Arena Realm also carries traces of the other Wounds. The Crystal Network nodes in the Realm are partially dormant — a mark of the Wound of Knowledge. The routes that once brought travelers from distant Realms are only partially restored — echoes of the Wound of Discovery. But the Arena Realm is further along in healing than most: its gathering hall stands, its Lantern burns, its Keeper is present, and Kael holds the community together with the particular steadiness of someone who has decided that this place will not go quiet.

---

## 3. The Civic Tradition

During the First Harmony, the Arena Realm was the place civilization chose when it needed to be reminded of itself.

The First Harmony document confirms that the Arena Realm "served as the primary meeting ground — the place where delegates, travelers, scholars, and ordinary citizens from every Realm converged." It was the crossroads of the world before the Shattering, and it earned that role not through power or position but through deliberate, sustained cultivation of welcome.

[PROPOSAL — awaiting creator confirmation: The Arena Realm hosted the great cross-Realm civic assemblies — gatherings that were neither government nor festival, but something in between. They were the moments when Houses spoke to each other through the people who lived in their Realms, not only through official representatives. The Arena Realm's neutrality was considered its most important civic quality. No House could claim it. No Realm could dominate it. It belonged, in principle, to every citizen of civilization equally. The phrase that likely appeared above its entrance — *"All roads home pass through here"* — may have been a literal description before it became a sentiment. Flag as proposal; the specific phrase requires creator sign-off.]

[PROPOSAL — awaiting creator confirmation: The Festival Grounds in the Arena Realm hosted the three or four largest annual festivals across the First Harmony — including the Harmony Week and the Festival of Beginnings, both of which are confirmed festival names. These were not local celebrations. They were the festivals that citizens from other Realms traveled to attend. The civic act of attending a festival in another Realm — described in the First Harmony document as "choosing to know people you didn't have to know" — would have been most legible at the Arena Realm, where more of those people were gathered than anywhere else. Flag for creator confirmation.]

The civic culture of the Arena Realm during the First Harmony would have been defined by hospitality as a civic value — not mere courtesy, but the active practice of making space for people who were different from you, who knew different things, who had come from somewhere else and needed to feel that their presence was expected. This is consistent with the Community Pillar and with Belonging as an ambient civilizational condition.

The Arena Realm would also have maintained its own Archive outpost — closely tied to the Great Archive but also serving as a point of first contact for travelers arriving with records to contribute. The knowledge that passed through the Arena Realm during the First Harmony, flowing in and out from every direction, would have been civilizationally significant in ways that are still being rediscovered in the Restoration Era.

---

## 4. The Physical Realm

The concept art describes the Arena Realm as **lush and organic in feel** — living, green, grown rather than built. This is the visual foundation. The Arena Realm is not a city in stone. It is a Realm where architecture and landscape have grown together over centuries of care.

[PROPOSAL — awaiting creator confirmation: The following locations are proposed as the primary physical geography of the Arena Realm in the Restoration Era. All are flagged; none are locked without creator review.]

**The Great Gathering Hall** — The civic center of the Arena Realm, and by extension the civic center of the known world during the First Harmony. It still stands in the Restoration Era. Its scale suggests it was built for full civilizational attendance — it feels quiet now with only the Arena Realm's current population inside it. Its architecture incorporates Archive alcoves (consistent with First Harmony building philosophy), several dormant Crystal Network connection points, and Lantern housing at every entrance. The Hall is the physical embodiment of what the Arena Realm represents: a space that assumed people would come.

**Harmony Plaza** — The open-air gathering space at the heart of the Realm. Locked as a canonical hub zone. During the First Harmony, this was where the informal civic life of the Realm happened between the organized assemblies — markets, impromptu conversations, Companion gatherings, children learning from travelers. In the Restoration Era it is quieter but not abandoned. Some of the original paving remains; some has been reclaimed by moss and root.

**The Lantern Site (Guardian Entry Point)** — A small, still-burning Lantern at the edge of the Arena Realm where Guardians first arrive. The fire is real. Someone keeps it lit. The Keeper who greets arriving Guardians here is the first voice they hear in GemVerse. The Lantern Site is not grand. It is intimate — a single light, a single person, a welcome without ceremony.

**The Great Archive (Hub Zone)** — The Archive presence within the Arena Realm is one of the most significant surviving Archive installations. It holds records from before the Shattering alongside the incomplete records that prompted the first puzzle: *"What was here before?"* The Archive outpost here has a record waiting for each arriving Guardian — incomplete, puzzling, and genuinely uncertain. It is not a tutorial. It is an open question.

**The Festival Grounds** — A locked canonical hub zone. In the Restoration Era, the Festival Grounds are used but not full — they accommodate the festivals that still happen, and they carry the memory of festivals that no longer do. Old setup points remain from gatherings that were never struck because no one quite finished dismantling them before the drift set in.

**The Companion Grove** — A locked canonical hub zone. The First Harmony document confirms the Companion Grove is "a survival — or a reconstruction — of a much larger network of Companion gathering places." In the Arena Realm, the Grove is one of the few places where Companions of different families convene without human direction. What they do there, what they remember, and what they keep among themselves is not fully known.

**Dormant Crystal Network Nodes** — Several nodes exist in the Arena Realm, confirmed partially dormant. Their locations are not yet specified. Some are embedded in the Great Gathering Hall. Others may be along the routes that once connected the Arena Realm to other Realms. Their records are intact, waiting for restoration.

**The Marketplace and House Districts** — Both are locked canonical hub zones. The Marketplace reflects the Arena Realm's role as crossroads: what it sold during the First Harmony came from everywhere. In the Restoration Era, it is more local but still active. The House Districts each represent their respective House's presence in the Realm — the community's civic backbone.

---

## 5. Citizens of the Arena Realm

The Arena Realm in the Restoration Era holds a community that is, relative to other Realms, more intact — but intact does not mean whole. Citizens here remember more of what civilization felt like than their counterparts in more isolated Realms. That memory is a gift and sometimes a grief.

[PROPOSAL — awaiting creator confirmation: The Arena Realm's population in the Restoration Era skews toward the **Mentor Path** and the **Harmonist Path** — people who have stayed because staying is a contribution, and who spend their days maintaining what the Realm offers rather than expanding it. There are also Chroniclers here, drawn by the Archive presence. Pathfinders pass through rather than settle. Scholars come to access Archive records and sometimes stay longer than they intended. Flag for creator confirmation.]

[PROPOSAL — awaiting creator confirmation: The citizens of the Arena Realm share a particular quality that distinguishes them from citizens of more isolated Realms: they expect people to arrive. This expectation — shaped by generations of living at the crossroads of civilization — means that the community here retains a hospitality instinct that reads as warmth to arriving Guardians. It is not performed. It is cultural. They have been welcoming strangers for as long as anyone can remember, and they continued the practice even when strangers stopped coming as often. Flag for creator confirmation.]

Several of the six named citizens (Rowan, Elara, Mira, Taren, Solen, Lyra) may have strong ties to the Arena Realm given its civic character. Rowan (Community, Reliability, Stewardship) and Solen (Balance, Harmony, Reflection) map particularly naturally to a Realm built around Community and Harmony. These connections are not locked — they require creator confirmation before being assigned in Tier 3.

The Companion Grove in the Arena Realm means that Companions are more visible here than elsewhere. A Guardian arriving for the first time will likely encounter a Companion early — possibly Spark, given Spark's themes of Hope, Curiosity, and Beginnings, which align well with the entry experience. This is a proposal, not a locked assignment.

---

## 6. The Arena Realm During the Shattering

The Shattering was not evenly distributed. The Arena Realm experienced it differently from a Realm like the Frozen Expanse or the Sky Citadel — not because it was spared, but because its particular wound was social rather than structural.

The Five Wounds document describes what the Wound of Belonging felt like during the Shattering: "People felt, gradually, that there was less point to contribution — that their discoveries went nowhere, that the larger civilization was not really there anymore, that the future was not really theirs to shape." For a Realm built entirely around the premise that contribution to the whole is meaningful, this drift would have been felt acutely.

The Arena Realm did not collapse. Its buildings did not fall. But the attendance at the Great Gathering Hall thinned — first the delegates from the most distant Realms, then the scholars, then the travelers, then the festival-goers from other communities. The Hall was built for ten thousand and began hosting a thousand, then hundreds. The Keepers at the Lantern sites stayed. The Archive staff stayed. The citizens who called the Arena Realm home stayed. But the fullness drained out slowly, and no one could point to the moment it happened.

[PROPOSAL — awaiting creator confirmation: During the worst period of the drift — after the Crystal Network nodes began going dormant but before the Threshold was crossed — some communities in the Arena Realm made the choice to close the Great Gathering Hall to visitors from other Realms, citing resource constraints. This was not malicious. It was practical. But it was also the moment when the Arena Realm most deeply betrayed what it existed to be. The memory of that closure is still uncomfortable for community elders in the Restoration Era. It is not spoken of directly. It is the kind of wound that doesn't require a villain — only a series of understandable decisions that led somewhere no one intended. Flag for creator confirmation; this framing requires review before use.]

The Crystal Network nodes in the Arena Realm went dormant not through destruction but through disuse — the connections thinned as fewer and fewer Realms were contributing to the Network, until the nodes had nothing to route and no active nodes to route to. Their records survived. The knowledge is intact. It is simply waiting.

The Lantern sites were maintained more diligently in the Arena Realm than in most other locations — a function of the Keeper tradition being stronger here than elsewhere. At least one Lantern site burned continuously through the Shattering and into the Restoration Era. That continuity matters. It is the detail that gives a Guardian arriving for the first time a reason for hope that isn't naive.

---

## 7. Current State — Restoration Era

A Guardian arriving at the Arena Realm for the first time notices, before anything else, that someone has been taking care of things.

The paths are clear. The Lantern is lit. The Keeper is present and expecting them — not because the Keeper was told to expect them, but because the Keeper has been expecting every possible arrival for years. The Archive has a record waiting. It is incomplete, but it exists, which is more than many communities can say about their records.

The Great Gathering Hall stands. Its doors are open. Inside, the scale of what it was built for is visible in the space between where people are and where they could be standing. The Hall was built for convergence. It is receiving convergence again, slowly — one Guardian, one traveler, one restored connection at a time.

The Festival Grounds hold the smaller festivals that still happen. Not Harmony Week at full civilizational attendance, but the local observances that survived — some of them adapted, some of them nearly unchanged, all of them maintained because the Arena Realm community understood that keeping the practice alive mattered even when the people who used to attend were not there.

What is broken: the Crystal Network nodes are dormant. The routes to other Realms are only partially restored. The Great Gathering Hall feels quieter than it should. The full civilizational attendance that defined the Arena Realm during the First Harmony has not returned. The Archive record waiting for the arriving Guardian is incomplete — and that incompleteness is the first puzzle, the first invitation, the first signal that restoration is work and not ceremony.

What is working: the Lantern burns. The Keeper is there. The Archive has something. Kael is present. The community has not left. The sense of welcome — that instinct shaped by generations of expecting people to arrive — is intact. A Guardian who arrives at the Arena Realm does not arrive into ruin. They arrive into a place that has been waiting for them, and that is different.

What a Guardian first notices: warmth before grandeur. The Keeper before the Hall. The small before the large. The Arena Realm earns its scale through what it means, not how it looks.

---

## 8. Kael's Role in the Realm

Kael holds the title of **Arena Champion** — the highest civic honorific the Arena Realm confers. It was not given to him for winning something. It was given to him for being the kind of person who shows up, consistently, over time, without requiring recognition for it — and then receiving recognition anyway, because that is what the title exists to acknowledge.

[PROPOSAL — awaiting creator confirmation: Kael earned the title of Arena Champion during the period when attendance at the Great Gathering Hall had thinned most severely. When it was no longer clear whether the Hall would remain open — when the practical argument for closing it was becoming difficult to counter — Kael made the case for keeping it open. Not through a single dramatic speech. Through sustained, unglamorous civic maintenance: cleaning, repairing, organizing what remained of the festival infrastructure, keeping records for an Archive that had fewer and fewer visitors, being present so that anyone who did arrive found someone there. The title commemorates that sustained presence. It commemorates the decision to act as though civilization would return, during the years when it was not clear that it would. Flag for creator confirmation before use in any Tier 2 or Tier 3 writing.]

Kael's personality — brave, determined, adventurous — is expressed in civic terms. Bravery, in the Arena Realm's civic tradition, is not the absence of fear in the face of danger. It is the willingness to continue caring for something when continuation feels uncertain. Determination is not stubbornness; it is the quality that keeps a Lantern lit when you do not know if anyone will follow it. Adventurousness, for a person whose contribution is civic rather than exploratory, means remaining open — remaining curious about the people who arrive, the records that surface, the connections that become possible as restoration progresses.

To the community of the Arena Realm, Kael represents something specific: **the decision to stay**. In a Realm that was built around people coming and going, the people who stayed during the worst of the drift are remembered as its anchor. Kael is the most recognized of those anchors. His title says, in the civic language of the Arena Realm: this person's contribution will not be forgotten.

His relationship with arriving Guardians should feel like peer engagement, not mentorship. He does not know more than a Guardian. He knows this Realm. That is what he offers — not guidance toward some secret, but the particular knowledge of a person who has been somewhere a long time and paid attention.

---

## 9. Open Questions

These questions cannot be answered without creator input. They are sorted by the downstream impact their answers would have on Tier 2 and Tier 3 writing.

| Priority | Question | Why it matters |
|---|---|---|
| 1 | **What specifically did Kael do to earn the Arena Champion title?** | All Tier 3 Kael writing depends on this. The proposal above offers one direction, but the creator must confirm or replace it before Kael can be written into any document. |
| 2 | **Did the community of the Arena Realm close the Great Gathering Hall during the Shattering?** | This is the most significant unresolved moment in the Realm's history. If it happened, it has implications for community culture, elder relationships, and what restoration means here. If it didn't happen, that shapes the Realm differently. |
| 3 | **Who is the Keeper who greets arriving Guardians?** | This is the first character voice a Guardian hears in GemVerse. Their name, personality, and relationship to the Keeper tradition must be established before the entry experience can be written. |
| 4 | **What is the incomplete Archive record that triggers the first puzzle?** | "What was here before?" is established as the first puzzle. What was there? What kind of record survived? What does its incompleteness suggest? This shapes the first narrative beat of the entire game. |
| 5 | **Which of the six named citizens (Rowan, Elara, Mira, Taren, Solen, Lyra) are primarily associated with the Arena Realm?** | Tier 3 citizen encyclopedia entries for any Arena Realm citizen require this assignment to be confirmed. |
| 6 | **What Paths are most represented in the Arena Realm community?** | Shapes the character of community interactions and the kinds of contributions Guardians can make here. |
| 7 | **What happened to the Harmony Council, and is any trace of it visible in the Arena Realm?** | The Harmony Council convened in or near the Arena Realm during the First Harmony. Its fate during the Shattering is unresolved. The Arena Realm may hold physical or archival traces of it. |
| 8 | **What does the Great Gathering Hall look like inside?** | Required before the Hall can be written with physical specificity in Tier 2. General direction (large, Archive alcoves, dormant Crystal nodes, Lantern housing) is established; detailed layout is not. |
| 9 | **What is the Keeper tradition in the Arena Realm specifically?** | The Lantern Network document has not yet been written. Until the Keeper role is defined civilization-wide, the Arena Realm's specific Keeper character cannot be finalized. |
| 10 | **Is the Arena Realm the only Realm in the MVP scope, or does the Restoration Era entry describe it in contrast to others?** | The MVP includes only the Arena Realm. The Restoration Era entry (Tier 1, not yet written) may define how the other Realms are described before a Guardian can visit them. This affects how the Arena Realm is framed at the entry point. |

---

## 10. Dependencies

The following documents must be written or confirmed before the Arena Realm's Tier 2 entries (Realm Culture, Realm History) can be produced.

**Must be complete before Tier 2 writing begins:**

- **Restoration Era (Tier 1 entry)** — Not yet written. This is the single most important upstream dependency for the Arena Realm Realm Packet. The Restoration Era entry will define: how long after the Shattering the game begins, who leads civilization, what institutions survive, the full Guardian entry point narrative, and the emotional tone of the world at the start of play. Until this is written, Tier 2 entries for the Arena Realm cannot be finalized.
- **Lantern Network (Tier 1 entry)** — Not yet written. The Keeper who greets arriving Guardians is a Lantern Keeper. Until the Keeper tradition is defined civilization-wide, the specific Keeper at the Guardian entry point cannot be written.
- **Crystal Network (Tier 1 entry)** — Not yet written. The dormant Crystal nodes in the Arena Realm cannot be written with specificity until the Network's origin, function, and failure mode are established.
- **Kael Conflict 3 Resolution (LOCKED — Option A confirmed)** — Confirmed locked this session. Kael is a civic contributor; the Arena Champion title is not martial. All writing may proceed on this basis.

**Recommended before Tier 2 writing begins (flagged, not blocking):**

- **Harmony Council fate** — The Arena Realm may hold the last traces of the Harmony Council. Without knowing what happened to the Council, one significant strand of the Realm's history cannot be written.
- **Named citizen assignments** — Which of the six named citizens belong to the Arena Realm? This shapes the community character of the Realm and every citizen-level interaction in it.
- **Festival detail (at least 2–3 confirmed traditions)** — The Festival Grounds are a canonical hub zone. Without at least some confirmed festival detail, the cultural life of the Arena Realm cannot be rendered with warmth and specificity.

**Can be written now:**
- The Guardian entry experience (structure, not full dialogue)
- The Great Gathering Hall (physical description, general layout)
- Kael's civic role and relationship with arriving Guardians (from the proposal, subject to confirmation)
- The emotional character of the Arena Realm community

---

## Review Checklist

Before any content in this packet is used in Tier 2 or Tier 3 writing, the creator should confirm:

- [ ] Is the Wound of Belonging — the Division — confirmed as the Arena Realm's primary Wound?
- [ ] Is the proposal about the great cross-Realm civic assemblies confirmed as the Arena Realm's First Harmony tradition?
- [ ] Is the proposed brief — that the Gathering Hall risked closure during the drift period — an acceptable framing of the Arena Realm's Shattering experience?
- [ ] Is the proposal that Kael rebuilt or maintained the civic hall during the worst of the drift confirmed as the basis for his honorific?
- [ ] Is the Keeper character at the Guardian entry point named? If so, what is the name?
- [ ] What is the incomplete Archive record that triggers the first puzzle?
- [ ] Which named citizens are assigned to the Arena Realm?
- [ ] Is the Restoration Era entry confirmed as the next document to be written before Tier 2 begins?
- [ ] Do all proposals in this packet pass the Canon Validator's core test: no combat framing, no chosen-one framing, no villain, no hopeless tone?
- [ ] Does this packet's framing of the Arena Realm as a place of civic welcome — warm, hopeful, restorative — feel consistent with the creator's vision?
