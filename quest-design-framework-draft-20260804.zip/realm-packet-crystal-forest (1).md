---
title: Realm Packet — Crystal Forest
tier: Work Queue Task 6
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: Crystal Network (Tier 1), First Harmony (Tier 1), Restoration Era (Tier 1)
feeds-into: Tier 2 Realm Cultures, Tier 2 Realm Histories, Tier 3 Companion Encyclopedia (Spark, Prism)
---

# Realm Packet — Crystal Forest

---

## 1. Known Canon Summary

The following is confirmed locked canon for the Crystal Forest. Nothing below is proposal. These items may be written from directly in Tier 2 and Tier 3 documents without additional creator confirmation.

**Identity**
- The Crystal Forest's theme is **Knowledge** (confirmed in Canon Map).
- Art Bible description: "A crystalline realm filled with living crystal and harmony" — canon-consistent.
- The Crystal Forest's current state in the Restoration Era: partially restored, many secrets remain.
- Concept art has been transferred and depicts a lush crystalline environment — living crystal formations, organic and radiant.

**The Crystal Network Connection**
- The Crystal Network was built by House Lumina scholars in collaboration with Crystalkin Companions, extending natural crystalline formations into deliberate civilization-wide infrastructure (confirmed in Crystal Network Tier 1 entry).
- Crystal nodes were cultivated, not constructed — requiring a seed-crystal, a chosen location, and a foundation contribution (confirmed).
- The four Crystal Network node states in the Restoration Era: Active, Dormant, Damaged, Lost (confirmed).
- The Silencing — the name for the last major relay collapse — is confirmed canon. It was not a dramatic destruction but a quiet failure of maintenance: three Lumina scholars left for what each believed was a temporary absence, none knowing the others had left, and none returned (confirmed in Crystal Network Tier 1 entry).
- Crystalkin Companions were the Network's primary caretakers and are its most intimate users (confirmed).

**House and Companion Connection**
- House Lumina's Pillar is Knowledge; colour #1F4E79 (confirmed).
- Companion families: Crystalkin (Knowledge, Light, Reflection — Gold, White, Crystal Blue) are fully locked as a family (confirmed).
- Launch companions Spark (Hope, Curiosity, Beginnings) and Prism (Knowledge, Insight, Perspective) are both Crystalkin (confirmed in Canon Map).
- Every launch Companion carries memories associated with specific Crystal Network sites (confirmed in Crystal Network Tier 1 entry).

**Wounds relevant to this Realm**
- Wound of Knowledge — The Fragmentation: knowledge stopped flowing; research became isolated; the Crystal Network's degradation and this Wound are the same phenomenon viewed from two directions (confirmed).
- Wound of Memory — The Forgetting: the Crystal Network was the Archive's infrastructure layer; the Archive and the Network are inseparable; damage to one is damage to the other (confirmed).

**Notable Crystal Network Nodes (proposals, flagged for Tier 2)**
- Heart Node (Arena Realm, Great Archive) — largest active node in the Restoration Era
- Remembrance Node (Frozen Expanse) — major dormant node holding Memory-pillar records
- Wanderer's Log (Sky Citadel) — dormant relay node, location approximate

---

## 2. Realm Identity

The Crystal Forest is built around a single irreducible truth: **that knowledge is not an individual achievement — it is a civilization's shared inheritance**.

During the First Harmony, every discovery made anywhere in the world passed through or was touched by what the Crystal Forest cultivated. This was not power. It was custodianship. The scholars and Crystalkin Companions who tended the Network's deepest nodes understood themselves to be doing something closer to gardening than scholarship — a sustained, patient, collective act of care for something that belonged to everyone.

Its relationship to the Seven Pillars places it most naturally in the domain of **Knowledge** — but the Crystal Forest, at its heart, is also deeply shaped by **Memory**. The Crystal Network was the infrastructure that allowed the Archive to be everywhere, that allowed a discovery in one Realm to reach a researcher in another within a day, that allowed a Companion's memory to be preserved beyond that Companion's ability to carry it. Knowledge and Memory were inseparable here. To tend the Network was to tend civilization's remembering.

[PROPOSAL — awaiting creator confirmation: The Crystal Forest's primary Wound is the **Wound of Knowledge — the Fragmentation**. A Realm built around the flow of knowledge is most deeply wounded when knowledge stops flowing. The crystal formations themselves still stand — the physical infrastructure of the Network is largely intact. What was lost was the active life of the Network: the scholars at relay nodes who reviewed incoming records, the Crystalkin Companions who sensed deterioration before it became irreversible, the continuous human and Companion presence that kept the crystal lattice warm and connected. The silence in the Crystal Forest is not the silence of ruin. It is the silence of something that was once full of purposeful sound and is now waiting to be tended again. Flag for creator confirmation before use in Tier 2.]

The Crystal Forest also carries the Wound of Memory more directly than most Realms, because the records held in its dormant nodes — records that have not been lost, only gone quiet — represent a significant portion of what the Archive is still missing. To restore the Crystal Forest is to restore civilization's ability to know what it once knew.

---

## 3. The Knowledge Tradition

During the First Harmony, the Crystal Forest was not simply where the Crystal Network was maintained. It was where **the practice of knowledge-keeping was understood most deeply**.

The Crystal Network Tier 1 entry confirms that the earliest crystalline knowledge-preservation sites predate the formal Houses — communities in the Crystal Forest discovered that certain formations of living crystal could hold impressions before anyone had a word for what was happening. Scholars who would become the founding members of House Lumina recognized what these formations were doing and began the deliberate work of extending, replicating, and connecting them. The Crystal Forest was, in this sense, where civilization first learned that knowledge could be preserved in the land itself.

[PROPOSAL — awaiting creator confirmation: The Crystal Forest housed the original seat of House Lumina — not a formal headquarters in the institutional sense, but the place where the scholars who first understood the living crystal tradition made their home and did their work. If this is confirmed, the Crystal Forest is not merely a realm aligned with House Lumina; it is the origin of House Lumina's identity. Flag for creator confirmation; this has significant implications for Tier 2 Realm History.]

[PROPOSAL — awaiting creator confirmation: The scholarly tradition of the Crystal Forest during the First Harmony was built around three practices: **cultivation** (growing and tending nodes), **resonance-reading** (the art of listening to what nodes held, including the impressions accumulated over time), and **contribution scholarship** (the discipline of deciding what records were significant enough to distribute across the Network, and how). These three practices were taught together — no Lumina scholar was considered fully trained until they had demonstrated competence in all three. Crystalkin Companions participated in cultivation and resonance-reading in ways that human scholars could assist but not replicate. Flag for creator confirmation.]

The Crystal Forest's knowledge tradition was never the hoarding of expertise. The Book of Harmony's principle — *"What is discovered belongs first to wonder, then to understanding, then to those who come after"* — describes the orientation that the Crystal Forest's scholars held as a civic value. The purpose of maintaining the Network was not to control information. It was to make sure that no discovery stayed in one place when it was needed everywhere.

---

## 4. The Physical Realm

The transferred concept art depicts a lush crystalline environment — living crystal formations, organic and radiant, growing alongside and through natural landscapes. This is the visual foundation.

The Crystal Forest is not a forest of stone. It is a forest of **living crystal** — formations that pulse faintly with stored resonance, that catch light and scatter it, that have grown over centuries alongside trees and moss and waterways until the distinction between the crystalline and the organic is not always clear. You do not walk through the Crystal Forest and feel you are in a constructed place. You feel you are in a place that has been cared for so long and so attentively that the care has become part of the landscape.

[PROPOSAL — awaiting creator confirmation: The following locations are proposed as primary physical geography of the Crystal Forest in the Restoration Era. All are flagged; none are locked without creator review.]

**The Resonance Groves** — The original sites where natural crystal formations were first discovered to hold impressions. During the First Harmony, these were maintained as the Network's deepest nodes — the oldest, the most accumulated, the most significant. In the Restoration Era, the Groves are dormant but intact. A Guardian who enters a Resonance Grove for the first time describes it as walking into a silence that has texture — as if the air itself is holding something carefully. Crystalkin Companions who enter these Groves sometimes become very still, attending to something no human scholar can yet hear. Flag for creator confirmation.

**The Lumina Halls** — The working spaces where House Lumina scholars tended node cultivation and conducted resonance scholarship. The architecture is characterized by crystal-integrated surfaces — walls into which active nodes were embedded, ceiling structures that distributed light from crystalline sources, working alcoves sized for both human scholars and their Crystalkin Companion partners. In the Restoration Era, some Halls are occupied by the scholars who remained; others are quiet, their embedded nodes dormant, their working surfaces accumulating the slow growth of crystal formations that have continued to develop without tending. Flag for creator confirmation.

**The Seed-Crystal Repository** — A protected site where seed-crystals were stored and prepared for new node cultivation. During the First Harmony, this was maintained continuously — new seed-crystals were always being prepared, because the Network was always growing. In the Restoration Era, the Repository is intact but largely inactive. Some seed-crystals remain. A Guardian who understands what they represent — the potential for new nodes, new connections, new expansion of the Network — encounters here not loss but possibility. Flag for creator confirmation.

**The Living Lattice** — The visible portions of the Crystal Network's resonance pathways in the Crystal Forest. During the First Harmony, these were actively maintained and lit with the ambient resonance of information flowing through them. In the Restoration Era, sections of the Lattice are dark. Others still carry faint resonance — not from current information flow but from the impressions of information that once flowed through them. Walking the Lattice paths is considered one of the most moving experiences in the Crystal Forest for those who can sense what it once was. Flag for creator confirmation.

**Dormant and Active Nodes throughout the Forest** — Not confined to the Halls or Groves. Individual nodes exist throughout the Crystal Forest — some in natural formations that were incorporated into the Network, some in purpose-grown structures, some in unexpected locations where a scholar or Companion recognized a site's potential and cultivated a node without building anything around it. The density of nodes here is higher than in any other Realm. Flag for creator confirmation.

---

## 5. Citizens of the Crystal Forest

The Crystal Forest in the Restoration Era holds a community shaped by proximity to something that was once the center of the world and has gone quiet.

[PROPOSAL — awaiting creator confirmation: The Crystal Forest's population in the Restoration Era skews heavily toward the **Scholar Path** — people who have stayed because tending the Network, even in its dormant state, is still a form of contribution. There are also Chroniclers here, drawn by the Archive records accessible through active nodes. Crystalkin Companions are more present here than in any other Realm; many of them have remained near nodes they once tended, maintaining a kind of vigil. Flag for creator confirmation.]

[PROPOSAL — awaiting creator confirmation: The community character of the Crystal Forest is defined by two qualities that live in productive tension: **patient attention** and **held grief**. Patient attention, because the tradition of the Crystal Forest is attentiveness — to the network, to what it holds, to what it is doing. Held grief, because the people who stayed here after the Silencing live within daily sight of what was lost. The dormant nodes are not invisible to them. The silence where resonance used to move through the Lattice is audible to those who remember the sound. They do not perform this grief; they carry it with the particular steadiness of people who have decided that continuing to show up is itself the appropriate response to loss. Flag for creator confirmation.]

[PROPOSAL — awaiting creator confirmation: Citizens of the Crystal Forest do not speak lightly about what the Network was. This is not secrecy — it is a kind of reverence. When a Guardian arrives and asks about the crystal formations, a Crystal Forest scholar does not explain them the way a person explains something they own. They explain them the way a person explains something they love and have been tending for a long time. Flag for creator confirmation.]

Spark and Prism — both Crystalkin Companions and both launch companions — have strong natural associations with this Realm given the Crystalkin family's role as the Network's primary caretakers. Their memories of specific nodes in the Crystal Forest are among the most significant contributions available to the early restoration effort. These connections are not fully locked; specific node memories require Tier 3 Companion Encyclopedia confirmation.

---

## 6. The Crystal Forest During the Shattering

The Crystal Forest did not experience the Shattering as catastrophe. It experienced it as a slow withdrawal — the most painful kind.

The Crystal Network Tier 1 entry describes the Network's failure: as communities withdrew from civilization's shared life, they withdrew from Network maintenance. Relay nodes went unattended. Resonance pathways that required regular clearing began to cloud. For the Crystal Forest — the place that had tended the Network most deeply and most consistently — this meant watching the system they had built and maintained withdraw from itself, region by region, one dark node at a time.

[PROPOSAL — awaiting creator confirmation: The Lumina scholars in the Crystal Forest were among the last to accept that the Silencing was permanent. For years after the largest relay collapse, scholars continued traveling to dormant nodes in other Realms, attempting to reawaken them. These journeys became increasingly isolated as the routes between Realms degraded. Some scholars set out and did not return — not because anything catastrophic happened to them, but because the communities they reached needed their presence more than the Crystal Forest needed their return. The Archive has incomplete records of these journeys. Some of what those scholars found is preserved in the nodes of Realms that have not yet been reached in the Restoration Era. Flag for creator confirmation; this framing has implications for Discovery-Pillar content and cross-Realm narrative.]

The Silencing — the final major relay collapse — was felt most acutely here. The Crystal Network Tier 1 entry establishes that the last major relay hub went dark because three Lumina scholars, each believing their absence would be temporary, left without knowing the others had left. For the Crystal Forest community, this moment — when it became known — was not a moment of blame. It was a recognition of how the Shattering worked: not through malice or negligence, but through the gradual failure of coordination that had always required sustained attention to maintain.

[PROPOSAL — awaiting creator confirmation: After the Silencing, the Crystal Forest community made a collective decision to stop attempting cross-Realm relay restoration and instead focus on preserving what remained within their own Realm — tending the nodes they could still reach, recording everything they knew about Network function, and maintaining the Resonance Groves against the possibility that someone would eventually come to restore them. This was not giving up. It was a form of institutional memory-keeping — the decision to become a record of what had been lost rather than an unsuccessful attempt to restore it alone. The Archive has copies of those records. They are among the most complete accounts of Crystal Network function that survive. Flag for creator confirmation.]

What was preserved here through the Shattering: the physical infrastructure, the Resonance Groves, the Lumina Halls, the Seed-Crystal Repository, the knowledge of how to cultivate and tend nodes, the Crystalkin Companions who remained. What was lost: the active flow of the Network, the connections to other Realms, the continuous presence of scholars from across civilization who had once made the Crystal Forest a place of civilizational convergence.

---

## 7. Current State — Restoration Era

A Guardian arriving at the Crystal Forest for the first time notices, before anything else, that the light is different here.

Not brighter — the crystal formations scatter and diffuse light rather than amplifying it. But more present. More dimensional. Light that has passed through a dormant node carries something the Crystal Forest scholars can identify but cannot fully explain to someone who has not spent time here: a quality of accumulated attention, as if the light has been somewhere that remembered things.

The Crystal Forest in the Restoration Era is **the most intact dormant system in GemVerse**. Other Realms have experienced physical damage, community collapse, or loss of the traditions that allowed restoration to be understood. The Crystal Forest has kept its traditions, kept its scholars, kept its Crystalkin Companions, and kept its knowledge of how the Network functions. What it has lost is active connection — to other Realms, to the civilization it was built to serve.

**What is active:** Some nodes in the Crystal Forest are still functional — maintained continuously by the scholars and Crystalkin Companions who remained. These nodes hold records that are accessible, complete, and waiting. The Lumina Halls are occupied. The community has not collapsed. The tradition of cultivation is intact.

**What is dormant:** Most of the Network's pathways between the Crystal Forest and other Realms have gone dark. The Resonance Groves, the largest and oldest nodes, are dormant — not damaged, but quiet. Their records are intact and waiting. The Seed-Crystal Repository has prepared crystals that have never been used.

**What is damaged:** Some nodes at the edges of the Realm, where the Crystal Forest's pathways connected to Realms that experienced more physical disruption during the Shattering, have sustained crystalline fractures. Records in these nodes are partially intact, partially corrupted, partially lost.

**What is lost:** The precise resonance pathways that connected the Crystal Forest to the Wanderer's Log (Sky Citadel) and the Remembrance Node (Frozen Expanse) are no longer mapped. The Network's largest relay routes are not merely dormant — they are unknown. The Archive references them; the Crystal Forest scholars know they existed; no current Guardian has traveled them.

What a Guardian first notices: quiet that is full rather than empty. The Crystal Forest is not abandoned. It is attending. The scholars who remain here have spent years in patient, sustained care of something they believe civilization will eventually come to reclaim. A Guardian who arrives is not greeted with relief that someone has finally come. They are greeted with the quiet pleasure of a community that always expected someone would come, and is glad the waiting has become welcome.

---

## 8. The Crystal Network Connection

For every other Realm, the Crystal Network is something that once passed through their territory — a system that connected them to civilization. For the Crystal Forest, the Crystal Network is not something external to the Realm. It is the Realm's identity.

This distinction matters to the scholars and Crystalkin Companions who live here. When a Guardian arrives and asks about restoring a node, they are not asking about a maintenance task. They are asking about something the Crystal Forest community has been holding in trust for the entirety of the Restoration Era. The response is not reluctance — it is care. A community that has spent years tending dormant nodes wants restoration to be done correctly, by people who understand what they are reawakening.

[PROPOSAL — awaiting creator confirmation: Tending a node in the Crystal Forest involves a specific etiquette that the community observes even when the node is fully dormant: a practitioner announces themselves — their name, their Path, the purpose of their visit — before approaching. This is not ritual in the religious sense. It is the scholar's equivalent of knocking before entering. The node may not respond; it may be dormant past response. But the practitioner announces themselves anyway, because the tradition holds that impressions accumulate, and the node will eventually know who tended it. Guardians who observe this practice without being asked to are recognized immediately by Crystal Forest scholars as people who understand what they are working with. Flag for creator confirmation.]

[PROPOSAL — awaiting creator confirmation: The Crystal Forest community maintains a **Node Registry** — a continuously updated record of every node in the Realm, its current state, what it is known to hold, and the history of who has tended it. This Registry is the most comprehensive surviving record of Crystal Network function in existence. It was begun during the First Harmony as an Archive resource and has been maintained in the Crystal Forest through the Shattering and into the Restoration Era by the scholars who stayed. A Guardian who is given access to the Node Registry — a privilege extended only after demonstrated understanding and care — receives the most complete map of Crystal Network restoration possibilities in the known world. Flag for creator confirmation.]

What does tending a node in the Crystal Forest mean, emotionally? It means participating in something that has been going on for centuries, that will continue long after you leave, that existed before you arrived and will remember you were there. The Crystal Forest does not frame node-tending as a Guardian achievement. It frames it as a contribution to an ongoing communal act of care — one that began with the first scholars who recognized what the living crystal was doing, and has not stopped since.

The three proposed notable nodes (Heart Node in the Arena Realm, Remembrance Node in the Frozen Expanse, Wanderer's Log in the Sky Citadel) are all flagged for Tier 2 confirmation. From the Crystal Forest's perspective, the most significant missing connections are those three — the pathways that once allowed the Crystal Forest to serve as the relay hub for the full Network. Restoring those connections is the largest open task in the Realm's restoration story.

---

## 9. Open Questions

These questions cannot be answered without creator input. They are sorted by the downstream impact their answers would have on Tier 2 and Tier 3 writing.

| Priority | Question | Why it matters |
|---|---|---|
| 1 | **Is the Crystal Forest confirmed as the origin point or heart of the Crystal Network?** | The Tier 1 Crystal Network entry places the earliest crystalline discovery sites in the Crystal Forest. If this is confirmed as the heart of the Network — not merely a major node location but the origin of the entire system — it fundamentally shapes the Realm's identity and House Lumina's historical narrative. All Tier 2 Realm History writing depends on this. |
| 2 | **Is the Crystal Forest confirmed as House Lumina's home Realm?** | If confirmed, the Crystal Forest is where House Lumina's identity was formed, where its earliest scholars worked, and where its deepest institutional memory resides. If not confirmed, the Realm's relationship to House Lumina must be defined differently. This affects Tier 2 Realm Culture, citizen identity, and the House District presence within the Realm. |
| 3 | **What is the Silencing's specific impact on the Crystal Forest?** | The Silencing (the last major relay collapse) is established canon. Whether the Crystal Forest was the location of the relay hub that went dark, or whether that hub was elsewhere, changes the Realm's specific Shattering wound. If the hub was here, the Crystal Forest experienced the Silencing as the loss of something that happened on their ground. If it was elsewhere, they experienced it as watching the connection fail from a distance. |
| 4 | **What do Spark and Prism specifically remember about the Crystal Forest?** | Both are Crystalkin Companions with natural connection to this Realm. Their specific memories of Network sites, of what the Crystal Forest felt like during the First Harmony, and of what they witnessed during the Shattering are among the most significant early restoration contributions available. These memories cannot be written without Tier 3 Companion Encyclopedia confirmation. |
| 5 | **What Paths are most represented in the Crystal Forest community?** | The Scholar Path seems likely, but the community also performs ongoing node-tending that maps more naturally to the Chronicler Path. Whether the community has a strong Harmonist presence — scholars concerned with balance rather than pure knowledge — shapes the community's emotional character significantly. |
| 6 | **What does the Node Registry contain, and who has access?** | The Node Registry (proposed) is potentially the most significant navigational document in the restoration effort. Its contents, access protocols, and the political or relational complexity of granting a Guardian access to it shape a major narrative strand in Tier 2. |
| 7 | **Are there Crystal Forest citizens who left during the Shattering and have not returned?** | The scholars who set out to tend nodes in other Realms and stayed (proposed) represent a significant narrative thread. If confirmed, some of them — or their descendants — may be the named scholars whose records appear in Archive holdings from Realms not yet restored. Finding them, or their work, is a potential cross-Realm story strand. |
| 8 | **What is the Crystal Forest's festival tradition?** | The First Harmony entry confirms that festivals were the primary mechanism by which distant communities maintained relationship. The Crystal Forest likely had specific festival traditions connected to the Network — marking the first cultivation of a new node, observing the Silencing, celebrating restored connections. None of these are yet defined. |
| 9 | **What does a first-time Guardian encounter experience in the Crystal Forest?** | Unlike the Arena Realm (where the Guardian entry point is established), the Crystal Forest's specific entry experience — the first image, the first voice, the first puzzle — has not been defined. This is the emotional introduction to GemVerse's Knowledge Pillar and requires creator confirmation before it can be written. |
| 10 | **Is the Crystal Forest's location in the Realm map in relationship to the Arena Realm?** | The restoration narrative implies that Guardians travel from the Arena Realm to the Crystal Forest at some point. Whether the Crystal Forest is a nearby Realm (early expansion) or a more distant one (mid-game) affects how its story is paced and what restoration state a Guardian arrives to find. |

---

## 10. Dependencies

The following documents must be written or confirmed before the Crystal Forest's Tier 2 entries (Realm Culture, Realm History) can be produced.

**Must be complete before Tier 2 writing begins:**

- **Restoration Era (Tier 1 entry)** — Not yet written. This is the most important upstream dependency for the Crystal Forest, as for all Realms. The Restoration Era entry will define how long after the Shattering the game begins, what institutions survive, and how a Guardian first enters the world. The Crystal Forest cannot be placed in context without this.
- **Crystal Network (Tier 1 entry)** — Now complete. The Crystal Forest Realm Packet builds directly on this entry. All node mechanics, the Silencing, cultivation requirements, and Crystalkin Companion roles are established and may be drawn from.
- **House Lumina — Home Realm confirmation** — The proposal that the Crystal Forest is House Lumina's home Realm is flagged for creator confirmation. Until confirmed or replaced, the Realm's cultural and institutional relationship to House Lumina cannot be fully written.
- **Crystal Forest as Network Origin/Heart** — The proposal that the Crystal Forest is the origin point or heart of the Crystal Network is flagged for creator confirmation. This is the most consequential unresolved question in this packet. All Tier 2 Realm History writing depends on it.

**Recommended before Tier 2 writing begins (flagged, not blocking):**

- **Spark and Prism Companion Encyclopedia entries (Tier 3)** — Both Crystalkin Companions have strong natural ties to this Realm. Their specific memories and restoration contributions should be defined before the Crystal Forest's most significant narrative moments can be written.
- **Named citizen assignments** — Which of the six named citizens (Rowan, Elara, Mira, Taren, Solen, Lyra) are associated with the Crystal Forest? Elara (Learning, Curiosity, Knowledge) maps particularly naturally. Requires creator confirmation before Tier 3.
- **Festival detail for at least 2–3 Crystal Forest traditions** — The community's cultural life cannot be rendered with specificity until at least some festival and observance detail is confirmed.
- **Lantern Network (Tier 1 entry)** — Not yet written. The Crystal Forest's relationship to the Lantern Network — whether it had active Lantern Keeper presence or relied primarily on Crystal Network connections — is unresolved. Until the Lantern Network is defined, this thread cannot be closed.

**Can be written now:**
- The physical character of the Crystal Forest (crystalline formations, organic integration, quality of light)
- The emotional character of the community (patient attention, held grief, steady care)
- The Crystal Network's functional role in this Realm and what restoration means here
- The Crystalkin Companion presence and their relationship to the Realm's nodes
- The community's relationship to the Silencing — how it is remembered, how it is not blamed

---

## Review Checklist

Before any content in this packet is used in Tier 2 or Tier 3 writing, the creator should confirm:

- [ ] Is the Crystal Forest confirmed as the origin point or heart of the Crystal Network, or should this be left open for Tier 2 development?
- [ ] Is the Crystal Forest confirmed as House Lumina's home Realm?
- [ ] Is the Wound of Knowledge — the Fragmentation — confirmed as the Crystal Forest's primary Wound?
- [ ] Does the framing of the Crystal Forest community as patient, attentive, and carrying a held grief feel consistent with the creator's vision?
- [ ] Is the proposed node-tending etiquette (announcing yourself before approaching a node) an acceptable cultural detail, or does it risk over-defining a tradition that belongs in Tier 2?
- [ ] Is the proposed Node Registry an acceptable piece of infrastructure for this Realm?
- [ ] Is the proposal that Lumina scholars set out during the Shattering to tend nodes in other Realms and stayed — becoming part of those communities — an acceptable narrative thread?
- [ ] Do Spark and Prism have confirmed Crystal Forest memories, or are their specific connections to this Realm to be established in Tier 3?
- [ ] Does the current state description (most intact dormant system in GemVerse) feel correct — a Realm with preserved infrastructure and intact tradition, waiting to be reconnected rather than rebuilt?
- [ ] Do all proposals in this packet pass the Canon Validator's core test: no combat framing, no chosen-one framing, no villain, no hopeless tone?
- [ ] Does this packet's framing of the Crystal Forest as a place of living knowledge — crystalline, luminous, patiently attended — feel consistent with the creator's vision and the transferred concept art?
