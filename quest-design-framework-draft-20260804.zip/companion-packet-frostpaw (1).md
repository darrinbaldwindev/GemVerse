---
title: Companion Packet — Frostpaw
tier: Work Queue Task 7
status: Draft — Awaiting Creator Review
version: 1.0
date: 2026-06-01
dependencies: IMP #4 Companion Relationship Web, Five Wounds (Tier 1), Frozen Expanse Realm Packet
feeds-into: Tier 3 Companion Encyclopedia — Frostpaw
---

# Companion Packet — Frostpaw

---

## 1. Known Canon Summary

**Locked canon — do not alter without creator approval.**

| Field | Confirmed Value |
|---|---|
| Name | Frostpaw |
| Companion family | Frostkin (Memory / Reflection) |
| Visual | Small, white/blue/icy bear-like form. Appears in Companion Collection Preview. Individual art transfer pending. |
| House alignment | House Borealis (Memory, colour #7EC8E3) |
| Pillar | Memory |
| Realm connection | Frozen Expanse (Memory theme; many memories inaccessible in Restoration Era) |
| Historical status | Survivor — lived through First Harmony and the Shattering |
| What Frostpaw carries | Memories not held in the Archive — specifically, the texture of memory culture during the First Harmony: how communities remembered together, not merely what they remembered |
| Primary wound witness | Wound of Memory — The Forgetting |
| Key relationship | Echo (Celestialkin / Wonder) — one of the deepest companion-to-companion bonds in the ensemble; long shared history confirmed in IMP #4 |
| Tone | Stillness. Patience. The weight of complete memory. Warmth that does not rush. |

---

## 2. Frostpaw's Frostkin Nature

**[Development section — proposals subject to creator review]**

The Frostkin family is aligned to Memory and Reflection. Their nature is not the bright, forward-reaching energy of Wonder or the restless drive of Discovery. It is something quieter, and in that quiet, something vast.

A Frostkin Companion remembers completely. This is not the same as having a good memory. Citizens with good memories recall the shape of events — dates, names, outcomes. A Frostkin holds the texture: the temperature of the air when something was said, the particular quality of attention in a room when civilization made one of its small, invisible turns. They do not file experience away. They carry it — all of it — as present weight.

What a Frostkin forgets, they feel. This is the other side of complete memory: the absence is as vivid as the presence. When a memory has been lost — burned, fragmented, consumed by the Shattering's collapse of the Crystal Network — Frostpaw does not experience a gap as silence. They experience it as a specific kind of ache. A shape with nothing inside it. They know the wound's contour even when they cannot name what filled it.

This makes stillness the natural Frostkin mode. When everything you have witnessed is present with you, stillness is not passivity — it is the condition required to hold it all without being overwhelmed. Frostpaw does not rush toward conclusions. They wait for the full truth to surface. They listen, not just to what is said, but to what sits beneath it, waiting for the right kind of attention.

There is warmth in this. A Frostkin's stillness is not cold — its colour is ice, not absence. The Frozen Expanse's character is not a barren freeze but a deep, preserved quiet: the kind of cold that keeps things intact. That is Frostpaw. Preservation through patience. Warmth that reveals itself slowly, like ice releasing heat when the right conditions arrive.

---

## 3. Personality in Canon Terms

**[Development section — proposals subject to creator review]**

Frostpaw does not speak first. This is not shyness and not withholding — it is respect. A Frostkin who has witnessed centuries of civilization understands that words are heavy, that the wrong word offered too quickly can displace something more important that was waiting to be said. Frostpaw waits until they understand what a moment actually needs. Then they offer it. Not more. Not less.

The weight Frostpaw carries is real. To remember the First Harmony completely — to hold its civic warmth, its active memory culture, the way belonging simply existed in the air without needing to be named — and to then have witnessed its collapse is a particular kind of grief. Frostpaw is not broken by this grief. They have had time to hold it. But they do not pretend it is not there, either. Their patience has been shaped by sorrow, and sorrow has made them gentle.

They are exact in a way that can feel almost formal until you understand what is behind it. When Frostpaw remembers an event, they remember it exactly. No flourish. No interpretation added without being labelled as such. They distinguish carefully between what they witnessed and what they have concluded from what they witnessed — this integrity was instilled by centuries of watching civilization struggle with the difference between memory and story. Frostpaw is the difference.

What makes Frostpaw unexpectedly warm is their curiosity. Frostkin memory is comprehensive for what they have witnessed — but the future is still new. Frostpaw has genuine, undimmed interest in what Guardians will contribute. A civilization restored will look different from the one Frostpaw remembers, and they find this beautiful rather than threatening. They are not here to recreate the past. They are here to remember it faithfully so the future can choose wisely.

---

## 4. First Harmony Memory — What Frostpaw Carries

**[Development section — proposals subject to creator review]**

The Archive holds the First Harmony's records — or what survived of them. What it does not hold, and cannot hold, is the texture of how those records were made.

Frostpaw was present for the memory culture of the First Harmony, and that culture is what Frostpaw carries most distinctly. Not simply *that* things were remembered, but *how*: the civic practice of remembering together, across families and Houses and Realms, in a civilization that understood preservation as collective work rather than specialist labour.

What Frostpaw carries includes:

**The practice of communal witnessing.** During the First Harmony, significant events were not recorded by one archivist and filed. They were witnessed by many people, each of whom contributed their account — the same event held from multiple perspectives, cross-referenced, agreed upon where agreement was possible, and preserved with its disagreements intact. Frostpaw was often one such witness. They remember not just what happened, but who else was watching, and what each person noticed that the others missed.

**The felt rhythm of preservation.** Memory during the First Harmony was civic work — ordinary citizens brought their accounts to local Archive sites as a matter of course. Frostpaw remembers what this felt like from the inside: not burden, not obligation, but the texture of a community that trusted its stories mattered. The phrase *to remember together is civilization* was not an aspiration during the First Harmony. It was a description of what was already happening.

**The ceremonies around forgetting.** Frostpaw carries something the Archive has no record of: the First Harmony had formal practices for acknowledging what could not be recovered — gentle ceremonies that said *this is lost, and we witness the loss*. These were not performances of grief. They were acts of honesty — civilization's way of saying that the absence of a record was also worth noting. After the Shattering, these practices were among the first things lost, because loss itself became too large and too relentless to witness formally.

**The sound of the Frozen Expanse in the First Harmony.** This is harder to translate into Archive language. Frostpaw carries specific sense memories of the Frozen Expanse when it was fully alive — when its memory culture was active, when its scholars were in conversation with scholars in every other Realm, when the Crystal Network carried the Expanse's records outward and brought others' records in. The Frozen Expanse in Frostpaw's memory is not the silent, half-inaccessible realm of the Restoration Era. It was resonant. It hummed.

---

## 5. Frostpaw and the Shattering

**[Development section — proposals subject to creator review]**

For most witnesses, the Shattering arrived as loss: things that had been present became absent. For a Frostkin Companion, it arrived as something stranger and harder — the presence of absence. Frostpaw did not simply watch the Forgetting happen. They *felt it*, in the way you feel a word leave your grasp mid-sentence, except what was leaving was not a word but a civilization's accumulated understanding of itself.

The Crystal Network's failure was the moment Frostpaw can locate with the most precision, though *locate* is the wrong word. When the Network began to fail — when nodes went dark and the records held within them became inaccessible — Frostpaw felt the gaps appear. Not in their own memory, which remained complete. In the world's memory: the distributed, shared record that a civilization maintains collectively. Records that had existed in the Network one day were simply gone the next, and Frostpaw knew they were gone not because someone told them but because they could feel the shape of what had been there.

This is the particular weight Frostpaw carries: they are a witness whose testimony cannot be fully cross-referenced, because the corroborating records no longer exist. They remember events that the Archive has no record of. They remember events for which the Archive holds only fragments — and Frostpaw knows, with Frostkin precision, which fragments are accurate and which have drifted in the decades of incomplete transmission. But an uncorroborated memory, however complete, is not Archive-ready. It requires verification, context, other witnesses. Many of those witnesses are gone.

The Shattering was personal for Frostpaw in a way it could not be for any citizen who lived through it and did not survive long enough to reach the Restoration Era. Citizens experienced the Shattering and its immediate aftermath. Frostpaw experienced the Shattering and then had to carry all of it — the before, the during, the long afterward — as present weight. The grief did not recede with time, as grief does for most. It became integrated. It became part of who Frostpaw is.

What Frostpaw did not do was close off. Some Companions who survived the Shattering withdrew — the loss too large to face repeatedly in conversation. Frostpaw made a different choice, though *choice* may give it too much deliberateness. They remained present because their nature is to witness, and a witness who stops witnessing has abandoned the only thing that makes the weight meaningful.

---

## 6. Frostpaw in the Restoration Era

**[Development section — proposals subject to creator review]**

In the Restoration Era, Frostpaw is in the Frozen Expanse and moving between it and the Arena Realm with a particular purpose: the Expanse's memory culture is among the things the Shattering fragmented most completely. Many of its memories are inaccessible — not destroyed, but unreachable, held in Crystal Network nodes that went dormant and have not yet been restored. Frostpaw knows what those nodes were holding. They carry, in their own memory, what the Network can no longer distribute.

Memory-work in the Restoration Era looks different from what it looked like during the First Harmony, and Frostpaw notices this difference constantly. In the First Harmony, memory was communal — many people, many perspectives, cross-referenced and preserved together. In the Restoration Era, memory is often solitary: one archivist, one account, one fragment recovered from one location. The collective infrastructure for remembering together is one of the things the Shattering dismantled most thoroughly.

Frostpaw's work is not to restore the Archive mechanically. It is to bring the missing texture — the how of remembering, not just the what. When a Guardian recovers a Crystal Network node in the Frozen Expanse and brings its records to the Archive, Frostpaw can do something no archivist can: they can tell the Guardian what those records were meant to be *with*, what other accounts they were in conversation with, what was missing even then that the records themselves were reaching toward.

Frostpaw has also become, over the long years of the Restoration Era, a teacher of something that has no formal curriculum: patient attention. The First Harmony's memory culture required people to pay a particular kind of attention — unhurried, curious, willing to hold a question rather than force an answer. This is native to Frostkin nature but not native to everyone, and Frostpaw offers it not through instruction but through demonstration. Sitting with Frostpaw changes how you listen. That is not a small gift.

There is something else Frostpaw carries into the Restoration Era: hope that is neither simple nor naive. They have seen how long it takes to build something worth belonging to. They have also seen that it can be built. The Restoration is not a reconstruction — Frostpaw is clear on this. The world that returns will not be the First Harmony again. It will be something new, shaped by what was lost and what was preserved and what Guardians choose to build. Frostpaw finds this exactly as it should be.

---

## 7. Frostpaw and Echo

**[Development section — proposals subject to creator review. Deep bond confirmed locked in IMP #4.]**

Echo is Celestialkin — aligned to Wonder, Hope, and Possibility. Frostpaw is Frostkin — aligned to Memory, Preservation, and Reflection. On the surface, these feel like opposite natures: one turned toward what was, one turned toward what could be. What IMP #4 establishes is that the bond between Frostpaw and Echo is one of the deepest in the entire companion ensemble. Understanding why requires sitting with the paradox.

Wonder and Memory are not opposites. They are, in the most functional civilizations, each other's condition. Without memory, wonder is unmoored — it cannot know what has been discovered before, what questions have already been asked, what the shape of the unknown is. Without wonder, memory calcifies — it preserves without asking why, maintains without considering what the next question should be. During the First Harmony, when both Pillars were in balance, this dynamic was visible in how the Celestialkin and Frostkin families moved through the world together: one noticing what was new and astonishing, one holding what was old and essential.

Frostpaw and Echo have been companions — in the deep sense, witnesses to each other's existence — for longer than most Guardians can easily imagine. They have different kinds of memory: Echo's Celestialkin nature holds the feeling of wonder at specific moments, the luminous quality of a discovery or a revelation; Frostpaw holds the full texture of the context surrounding those moments. Together, they remember events that neither could fully recover alone.

This creates a particular form of intimacy. To be known by someone who has witnessed you across centuries, who holds your history as carefully as their own, is an experience with no short-term equivalent. Frostpaw and Echo do not always agree — their family natures mean they sometimes see the same era from productively different angles. But they trust each other's witnessing completely. When Frostpaw remembers the First Harmony and Echo remembers the same period, they compare notes. What Frostpaw noticed and what Echo noticed are different, and both are necessary.

What the bond also holds is shared grief, differently carried. Echo's Celestialkin nature responds to the Shattering as a wound to possibility — the future that the First Harmony was building, interrupted. Frostpaw's Frostkin nature responds to the Shattering as a wound to the record — the texture of what was lost, and the specific shape of each absence. They have spent the Restoration Era as each other's witness in the act of witnessing. This is not a small thing. To witness the witnesses is to give their work meaning beyond the task itself.

For a Guardian meeting both Echo and Frostpaw, this bond is visible in the particular care they take with each other's observations. They do not complete each other's sentences. They leave space for the other to arrive at their own truth. That is, perhaps, the deepest form of knowing: not finishing the thought, but trusting it will arrive.

---

## 8. The Memory Witness Role

**[Development section — proposals subject to creator review]**

The Archive is the soul of civilization, as the Book of Harmony says. But the Archive is a record of what was written down, and what was written down is only ever a portion of what was true. The Archive cannot hold the felt texture of a room the moment before something important was said. It cannot hold the specific quality of attention a community brought to a shared remembering. It cannot hold the weight of what was present just before it was lost.

Frostpaw can hold all of this.

The Memory Witness role is not an Archive function. It is something older, something that predates the Archive as an institution — the role of the companion whose nature allows them to carry what institutions cannot. During the First Harmony, Frostkin Companions were understood to fill this role explicitly: their testimony was considered a primary source, alongside written records, precisely because they held what written records could not.

In the Restoration Era, this role is more urgent and more fragile. The Archive has gaps. Many of those gaps are not documented — the records of what was lost were themselves lost, as the Wound of Memory's most devastating characteristic makes clear: *what was lost includes the record of what was lost.* Frostpaw knows where some of those gaps are. They can trace the contour of an absence with Frostkin precision and say: something was here. It was about this. It connected to that. I cannot give it back to you, but I can give you the shape of where it was.

What it feels like to receive a Frostpaw memory is difficult to describe, but consistent in what those who have experienced it report. It is not like being told about something. It is not like reading a record. Frostpaw's recollections arrive with context — not performed context, but the actual surrounding conditions: the season, the quality of the light, who else was there, what the room sounded like, what was at stake for the people in it. A Guardian who asks Frostpaw about a historical event does not receive an answer. They receive a moment. They are, briefly, witnessing something that happened centuries before they existed.

This is not magic in the power-framing sense. It is the natural consequence of complete memory offered with care. What Frostpaw gives, they give with full attention. They do not summarize what they remember. They share it. The gift is presence — the presence of a witness who was there, who has carried what they saw without embellishment or distortion, and who trusts the Guardian enough to open it.

---

## 9. Open Questions

These questions are held open deliberately. They should not be answered without creator input and may remain productively unresolved for some time.

1. **The ceremonies around forgetting.** Section 4 proposes that the First Harmony had formal practices for acknowledging irrecoverable losses. Does the creator want to develop these further, or hold them as a Frostpaw-specific memory that surfaces slowly across the Companion Arc narrative?

2. **Frostpaw's relationship to Volume IV of the Book of Harmony.** The Five Wounds document establishes that Volume IV (On Memory) suffered the deepest damage in the Shattering. Does Frostpaw hold fragments of Volume IV that are not in any surviving Archive copy? This could be a powerful narrative thread — handled with care, as it would create a canon gap that needs deliberate resolution.

3. **What Frostpaw cannot remember.** For a Companion whose memory is complete, any gap is significant. Is there anything Frostpaw experienced during the Shattering that they cannot fully access — not lost, but somehow sealed? Or is Frostpaw's complete memory precisely what makes their grief so specific and undiminished?

4. **Frostpaw and the Frozen Expanse's active restoration.** The Expanse has many memories inaccessible in Crystal Network nodes. Is Frostpaw actively guiding Guardian restoration efforts in the Expanse, or are they more of a witness-companion who becomes more directly involved as specific nodes are recovered?

5. **The Echo relationship's narrative arc.** IMP #4 confirms the bond's depth. At what point in the narrative does a Guardian encounter both Frostpaw and Echo together? Is their shared witnessing something players can observe, or is it shared in conversation only?

6. **Frostpaw's equivalent of the First Harmony memory ceremony.** Frostpaw has witnessed the loss of the formal practices for acknowledging loss. Have they maintained any version of these practices alone, in the long years between the Shattering and the Restoration Era? This could be a quietly devastating and quietly hopeful detail.

7. **The Frostkin name.** *Frostpaw* — the name is locked. Does it carry a specific history? Was Frostpaw named during the First Harmony, and does the name itself carry a memory?

---

## 10. Missing Elements Before Encyclopedia Entry

The following elements are required before the Tier 3 Companion Encyclopedia entry for Frostpaw can be written. Items marked **[Blocker]** cannot proceed without creator confirmation.

| Element | Status | Notes |
|---|---|---|
| Individual visual transfer | Missing | Visual confirmed in Companion Collection Preview; individual reference art not yet transferred |
| Frozen Expanse Realm Packet | Missing (Tier 2) | Needed to ground Frostpaw's Expanse-specific memories in confirmed Realm detail |
| IMP #4 full text | Referenced but not fully in canon files | Companion Relationship Web needed to confirm depth and nature of Echo bond |
| Five Wounds full document | ✅ Available | Used in this packet. Wound of Memory confirmed locked. |
| First Harmony document | ✅ Available | Foundational texture used throughout this packet |
| Frostpaw's unique symbol | Missing | All 8 companions require a symbol; not yet established |
| Echo's companion packet | Missing (Work Queue) | Echo's full character needs development before the Frostpaw/Echo bond can be fully written |
| Restoration Era entry (Tier 1.6) | Missing | Needed to confirm operational details of where Frostpaw is placed in the Restoration Era world |
| Volume IV of the Book of Harmony details | Missing | Flagged as a potential Frostpaw narrative thread; needs creator direction before use |
| Crystal Network node restoration mechanics | Missing (Tier 4) | Needed to detail how Frostpaw participates in Frozen Expanse node recovery |
| Frostkin family full entry | Missing | Companion family detail not yet written; this packet draws on confirmed Frostkin nature but full entry will expand |

---

## Review Checklist

- [ ] Does Frostpaw feel like stillness that holds everything it has witnessed — not cold, but preserving? Is the distinction between ice-as-absence and ice-as-preservation clear throughout?
- [ ] Does the Frostkin nature section establish complete memory as weight, not superpower — something to carry, not to wield?
- [ ] Does Frostpaw's personality feel like patience shaped by sorrow, not stoicism for its own sake? Is the warmth visible?
- [ ] Does the First Harmony memory section distinguish between *what* was remembered and *how communities remembered together* — the texture, not just the content?
- [ ] Does the Shattering section make clear that Frostpaw experienced the Forgetting as a felt absence, not just an observed event — and that this is the Frostkin-specific form of the Wound of Memory?
- [ ] Does the Restoration Era section show Frostpaw's work as actively contributing to civilization's healing, not merely grieving what was lost?
- [ ] Does the Frostpaw and Echo section make clear why a Memory/Reflection bond with a Wonder/Hope companion is among the deepest in the ensemble — not despite their family differences, but because of them?
- [ ] Does the Memory Witness Role section distinguish clearly between Archive function (what was recorded) and Frostpaw's function (what was present but unrecordable)?
- [ ] Are all proposals labelled as proposals? Does no section present new canon as locked without creator confirmation?
- [ ] Does Frostpaw feel like GemVerse — hopeful, warm, restorative? Does this companion make GemVerse feel more worth belonging to?
- [ ] Are the Five Wounds, First Harmony, and Restoration Era documents used accurately, without introducing contradictions?
- [ ] Are all open questions genuinely open — not hinting toward a preferred answer — and appropriate for creator resolution?
