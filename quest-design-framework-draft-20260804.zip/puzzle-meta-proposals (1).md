---
title: Puzzle Meta Proposals for GemVerse
author: Perplexity Puzzle Assistant
status: PROPOSAL ONLY
date: 2026-06-02
note: This file contains proposal language and placeholder examples only. It does not add or resolve locked canon.
---

# Puzzle Meta Proposals for GemVerse

## Purpose

This file collects proposal material for extending the existing Puzzle Catalog with:

- A Puzzle Philosophy section
- Multi-layer mapping onto the eight puzzle types
- Cross-realm meta / fractured codex guidance
- A Pattern Registry template
- Example meta threads distributed across the Five Wounds
- Review Checklist additions
- Stop Rule reinforcement notes for power-up and combo-risk areas

All items in this file are **[PROPOSAL]** unless otherwise noted.

---

## 1. Puzzle Philosophy — The World Is the Cipher [PROPOSAL]

In GemVerse, the **world itself is the puzzle**. Every realm, House, symbol, color, artifact, and story should be designed as if it serves at least two purposes at once:

1. Its narrative purpose — what it means to the people and places of GemVerse.
2. Its puzzle purpose — what it reveals when a Guardian reads it as a pattern.

A Guardian examining a realm map, a House crest, a festival banner, or a page of Archive text should never be entirely sure whether they are seeing lore, a clue, or both. The design goal is **hidden consistency**: symbols have stable meanings, realm patterns repeat, House relationships follow quiet rules, and historical events leave measurable traces.

This philosophy extends the Puzzle Design Test: puzzles are not separate from the world; they are **how the world reveals itself**. A great puzzle does not stand between the Guardian and a reward. It transforms understanding.

### Design prompts

- Can this asset be read as both story and code?
- If a Guardian re-examines this artifact after other discoveries, does it reveal more?
- Does solving this puzzle cause a Guardian to reinterpret something they thought they already understood?

---

## 2. Multi-Layer Reading of the Eight Puzzle Types [PROPOSAL]

Each canonical puzzle type can be designed with multiple layers of truth:

- Surface answer — what the Guardian does
- Lore answer — what the Guardian learns
- Symbolic answer — what pattern it reinforces
- Meta answer — how it fits into cross-realm structures

### Crystal Resonance
- Surface: restore node patterns and reconnect signal pathways.
- Lore: discover what knowledge the node carried and who lost access to it.
- Symbolic/meta: repeated node motifs can hint at larger knowledge-distribution structures across realms.

### Pathfinder's Mark
- Surface: reconstruct routes and wayfinding sequences.
- Lore: learn which communities were connected and what was lost when routes failed.
- Symbolic/meta: route geometries and Lantern layouts can encode larger cross-realm patterns.

### Echo Sequence
- Surface: replay memory, symbol, or narrative sequences correctly.
- Lore: receive Companion testimony and first-person memory.
- Symbolic/meta: recurring sequence structures can mirror Book of Harmony or timeline patterns.

### Community Pattern
- Surface: complete collective ritual or festival structures.
- Lore: recover how a community practiced belonging.
- Symbolic/meta: repeated civic motifs can reveal hidden grammars of belonging across realms.

### Verdance Cultivation
- Surface: restore the correct conditions for growth.
- Lore: understand how cultivation, mentoring, and traditions were transmitted.
- Symbolic/meta: garden layouts and growth diagrams can double as network maps for civilizational development.

### Fragment Assembly
- Surface: reassemble damaged or distributed records.
- Lore: recover a record that civilization intentionally tried to preserve.
- Symbolic/meta: fragment distribution itself can become a readable map of absence, memory, or planned redundancy.

### Harmony Alignment
- Surface: balance multiple elements into stable relationship.
- Lore: learn how Harmonists maintained systemic equilibrium.
- Symbolic/meta: repeated balance diagrams can teach the hidden laws of the world.

### Legacy Seal
- Surface: satisfy layered conditions to open a preserved record.
- Lore: receive a high-significance contribution from the past.
- Symbolic/meta: Legacy Seals can act as capstones for multi-realm pattern recognition.

---

## 3. Cross-Realm Meta Reveals and the Fractured Codex [PROPOSAL]

Some reveals should be understood only when multiple realms, puzzle types, and records are viewed together. These are cross-realm meta structures, not single-puzzle answers.

### Principles

- A single puzzle should never deliver a complete meta answer.
- Each local reveal should be meaningful on its own and suggestive at a larger scale.
- Meta structures should be built from stable patterns: recurring symbols, constellation layouts, route geometries, House crest motifs, Harmony diagrams, and Archive cross-references.
- When the pattern spans multiple media, the set functions as a **fractured codex**.

### Tracker usage

- Give every local piece its own Reveal ID.
- Note suspected meta linkage in the Notes field.
- Do not create a final “decoded truth” reveal without explicit creator approval.
- Meta structures may deepen open mysteries but must never resolve them.

### Outcome rule

The highest-tier meta reveals should be revelations, not possessions. They should reframe understanding rather than grant power, loot, or access dominance.

---

## 4. Pattern Registry Template [PROPOSAL]

The Pattern Registry is a working tool for tracking hidden consistencies across puzzles, realms, and documents. It does not define canon by itself.

### Symbol Patterns

| Field | Description |
|---|---|
| Pattern ID | Short code, e.g. PAT-SYM-001 |
| Symbol form | Visual description |
| Known appearances | Where it appears |
| Associated systems | Pillars, Houses, Wounds, puzzle types |
| Working interpretation [PROPOSAL] | One-sentence current guess |
| Notes | Suspected meta links |

### Constellation & Map Patterns

| Field | Description |
|---|---|
| Pattern ID | Short code, e.g. PAT-MAP-002 |
| Layout description | Geometric or spatial arrangement |
| Data sources | Maps, star charts, Lantern diagrams, Harmony layouts |
| Cross-realm link [PROPOSAL] | Which systems it may connect |
| Meta potential | Whether it is intended for a meta thread |

### House & Relationship Patterns

| Field | Description |
|---|---|
| Pattern ID | Short code, e.g. PAT-REL-003 |
| Relationship form | Structural rule |
| Evidence | Specific references |
| Impacted puzzles | Puzzle types using the pattern |
| Open questions | What remains unresolved |

### Registry rules

- All interpretation lines remain **[PROPOSAL]**.
- The registry supports the Reveal Tracker; it does not override it.
- If an interpretation would resolve a named mystery, it does not belong here without creator approval.

---

## 5. Example Meta Threads [PROPOSAL / PLACEHOLDER]

### 5.1 Knowledge / Discovery — The Three Lantern Lines

**Overview:** Three local reveals imply that resilient Lantern infrastructure required multiple independent ways home.

#### Local pieces
- REV-0A1 [PLACEHOLDER] — Crystal Forest / Lantern waypoint: a restored stone records that three Lantern lines once met at a single waystation.
- REV-0A2 [PLACEHOLDER] — Sky Citadel / route ledger: a fragmented route record references “Three Lantern Lines of Return.”
- REV-0A3 [PLACEHOLDER] — Twilight Frontier / Harmony diagram: a border settlement diagram shows three Lantern icons around a central Hearthlight symbol.

#### Meta interpretation [PROPOSAL]
The civilization may have treated “three independent ways home” as a design minimum for resilient route infrastructure.

---

### 5.2 Memory / Knowledge — The Three Broken Citations

**Overview:** Three Archive-related reveals suggest Borealis scholars sometimes left deliberately broken citations to force careful inquiry.

#### Local pieces
- REV-0B1 [PLACEHOLDER] — Arena Realm / reconstructed research record with a surviving citation number but missing title.
- REV-0B2 [PLACEHOLDER] — Frozen Expanse / Companion testimony about Chroniclers intentionally leaving some citations “broken.”
- REV-0B3 [PLACEHOLDER] — Legacy Realm / damaged Volume IV margin note: “If you find three broken citations in the same record, assume the absence is intentional.”

#### Meta interpretation [PROPOSAL]
Some gaps in the Archive may have been designed as ethical prompts rather than mere failures of preservation.

---

### 5.3 Growth — The Verdance Lattice

**Overview:** Cultivation diagrams, apprenticeship rituals, and mentorship ledgers suggest a quiet cross-realm lattice of growth transmission.

#### Local pieces
- REV-0G1 [PLACEHOLDER] — Ember Depths / teaching garden with three rings corresponding to mentors and students.
- REV-0G2 [PLACEHOLDER] — Frozen Expanse / apprenticeship ceremony whose seating arrangement mirrors the same three-ring pattern.
- REV-0G3 [PLACEHOLDER] — Sky Citadel / mentorship registry fragment describing “lattice nodes.”

#### Meta interpretation [PROPOSAL]
Verdance Stewards may have maintained a distributed lattice of learning so growth always exceeded local boundaries.

---

### 5.4 Belonging — The Festival of Echoes

**Overview:** Festival motifs across realms suggest that communities used repeated visual structures to remember belonging even when full attendance was impossible.

#### Local pieces
- REV-0BEL1 [PLACEHOLDER] — Arena Realm / Harmony Week pattern with eight interlocking lantern symbols.
- REV-0BEL2 [PLACEHOLDER] — Twilight Frontier / Companion memory of a half-ring variant used when only four realms were present.
- REV-0BEL3 [PLACEHOLDER] — Celestial Nexus / mural restoration where the lantern ring appears quietly in background festival art.

#### Meta interpretation [PROPOSAL]
Communities may have repeated a shared “all of us belong here” motif even in moments of partial gathering.

#### Belonging safeguard
This thread must never be framed as “solving Belonging.” It only creates the conditions for belonging to be felt.

---

### 5.5 Harmony / Cross-Wound — The Seven Plus One Constellations

**Overview:** Harmony Alignment diagrams suggest a stable visual grammar for seven measured Pillars plus one unmeasured center.

#### Local pieces
- REV-0H1 [PLACEHOLDER] — Celestial Nexus / seven Pillars around an empty center.
- REV-0H2 [PLACEHOLDER] — Arena Realm / civic balance record labeling the center as Belonging (unmeasured).
- REV-0H3 [PLACEHOLDER] — Legacy Realm / fully lit eight-point diagram with a warning that it represents a moment, not completion.

#### Meta interpretation [PROPOSAL]
Harmonists may have used a stable “seven plus one” visual grammar to teach that all systems depend on an unmeasured condition of belonging.

---

## 6. Review Checklist Additions [PROPOSAL]

Add the following to the Puzzle Catalog Review Checklist:

### Pattern & Meta Structure
- [ ] If this puzzle uses a recurring symbol or layout, is it registered in the Pattern Registry?
- [ ] Does the puzzle create local meaning first, with meta meaning only as a second layer?
- [ ] If it participates in a fractured codex structure, are the linked Reveal IDs and Pattern IDs documented?
- [ ] Does the meta implication deepen the world without resolving a named open mystery?
- [ ] If the puzzle references Belonging, is it creating conditions for belonging rather than claiming to solve it?

### Multi-Layer Design
- [ ] Does the puzzle have at least a surface layer and a lore layer?
- [ ] If a symbolic or meta layer exists, is it still understandable for players who never discover it?
- [ ] Does re-examining the puzzle after later discoveries reveal additional meaning?

---

## 7. Stop Rule Reinforcement — Power-Up and Combo Risk Areas [PROPOSAL]

These notes do not change the existing Stop Rules; they strengthen interpretation in light of currently flagged canon risk areas.

### 7.1 Puzzle Tools vs Power Advantages
If a special gem, booster, helper effect, or board-changing mechanic exists, it must answer the Puzzle Design Test independently.

Questions:
- Why does this effect exist in-world?
- Who created it?
- What restorative purpose does it serve?
- What does it reveal about civilization?
- What does it restore besides player advantage?

If the only honest answer is “it helps clear the board faster,” it fails canon-safety review.

### 7.2 Naming guardrail
Names that imply destruction, domination, or power fantasy should be treated as suspect.

Risk examples:
- Bomb
- Blast
- Lightning
- Power-up
- Booster

Safer framing directions may include:
- Resonance
- Alignment
- Recall
- Bridge
- Echo
- Weave
- Restoration

### 7.3 Combo and scoring guardrail
If combo systems remain, they should be framed as restoration flow, resonance continuity, or harmony momentum — not escalating power.

The emotional register must remain:
- understanding
- attunement
- restoration momentum

and not:
- domination
- damage output
- power escalation

### 7.4 Companion safeguard
No mechanic should describe a Companion as something that “helps complete puzzles” in a tool-like sense. Companions may witness, remember, prompt, accompany, or contextualize. They are not instruments.

### 7.5 Belonging safeguard
No mechanic, reward, UI meter, or puzzle resolution may claim to quantify Belonging. Any system that implies Belonging can be filled, maxed, purchased, or solved fails review.

---

## 8. Integration Notes [PROPOSAL]

Recommended placement in the current Puzzle Catalog:

- Section 1: add “Puzzle Philosophy — The World Is the Cipher” after Puzzle Experience Principles.
- Section 2: add “Multi-Layer Reading of the Eight Puzzle Types” after the canon alignment note or as a short appendix reference.
- Section 4: add “Cross-Realm Meta Reveals and the Fractured Codex” and the Pattern Registry template after Tracker Usage Notes.
- Review Checklist: append the checklist additions in Section 6 of this file.
- Section 5: keep the existing Stop Rules, but use Section 7 of this file as interpretation guidance during review.

---

## 9. Final Reminder

This file is a design aid. It is not locked canon. It proposes structures for making GemVerse puzzles feel like revelations embedded in civilization rather than isolated mechanics.
