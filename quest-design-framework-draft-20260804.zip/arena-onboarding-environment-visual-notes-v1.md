# Arena Onboarding & Environment Visual Notes v1

**Project:** GemVerse  
**Mode:** GemVerse Art Studio  
**Scope:** Arena Realm first-arrival visuals, onboarding beats, environment art direction, hub-zone interpretation  
**Status:** Production-safe working notes derived from current Space canon

---

## Purpose

This document translates the Arena Realm canon and production brief into practical visual notes for concept artists, environment artists, UI designers, onboarding designers, and narrative-visual reviewers.

It is designed to protect the Arena Realm's belonging-first identity during first-realm execution.

---

## Core visual principle

**The Arena Realm should feel like civilization kept alive through welcome.**

If a scene feels more like a spectacle space than a cared-for civic place, it is drifting off-canon.

---

## First-arrival sequence

The first-arrival visual rhythm should follow this order:

1. **Lantern first** — a small still-burning Lantern site, intimate and human-scaled.
2. **Keeper second** — the first presence is a person, not architecture.
3. **Evidence of care third** — clear paths, repaired surfaces, use-worn thresholds, maintained greenery.
4. **Archive signal fourth** — the sense that memory and record survive here, even if incomplete.
5. **Scale last** — only after warmth and care are established should the wider civic grandeur appear.

This order should remain stable across splash art, opening concept frames, UI backgrounds, intro sequences, and early environment blockouts.

---

## Emotional hierarchy

The Arena Realm should communicate these feelings in order:

- welcome
- care
- continuity
- shared life
- civic memory
- scale

Not this order:

- spectacle
- dominance
- scale
- challenge
- intimidation
- victory

The Realm earns grandeur through meaning, not through overwhelm.

---

## Environment art rules

### Favor

- Organic architecture integrated with landscape.
- Civic pathways that suggest arrival, crossing, and return.
- Warm lantern light at entries, corners, doors, bridges, and gathering edges.
- Spaces that support conversation, pausing, assembly, and shared presence.
- Surfaces that show maintenance rather than abandonment.
- Signs of previous fullness without implying ruin.
- Moss, roots, crystal traces, wood, stone, and greenery working together rather than competing.

### Avoid

- Coliseum reads.
- Combat bowl silhouettes.
- Fortress massing.
- Triumphal banner staging.
- Throne-room compositions.
- Weapon motifs or shield-like framing.
- Victory avenues, parade-ground geometry, or challenge-gate presentation.
- Anything that makes the Realm look like it must be beaten, cleared, or conquered.

---

## Composition notes

### Good Arena compositions

Good Arena compositions usually include:
- an inviting threshold
- visible route lines
- partial human scale before full spatial scale
- layered depth through civic life cues
- light that gathers rather than spotlights
- architecture that frames people, not power

### Weak Arena compositions

Weak Arena compositions tend to:
- center dominance architecture before lived-in detail
- frame the Hall like a boss destination
- use symmetry in a triumphal or militarized way
- prioritize monument over welcome
- remove the small care details that sell continuity

---

## Hall guidance

The Great Gathering Hall should read as a place built for people to come together, not a place built for one figure to rule from.

Interior or exterior depictions should favor:
- open doors
- approachability
- layered entry points
- alcoves, records, lantern housings, and gathering surfaces
- traces of ongoing use
- scale that feels generous rather than domineering

The Hall should never read like a throne room, stadium, or combat arena.

---

## Hub-zone notes

### Harmony Plaza
A social center, not a ceremonial victory court. Think gathering overflow, everyday meetings, lingering movement, and informal civic life.

### Great Archive
A record-bearing civic presence embedded into the Realm, not an isolated academic monument. It should feel reachable and active, even if incomplete.

### Festival Grounds
A place that remembers fullness. It should feel capable of hosting joy, even when current attendance is smaller than in the First Harmony.

### Companion Grove
A quieter, relational zone that softens the civic core with non-human life, memory, and witness.

### Marketplace
Still active, still local, still connected. It should suggest crossroads energy without becoming noisy chaos.

### Lantern Tower
Vertical emphasis is acceptable here, but it should signal guidance and continuity, not surveillance or dominance.

---

## Kael placement notes

When Kael appears in environment art or onboarding art:

- Place him in relation to maintenance, welcome, movement, records, preparation, or shared space.
- He should look like he belongs to the Realm's daily civic life.
- He should not be staged as a fighter, commander, or lone heroic silhouette.
- His visual power should come from steadiness and presence, not force.

Good Kael activities:
- opening doors
- carrying records
- preparing a gathering space
- speaking with arrivals
- repairing or checking civic details
- standing within shared space rather than above it

---

## UI and card copy direction

Preferred Arena language families:
- gathering
- welcome
- convergence
- shared life
- continuity
- stewardship
- belonging
- civic care
- arrival
- remembrance

Avoid language families:
- strength
- conquest
- clash
- dominance
- battle
- victory
- power
- defeat
- challenge arena
- hero saves all

---

## Safe replacement lines

Use these as starter lines for realm cards, environment labels, and presentation decks:

- Arena Realm — The civic heart of civilization.
- A welcoming crossroads shaped by shared life.
- The first Realm a Guardian enters, where care comes before grandeur.
- A place where civilization remembers itself by gathering.
- A Realm of welcome, continuity, and lived-in hope.

---

## Review checklist

Before approving any Arena visual, ask:

- Does this feel like a place of welcome more than spectacle?
- Is the first emotional read care, not dominance?
- Does the Hall feel civic rather than ceremonial-powerful?
- Would a new viewer mistake this for a combat arena?
- Are there visible signs that someone has been taking care of things?
- Does Kael read as a civic anchor rather than a warrior archetype?
- Is the Realm's scale earned through meaning rather than intimidation?

If any answer trends toward combat, conquest, or spectacle-first reading, return the asset for reframe.

---

## Best immediate uses

This document is ready to support:
- concept art reviews
- environment blockout direction
- onboarding storyboard framing
- UI background selection
- Arena Realm deck cleanup
- Kael placement review in environment scenes

For deeper canon nuance, pair this file with the Arena Realm production brief and the visual framing notes file.
